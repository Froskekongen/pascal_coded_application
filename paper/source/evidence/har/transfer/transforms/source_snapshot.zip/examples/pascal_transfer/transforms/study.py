"""Matched pre-signature transforms and fully nested eight-person DSADS.

All prior experiments are preserved. The fixed menu is an exploratory follow-up
after earlier test inspection; this is not an untouched confirmation cohort.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from itertools import combinations
from pathlib import Path
from time import perf_counter

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
sys.path.insert(0, str(PARENT / "followup"))
import numpy as np
import run as previous
import streams
import torch
from benchmark import metrics, write_csv, write_json
from datasets import DEFAULT_DATA, load_dataset, sha256
from features import spectrum, standardize_axes
from observable_features import build_blocks, scalar_logsignature
from threadpoolctl import threadpool_limits

LAMBDAS = previous.LAMBDAS
PARAMS = [(clip, penalty) for clip in (False, True) for penalty in LAMBDAS]
BASELINES = ("baseline_moments", "baseline_spectral_pool", "baseline_factorized_spectral", "baseline_prior_rich")


def menu(dataset):
    return [*BASELINES, *(["baseline_lagged_mav"] if dataset == "ninapro" else []),
            *streams.model_names(dataset, extra_names=("rms", "waveform_length") if dataset == "ninapro" else ())]


def features(unit, indices, n_train, batch_size):
    signals = unit["signals"][indices]
    blocks, metadata = build_blocks(signals, n_train, unit["dataset"], batch_size)
    for key, source in (("baseline_moments", "moments"), ("baseline_spectral_pool", "spectral_pool")):
        yield key, blocks[source], {"baseline": source, "calibration": metadata}
    z = standardize_axes(torch.as_tensor(signals, dtype=torch.float64), n_train)
    parts = []
    for batch in z.split(batch_size):
        mass, energy, _ = spectrum(batch)
        log = scalar_logsignature(mass * mass.shape[1]).reshape(len(batch), signals.shape[-1], 6)
        log[:, :, 3:] *= np.sqrt(2)
        parts.append(np.column_stack((log.reshape(len(batch), -1), energy.numpy(), energy.log1p().numpy())))
    yield "baseline_factorized_spectral", np.concatenate(parts).astype(np.float32), {"baseline": "Original scalar spectral P3 logs with raw/log energy; same new ridge grid"}
    del z, parts
    rich_keys = previous.POOL + previous.RICH
    rich = np.column_stack([blocks[key] for key in rich_keys])
    yield "baseline_prior_rich", rich, {"baseline": "Prior richest observable feature map, common one-group ridge scaling, clipping validation-tuned; not the prior grouped-gamma selection procedure", "calibration": metadata}
    if unit["dataset"] == "ninapro":
        yield "baseline_lagged_mav", blocks["lagged_mav"], {"baseline": "Same six causal MAV observations"}
    del blocks, rich
    extra = {key: value[indices] for key, value in unit.get("extra_streams", {}).items()}
    yield from streams.iter_features(signals, n_train, unit["dataset"], batch_size, extra_streams=extra or None)


def with_duration(unit, indices, values):
    return np.column_stack((values, unit["auxiliary"][indices])) if "auxiliary" in unit else values


def design(values, n_train):
    """One training fit; clipped and plain queries share its Gram matrix."""
    values = np.asarray(values, float)
    train, query = values[:n_train], values[n_train:]
    keep = train.std(0) > 1e-6 * np.abs(train).max(0)
    a, b = train[:, keep], query[:, keep]
    if not keep.any():
        return a, b, b.copy()
    center, scale = a.mean(0), a.std(0) * np.sqrt(keep.sum())
    return ((a-center)/scale, (b-center)/scale,
            (np.clip(b, a.min(0), a.max(0))-center)/scale)


def grid_predictions(values, n_train, fit_y, classification):
    x, z, clipped = design(values, n_train)
    predictions = previous.ridge_grid(x, fit_y, np.concatenate((z, clipped)), LAMBDAS, classification)
    return [p[:len(z)] for p in predictions] + [p[len(z):] for p in predictions]


def loss(y, prediction, classification):
    return float((y != prediction).sum()) if classification else float(np.square(y.reshape(prediction.shape)-prediction).sum()/prediction.shape[1])


def select(scores, count, names):
    selected = {}
    for model in names:
        losses = scores[model]
        threshold = min(losses) + 1e-10 * max(1., abs(min(losses)))
        index = max((i for i, v in enumerate(losses) if v <= threshold), key=lambda i: (PARAMS[i][1], -PARAMS[i][0]))
        clip, penalty = PARAMS[index]
        selected[model] = {"parameter_index": index, "clipped": clip, "penalty": previous.finite(penalty), "validation_loss": float(losses[index]/count)}
    winner = min(names, key=lambda key: selected[key]["validation_loss"])
    return {"winner": winner, "models": selected, "n_validation": count}


def protocol(unit, train, test, folds):
    sources = [HERE/"study.py", HERE/"streams.py", HERE/"emg_observations.py",
               PARENT/"followup/run.py", PARENT/"followup/observable_features.py",
               PARENT/"features.py", PARENT/"datasets.py", PARENT/"regression_datasets.py",
               PARENT.parent/"uci_har/retained_features.py"]
    return {"unit": unit["name"], "dataset": unit["dataset"], "classification": unit["classification"],
            "models": menu(unit["dataset"]), "parameters": [[c, previous.finite(p)] for c,p in PARAMS],
            "train_indices": train.tolist(), "test_indices": test.tolist(),
            "folds": [{"train": a.tolist(), "validation": b.tolist()} for a,b in folds],
            "data": unit["metadata"],
            "head": "Train column scaling and /sqrt(retained width); mean-SSE ridge with free intercept; optional train-range query clipping; largest lambda then unclipped tie; first family for exact family tie",
            "source_sha256": {str(p.relative_to(PARENT.parent)): sha256(p) for p in sources},
            "exploratory": "New menu fixed before outcomes; reused cohorts after prior test inspection, no untouched confirmation claim"}


def fit_final(unit, train, test, choices, output, batch_size):
    y = unit["labels"] if unit["classification"] else unit["target"]
    indices = np.r_[train, test]
    rows = []
    saved = {"target": y[test], "test_indices": test, "train_indices": train}
    for name, values, metadata in features(unit, indices, len(train), batch_size):
        values = with_duration(unit, indices, values)
        x, z, zclip = design(values, len(train))
        choice = choices["models"][name]
        clip, penalty = PARAMS[choice["parameter_index"]]
        prediction = previous.ridge_grid(x, y[train], zclip if clip else z, [penalty], unit["classification"])[0]
        saved[name] = prediction
        row = {"dataset": unit["dataset"], "unit": unit["name"], "model": name, "selected": name == choices["winner"],
               "clipped": clip, "penalty": previous.finite(penalty), "features": x.shape[1],
               "validation_loss": choice["validation_loss"], **metrics(y[test], prediction, unit["classification"])}
        rows.append(row)
        write_json(output/f"feature_{name}.json", metadata)
        print(f"FINAL {unit['name']} {name}: {row}", flush=True)
    np.savez_compressed(output/"predictions.npz", **saved)
    write_csv(output/"results.csv", rows)
    return rows


def regular_unit(unit, output, batch_size):
    output.mkdir(parents=True, exist_ok=False)
    tick = perf_counter()
    train, test = unit["train"], unit["test"]
    folds = unit.get("inner_folds", [(train, unit.get("validation"))])
    y = unit["labels"] if unit["classification"] else unit["target"]
    names = menu(unit["dataset"])
    write_json(output/"protocol.json", protocol(unit, train, test, folds))
    scores = {key: np.zeros(len(PARAMS)) for key in names}
    rows, count = [], 0
    for fold, (fit, validation) in enumerate(folds):
        if np.intersect1d(fit, validation).size or np.intersect1d(np.r_[fit,validation],test).size:
            raise ValueError("Split overlap")
        indices = np.r_[fit, validation]
        seen = []
        for name, values, metadata in features(unit, indices, len(fit), batch_size):
            values = with_duration(unit, indices, values)
            predictions = grid_predictions(values, len(fit), y[fit], unit["classification"])
            for i, (prediction, (clip, penalty)) in enumerate(zip(predictions, PARAMS)):
                v = loss(y[validation], prediction, unit["classification"])
                scores[name][i] += v
                rows.append({"fold": fold, "model": name, "clipped": clip, "penalty": previous.finite(penalty), "loss_sum": v, "n": len(validation)})
            seen.append(name)
            print(f"GRID {unit['name']} fold{fold} {name}", flush=True)
        assert seen == names
        count += len(validation)
    choices = select(scores, count, names)
    write_json(output/"selection.json", choices)
    write_csv(output/"grid.csv", rows)
    fit_final(unit, train, test, choices, output, batch_size)
    write_json(output/"run.json", {"complete": True, "wall_s": perf_counter()-tick})


def dsads_nested(unit, output, batch_size, resume=False):
    """28 shared six-person fits supply 56 distinct inner validation folds.

    The two excluded people share the same training calibration. Predictions
    for b update only the selector whose outer test person is a, and vice versa.
    Neither excluded person's data fit any transformation or ridge coefficient.
    All eight selections are persisted before any seven-person outer refit.
    """
    output.mkdir(parents=True, exist_ok=resume)
    tick = perf_counter()
    names, people = menu("dsads"), np.unique(unit["subjects"])
    if not np.array_equal(people, np.arange(1,9)):
        raise ValueError("Expected all eight DSADS people")
    y, groups = unit["labels"], unit["subjects"]
    ids = np.arange(len(y))
    specs = {}
    for person in people:
        train, test = ids[groups != person], ids[groups == person]
        folds = [(train[groups[train] != p], train[groups[train] == p]) for p in people if p != person]
        own = {**unit, "name": f"dsads_person{person}"}
        specs[int(person)] = (own, train, test, folds)
        folder = output/f"person{person}"
        folder.mkdir(exist_ok=resume)
        value = protocol(own, train, test, folds)
        if (folder/"protocol.json").exists():
            if json.loads((folder/"protocol.json").read_text()) != value:
                raise ValueError("Resume sources or protocol changed")
        else:
            write_json(folder/"protocol.json", value)
    for a,b in combinations(people,2):
        pair = output/f"inner_exclude{a}_{b}.csv"
        if resume and pair.exists():
            continue
        fit = ids[(groups != a)&(groups != b)]
        va, vb = ids[groups == a], ids[groups == b]
        indices = np.r_[fit, va, vb]
        rows, seen = [], []
        start = perf_counter()
        for name, values, metadata in features(unit, indices, len(fit), batch_size):
            predictions = grid_predictions(values, len(fit), y[fit], True)
            for i,(prediction,(clip,penalty)) in enumerate(zip(predictions,PARAMS)):
                for outer, held, actual, pred in ((b,a,y[va],prediction[:len(va)]),(a,b,y[vb],prediction[len(va):])):
                    rows.append({"outer_person": int(outer), "validation_person": int(held), "model": name, "clipped": clip,
                                 "penalty": previous.finite(penalty), "parameter_index": i,
                                 "loss_sum": loss(actual,pred,True), "n": len(pred)})
            seen.append(name)
            print(f"DSADS exclude{a},{b} {name} {perf_counter()-start:.1f}s", flush=True)
        assert seen == names
        temporary = pair.with_suffix(".tmp")
        write_csv(temporary, rows)
        temporary.replace(pair)
    import csv
    scores = {int(person): {name: np.zeros(len(PARAMS)) for name in names} for person in people}
    all_rows = []
    for a,b in combinations(people,2):
        with (output/f"inner_exclude{a}_{b}.csv").open() as stream:
            pair_rows = list(csv.DictReader(stream))
            expected = {(int(outer),int(held),name,i) for outer,held in ((a,b),(b,a)) for name in names for i in range(len(PARAMS))}
            actual = {(int(r["outer_person"]),int(r["validation_person"]),r["model"],int(r["parameter_index"])) for r in pair_rows}
            if len(pair_rows) != len(expected) or actual != expected:
                raise ValueError(f"Incomplete cached inner grid for {a},{b}")
            for row in pair_rows:
                scores[int(row["outer_person"])][row["model"]][int(row["parameter_index"])] += float(row["loss_sum"])
                all_rows.append(row)
    selections = {p: select(v,7*1140,names) for p,v in scores.items()}
    for person, choice in selections.items():
        folder = output/f"person{person}"
        write_json(folder/"selection.json",choice)
        write_csv(folder/"grid.csv",[r for r in all_rows if int(r["outer_person"]) == person])
    write_json(output/"selections_before_outer_testing.json", selections)
    for person,(own,train,test,folds) in specs.items():
        folder = output/f"person{person}"
        if resume and (folder/"run.json").exists():
            continue
        local_start = perf_counter()
        fit_final(own,train,test,selections[person],folder,batch_size)
        write_json(folder/"run.json",{"complete":True,"wall_s":perf_counter()-local_start})
    write_json(output/"run.json",{"complete":True,"wall_s":perf_counter()-tick,"inner_calibrations":28,"inner_validation_folds":56,"outer_refits":8})


def get_units(dataset, data):
    if dataset in ("kimore", "ninapro"):
        from regression_datasets import kimore_units, ninapro_units
        units = (kimore_units if dataset == "kimore" else ninapro_units)(data/dataset)
        if dataset == "ninapro":
            cache = np.load(data/"ninapro/emg_observations.npz")
            np.testing.assert_array_equal(cache["target"], units[0]["target"])
            np.testing.assert_allclose(cache["current_window_mav"], units[0]["signals"][:,-1], atol=1e-12, rtol=1e-6)
            extra = {key:cache[key] for key in ("rms","waveform_length")}
            for unit in units:
                unit["extra_streams"] = extra
                unit["metadata"]["raw_descriptor_cache_sha256"] = sha256(data/"ninapro/emg_observations.npz")
        return units
    if dataset == "uci_har":
        return [previous.uci_unit(data)]
    unit = load_dataset(dataset,data)
    unit.update(dataset=dataset,classification=True)
    return [unit]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--datasets", nargs="+", default=["dsads","ninapro","natops","utd_mhad","kimore","uci_har"])
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA)
    parser.add_argument("--output", type=Path, default=HERE/"results")
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        for dataset in args.datasets:
            for unit in get_units(dataset,args.data):
                folder = args.output/unit["name"]
                if dataset == "dsads":
                    dsads_nested(unit,folder,args.batch_size,args.resume)
                elif args.resume and (folder/"run.json").exists():
                    continue
                else:
                    regular_unit(unit,folder,args.batch_size)


if __name__ == "__main__":
    main()
