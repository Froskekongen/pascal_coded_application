"""Training-only selection of observable-first transfers from UCI HAR.

This is a declared follow-up after inspecting the original transfer results.
Old datasets, splits and outcomes are retained; only DSADS selection changes.
"""
from __future__ import annotations

import argparse
import importlib.util
import os
import platform
import sys
from pathlib import Path
from time import perf_counter

os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
sys.path.insert(0, str(PARENT))

import numpy as np
import scipy.linalg
import torch
from benchmark import metrics, write_csv, write_json
from datasets import DEFAULT_DATA, load_dataset, sha256
from observable_features import build_blocks
from sklearn.model_selection import GroupKFold
from threadpoolctl import threadpool_limits

LAMBDAS = tuple(10. ** k for k in range(-8, 3)) + (float("inf"),)
GAMMAS = (0., .1, 1.)
# Each extra is standardized separately from the base, then divided by sqrt(d).
# Gamma is applied AFTER this scaling; zero nests the base exactly.
POOL = ("moments", "spectral_pool")
GO = ("geometry", "occupation")
RICH = GO + ("pascal_bounded", "events_state", "spectral_bounded")
MODELS = {
    "moments": (("moments",), (), False),
    "spectral_pool": (("spectral_pool",), (), False),
    "pool": (POOL, (), False),
    "pool_geometry": (POOL, ("geometry",), False),
    "pool_occupation": (POOL, ("occupation",), False),
    "pool_geometry_occupation": (POOL, GO, False),
    "pool_raw_local": (POOL, GO + ("pascal_unbounded",), False),
    "pool_bounded_local": (POOL, GO + ("pascal_bounded",), False),
    "pool_static_events": (POOL, GO + ("events_static",), False),
    "pool_stateful_events": (POOL, GO + ("events_state",), False),
    "pool_bounded_stateful": (POOL, GO + ("pascal_bounded", "events_state"), False),
    "pool_bounded_stateful_spectral": (POOL, RICH, False),
    "moments_clipped": (("moments",), (), True),
    "pool_clipped": (POOL, (), True),
    "pool_bounded_stateful_spectral_clipped": (POOL, RICH, True),
}
NINA_MODELS = {
    "lagged_mav": (("lagged_mav",), (), False),
    "lagged_mav_all": (("lagged_mav",), RICH, False),
    "lagged_mav_emg_spectral": (("lagged_mav",), ("emg_spectral",), False),
    "lagged_mav_clipped": (("lagged_mav",), (), True),
}


def finite(value):
    return "infinity" if np.isinf(value) else float(value)


def model_menu(dataset):
    return {**MODELS, **(NINA_MODELS if dataset == "ninapro" else {})}


def standardize(train, query, clipped=False):
    """Training constants, scale, optional hinge box, and width normalization."""
    train, query = np.asarray(train, float), np.asarray(query, float)
    keep = train.std(0) > 1e-6 * np.abs(train).max(0)
    a, b = train[:, keep], query[:, keep]
    if not keep.any():
        return a, b
    if clipped:
        b = np.clip(b, a.min(0), a.max(0))
    mean, scale = a.mean(0), a.std(0)
    scale *= np.sqrt(keep.sum())
    return (a - mean) / scale, (b - mean) / scale


def encoded(blocks, n_train, spec):
    base, extra, clipped = spec
    b = np.column_stack([blocks[key] for key in base])
    if "duration" in blocks:
        b = np.column_stack((b, blocks["duration"]))
    bx, bz = standardize(b[:n_train], b[n_train:], clipped)
    if extra:
        e = np.column_stack([blocks[key] for key in extra])
        ex, ez = standardize(e[:n_train], e[n_train:], clipped)
    else:
        ex, ez = np.empty((n_train, 0)), np.empty((len(bz), 0))
    return bx, bz, ex, ez


def ridge_grid(x, y, z, penalties, classification):
    """Already centered/scaled design; mean-SSE ridge with free intercept."""
    classes = np.unique(y) if classification else None
    target = 2. * (y[:, None] == classes) - 1. if classification else np.asarray(y).reshape(len(y), -1)
    intercept = target.mean(0)
    rhs = target - intercept
    dual = len(x) < x.shape[1]
    gram = x @ x.T if dual else x.T @ x
    rhs = rhs if dual else x.T @ rhs
    basis = z @ x.T if dual else z
    if len(penalties) > 1 and gram.size:
        eigenvalues, vectors = scipy.linalg.eigh(gram, driver="evd", check_finite=False, overwrite_a=True)
        if eigenvalues.min() < -1e-8 * max(1., eigenvalues.max()):
            raise ArithmeticError("Indefinite ridge Gram matrix")
        eigenvalues = np.maximum(eigenvalues, 0.)
        basis, rhs = basis @ vectors, vectors.T @ rhs
    result = []
    for penalty in penalties:
        if np.isinf(penalty) or not gram.size:
            pred = np.broadcast_to(intercept, (len(z), len(intercept))).copy()
        elif len(penalties) == 1:
            gram.flat[::len(gram) + 1] += len(x) * penalty
            pred = basis @ np.linalg.solve(gram, rhs) + intercept
        else:
            pred = basis @ (rhs / (eigenvalues[:, None] + len(x) * penalty)) + intercept
        if not np.isfinite(pred).all():
            raise ArithmeticError("Nonfinite ridge prediction")
        result.append(classes[pred.argmax(1)] if classification else pred)
    return result


def make_blocks(unit, indices, n_train, batch_size):
    blocks, metadata = build_blocks(unit["signals"][indices], n_train, unit["dataset"], batch_size)
    if "auxiliary" in unit:
        blocks["duration"] = np.asarray(unit["auxiliary"])[indices]
    if "emg_spectral" in unit:
        blocks["emg_spectral"] = unit["emg_spectral"][indices]
    return blocks, metadata


def candidates(spec):
    return [(g, p) for g in (GAMMAS if spec[1] else (0.,)) for p in LAMBDAS]


def validation_fold(blocks, n_train, fit_y, val_y, menu, classification):
    result, cache = {}, {}
    for model, spec in menu.items():
        tick = perf_counter()
        bx, bz, ex, ez = encoded(blocks, n_train, spec)
        losses = []
        for gamma in GAMMAS if spec[1] else (0.,):
            cache_key = (spec[0], spec[2])
            if gamma == 0. and cache_key in cache:
                predictions = cache[cache_key]
            else:
                x = np.column_stack((bx, gamma * ex)) if gamma else bx
                z = np.column_stack((bz, gamma * ez)) if gamma else bz
                predictions = ridge_grid(x, fit_y, z, LAMBDAS, classification)
                if gamma == 0.:
                    cache[cache_key] = predictions
            for pred in predictions:
                losses.append(float((pred != val_y).sum()) if classification else
                              float(np.square(pred - val_y.reshape(pred.shape)).sum() / pred.shape[1]))
        result[model] = losses
        print(f"  {model}: grid {perf_counter()-tick:.1f}s", flush=True)
    return result


def choices_from_scores(scores, count, menu):
    selected = {}
    for model, losses in scores.items():
        params = candidates(menu[model])
        best = min(losses)
        tol = 1e-10 * max(1., abs(best))
        indices = [i for i, loss in enumerate(losses) if loss <= best + tol]
        index = max(indices, key=lambda i: (params[i][1], -params[i][0]))
        gamma, penalty = params[index]
        selected[model] = {"index": index, "gamma": gamma, "penalty": finite(penalty),
                           "validation_loss": float(losses[index] / count)}
    winner = min(menu, key=lambda model: selected[model]["validation_loss"])
    return {"winner": winner, "models": selected, "validation_count": count}


def run_unit(unit, output, batch_size):
    output.mkdir(parents=True, exist_ok=False)
    started = perf_counter()
    classification, name, dataset = unit["classification"], unit["name"], unit["dataset"]
    target = unit["labels"] if classification else unit["target"]
    train, test = unit["train"], unit["test"]
    folds = unit.get("inner_folds", [(train, unit.get("validation"))])
    if dataset == "dsads":
        subjects = unit["subjects"]
        folds = [(train[subjects[train] != s], train[subjects[train] == s]) for s in np.unique(subjects[train])]
    menu = model_menu(dataset)
    source_paths = [HERE / "run.py", HERE / "observable_features.py", HERE / "emg_spectrum.py",
                    PARENT / "datasets.py", PARENT / "regression_datasets.py", PARENT / "features.py",
                    PARENT / "benchmark.py", PARENT.parent / "uci_har/retained_features.py"]
    protocol = {"dataset": dataset, "unit": name, "classification": classification,
                "models": menu, "lambdas": list(map(finite, LAMBDAS)), "gammas": GAMMAS,
                "readout": "train standardization; base and extra each /sqrt(retained width); extra *gamma; mean SSE + lambda||W||²; free intercept",
                "ties": "lowest loss within 1e-10 relative; highest lambda then smallest gamma; first model for family tie",
                "clipped": "query coordinates projected to training min/max BEFORE standardization; fit unchanged",
                "train_indices": train.tolist(), "test_indices": test.tolist(),
                "folds": [{"train": a.tolist(), "validation": b.tolist()} for a, b in folds],
                "metadata": unit["metadata"],
                "source_sha256": {str(p.relative_to(PARENT.parent)): sha256(p) for p in source_paths},
                "exploratory": "Feature families fixed before new scores, but designed after inspecting original tests; no untouched-confirmation claim"}
    write_json(output / "protocol.json", protocol)
    scores = {key: np.zeros(len(candidates(spec))) for key, spec in menu.items()}
    count, grid = 0, []
    for fold, (fit, validation) in enumerate(folds):
        if np.intersect1d(fit, validation).size or np.intersect1d(np.r_[fit, validation], test).size:
            raise ValueError("Split leakage")
        print(f"{name}: fold {fold+1}/{len(folds)}, {len(fit)} train/{len(validation)} validation", flush=True)
        blocks, metadata = make_blocks(unit, np.r_[fit, validation], len(fit), batch_size)
        write_json(output / f"features_fold{fold}.json", metadata)
        losses = validation_fold(blocks, len(fit), target[fit], target[validation], menu, classification)
        for model, values in losses.items():
            scores[model] += values
            for (gamma, penalty), loss in zip(candidates(menu[model]), values):
                grid.append({"selector": "primary", "fold": fold, "model": model, "gamma": gamma,
                             "penalty": finite(penalty), "loss_sum": loss, "n": len(validation)})
        count += len(validation)
        del blocks
    selections = {"primary": choices_from_scores(scores, count, menu)}
    if dataset == "dsads":
        validation = unit["validation"]
        blocks, metadata = make_blocks(unit, np.r_[train, validation], len(train), batch_size)
        losses = validation_fold(blocks, len(train), target[train], target[validation], menu, classification)
        selections["subject7"] = choices_from_scores(losses, len(validation), menu)
        for model, values in losses.items():
            for (gamma, penalty), loss in zip(candidates(menu[model]), values):
                grid.append({"selector": "subject7", "fold": 0, "model": model, "gamma": gamma,
                             "penalty": finite(penalty), "loss_sum": loss, "n": len(validation)})
        del blocks
    # Both DSADS selectors are frozen here, before any p8 feature extraction.
    write_json(output / "selection.json", selections)
    write_csv(output / "grid.csv", grid)
    query = np.r_[unit["validation"], test] if dataset == "dsads" else test
    blocks, metadata = make_blocks(unit, np.r_[train, query], len(train), batch_size)
    write_json(output / "features_final.json", metadata)
    rows, saved = [], {"target": target[test], "test_indices": test, "train_indices": train}
    if dataset == "dsads":
        saved.update(subject7_target=target[unit["validation"]], subject7_indices=unit["validation"])
    for selector, selection in selections.items():
        for model, choice in selection["models"].items():
            tick = perf_counter()
            bx, bz, ex, ez = encoded(blocks, len(train), menu[model])
            gamma, penalty = candidates(menu[model])[choice["index"]]
            x = np.column_stack((bx, gamma * ex)) if gamma else bx
            z = np.column_stack((bz, gamma * ez)) if gamma else bz
            pred = ridge_grid(x, target[train], z, [penalty], classification)[0]
            if dataset == "dsads":
                saved[f"{selector}__{model}__subject7"] = pred[:-len(test)]
                pred = pred[-len(test):]
            saved[f"{selector}__{model}"] = pred
            row = {"dataset": dataset, "unit": name, "selector": selector, "model": model,
                   "selected": model == selection["winner"], "gamma": gamma, "penalty": finite(penalty),
                   "features": x.shape[1], "validation_loss": choice["validation_loss"],
                   **metrics(target[test], pred, classification), "fit_predict_s": perf_counter()-tick}
            rows.append(row)
            print(f"{name} {selector}/{model}: {metrics(target[test], pred, classification)}", flush=True)
    np.savez_compressed(output / "predictions.npz", **saved)
    write_csv(output / "results.csv", rows)
    write_json(output / "run.json", {"wall_s": perf_counter()-started, "complete": True,
                                      "python": platform.python_version(), "numpy": np.__version__,
                                      "torch": torch.__version__, "threads": 1})
    return rows


def uci_unit(data):
    spec = importlib.util.spec_from_file_location("har_data_loader", PARENT.parent / "uci_har/benchmark.py")
    loader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loader)
    source = data / "uci_har.zip"
    values = loader.load_data(source)
    n = len(values["train"]["signals"])
    x = np.concatenate([values[s]["signals"] for s in ("train", "test")])
    y = np.concatenate([values[s]["labels"] for s in ("train", "test")])
    groups = np.concatenate([values[s]["subjects"] for s in ("train", "test")])
    folds = list(GroupKFold(5).split(x[:n], y[:n], groups[:n]))
    return {"name": "uci_har", "dataset": "uci_har", "classification": True, "signals": x, "labels": y, "subjects": groups,
                "train": np.arange(n), "test": np.arange(n, len(x)), "inner_folds": folds,
                "metadata": {"source_url": loader.DATA_URL, "source_sha256": sha256(source),
                          "protocol": "Official7352/2947 subject split; five GroupKFold training-subject validation folds; all9 raw signal channels"}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--datasets", nargs="+", default=["natops", "utd_mhad", "dsads", "kimore", "ninapro", "uci_har"])
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA)
    parser.add_argument("--output", type=Path, default=HERE / "results")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        for dataset in args.datasets:
            if dataset in ("kimore", "ninapro"):
                from regression_datasets import kimore_units, ninapro_units
                units = (kimore_units if dataset == "kimore" else ninapro_units)(args.data / dataset)
                if dataset == "ninapro":
                    cache = np.load(args.data / "ninapro/emg_spectrum.npz")
                    np.testing.assert_allclose(cache["target"], units[0]["target"], rtol=0, atol=0)
                    np.testing.assert_allclose(cache["current_window_mav"], units[0]["signals"][:, -1], rtol=1e-6, atol=1e-12)
                    extra = np.column_stack((cache["emg_mass_log"], cache["log1p_energy"]))
                    for unit in units:
                        unit["emg_spectral"] = extra
            elif dataset == "uci_har":
                units = [uci_unit(args.data)]
            else:
                unit = load_dataset(dataset, args.data)
                unit.update(dataset=dataset, classification=True)
                units = [unit]
            for unit in units:
                out = args.output / unit["name"]
                if args.resume and (out / "run.json").exists():
                    continue
                run_unit(unit, out, args.batch_size)


if __name__ == "__main__":
    main()
