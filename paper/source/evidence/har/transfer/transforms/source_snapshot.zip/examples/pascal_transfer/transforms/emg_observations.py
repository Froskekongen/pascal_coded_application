"""Causal raw-EMG RMS and mean absolute difference at existing MAV endpoints."""

from __future__ import annotations

import argparse
import json
import sys
from itertools import pairwise
from pathlib import Path

import numpy as np
import torch
from scipy.io import loadmat, whosmat
from threadpoolctl import threadpool_limits

HERE = Path(__file__).resolve().parent
TRANSFER = HERE.parent
sys.path.insert(0, str(TRANSFER))
from regression_datasets import SIBLING, _loader, _sha256


def cumulative(x):
    return np.vstack((np.zeros((1, x.shape[1])), np.cumsum(x, axis=0, dtype=np.float64)))


def extract(data_dir, output, verification):
    if output.exists() or verification.exists():
        raise FileExistsError("Refusing to replace an existing observation cache or audit")
    loader, source = _loader("ninapro", SIBLING)
    width, step, history = loader.MAV_SAMPLES, loader.STEP_SAMPLES, loader.HISTORY
    assert (width, step, history) == (256, 100, 6)
    names = ("rms", "waveform_length", "target", "current_window_mav", "acquisition",
             "movement", "repetition", "history_window_end_exclusive", "history_start",
             "current_window_end_exclusive")
    arrays, checks = {name: [] for name in names}, []
    rng = np.random.default_rng(20261013)
    old_spectrum = np.load(data_dir / "emg_spectrum.npz")
    offset = 0
    for acquisition in (1, 2, 3):
        path = data_dir / f"S1_E1_A{acquisition}.mat"
        spelling = {name.lower(): name for name, _, _ in whosmat(path)}
        required = ("emg", "glove", "restimulus", "rerepetition")
        data = loadmat(path, variable_names=[spelling[name] for name in required])
        emg, glove, motion, repetition = (data[spelling[name]] for name in required)
        motion, repetition = motion.ravel(), repetition.ravel()
        old_x, old_y, old_reps, old_motion = loader.windows_from_arrays(emg, glove, motion, repetition)
        boundaries = np.r_[0, np.flatnonzero((np.diff(motion) != 0) | (np.diff(repetition) != 0)) + 1, len(emg)]
        trial = {name: [] for name in names if name != "acquisition"}
        all_mav, checked_starts, checked_stops = [], [], []
        for start, stop in pairwise(boundaries):
            if motion[start] == 0 or repetition[start] == 0:
                continue
            endpoints = np.arange(width, stop - start + 1, step)
            if len(endpoints) < history:
                continue
            raw = np.asarray(emg[start:stop], dtype=np.float64)
            squared = cumulative(np.square(raw))
            differences = cumulative(np.abs(np.diff(raw, axis=0)))
            absolute = cumulative(np.abs(raw))
            target_sum = cumulative(glove[start:stop])
            rms = np.sqrt(np.maximum((squared[endpoints] - squared[endpoints - width]) / width, 0))
            # Difference j joins raw[j] to raw[j+1]. No edge across a trial or window boundary.
            waveform = (differences[endpoints - 1] - differences[endpoints - width]) / (width - 1)
            mav = (absolute[endpoints] - absolute[endpoints - width]) / width
            target = (target_sum[endpoints] - target_sum[endpoints - width]) / width
            chosen = np.arange(history - 1, len(endpoints))
            history_indices = chosen[:, None] - np.arange(history - 1, -1, -1)
            ends = start + endpoints[history_indices]
            trial["rms"].append(rms[history_indices])
            trial["waveform_length"].append(waveform[history_indices])
            trial["target"].append(target[chosen])
            trial["current_window_mav"].append(mav[chosen])
            trial["movement"].append(np.full(len(chosen), int(motion[start]), dtype=np.int64))
            trial["repetition"].append(np.full(len(chosen), int(repetition[start]), dtype=np.int64))
            trial["history_window_end_exclusive"].append(ends)
            trial["history_start"].append(ends[:, 0] - width)
            trial["current_window_end_exclusive"].append(ends[:, -1])
            all_mav.append(mav[history_indices])
            checked_starts.extend([start] * len(chosen))
            checked_stops.extend([stop] * len(chosen))
        trial = {key: np.concatenate(values) for key, values in trial.items()}
        n = len(old_x)
        np.testing.assert_array_equal(np.concatenate(all_mav), old_x.numpy())
        np.testing.assert_array_equal(trial["target"], old_y.numpy())
        np.testing.assert_array_equal(trial["movement"], old_motion.numpy())
        np.testing.assert_array_equal(trial["repetition"], old_reps.numpy())
        np.testing.assert_array_equal(trial["current_window_end_exclusive"], old_spectrum["window_end_exclusive"][offset:offset + n])
        np.testing.assert_array_equal(trial["target"], old_spectrum["target"][offset:offset + n])
        ends = trial["history_window_end_exclusive"]
        assert np.all(ends[:, 0] - width >= np.asarray(checked_starts))
        assert np.all(ends[:, -1] <= np.asarray(checked_stops))
        assert np.all(ends[:, -1] - trial["history_start"] == 756)
        assert np.all(np.diff(ends, axis=1) == step)
        maximum_rms, maximum_waveform, maximum_target = 0., 0., 0.
        selected = np.unique(np.r_[0, n - 1, rng.choice(n, 16, replace=False)])
        for row in selected:
            for position, end in enumerate(ends[row]):
                raw = np.asarray(emg[end - width:end], dtype=np.float64)
                direct_rms = np.sqrt(np.mean(np.square(raw), axis=0))
                direct_waveform = np.mean(np.abs(np.diff(raw, axis=0)), axis=0)
                np.testing.assert_allclose(trial["rms"][row, position], direct_rms, rtol=1e-10, atol=1e-14)
                np.testing.assert_allclose(trial["waveform_length"][row, position], direct_waveform, rtol=1e-10, atol=1e-14)
                maximum_rms = max(maximum_rms, float(np.max(np.abs(trial["rms"][row, position] - direct_rms))))
                maximum_waveform = max(maximum_waveform, float(np.max(np.abs(trial["waveform_length"][row, position] - direct_waveform))))
            end = ends[row, -1]
            direct_target = np.mean(glove[end - width:end], axis=0, dtype=np.float64)
            np.testing.assert_allclose(trial["target"][row], direct_target, rtol=1e-10, atol=1e-9)
            maximum_target = max(maximum_target, float(np.max(np.abs(trial["target"][row] - direct_target))))
        for key, values in trial.items():
            arrays[key].append(values)
        arrays["acquisition"].append(np.full(n, acquisition, dtype=np.int64))
        checks.append({"acquisition": acquisition, "windows": n, "source_file": path.name,
                       "source_sha256": _sha256(path), "all_six_mav_vectors_exact": True,
                       "targets_and_trial_labels_exact": True, "all_history_support_inside_trial": True,
                       "manual_histories_checked": selected.tolist(), "manual_raw_windows": len(selected) * history,
                       "maximum_manual_rms_absolute_difference": maximum_rms,
                       "maximum_manual_waveform_length_absolute_difference": maximum_waveform,
                       "maximum_manual_target_absolute_difference": maximum_target})
        offset += n
        print(f"A{acquisition}: {n} aligned six-descriptor histories, direct formulas checked", flush=True)
        del data, emg, glove, motion, repetition, old_x, old_y, trial
    arrays = {key: np.concatenate(values) for key, values in arrays.items()}
    assert arrays["rms"].shape == arrays["waveform_length"].shape == (22072, 6, 16)
    assert all(np.isfinite(values).all() for values in arrays.values())
    assert (arrays["rms"] >= 0).all() and (arrays["waveform_length"] >= 0).all()
    for key in ("acquisition", "movement", "repetition"):
        np.testing.assert_array_equal(arrays[key], old_spectrum[key])
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(output, **arrays)
    report = {"status": "passed", "cache": str(output.resolve()), "cache_sha256": _sha256(output),
              "extractor_sha256": _sha256(Path(__file__)), **source,
              "reference_spectrum_cache_sha256": _sha256(data_dir / "emg_spectrum.npz"),
              "definitions": {"rms": "sqrt(mean(raw_EMG**2)) over256 raw observations for each electrode and each of six existing MAV endpoints",
                              "waveform_length": "mean(abs(diff(raw_EMG))) over255 adjacent differences INSIDE each256-observation window; not the unnormalized sum",
                              "shape_order": "recording-history row, six chronological endpoints,16 electrodes",
                              "sampling_rate_hz": 2000, "endpoint_spacing_samples": 100,
                              "window_samples": 256, "history_support_samples": 756,
                              "history_support_ms": 378, "dtype": "float64 in supplied raw units",
                              "fitting": "No centering, scaling, logarithm, learned parameter or model fit. All cumulative arrays reset within active motion/repetition trial."},
              "shapes": {key: list(values.shape) for key, values in arrays.items()},
              "alignment": checks, "model_fits": 0}
    verification.parent.mkdir(parents=True, exist_ok=True)
    verification.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=TRANSFER / "data/ninapro")
    parser.add_argument("--output", type=Path, default=TRANSFER / "data/ninapro/emg_observations.npz")
    parser.add_argument("--verification", type=Path, default=HERE / "emg_observations_verification.json")
    args = parser.parse_args()
    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        extract(args.data, args.output, args.verification)
