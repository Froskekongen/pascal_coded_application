"""Reuse the original tensorsig KIMORE and NinaPro preprocessing and splits.

Adapters never fit normalization or inspect held-out targets. Signals exclude
clocks and basepoints so the transfer feature builder can add its conventions.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np

SIBLING = Path(__file__).resolve().parents[3] / "tensorsig"
DEFAULT_DATA = Path(__file__).resolve().parent / "data"


def _sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def _loader(dataset: str, tensorsig_root: Path):
    source = Path(tensorsig_root) / "examples" / dataset / "benchmark.py"
    spec = importlib.util.spec_from_file_location(f"transfer_{dataset}_loader", source)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot import existing dataset loader: {source}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, {"loader": str(source), "loader_sha256": _sha256(source)}


def _check_unit(unit: dict) -> None:
    """Validate finite aligned arrays and separation at the declared group level."""
    x, y = unit["signals"], unit["target"]
    if x.ndim != 3 or y.ndim != 2 or len(x) != len(y):
        raise ValueError("Expected aligned N×T×C signals and N×outputs targets")
    if not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError("Nonfinite signals or targets")
    if len(unit["record_ids"]) != len(x) or len(set(unit["record_ids"])) != len(x):
        raise ValueError("Recording identifiers must be unique and aligned")
    splits = [unit[key] for key in ("train", "validation", "test")]
    if any(len(split) < 2 for split in splits):
        raise ValueError("At least two observations are required in each split")
    groups = [set(unit["groups"][split]) for split in splits]
    if any(groups[i] & groups[j] for i, j in ((0, 1), (0, 2), (1, 2))):
        raise ValueError("Group leakage across train, validation, or test")
    indices = np.concatenate(splits)
    if len(np.unique(indices)) != len(indices) or indices.min() < 0 or indices.max() >= len(x):
        raise ValueError("Invalid or overlapping split indices")
    for key in ("auxiliary", "clock_end"):
        if key in unit and (len(unit[key]) != len(x) or not np.isfinite(unit[key]).all()):
            raise ValueError(f"Invalid {key}")


def kimore_units(data_dir: Path = DEFAULT_DATA / "kimore", *, seed: int = 123,
                 frames: int = 128, tensorsig_root: Path = SIBLING) -> list[dict]:
    """All five exercises and subject folds, using each full training pool.

    The sibling loader retains original clinical TS on its 0–50 scale, strict
    score-identity checks, constant initial-pelvis centering and torso scaling.
    Duration is supplied for every map as a common scalar and for the ordinary
    geometric path's elapsed-seconds/10 clock. Spectral bin indices describe
    normalized trial time; multiplying them by duration would not recover Hz.
    """
    data_dir = Path(data_dir)
    loader, source = _loader("kimore", tensorsig_root)
    manifest_path = data_dir / "download_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    if manifest.get("errors") or sorted(manifest.get("exercises", [])) != [1, 2, 3, 4, 5]:
        raise ValueError("Complete KIMORE download of all five exercises is required")
    records, excluded = loader.load_dataset(data_dir, frames)
    folds = loader.subject_folds(records, seed)
    source.update(source_url=manifest["source"], source_manifest_sha256=_sha256(manifest_path),
                  source_files=len(manifest["files"]), retained_recordings=len(records),
                  excluded=excluded, subject_folds=folds)
    units = []
    for exercise in range(1, 6):
        available = [record for record in records if record["exercise"] == exercise]
        x = np.stack([record["path"].numpy() for record in available])
        y = np.array([record["target"] for record in available], dtype=np.float64)[:, None]
        people = np.array([record["subject"] for record in available])
        duration = np.array([record["duration_seconds"] for record in available])
        indices = np.arange(len(available), dtype=np.int64)
        assignment = np.array([folds[person] for person in people])
        for fold in range(5):
            train = indices[(assignment != fold) & (assignment != (fold + 1) % 5)]
            train_records = [available[index] for index in train]
            train = train[loader.training_order(train_records, seed + fold)]
            validation, test = indices[assignment == (fold + 1) % 5], indices[assignment == fold]
            unit = dict(name=f"kimore_ex{exercise}_fold{fold}", dataset="kimore",
                        classification=False, signals=x, target=y, train=train,
                        validation=validation, test=test, groups=people,
                        record_ids=[f"{person}/Es{exercise}" for person in people],
                        auxiliary=duration[:, None], clock_end=duration / 10,
                        metadata={**source, "exercise": exercise, "test_fold": fold,
                                  "training_budget": 0, "seed": seed, "frames": frames,
                                  "shape": list(x.shape), "target": "clinical TS, original 0–50 scale",
                                  "protocol": "five subject folds; next fold validation; remaining three train; full training pool; no refit",
                                  "preprocessing": "original skeleton repair and timestamp interpolation; fixed initial pelvis translation and torso scale; duration appended to every feature map",
                                  "auxiliary_names": ["duration_seconds"],
                                  "counts": {"train": len(train), "validation": len(validation), "test": len(test)},
                                  "record_metadata": [{key: value for key, value in record.items() if key != "path"} for record in available]})
            _check_unit(unit)
            units.append(unit)
    return units


def ninapro_units(data_dir: Path = DEFAULT_DATA / "ninapro", *, subject: int = 1,
                  repetitions: tuple[int, ...] = (1, 2, 5, 10),
                  max_windows_per_trial: int = 0,
                  tensorsig_root: Path = SIBLING) -> list[dict]:
    """Original causal MAV histories and A1/A2/A3 split, one unit per budget.

    These are within-subject acquisition tests. Overlapping history windows
    are not independent replicates. Unused A1 repetitions stay out of all
    splits; no validation observation enters the training calibration budget.
    """
    if subject not in range(1, 11) or not repetitions or any(b not in range(1, 11) for b in repetitions):
        raise ValueError("Intact subject and repetition budgets must lie in 1..10")
    if len(set(repetitions)) != len(repetitions) or max_windows_per_trial < 0:
        raise ValueError("Unique budgets and nonnegative window limit required")
    loader, source = _loader("ninapro", tensorsig_root)
    acquisitions, source_files = [], []
    for acquisition in (1, 2, 3):
        path = Path(data_dir) / f"S{subject}_E1_A{acquisition}.mat"
        acquisitions.append(loader.load_acquisition(path, max_windows_per_trial))
        source_files.append(dict(file=path.name, bytes=path.stat().st_size, sha256=_sha256(path),
                                 source_url=f"https://ninapro.hevs.ch/files/DB8/{path.name}"))
    x = np.concatenate([acquisition[0].numpy() for acquisition in acquisitions])
    y = np.concatenate([acquisition[1].numpy() for acquisition in acquisitions])
    reps = np.concatenate([acquisition[2].numpy() for acquisition in acquisitions])
    movements = np.concatenate([acquisition[3].numpy() for acquisition in acquisitions])
    acquisition_ids = np.concatenate([np.full(len(a[0]), i, dtype=np.int64) for i, a in enumerate(acquisitions, 1)])
    groups = np.array([f"S{subject}_A{a}_M{m}_R{r}" for a, m, r in zip(acquisition_ids, movements, reps)])
    record_ids = [f"S{subject}_A{a}_history{i}" for a, values in enumerate(acquisitions, 1) for i in range(len(values[0]))]
    indices = np.arange(len(x), dtype=np.int64)
    units = []
    for budget in repetitions:
        train = indices[(acquisition_ids == 1) & (reps <= budget)]
        present = set(zip(movements[train].tolist(), reps[train].tolist()))
        expected = {(m, r) for m in range(1, 10) for r in range(1, budget + 1)}
        if not expected <= present:
            raise ValueError(f"Missing calibration movement/repetition pairs: {sorted(expected - present)}")
        validation, test = indices[acquisition_ids == 2], indices[acquisition_ids == 3]
        unit = dict(name=f"ninapro_s{subject}_reps{budget}", dataset="ninapro", classification=False,
                    signals=x, target=y, train=train, validation=validation, test=test,
                    groups=groups, record_ids=record_ids,
                    metadata={**source, "source_url": loader.SOURCE, "source_files": source_files,
                              "subject": subject, "calibration_repetitions": budget,
                              "max_windows_per_trial": max_windows_per_trial, "shape": list(x.shape),
                              "protocol": "within-subject A1 calibration; A2 validation; A3 test; active-trial interiors; no refit",
                              "target": "18 calibrated glove channels, trailing 128ms mean",
                              "preprocessing": "six causal MAV vectors 50ms apart; 128ms averaging; 378ms total raw support; histories never cross trial boundaries",
                              "counts": {"train": len(train), "validation": len(validation), "test": len(test)},
                              "record_acquisition": acquisition_ids.tolist(),
                              "record_movement": movements.tolist(), "record_repetition": reps.tolist()})
        _check_unit(unit)
        units.append(unit)
    return units


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset", choices=("kimore", "ninapro"))
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA)
    args = parser.parse_args()
    units = (kimore_units if args.dataset == "kimore" else ninapro_units)(args.data_dir / args.dataset)
    for unit in units:
        print(json.dumps({"unit": unit["name"], "shape": unit["metadata"]["shape"],
                          "counts": unit["metadata"]["counts"]}), flush=True)
    if args.dataset == "kimore":
        for exercise in range(1, 6):
            exercise_units = units[5 * (exercise - 1):5 * exercise]
            held_out = np.concatenate([unit["test"] for unit in exercise_units])
            assert np.array_equal(np.sort(held_out), np.arange(len(exercise_units[0]["signals"])))
