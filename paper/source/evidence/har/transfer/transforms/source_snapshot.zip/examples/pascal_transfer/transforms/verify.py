"""Independent numerical and saved-result audit for the transform experiment."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter
from itertools import combinations
from pathlib import Path

import numpy as np
import study
import torch
from sklearn.linear_model import Ridge, RidgeClassifier
from sklearn.metrics import confusion_matrix, f1_score
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

HERE = Path(__file__).resolve().parent
TRANSFER = HERE.parent


def read_json(path):
    return json.loads(path.read_text())


def read_csv(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def penalty(value):
    return float("inf") if value == "infinity" else float(value)


def clipped(value):
    return value is True or value == "True"


def same(actual, expected):
    np.testing.assert_allclose(actual, expected, rtol=1e-11, atol=1e-11)


def hash_file(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def check_hash(path, expected, hashes):
    key = str(Path(path).resolve())
    if key not in hashes:
        hashes[key] = hash_file(key)
    assert hashes[key] == expected, f"Source hash mismatch: {path}"


def independent_design(values, n, clip):
    """sklearn StandardScaler, fitted only to training columns, then width scale."""
    train, query = np.asarray(values[:n], float), np.asarray(values[n:], float)
    keep = train.std(0) > 1e-6 * np.max(np.abs(train), axis=0)
    train, query = train[:, keep], query[:, keep]
    if not keep.any():
        return train, query
    if clip:
        query = np.minimum(np.maximum(query, train.min(0)), train.max(0))
    scaler = StandardScaler().fit(train)
    return scaler.transform(train) / np.sqrt(keep.sum()), scaler.transform(query) / np.sqrt(keep.sum())


def independent_prediction(values, n, y, is_classification, clip, lam):
    x, z = independent_design(values, n, clip)
    if np.isinf(lam) or not x.shape[1]:
        if is_classification:
            classes, counts = np.unique(y, return_counts=True)
            return np.full(len(z), classes[counts.argmax()])
        return np.broadcast_to(y.mean(0), (len(z), y.shape[1])).copy()
    cls = RidgeClassifier if is_classification else Ridge
    model = cls(alpha=n * lam, fit_intercept=True, solver="lsqr", tol=1e-10, max_iter=20000)
    model.fit(x, y)
    prediction = model.predict(z)
    return prediction if is_classification else prediction.reshape(len(z), -1)


def self_check():
    """Both Gram regimes, clipping, constant removal, intercepts and grid ties."""
    rng = np.random.default_rng(20261013)
    results = []
    for regime, n, d in (("primal", 43, 8), ("dual", 9, 31), ("constant", 17, 4)):
        train, query = rng.normal(size=(n, d)), 5 * rng.normal(size=(11, d))
        if regime == "constant":
            train.fill(3.)
        values = np.column_stack((np.r_[train, query], np.ones(n + len(query))))
        train_copy = values[:n].copy()
        for classification in (False, True):
            y = np.arange(n) % 3 if classification else 3 + rng.normal(size=(n, 2))
            actual = study.grid_predictions(values, n, y, classification)
            assert len(actual) == len(study.PARAMS)
            maximum = 0.
            for prediction, (clip, lam) in zip(actual, study.PARAMS):
                expected = independent_prediction(values, n, y, classification, clip, lam)
                if classification:
                    np.testing.assert_array_equal(prediction, expected)
                else:
                    np.testing.assert_allclose(prediction, expected, rtol=2e-7, atol=2e-7)
                maximum = max(maximum, float(np.max(np.abs(prediction - expected))))
            results.append({"regime": regime, "classification": classification,
                            "grid_predictions": len(actual), "max_absolute_difference": maximum})
        np.testing.assert_array_equal(values[:n], train_copy)
        original_x = study.design(values, n)[0]
        changed = values.copy()
        changed[n:] *= 1000
        np.testing.assert_array_equal(study.design(changed, n)[0], original_x)
    params = study.PARAMS
    scores = {"first": np.ones(len(params)), "second": np.ones(len(params))}
    choice = study.select(scores, 10, list(scores))
    assert choice["winner"] == "first"
    assert choice["models"]["first"]["penalty"] == "infinity"
    assert choice["models"]["first"]["clipped"] is False
    return {"status": "passed", "numerics": results, "readouts_checked": sum(r["grid_predictions"] for r in results),
            "training_unchanged_by_query_perturbation": True,
            "ties": "largest penalty, then unclipped, then first family", "verifier_sha256": hash_file(__file__),
            "runner_sha256": hash_file(HERE / "study.py")}


def selection_audit(protocol, grid, selection, dsads_person=None):
    names = protocol["models"]
    params = [(bool(c), penalty(p)) for c, p in protocol["parameters"]]
    assert {row["model"] for row in grid} == set(names)
    assert list(selection["models"]) == names
    folds = protocol["folds"]
    sizes = {i: len(fold["validation"]) for i, fold in enumerate(folds)}
    if dsads_person is not None:
        sizes = {person: 1140 for person in range(1, 9) if person != dsads_person}
    assert selection["n_validation"] == sum(sizes.values())
    losses, expected_count = {}, 0
    for name in names:
        rows = [r for r in grid if r["model"] == name]
        key = "validation_person" if dsads_person is not None else "fold"
        entries = {(int(r[key]), clipped(r["clipped"]), penalty(r["penalty"])): r for r in rows}
        assert len(entries) == len(rows) == len(params) * len(folds)
        sums = []
        for i, (clip, lam) in enumerate(params):
            total = 0.
            for fold, count in sizes.items():
                row = entries[fold, clip, lam]
                assert int(row["n"]) == count
                if dsads_person is not None:
                    assert int(row["outer_person"]) == dsads_person
                    assert int(row["parameter_index"]) == i
                value = float(row["loss_sum"])
                assert np.isfinite(value) and value >= 0
                if protocol["classification"]:
                    assert value <= count and value == round(value)
                total += value
            sums.append(total)
        best = min(sums)
        admissible = [i for i, value in enumerate(sums) if value <= best + 1e-10 * max(1., abs(best))]
        index = min(admissible, key=lambda i: (-params[i][1], params[i][0]))
        saved = selection["models"][name]
        assert index == saved["parameter_index"]
        assert params[index] == (saved["clipped"], penalty(saved["penalty"]))
        same(saved["validation_loss"], sums[index] / sum(sizes.values()))
        losses[name] = sums[index] / sum(sizes.values())
        expected_count += len(rows)
    assert len(grid) == expected_count
    assert selection["winner"] == min(names, key=losses.get)
    return len(grid)


def split_audit(unit, protocol, person=None):
    train, test = unit["train"], unit["test"]
    if person is None:
        folds = unit.get("inner_folds", [(train, unit.get("validation"))])
    else:
        ids, groups = np.arange(len(unit["labels"])), unit["subjects"]
        train, test = ids[groups != person], ids[groups == person]
        folds = [(train[groups[train] != p], train[groups[train] == p]) for p in range(1, 9) if p != person]
        assert len(train) == 7980 and len(test) == 1140
    np.testing.assert_array_equal(protocol["train_indices"], train)
    np.testing.assert_array_equal(protocol["test_indices"], test)
    assert len(folds) == len(protocol["folds"])
    groups = unit.get("groups", unit.get("subjects"))
    group_audit = unit["dataset"] != "natops"
    if group_audit:
        assert not set(groups[train]) & set(groups[test])
    for (fit, validation), saved in zip(folds, protocol["folds"]):
        np.testing.assert_array_equal(saved["train"], fit)
        np.testing.assert_array_equal(saved["validation"], validation)
        combined = np.r_[fit, validation, test]
        assert len(np.unique(combined)) == len(combined)
        if group_audit:
            assert not set(groups[fit]) & set(groups[validation])
            assert not set(groups[validation]) & set(groups[test])
        if person is not None:
            assert len(fit) == 6840 and len(validation) == 1140
    if person is not None or "inner_folds" in unit:
        np.testing.assert_array_equal(np.sort(np.concatenate([b for _, b in folds])), np.sort(train))
    return train, test


def source_audit(protocol, data, hashes):
    for name, expected in protocol["source_sha256"].items():
        check_hash(TRANSFER.parent / name, expected, hashes)
    metadata = protocol["data"]
    if "loader" in metadata:
        check_hash(metadata["loader"], metadata["loader_sha256"], hashes)
    files = metadata.get("source_files", [])
    if isinstance(files, list):
        for source in files:
            path = source.get("path") or data / protocol["dataset"] / source["file"]
            check_hash(path, source["sha256"], hashes)
    if protocol["dataset"] == "kimore":
        manifest = data / "kimore/download_manifest.json"
        check_hash(manifest, metadata["source_manifest_sha256"], hashes)
        for source in read_json(manifest)["files"]:
            check_hash(data / "kimore" / source["path"], source["sha256"], hashes)
    if protocol["dataset"] == "uci_har":
        check_hash(data / "uci_har.zip", metadata["source_sha256"], hashes)
    if protocol["dataset"] == "ninapro":
        check_hash(data / "ninapro/emg_observations.npz", metadata["raw_descriptor_cache_sha256"], hashes)


def metrics_audit(unit, protocol, selection, rows, predictions, train, test):
    y = unit["labels"] if unit["classification"] else unit["target"]
    np.testing.assert_array_equal(predictions["target"], y[test])
    np.testing.assert_array_equal(predictions["train_indices"], train)
    np.testing.assert_array_equal(predictions["test_indices"], test)
    assert [r["model"] for r in rows] == protocol["models"]
    for row in rows:
        name = row["model"]
        choice = selection["models"][name]
        assert row["selected"] == str(name == selection["winner"])
        assert clipped(row["clipped"]) == choice["clipped"]
        assert penalty(row["penalty"]) == penalty(choice["penalty"])
        same(float(row["validation_loss"]), choice["validation_loss"])
        prediction = predictions[name]
        assert prediction.shape == y[test].shape and np.isfinite(prediction).all()
        if unit["classification"]:
            assert int(row["errors"]) == np.count_nonzero(prediction != y[test])
            same(float(row["accuracy"]), np.mean(prediction == y[test]))
            same(float(row["macro_f1"]), f1_score(y[test], prediction, average="macro", zero_division=0))
        else:
            residual = prediction - y[test]
            same(float(row["mae"]), np.abs(residual).mean())
            same(float(row["rmse"]), np.sqrt(np.square(residual).mean()))
            same(float(row["r2"]), 1 - np.square(residual).sum() / np.square(y[test] - y[test].mean(0)).sum())
    return len(rows)


def dsads_pair_audit(folder, hashes):
    protocols = {person: read_json(folder / f"person{person}/protocol.json") for person in range(1, 9)}
    all_choices = read_json(folder / "selections_before_outer_testing.json")
    assert set(all_choices) == {str(person) for person in range(1, 9)}
    preparation = None
    if (folder / "outer_prepare.json").exists():
        preparation = read_json(folder / "outer_prepare.json")
        assert preparation["all_selections_frozen_before_any_outer_fit"] is True
        expected_files = {f"inner_exclude{a}_{b}.csv" for a, b in combinations(range(1, 9), 2)}
        assert set(preparation["inner_grid_sha256"]) == expected_files
        for filename, digest in preparation["inner_grid_sha256"].items():
            check_hash(folder / filename, digest, hashes)
        for source in ("study", "streams"):
            check_hash(HERE / (source + ".py"), preparation[source + "_sha256"], hashes)
        check_hash(HERE / "outer_worker.py", preparation["helper_sha256"], hashes)
    directed = {person: [] for person in range(1, 9)}
    worker_sidecars, serial_pairs = [], []
    for index, (a, b) in enumerate(combinations(range(1, 9), 2)):
        path = folder / f"inner_exclude{a}_{b}.csv"
        rows = read_csv(path)
        assert {(int(r["outer_person"]), int(r["validation_person"])) for r in rows} == {(a, b), (b, a)}
        sidecar = path.with_suffix(".worker.json")
        if sidecar.exists():
            worker = read_json(sidecar)
            assert worker["excluded"] == [a, b] and worker["shard"] == index % 3
            for source in ("study", "streams", "worker"):
                filename = "pair_worker.py" if source == "worker" else source + ".py"
                check_hash(HERE / filename, worker[source + "_sha256"], hashes)
            check_hash(path, worker["grid_sha256"], hashes)
            worker_sidecars.append(sidecar.name)
        else:
            serial_pairs.append([a, b])
        for row in rows:
            directed[int(row["outer_person"])].append(row)
    for person in range(1, 9):
        saved = read_csv(folder / f"person{person}/grid.csv")
        assert saved == directed[person]
        choice = read_json(folder / f"person{person}/selection.json")
        assert choice == all_choices[str(person)]
        selection_audit(protocols[person], saved, choice, person)
        run = read_json(folder / f"person{person}/run.json")
        if "outer_worker_sha256" in run:
            assert preparation is not None and run["shard"] == (person - 1) % 3
            check_hash(HERE / "outer_worker.py", run["outer_worker_sha256"], hashes)
    return {"shared_training_pools": 28, "directed_inner_holdouts": 56,
            "worker_sidecars_verified": worker_sidecars, "pairs_without_worker_sidecar": serial_pairs,
            "outer_preparation_manifest_verified": preparation is not None,
            "all_global_choices_equal_final_choices": True, "each_cached_direction_enters_only_its_assigned_outer_selector": True}


def actual_fit_audit(unit, name, train, test, selection, predictions, rows):
    if name not in ("dsads_person1", "natops", "kimore_ex1_fold0", "ninapro_s1_reps10"):
        return None
    winner = selection["winner"]
    indices = np.r_[train, test]
    y = unit["labels"] if unit["classification"] else unit["target"]
    for model, values, _ in study.features(unit, indices, len(train), 64):
        if model != winner:
            continue
        if "auxiliary" in unit:
            values = np.column_stack((values, unit["auxiliary"][indices]))
        choice = selection["models"][model]
        prediction = independent_prediction(values, len(train), y[train], unit["classification"],
                                            choice["clipped"], penalty(choice["penalty"]))
        expected = predictions[model]
        if unit["classification"]:
            np.testing.assert_array_equal(prediction, expected)
        else:
            np.testing.assert_allclose(prediction, expected, rtol=2e-7, atol=2e-6)
        width = independent_design(values, len(train), choice["clipped"])[0].shape[1]
        assert width == int(next(row["features"] for row in rows if row["model"] == model))
        return {"model": model, "clipped": choice["clipped"], "penalty": choice["penalty"],
                "exact_prediction_match": bool(np.array_equal(prediction, expected)),
                "maximum_absolute_difference": float(np.max(np.abs(prediction - expected))),
                "features": width, "solver": "sklearn LSQR, tol=1e-10, max_iter=20000, alpha=n_train*lambda"}
    raise AssertionError(f"Selected feature {winner} was not emitted")


def aggregate_dsads(parts):
    if not parts or len(next(iter(parts.values()))) != 8:
        return None
    result = {}
    for model, folds in parts.items():
        assert len(folds) == 8
        y, prediction = (np.concatenate([fold[index] for fold in folds]) for index in (0, 1))
        scores = [float(np.mean(fold[0] == fold[1])) for fold in folds]
        assert len(y) == 9120
        same(np.mean(y == prediction), np.mean(scores))
        result[model] = {"accuracy": float(np.mean(y == prediction)),
                         "macro_f1": float(f1_score(y, prediction, average="macro", zero_division=0)),
                         "errors": int(np.count_nonzero(y != prediction)),
                         "person_accuracy_in_order_1_to_8": scores,
                         "person_accuracy_sample_sd": float(np.std(scores, ddof=1)),
                         "confusion": confusion_matrix(y, prediction).tolist()}
    return result


def audit(args):
    hashes, units, pending, kimore_coverage, dsads_parts = {}, {}, [], {}, {}
    dsads_summary = None
    fixed = read_json(HERE / "protocol.json")
    resolved = fixed.get("resolved_source_sha256", fixed["source_sha256"])
    changed = [name for name in resolved if resolved[name] != fixed["source_sha256"][name]]
    if changed:
        initial = read_json(HERE / "protocol_initial.json")
        assert all(fixed[key] == value for key, value in initial.items()), "Original protocol fields changed"
        amendment = fixed["source_finalization"]
        assert changed == [amendment["file"]]
        assert amendment["initial_sha256"] == fixed["source_sha256"][amendment["file"]]
        assert amendment["final_sha256"] == resolved[amendment["file"]]
        assert amendment["explanation"].strip()
    for source, expected in resolved.items():
        check_hash(HERE / source, expected, hashes)
    emg_audit = read_json(HERE / "emg_observations_verification.json")
    check_hash(args.data / "ninapro/emg_observations.npz", emg_audit["cache_sha256"], hashes)
    for dataset in ("dsads", "ninapro", "natops", "utd_mhad", "kimore", "uci_har"):
        for unit in study.get_units(dataset, args.data):
            if dataset == "ninapro":
                with np.load(args.data / "ninapro/emg_observations.npz") as cache:
                    for key in ("acquisition", "movement", "repetition"):
                        np.testing.assert_array_equal(cache[key], unit["metadata"]["record_" + key])
                    np.testing.assert_array_equal(cache["target"], unit["target"])
            people = range(1, 9) if dataset == "dsads" else (None,)
            if dataset == "dsads" and (args.results / "dsads/run.json").exists():
                dsads_summary = dsads_pair_audit(args.results / "dsads", hashes)
            for person in people:
                name = f"dsads_person{person}" if person is not None else unit["name"]
                folder = args.results / "dsads" / f"person{person}" if person is not None else args.results / name
                if not (folder / "run.json").exists():
                    pending.append(name)
                    continue
                print(f"Auditing {name}", flush=True)
                assert read_json(folder / "run.json")["complete"] is True
                protocol, selection = read_json(folder / "protocol.json"), read_json(folder / "selection.json")
                assert protocol["dataset"] == dataset and protocol["unit"] == name
                assert protocol["models"] == study.menu(dataset) == fixed["models"][dataset]
                assert [(bool(c), penalty(p)) for c, p in protocol["parameters"]] == study.PARAMS
                source_audit(protocol, args.data, hashes)
                train, test = split_audit(unit, protocol, person)
                grid_rows = selection_audit(protocol, read_csv(folder / "grid.csv"), selection, person)
                rows = read_csv(folder / "results.csv")
                with np.load(folder / "predictions.npz") as predictions:
                    metric_rows = metrics_audit(unit, protocol, selection, rows, predictions, train, test)
                    fit = actual_fit_audit(unit, name, train, test, selection, predictions, rows) if args.actual_fits else None
                    if dataset == "dsads":
                        for model in protocol["models"]:
                            dsads_parts.setdefault(model, []).append((predictions["target"], predictions[model]))
                        dsads_parts.setdefault("nested_selected", []).append((predictions["target"], predictions[selection["winner"]]))
                units[name] = {"dataset": dataset, "train": len(train), "test": len(test),
                               "metrics_recomputed": metric_rows, "grid_rows_audited": grid_rows,
                               "splits_disjoint_and_match_loader": True,
                               "known_groups_disjoint": dataset != "natops", "choices_recomputed": True,
                               "independent_selected_fit": fit}
                if dataset == "kimore":
                    exercise = unit["metadata"]["exercise"]
                    kimore_coverage.setdefault(exercise, []).extend(test.tolist())
    for exercise, indices in kimore_coverage.items():
        if all(f"kimore_ex{exercise}_fold{fold}" in units for fold in range(5)):
            assert sorted(indices) == list(range(len(indices)))
    assert len(units) + len(pending) == fixed["evaluation_units"] == 40
    return {"status": "passed" if not pending else "partial_pass_pending_units", "pending": pending,
            "completed_units": len(units), "expected_units": 40,
            "dataset_unit_counts": dict(Counter(u["dataset"] for u in units.values())),
            "metrics_recomputed": sum(u["metrics_recomputed"] for u in units.values()),
            "grid_rows_audited": sum(u["grid_rows_audited"] for u in units.values()),
            "units": units, "dsads_pairs": dsads_summary, "dsads_pooled": aggregate_dsads(dsads_parts),
            "source_sha256_checked": hashes,
            "source_finalization": {"changed_pins": changed,
                                    "original_protocol_fields_preserved": True,
                                    "resolved_sources_match_all_completed_unit_protocols": True,
                                    "scope": "Final files and every saved unit hash verified. Initial-to-final nonsemantic-change explanation is recorded author attestation; the old source body is not present for independent diff."},
            "verifier_sha256": hash_file(__file__),
            "limitations": ["Only official row separation is known for NATOPS; subject identities absent.",
                            "Correct nested evaluation does not erase earlier test inspection or turn this exploratory cohort into independent confirmation."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-check", action="store_true")
    parser.add_argument("--actual-fits", action="store_true", help="Cross-check four representative selected real fits with sklearn")
    parser.add_argument("--data", type=Path, default=study.DEFAULT_DATA)
    parser.add_argument("--results", type=Path, default=HERE / "results")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        report = self_check() if args.self_check else audit(args)
    output = args.output or (HERE / "readout_checks.json" if args.self_check else args.results / "verification.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps({key: report[key] for key in ("status", "readouts_checked", "completed_units", "metrics_recomputed", "grid_rows_audited") if key in report}))


if __name__ == "__main__":
    main()
