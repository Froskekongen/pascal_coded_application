"""Descriptive DSADS recording/subject audit; no transforms or models are fitted."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
TRANSFER = HERE.parent
sys.path.insert(0, str(TRANSFER))
from datasets import DEFAULT_DATA, load_dataset, sha256

SITES = ("torso", "right_arm", "left_arm", "right_leg", "left_leg")
SENSORS = ("acceleration", "angular_velocity", "magnetic_field")
ACTIVITIES = (
    "sitting", "standing", "lying_back", "lying_right", "stairs_up", "stairs_down",
    "elevator_still", "elevator_moving", "walking_parking", "treadmill_flat",
    "treadmill_incline", "running", "stepper", "cross_trainer", "cycling_horizontal",
    "cycling_vertical", "rowing", "jumping", "basketball",
)


def csv_rows(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def save_csv(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def prior_scores(output, unit):
    folder = TRANSFER / "followup/results/dsads"
    protocol = json.loads((folder / "protocol.json").read_text())
    selection = json.loads((folder / "selection.json").read_text())
    grid = csv_rows(folder / "grid.csv")
    rows = []
    with np.load(folder / "predictions.npz") as saved:
        for model, choice in selection["primary"]["models"].items():
            matches = [r for r in grid if r["selector"] == "primary" and r["model"] == model
                       and float(r["gamma"]) == choice["gamma"] and r["penalty"] == str(choice["penalty"])]
            assert len(matches) == 6
            for row in matches:
                fold = protocol["folds"][int(row["fold"])]
                subject, = np.unique(unit["subjects"][fold["validation"]])
                count, errors = int(row["n"]), int(float(row["loss_sum"]))
                rows.append({"model": model, "subject": int(subject), "n": count, "errors": errors,
                             "accuracy": 1 - errors / count, "fit_people": 5,
                             "role": "inner validation reused for selecting this common penalty",
                             "gamma": choice["gamma"], "penalty": choice["penalty"]})
            for subject, suffix, target in ((7, "__subject7", "subject7_target"), (8, "", "target")):
                prediction = saved[f"primary__{model}{suffix}"]
                errors = int(np.count_nonzero(prediction != saved[target]))
                rows.append({"model": model, "subject": subject, "n": len(prediction), "errors": errors,
                             "accuracy": 1 - errors / len(prediction), "fit_people": 6,
                             "role": "separate diagnostic" if subject == 7 else "previously inspected test",
                             "gamma": choice["gamma"], "penalty": choice["penalty"]})
    save_csv(output / "prior_subject_scores.csv", rows)
    return {"primary_winner": selection["primary"]["winner"],
            "qualification": "P1-6 are five-person-fit inner validation at parameters selected using all six holdouts; P7/P8 use six-person refits. These cannot be pooled as a balanced or nested eight-person outer score.",
            "source_sha256": {name: sha256(folder / name) for name in
                              ("protocol.json", "grid.csv", "selection.json", "predictions.npz")}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA)
    parser.add_argument("--output", type=Path, default=HERE / "data_diagnostics")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    unit = load_dataset("dsads", args.data)
    x = unit["signals"].reshape(19, 8, 60, 125, 45)
    np.testing.assert_array_equal(unit["labels"], np.repeat(np.arange(19), 8 * 60))
    np.testing.assert_array_equal(unit["subjects"], np.tile(np.repeat(np.arange(1, 9), 60), 19))
    expected = [f"a{a:02d}/p{p}/s{s:02d}" for a in range(1, 20) for p in range(1, 9) for s in range(1, 61)]
    assert unit["record_ids"] == expected
    means = x.mean((2, 3))
    second = np.square(x).mean((2, 3))
    class_rows, vector_rows, seam_rows, norm_rows = [], [], [], []
    for activity in range(19):
        for person in range(8):
            other = np.arange(8) != person
            mean = means[activity, other].mean(0)
            sd = np.sqrt(np.maximum(second[activity, other].mean(0) - mean**2, 1e-16))
            shift = (means[activity, person] - mean) / sd
            row = {"activity": ACTIVITIES[activity], "subject": person + 1,
                   "class": activity + 1, "axis_mean_shift_rms": float(np.sqrt(np.square(shift).mean())),
                   "axis_mean_shift_maximum": float(np.abs(shift).max())}
            for sensor, name in enumerate(SENSORS):
                row[f"{name}_axis_shift_rms"] = float(np.sqrt(np.square(shift.reshape(5, 3, 3)[:, sensor]).mean()))
            class_rows.append(row)
            vectors = x[activity, person].reshape(60, 125, 5, 3, 3)
            norm = np.linalg.norm(vectors, axis=-1)
            query_mean = means[activity, person].reshape(5, 3, 3)
            train_mean = mean.reshape(5, 3, 3)
            for site, site_name in enumerate(SITES):
                for sensor, sensor_name in enumerate(SENSORS):
                    a, b = train_mean[site, sensor], query_mean[site, sensor]
                    na, nb = np.linalg.norm(a), np.linalg.norm(b)
                    cosine = np.clip(a @ b / max(na * nb, 1e-16), -1, 1)
                    median = float(np.median(norm[:, :, site, sensor]))
                    vector_rows.append({"activity": ACTIVITIES[activity], "subject": person + 1,
                        "site": site_name, "sensor": sensor_name,
                        "mean_vector_angle_deg": float(np.degrees(np.arccos(cosine))),
                        "other7_norm_of_mean": float(na), "subject_norm_of_mean": float(nb),
                        "subject_mean_norm": float(norm[:, :, site, sensor].mean()),
                        "subject_median_norm": median,
                        "subject_direction_coherence": float(nb / max(norm[:, :, site, sensor].mean(), 1e-16))})
                    norm_rows.append([activity + 1, person + 1, site, sensor, median])
            within = np.square(np.diff(vectors, axis=1)).mean((0, 1, 2, 4))
            boundary = np.square(vectors[1:, 0] - vectors[:-1, -1]).mean((0, 1, 3))
            for sensor, name in enumerate(SENSORS):
                seam_rows.append({"activity": ACTIVITIES[activity], "subject": person + 1,
                                  "sensor": name, "within_step_mean_square": float(within[sensor]),
                                  "segment_boundary_step_mean_square": float(boundary[sensor]),
                                  "boundary_over_within": float(boundary[sensor] / max(within[sensor], 1e-16))})
    for activity in ACTIVITIES:
        selected = [r for r in class_rows if r["activity"] == activity]
        order = sorted(selected, key=lambda r: -r["axis_mean_shift_rms"])
        for rank, row in enumerate(order, 1):
            row["within_activity_shift_rank_largest_first"] = rank
    save_csv(args.output / "class_subject_shifts.csv", class_rows)
    save_csv(args.output / "vector_directions.csv", vector_rows)
    save_csv(args.output / "recording_boundaries.csv", seam_rows)
    all_subjects = []
    for person in range(1, 9):
        rows = [r for r in class_rows if r["subject"] == person]
        all_subjects.append({"subject": person,
                            "class_shift_rms_mean": float(np.mean([r["axis_mean_shift_rms"] for r in rows])),
                            "class_shift_rms_median": float(np.median([r["axis_mean_shift_rms"] for r in rows])),
                            "classes_with_largest_shift": sum(r["within_activity_shift_rank_largest_first"] == 1 for r in rows)})
    norms = np.array(norm_rows)
    report = {"scope": "Post-result descriptive data audit across all eight people; no model fits, no train/test adaptation, no causal claim.",
              "shape": list(unit["signals"].shape), "record_ids_complete_unique": True,
              "metadata": unit["metadata"], "script_sha256": sha256(Path(__file__)),
              "class_shift_definition": "For each activity and held-out person, subtract the pooled mean of the other seven people and divide each of 45 axes by their pooled within-class sample SD (floor1e-8); report RMS across axes. No labels or statistics from this analysis may be fitted into classifiers.",
              "subject_summary": all_subjects,
              "median_recording_median_norm_by_sensor": {name: float(np.median(norms[norms[:, 3] == i, 4])) for i, name in enumerate(SENSORS)},
              "stationary_acceleration_median_norm_range": [float(v) for v in (np.min(norms[np.isin(norms[:, 0], [1, 2, 3, 4, 7]) & (norms[:, 3] == 0), 4]), np.max(norms[np.isin(norms[:, 0], [1, 2, 3, 4, 7]) & (norms[:, 3] == 0), 4]))],
              "boundary_ratio_median_by_sensor": {name: float(np.median([r["boundary_over_within"] for r in seam_rows if r["sensor"] == name])) for name in SENSORS},
              "units": "UCI description confirms modalities/order/rate but does not identify physical output units; numerical values kept in supplied units.",
              "prior_scores": prior_scores(args.output, unit)}
    (args.output / "summary.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps({key: report[key] for key in ("subject_summary", "median_recording_median_norm_by_sensor", "stationary_acceleration_median_norm_range", "boundary_ratio_median_by_sensor")}, indent=2))


if __name__ == "__main__":
    main()
