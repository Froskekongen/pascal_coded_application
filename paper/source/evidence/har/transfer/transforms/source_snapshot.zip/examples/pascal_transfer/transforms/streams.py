"""Matched transforms before joint raw and spectral Pascal signatures.

Calibration uses the training prefix. Iterate one transform family at a time;
the raw/spectral log maps share the combined map's allocation. All signatures
are exact depth-two piecewise-linear signatures evaluated by prefix sums.
"""

from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path

import numpy as np
import torch
from tensorsig.offset_coded_signatures.codes import OffsetCode

CHANNELS = {
    "natops": 24,
    "utd_mhad": 60,
    "kimore": 75,
    "dsads": 45,
    "ninapro": 16,
    "uci_har": 9,
}
COMMON = (
    "identity",
    "asinh",
    "tanh",
    "difference",
    "centered",
    "whiten",
    "robust_identity",
    "robust_asinh",
)
DSADS = ("magnitude", "unit_direction", "canonical", "gram")
NINA = ("rms_input", "log_mav", "gain_normalized")
EXTRAS = {"rms": "emg_log_rms", "waveform_length": "emg_log_wl"}
KINDS = ("raw_log", "spectral_log", "joint_log", "joint_endpoints", "joint_p1")
DESCRIPTIONS = {
    "identity": "z=(x-training_mean)/training_population_SD",
    "asinh": "asinh(z), with the identical identity calibration",
    "tanh": "tanh(z/2), with the identical identity calibration",
    "difference": "d[0]=0 and d[t]=z[t]-z[t-1]; within-window backward differences",
    "centered": "z minus its own per-window temporal mean; deliberately removes DC/posture levels",
    "whiten": "groupwise symmetric ZCA of z; covariance shrunk 0.9*Cov+0.1*I; no restandardization afterwards",
    "robust_identity": "(x-training_median)/(training_IQR/1.349); near-zero IQR falls back to ordinary training SD",
    "robust_asinh": "asinh(robust_identity), using the identical robust calibration",
    "magnitude": "physical triad norm divided by its training vector RMS; group acc/gyro/mag norms within each device",
    "unit_direction": "physical triad divided by its norm; zero-safe bounded extension below 1e-8 training vector RMS",
    "canonical": "project onto a right-handed window mean-acceleration/mean-magnetic frame, then divide each triad by training vector RMS; invalid device frames emit zeros and a validity sidecar",
    "gram": "asinh of six physical within-device Gram entries after each triad is divided by its training vector RMS; diagonal3 then off-diagonal(01,02,12)",
    "rms_input": "nonnegative MAV divided by training per-electrode RMS, without centering",
    "log_mav": "log1p(rms_input)",
    "gain_normalized": "rms_input divided by its own joint time/electrode RMS; zero windows emit zeros",
    "emg_log_rms": "log1p(causal raw-EMG RMS history / its training per-electrode RMS)",
    "emg_log_wl": "log1p(causal raw-EMG waveform-length history / its training per-electrode RMS)",
}


def transform_names(dataset, extra_names=()):
    if (
        dataset not in CHANNELS
        or set(extra_names) - set(EXTRAS)
        or (extra_names and dataset != "ninapro")
    ):
        raise ValueError("Unsupported dataset or additional stream name")
    return (
        *COMMON,
        *(DSADS if dataset == "dsads" else NINA if dataset == "ninapro" else ()),
        *(EXTRAS[name] for name in EXTRAS if name in extra_names),
    )


def model_names(dataset, extra_names=()):
    names = []
    for transform in transform_names(dataset, extra_names):
        names.extend(f"{transform}__{kind}" for kind in KINDS)
        if transform in ("identity", "asinh", "log_mav"):
            names.append(f"{transform}__joint_tensor")
    if dataset == "dsads":
        names.extend(("fft_norm__spectral_log", "fft_gram__spectral_log"))
    return tuple(names)


@lru_cache(maxsize=16)
def code(samples, columns):
    # Exactly the code used by uci_har.retained_features.pascal_code.
    return OffsetCode.pascal(
        samples, columns, orthonormal=True, dtype=torch.float64
    ).matrix.numpy()


def signature_levels(stream, group_width, columns, *, mass=False):
    """Return first/second levels, with channel-major code letters per group."""
    n, samples, channels = stream.shape
    if channels % group_width:
        raise ValueError("Stream width is not divisible by signature group width")
    grouped = stream.reshape(
        n, samples, channels // group_width, group_width
    ).transpose(0, 2, 1, 3)
    increments = (
        grouped[..., None] * code(samples, columns)[None, None, :, None, :]
    ).reshape(n, channels // group_width, samples, group_width * columns)
    if not mass:
        increments /= samples
    prefix = np.cumsum(increments, axis=2) - increments / 2
    first = increments.sum(2)
    second = np.einsum("ngti,ngtj->ngij", prefix, increments, optimize=True)
    return first, second


def log_coordinates(first, second):
    left, right = np.triu_indices(first.shape[2], 1)
    return np.concatenate(
        (first, (second[:, :, left, right] - second[:, :, right, left]) / 2), 2
    ).reshape(len(first), -1)


def tensor_coordinates(first, second):
    return np.concatenate((first, second.reshape(*first.shape[:2], -1)), 2).reshape(
        len(first), -1
    )


def fourier(stream):
    """Complex coefficients weighted so squared norms obey one-sided Parseval."""
    transformed = np.fft.rfft(stream, axis=1) / stream.shape[1]
    transformed[:, 1 : transformed.shape[1] - (stream.shape[1] % 2 == 0)] *= np.sqrt(
        2.0
    )
    return transformed


def normalized_power(stream):
    power = np.square(np.abs(fourier(stream)))
    energy = power.sum(1)
    mass = np.divide(
        power, energy[:, None], out=np.zeros_like(power), where=energy[:, None] > 1e-20
    )
    return mass, energy


def fit_calibration(x, n_train, dataset, extras):
    train = x[:n_train]
    center, scale = train.mean((0, 1)), np.maximum(train.std((0, 1)), 1e-8)
    lower, median, upper = np.quantile(train, (0.25, 0.5, 0.75), axis=(0, 1))
    robust_scale = (upper - lower) / 1.349
    fallback = robust_scale <= 1e-6 * scale
    robust_scale = np.where(fallback, scale, np.maximum(robust_scale, 1e-8))
    width = 16 if dataset == "ninapro" else 3
    if dataset == "ninapro":
        rms = np.maximum(np.sqrt(np.square(train).mean((0, 1))), 1e-8)
    else:
        rms = np.maximum(
            np.sqrt(
                np.square(train.reshape(*train.shape[:2], -1, 3)).sum(3).mean((0, 1))
            ),
            1e-8,
        )
    z = ((train - center) / scale).reshape(-1, x.shape[2] // width, width)
    covariance = np.einsum("ngc,ngd->gcd", z, z, optimize=True) / len(z)
    eigenvalues, eigenvectors = np.linalg.eigh(0.9 * covariance + 0.1 * np.eye(width))
    whitener = np.einsum(
        "gij,gj,gkj->gik", eigenvectors, 1 / np.sqrt(eigenvalues), eigenvectors
    )
    extra_rms = {
        name: np.maximum(np.sqrt(np.square(values[:n_train]).mean((0, 1))), 1e-8)
        for name, values in extras.items()
    }
    return {
        "center": center,
        "scale": scale,
        "robust_center": median,
        "robust_scale": robust_scale,
        "robust_fallback": fallback,
        "rms": rms,
        "whitener": whitener,
        "extra_rms": extra_rms,
    }


def energy_sidecar(x, calibration, dataset):
    if dataset == "ninapro":
        energy = np.square(x / calibration["rms"]).mean(1)
    else:
        vectors = (
            x.reshape(*x.shape[:2], -1, 3) / calibration["rms"][None, None, :, None]
        )
        energy = np.square(vectors).sum(3).mean(1)
    return np.log1p(energy)


def canonical_frame(vectors):
    """Vectors are N,T,5,3,3 in device/modal-vector/axis order, RMS scaled."""
    gravity = vectors[:, :, :, 0].mean(1)
    magnetic = vectors[:, :, :, 2].mean(1)
    gnorm = np.linalg.norm(gravity, axis=-1, keepdims=True)
    e3 = gravity / np.maximum(gnorm, 1e-30)
    horizontal = magnetic - np.sum(magnetic * e3, axis=-1, keepdims=True) * e3
    hnorm = np.linalg.norm(horizontal, axis=-1, keepdims=True)
    e1 = horizontal / np.maximum(hnorm, 1e-30)
    e2 = np.cross(e3, e1)
    frame = np.stack((e1, e2, e3), -1)
    valid = (gnorm[..., 0] > 1e-6) & (hnorm[..., 0] > 1e-6)
    projected = np.einsum("ntdvi,ndij->ntdvj", vectors, frame, optimize=True)
    projected *= valid[:, None, :, None, None]
    return projected.reshape(*vectors.shape[:2], 45), valid.astype(float)


def transform_batch(x, name, calibration, dataset, extra=None):
    z = (x - calibration["center"]) / calibration["scale"]
    width, flags = (16 if dataset == "ninapro" else 3), np.empty((len(x), 0))
    if name == "identity":
        y = z
    elif name == "asinh":
        y = np.arcsinh(z)
    elif name == "tanh":
        y = np.tanh(z / 2)
    elif name == "difference":
        y = np.concatenate((np.zeros_like(z[:, :1]), np.diff(z, axis=1)), 1)
    elif name == "centered":
        y = z - z.mean(1, keepdims=True)
    elif name == "whiten":
        y = np.einsum(
            "ntgc,gcd->ntgd",
            z.reshape(*z.shape[:2], -1, width),
            calibration["whitener"],
            optimize=True,
        ).reshape(z.shape)
    elif name in ("robust_identity", "robust_asinh"):
        y = (x - calibration["robust_center"]) / calibration["robust_scale"]
        if name == "robust_asinh":
            y = np.arcsinh(y)
    elif name in DSADS:
        vectors = (
            x.reshape(*x.shape[:2], 15, 3) / calibration["rms"][None, None, :, None]
        )
        norm = np.linalg.norm(vectors, axis=3, keepdims=True)
        if name == "magnitude":
            y = norm[..., 0]
        elif name == "unit_direction":
            y = (vectors / np.maximum(norm, 1e-8)).reshape(x.shape)
        elif name == "canonical":
            y, flags = canonical_frame(vectors.reshape(*x.shape[:2], 5, 3, 3))
        else:
            physical = vectors.reshape(*x.shape[:2], 5, 3, 3)
            gram = np.einsum("ntdvi,ntdwi->ntdvw", physical, physical, optimize=True)
            left, right = (0, 1, 2, 0, 0, 1), (0, 1, 2, 1, 2, 2)
            y, width = (
                np.arcsinh(gram[:, :, :, left, right]).reshape(*x.shape[:2], 30),
                6,
            )
    elif name in NINA:
        y = x / calibration["rms"]
        if name == "log_mav":
            y = np.log1p(y)
        elif name == "gain_normalized":
            gain = np.sqrt(np.square(y).mean((1, 2), keepdims=True))
            y = np.divide(y, gain, out=np.zeros_like(y), where=gain > 0)
    elif name in EXTRAS.values():
        source = next(key for key, value in EXTRAS.items() if value == name)
        y = np.log1p(extra / calibration["extra_rms"][source])
    else:
        raise ValueError(name)
    return y, width, flags


def invariant_spectra(x, calibration, kind):
    vectors = x.reshape(*x.shape[:2], 15, 3) / calibration["rms"][None, None, :, None]
    fft = fourier(vectors.reshape(x.shape)).reshape(
        len(x), x.shape[1] // 2 + 1, 5, 3, 3
    )
    if kind == "fft_norm":
        power = np.square(np.abs(fft)).sum(4)
        energy = power.sum(1)
        mass = np.divide(
            power,
            energy[:, None],
            out=np.zeros_like(power),
            where=energy[:, None] > 1e-20,
        )
        return mass.reshape(len(x), fft.shape[1], 15), 3
    gram = np.einsum("nfdvi,nfdwi->nfdvw", fft, fft.conj(), optimize=True)
    energy = np.real(np.diagonal(gram, axis1=3, axis2=4)).sum(1)
    denominator = np.sqrt(energy[:, :, :, None] * energy[:, :, None, :])
    valid = (energy[:, :, :, None] > 1e-20) & (energy[:, :, None, :] > 1e-20)
    gram = np.divide(
        gram, denominator[:, None], out=np.zeros_like(gram), where=valid[:, None]
    )
    diagonal = np.real(np.diagonal(gram, axis1=3, axis2=4))
    off = gram[:, :, :, (0, 0, 1), (1, 2, 2)]
    stream = np.concatenate((diagonal, off.real, off.imag), 3)
    return stream.reshape(len(x), fft.shape[1], 45), 9


def _metadata(calibration, dataset, n_train):
    return {
        "dataset": dataset,
        "n_train": n_train,
        "calibration": {
            key: (
                {name: value.tolist() for name, value in values.items()}
                if isinstance(values, dict)
                else values.tolist()
            )
            for key, values in calibration.items()
        },
        "energy_sidecar": "log1p of original-input mean squared norm / training RMS squared; one per physical XYZ triad, or one per Nina electrode; identical across transforms",
        "signature": "Piecewise-linear depth2: raw increments q*y/T; spectral increments q*p; channel-major code letters within groups; independent antisymmetric coordinates divided by2; no extra spectral sqrt2 factor",
        "spectral": "One-sided Parseval-weighted power, normalized separately per supplied transformed channel; energy<=1e-20 maps to zero mass",
        "storage": "float32 outputs, float64 calibration/signature arithmetic; raw and spectral views share joint-log allocation",
        "fit_policy": "Training prefix only; no restandardization after nonlinear transforms; readout scaling is external",
    }


def iter_features(signals, n_train, dataset, batch_size=64, extra_streams=None):
    """Yield (deterministic model key, finite float32 matrix, metadata).

    Consumers should fit/discard each matrix before requesting the next. The
    five/six matrices for one transform share or retain only that family, and
    previous families are released as iteration advances unless kept by caller.
    """
    x = np.asarray(signals, dtype=np.float64)
    extras = {
        name: np.asarray(values, dtype=np.float64)
        for name, values in (extra_streams or {}).items()
    }
    names = transform_names(dataset, tuple(extras))
    if (
        x.ndim != 3
        or x.shape[2] != CHANNELS[dataset]
        or x.shape[1] < 4
        or not 1 <= n_train <= len(x)
        or batch_size < 1
        or not np.isfinite(x).all()
    ):
        raise ValueError(
            "Expected finite supported N,T,C inputs with T>=4 and a valid training prefix"
        )
    if dataset == "ninapro" and np.any(x < 0):
        raise ValueError("NinaPro inputs must be nonnegative MAV histories")
    if any(
        values.shape != x.shape or not np.isfinite(values).all() or np.any(values < 0)
        for values in extras.values()
    ):
        raise ValueError(
            "Additional EMG histories must be aligned, finite and nonnegative"
        )
    calibration = fit_calibration(x, n_train, dataset, extras)
    common = _metadata(calibration, dataset, n_train)
    for name in names:
        buffers, raw_width, side_width = None, None, None
        tensor = name in ("identity", "asinh", "log_mav")
        for start in range(0, len(x), batch_size):
            batch = x[start : start + batch_size]
            extra_name = next(
                (key for key, value in EXTRAS.items() if value == name), None
            )
            extra = (
                None
                if extra_name is None
                else extras[extra_name][start : start + batch_size]
            )
            stream, group_width, flags = transform_batch(
                batch, name, calibration, dataset, extra
            )
            sidecar = np.column_stack(
                (energy_sidecar(batch, calibration, dataset), flags)
            )
            mass, _ = normalized_power(stream)
            raw_first, raw_second = signature_levels(stream, group_width, 3)
            spectral_first, spectral_second = signature_levels(
                mass, group_width, 3, mass=True
            )
            raw, spectral = (
                log_coordinates(raw_first, raw_second),
                log_coordinates(spectral_first, spectral_second),
            )
            first1, second1 = signature_levels(stream, group_width, 1)
            firstf, secondf = signature_levels(mass, group_width, 1, mass=True)
            values = {
                "joint_log": np.column_stack((raw, sidecar, spectral)),
                "joint_endpoints": np.column_stack(
                    (
                        raw_first.reshape(len(batch), -1),
                        sidecar,
                        spectral_first.reshape(len(batch), -1),
                    )
                ),
                "joint_p1": np.column_stack(
                    (
                        log_coordinates(first1, second1),
                        sidecar,
                        log_coordinates(firstf, secondf),
                    )
                ),
            }
            if tensor:
                values["joint_tensor"] = np.column_stack(
                    (
                        tensor_coordinates(raw_first, raw_second),
                        sidecar,
                        tensor_coordinates(spectral_first, spectral_second),
                    )
                )
            if buffers is None:
                buffers = {
                    kind: np.empty((len(x), value.shape[1]), dtype=np.float32)
                    for kind, value in values.items()
                }
                raw_width, side_width = raw.shape[1], sidecar.shape[1]
            for kind, value in values.items():
                if not np.isfinite(value).all():
                    raise ValueError(f"Nonfinite {name}/{kind} before storage")
                buffers[kind][start : start + len(batch)] = value
        buffers["raw_log"] = buffers["joint_log"][:, : raw_width + side_width]
        buffers["spectral_log"] = buffers["joint_log"][:, raw_width:]
        for kind in (*KINDS, *(("joint_tensor",) if tensor else ())):
            value = buffers[kind]
            if not np.isfinite(value).all():
                raise ValueError(f"Nonfinite float32 output {name}/{kind}")
            value.setflags(write=False)
            yield (
                f"{name}__{kind}",
                value,
                {
                    **common,
                    "transform": name,
                    "definition": DESCRIPTIONS[name],
                    "view": kind,
                    "features": value.shape[1],
                    "stream_channels": stream.shape[2],
                    "group_width": group_width,
                    "signature_groups": stream.shape[2] // group_width,
                    "sidecar_width": side_width,
                    "layout": "raw_log=[raw,sidecar]; spectral_log=[sidecar,spectral]; joint variants=[raw,sidecar,spectral]",
                    "canonical_validity": "Five binary device flags after common energy; valid iff scaled mean acceleration and horizontal magnetic norms both exceed1e-6"
                    if name == "canonical"
                    else None,
                },
            )
        del buffers
    if dataset == "dsads":
        for name in ("fft_norm", "fft_gram"):
            result = None
            for start in range(0, len(x), batch_size):
                batch = x[start : start + batch_size]
                mass, group_width = invariant_spectra(batch, calibration, name)
                first, second = signature_levels(mass, group_width, 3, mass=True)
                value = np.column_stack(
                    (
                        log_coordinates(first, second),
                        energy_sidecar(batch, calibration, dataset),
                    )
                )
                if result is None:
                    result = np.empty((len(x), value.shape[1]), dtype=np.float32)
                result[start : start + len(batch)] = value
            if not np.isfinite(result).all():
                raise ValueError(f"Nonfinite {name}")
            result.setflags(write=False)
            yield (
                f"{name}__spectral_log",
                result,
                {
                    **common,
                    "transform": name,
                    "view": "spectral_log",
                    "features": result.shape[1],
                    "group_width": group_width,
                    "signature_groups": 5,
                    "sidecar_width": 15,
                    "layout": "spectral log then common energy",
                    "definition": (
                        "Sum XYZ Fourier powers inside each triad, then normalize its frequency mass; jointly code the three modality masses per device; this is norm(FFT), not FFT(norm)"
                        if name == "fft_norm"
                        else "Complex Fourier Gram of acc/gyro/mag vectors within each device, divided by sqrt(total_energy_i*total_energy_j); diag3, realoff3, imagoff3; zero rows/columns for energy<=1e-20; jointly code9 streams per device. Cross streams are signed, not probability masses."
                    ),
                },
            )


def build_features(signals, n_train, dataset, batch_size=64, extra_streams=None):
    """Small-data convenience wrapper; experiments should consume iter_features."""
    values, metadata = {}, {}
    for name, value, info in iter_features(
        signals, n_train, dataset, batch_size, extra_streams
    ):
        values[name], metadata[name] = value, info
    return values, metadata


def self_check():
    from tensorsig.offset_coded_signatures.plans import LocalRealization

    rng = np.random.default_rng(18373)
    checks = []
    for samples in (6, 9):
        stream = rng.normal(size=(3, samples, 6))
        for columns in (1, 3):
            first, second = signature_levels(stream, 3, columns)
            grouped = (
                stream.reshape(3, samples, 2, 3)
                .transpose(0, 2, 1, 3)
                .reshape(6, samples, 3)
            )
            plan = LocalRealization(
                OffsetCode.pascal(
                    samples, columns, orthonormal=True, dtype=torch.float64
                ),
                channels=3,
                max_depth=2,
            ).signature(coordinates="dense")
            expected = (
                plan.evaluate(torch.from_numpy(grouped / samples)[:, None])[:, 0]
                .numpy()
                .reshape(3, -1)
            )
            np.testing.assert_allclose(
                tensor_coordinates(first, second), expected, atol=2e-15, rtol=2e-12
            )
            mass, energy = normalized_power(stream)
            np.testing.assert_allclose(energy, np.square(stream).mean(1), atol=1e-14)
            np.testing.assert_allclose(mass.sum(1), 1.0, atol=1e-14)
            spectral_first, spectral_second = signature_levels(
                mass, 3, columns, mass=True
            )
            bins = mass.shape[1]
            grouped_mass = (
                mass.reshape(3, bins, 2, 3).transpose(0, 2, 1, 3).reshape(6, bins, 3)
            )
            spectral_plan = LocalRealization(
                OffsetCode.pascal(bins, columns, orthonormal=True, dtype=torch.float64),
                channels=3,
                max_depth=2,
            ).signature(coordinates="dense")
            expected_spectral = (
                spectral_plan.evaluate(torch.from_numpy(grouped_mass)[:, None])[:, 0]
                .numpy()
                .reshape(3, -1)
            )
            np.testing.assert_allclose(
                tensor_coordinates(spectral_first, spectral_second),
                expected_spectral,
                atol=2e-15,
                rtol=2e-12,
            )
    checks.append(
        "P1/P3 grouped depth2 tensors equal official LocalRealization; odd/even one-sided Parseval and mass normalization"
    )
    zero_mass, zero_energy = normalized_power(np.zeros((2, 6, 3)))
    assert not zero_mass.any() and not zero_energy.any()
    widths = {}
    for dataset, channels in CHANNELS.items():
        signals = rng.normal(size=(5, 6, channels))
        if dataset == "ninapro":
            signals = np.abs(signals)
        before, metadata = build_features(signals, 3, dataset, 2)
        altered = signals.copy()
        altered[3:] = altered[3:] * 7 + 10
        after, updated = build_features(altered, 3, dataset, 2)
        assert tuple(before) == model_names(dataset) and metadata == updated
        for name in before:
            np.testing.assert_array_equal(before[name][:3], after[name][:3])
        for constant in (0.0, 1.0):
            values, _ = build_features(np.full_like(signals, constant), 3, dataset, 2)
            assert all(np.isfinite(value).all() for value in values.values())
        widths[dataset] = {name: value.shape[1] for name, value in before.items()}
    checks.append(
        "All datasets: deterministic menus, finite zero/constant streams, unchanged calibration and training features after held-out perturbation"
    )
    input_stream = rng.normal(size=(5, 9, 24))
    calibration = fit_calibration(input_stream, 3, "natops", {})
    z = transform_batch(input_stream, "identity", calibration, "natops")[0]
    whitened = transform_batch(input_stream, "whiten", calibration, "natops")[0]
    first, second = signature_levels(z, 3, 3)
    white_first, white_second = signature_levels(whitened, 3, 3)
    maps = np.array([np.kron(matrix, np.eye(3)) for matrix in calibration["whitener"]])
    np.testing.assert_allclose(
        white_first, np.einsum("ngi,gij->ngj", first, maps), atol=1e-14
    )
    np.testing.assert_allclose(
        white_second, np.einsum("gki,ngkl,glj->ngij", maps, second, maps), atol=1e-14
    )
    inverses = np.linalg.inv(maps)
    np.testing.assert_allclose(
        first, np.einsum("ngi,gij->ngj", white_first, inverses), atol=1e-14
    )
    np.testing.assert_allclose(
        second,
        np.einsum("gki,ngkl,glj->ngij", inverses, white_second, inverses),
        atol=1e-14,
    )
    checks.append(
        "Within-group ZCA transforms raw coded levels by an invertible linear tensor map; inverse reconstructs original levels"
    )
    physical = rng.normal(size=(4, 11, 45))
    # Nondegenerate stationary components define a reproducible frame.
    physical.reshape(4, 11, 5, 3, 3)[:, :, :, 0, 2] += 3
    physical.reshape(4, 11, 5, 3, 3)[:, :, :, 2, 0] += 2
    rotations = []
    for _ in range(5):
        q, _ = np.linalg.qr(rng.normal(size=(3, 3)))
        q[:, 0] *= np.linalg.det(q)
        rotations.append(q)
    rotations = np.array(rotations)
    rotated = np.einsum(
        "ntdvi,dij->ntdvj", physical.reshape(4, 11, 5, 3, 3), rotations
    ).reshape(physical.shape)
    calibration = fit_calibration(physical, 3, "dsads", {})
    rotated_calibration = fit_calibration(rotated, 3, "dsads", {})
    np.testing.assert_allclose(
        calibration["rms"], rotated_calibration["rms"], atol=1e-14
    )
    for name in ("magnitude", "gram", "canonical"):
        one = transform_batch(physical, name, calibration, "dsads")
        two = transform_batch(rotated, name, rotated_calibration, "dsads")
        np.testing.assert_allclose(one[0], two[0], atol=1e-13)
        np.testing.assert_array_equal(one[2], two[2])
    for name in ("fft_norm", "fft_gram"):
        np.testing.assert_allclose(
            invariant_spectra(physical, calibration, name)[0],
            invariant_spectra(rotated, rotated_calibration, name)[0],
            atol=1e-13,
        )
    invalid, flags = canonical_frame(np.zeros((2, 6, 5, 3, 3)))
    assert not invalid.any() and not flags.any()
    parallel = np.zeros((2, 6, 5, 3, 3))
    parallel[..., 2] = 1
    invalid, flags = canonical_frame(parallel)
    assert not invalid.any() and not flags.any()
    reflected = physical.reshape(4, 11, 5, 3, 3).copy()
    reflected[..., 0] *= -1
    reflected = reflected.reshape(physical.shape)
    canonical, _, _ = transform_batch(physical, "canonical", calibration, "dsads")
    mirror, _, _ = transform_batch(reflected, "canonical", calibration, "dsads")
    np.testing.assert_allclose(
        canonical.reshape(4, 11, 15, 3)[..., (0, 2)],
        mirror.reshape(4, 11, 15, 3)[..., (0, 2)],
        atol=1e-13,
    )
    np.testing.assert_allclose(
        canonical.reshape(4, 11, 15, 3)[..., 1],
        -mirror.reshape(4, 11, 15, 3)[..., 1],
        atol=1e-13,
    )
    checks.append(
        "Per-device proper-rotation invariance of magnitude/Gram/canonical and Fourier invariants; finite invalid frames; explicit reflection sign counterexample"
    )
    time = np.arange(16) * 2 * np.pi / 16
    rotating = np.column_stack((np.cos(time), np.sin(time), np.zeros(16)))[None]
    fft_norm = np.square(np.abs(fourier(rotating))).sum(2)
    norm_fft = np.square(
        np.abs(fourier(np.linalg.norm(rotating, axis=2, keepdims=True)))
    )[:, :, 0]
    assert np.argmax(fft_norm) == 1 and np.argmax(norm_fft) == 0
    mav = np.abs(rng.normal(size=(5, 6, 16)))
    calibration = fit_calibration(mav, 3, "ninapro", {})
    rms = transform_batch(mav, "rms_input", calibration, "ninapro")[0]
    gain = transform_batch(mav, "gain_normalized", calibration, "ninapro")[0]
    np.testing.assert_allclose(
        normalized_power(rms)[0], normalized_power(gain)[0], atol=1e-14
    )
    extras = {"rms": mav * 2, "waveform_length": mav * 3}
    values, _ = build_features(mav, 3, "ninapro", 2, extras)
    assert tuple(values) == model_names("ninapro", extras)
    np.testing.assert_allclose(
        values["rms_input__spectral_log"],
        values["gain_normalized__spectral_log"],
        atol=1e-7,
    )
    checks.append(
        "FFT(norm) differs from norm(FFT) on a rotating constant-norm vector; Nina common gain cancels from normalized power; aligned extra history menu"
    )
    return {
        "status": "passed",
        "seed": 18373,
        "checks": checks,
        "feature_widths": widths,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "real_data_model_fits": 0,
    }


if __name__ == "__main__":
    report = self_check()
    Path(__file__).with_name("checks.json").write_text(
        json.dumps(report, indent=2, allow_nan=False) + "\n"
    )
    print(
        json.dumps(
            {key: value for key, value in report.items() if key != "feature_widths"},
            indent=2,
        )
    )
