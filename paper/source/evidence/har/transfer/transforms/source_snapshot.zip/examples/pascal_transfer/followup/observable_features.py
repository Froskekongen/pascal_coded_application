"""Bounded occupations, physical geometry and short-state HAR transfers.

Only the training prefix fits calibration. Temporal Pascal blocks treat each
supplied channel separately, avoiding a quadratic expansion in channel count.
Geometry uses uncentered physical vectors, before independent axis scaling.
"""

from __future__ import annotations

from functools import lru_cache
import importlib.util
from itertools import combinations
from pathlib import Path

import numpy as np
import torch

PARENT = Path(__file__).resolve().parents[1]
_spec = importlib.util.spec_from_file_location("pascal_transfer_original_features", PARENT / "features.py")
legacy = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(legacy)
from retained_features import calibrated_graph_features, moment_summary, pascal_code, raw_logsignature
from tensorsig.offset_coded_signatures.plans import LocalRealization


# Exact joint indices copied from the existing dataset examples, whose ordering
# differs between NATOPS, UTD-MHAD and Kinect-v2 KIMORE.
BONES = {
    "natops": ((2, 4), (4, 0), (4, 6), (3, 5), (5, 1), (5, 7)),
    "utd_mhad": ((0, 1), (1, 2), (2, 3), (1, 4), (4, 5), (5, 6), (6, 7),
                 (1, 8), (8, 9), (9, 10), (10, 11), (3, 12), (12, 13), (13, 14),
                 (14, 15), (3, 16), (16, 17), (17, 18), (18, 19)),
    "kimore": ((0, 1), (1, 20), (20, 2), (2, 3), (20, 4), (4, 5), (5, 6), (6, 7),
               (7, 21), (6, 22), (20, 8), (8, 9), (9, 10), (10, 11), (11, 23),
               (10, 24), (0, 12), (12, 13), (13, 14), (14, 15), (0, 16),
               (16, 17), (17, 18), (18, 19)),
}
CHANNELS = {"natops": 24, "utd_mhad": 60, "kimore": 75, "dsads": 45, "ninapro": 16, "uci_har": 9}
BLOCKS = ("moments", "spectral_pool", "occupation", "geometry", "pascal_unbounded",
          "pascal_bounded", "events_static", "events_state", "spectral_bounded")


@lru_cache(maxsize=32)
def code(samples, columns):
    return pascal_code(samples, columns)


@lru_cache(maxsize=16)
def scalar_plan(samples):
    return LocalRealization(code(samples, 3), channels=1, max_depth=2).signature(coordinates="dense")


def coded_means(x, columns):
    """HAR visibility_features.coded_means, expressed using Torch arrays.

    These are first levels of increments phi(x[t])*q[t]/T, not nonlinear
    readouts claimed to be linear words of the original untransformed path.
    """
    return torch.einsum("ntc,ta->nca", x, code(x.shape[1], columns).matrix) / x.shape[1]


def lif_events(x, decay, threshold=.5):
    """HAR's literal soft-reset formula, also retaining the final state.

    Negative state is retained; the strict threshold gives at most one spike
    per sample. State is initialized independently for every observed window.
    """
    memory = np.zeros((len(x), x.shape[2]))
    events = np.empty_like(x)
    for t in range(x.shape[1]):
        memory = decay * memory + x[:, t]
        spike = memory > threshold
        events[:, t] = spike
        memory -= threshold * spike
    return events, memory


def scalar_logsignature(x):
    """Six P3 log coordinates per scalar channel, channel then coordinate."""
    windows, samples, channels = x.shape
    scalar = x.transpose(1, 2).reshape(windows * channels, samples, 1)
    tensor = scalar_plan(samples).evaluate((scalar / samples)[:, None])[:, 0].float().numpy()
    return raw_logsignature(tensor, width=3).reshape(windows, channels * 6)


def vector_layout(dataset):
    if dataset in BONES:
        bones = BONES[dataset]
        names = [f"joint{child}-joint{parent}" for parent, child in bones]
        pairs = [(i, j) for i, j in combinations(range(len(bones)), 2) if set(bones[i]) & set(bones[j])]
    elif dataset == "dsads":
        names = [f"site{site}_{sensor}" for site in range(5) for sensor in ("acc", "gyro", "mag")]
        pairs = [(3 * site + i, 3 * site + j) for site in range(5) for i, j in combinations(range(3), 2)]
    elif dataset == "uci_har":
        names, pairs = ["body_acc", "gyro", "gravity_total_minus_body"], list(combinations(range(3), 2))
    else:
        names, pairs = [], []
    return names, pairs


def physical_vectors(x, dataset):
    points = x.reshape(*x.shape[:2], -1, 3)
    if dataset in BONES:
        parents, children = zip(*BONES[dataset])
        return points[:, :, children] - points[:, :, parents]
    if dataset == "uci_har":
        return torch.stack((points[:, :, 0], points[:, :, 1], points[:, :, 2] - points[:, :, 0]), 2)
    return points


def graph_summary(stream):
    """HAR's calibrated mean/std and standardized P2 location coordinate."""
    statistics, trends = calibrated_graph_features(stream, skewness=False, trend=True, batch_size=len(stream))
    return np.concatenate((statistics, trends), 1)


def occupations(u, knots):
    observables = torch.cat((u, u.square(), *((u - knot).clamp_min(0) for knot in knots)), 2)
    return coded_means(observables, 2).flatten(1).numpy()


def geometry(vectors, rms, pairs):
    """Log norm, adjacent cosine/dot and lag-one directional persistence."""
    scaled = vectors / rms[None, None, :, None]
    direction = scaled / scaled.norm(dim=3, keepdim=True).clamp_min(1e-8)
    streams = [scaled.square().sum(3).log1p()]
    if pairs:
        left, right = zip(*pairs)
        streams.append((direction[:, :, left] * direction[:, :, right]).sum(3))
        dots = (scaled[:, :, left] * scaled[:, :, right]).sum(3)
        streams.append(dots.sign() * dots.abs().log1p())
    current = graph_summary(torch.cat(streams, 2))
    persistence = (direction[:, 1:] * direction[:, :-1]).sum(3)
    return np.concatenate((current, graph_summary(persistence)), 1), direction


@torch.inference_mode()
def build_blocks(signals: np.ndarray, n_train: int, dataset: str, batch_size: int = 64,
                 clock: np.ndarray | None = None) -> tuple[dict[str, np.ndarray], dict]:
    """Return separate float32 feature blocks and exact calibration metadata.

    Optional external clocks are validated but not used: these blocks compare
    sample-order histories. The runner appends KIMORE duration to every model.
    Physical geometry uses known vector groupings; temporal/event/spectral
    blocks use every supplied channel, with training axis standardization.
    """
    x = torch.as_tensor(signals, dtype=torch.float64)
    if (dataset not in CHANNELS or x.ndim != 3 or x.shape[2] != CHANNELS[dataset]
            or x.shape[1] < 6 or not 1 <= n_train <= len(x) or batch_size < 1
            or not torch.isfinite(x).all()):
        raise ValueError("Expected a supported dataset with finite (N,T,C) signals, T>=6 and training prefix")
    if clock is not None and (np.shape(clock) != tuple(x.shape[:2]) or not np.isfinite(clock).all()):
        raise ValueError("Expected finite optional clocks of shape (N,T)")
    if dataset == "ninapro" and (x < 0).any():
        raise ValueError("NinaPro MAV observations must be nonnegative")
    center = x[:n_train].mean((0, 1))
    scale = x[:n_train].std((0, 1), correction=0).clamp_min(1e-8)
    names, pairs = vector_layout(dataset)
    rms = None
    if names:
        squares = torch.zeros(len(names), dtype=torch.float64)
        for batch in x[:n_train].split(batch_size):
            squares += physical_vectors(batch, dataset).square().sum((0, 1, 3))
        rms = (squares / (n_train * x.shape[1])).sqrt().clamp_min(1e-8)
    mav_rms = x[:n_train].square().mean((0, 1)).sqrt().clamp_min(1e-8) if dataset == "ninapro" else None
    intervals = ((0, x.shape[1]), (0, x.shape[1] // 2), (x.shape[1] // 2, x.shape[1]))
    blocks = {name: [] for name in BLOCKS}
    if dataset == "ninapro":
        blocks["lagged_mav"] = []
    for batch in x.split(batch_size):
        z = (batch - center) / scale
        bounded = torch.tanh(z / 2)
        blocks["moments"].append(moment_summary(z).numpy())
        blocks["spectral_pool"].append(legacy.spectrum(z)[2].numpy())
        if dataset == "ninapro":
            logged = torch.log1p(batch / mav_rms)
            u = logged / (1 + logged)
            geo = torch.cat((u[:, 1:] * u[:, :-1], u[:, 1:] - u[:, :-1]), 2)
            blocks["geometry"].append(graph_summary(geo))
            blocks["occupation"].append(occupations(u, (.25, .5, .75)))
            blocks["lagged_mav"].append(batch.flatten(1).numpy())
        else:
            geo, direction = geometry(physical_vectors(batch, dataset), rms, pairs)
            blocks["geometry"].append(geo)
            u = direction[:, :, 2] if dataset == "uci_har" else direction.flatten(2)
            blocks["occupation"].append(occupations(u, (-.5, 0., .5)))
        for name, stream in (("pascal_unbounded", z), ("pascal_bounded", bounded)):
            blocks[name].append(np.concatenate([scalar_logsignature(stream[:, start:stop]) for start, stop in intervals], 1))
        for name, decay in (("events_static", 0.), ("events_state", .75)):
            events, final = lif_events(bounded.numpy(), decay)
            rates = coded_means(torch.from_numpy(events), 3).flatten(1).numpy()
            blocks[name].append(np.concatenate((rates, final), 1))
        mass, energy, _ = legacy.spectrum(bounded)
        spectral = scalar_logsignature(mass * mass.shape[1]).reshape(len(batch), x.shape[2], 6)
        spectral[:, :, 3:] *= np.sqrt(2)  # HAR spectral area convention.
        blocks["spectral_bounded"].append(np.concatenate((spectral.reshape(len(batch), -1),
                                                        energy.numpy(), energy.log1p().numpy()), 1))
    blocks = {name: np.concatenate(values).astype(np.float32, copy=False) for name, values in blocks.items()}
    if not all(np.isfinite(values).all() for values in blocks.values()):
        raise ValueError("Nonfinite output feature; the unbounded control may overflow for extreme inputs")
    metadata = {
        "dataset": dataset, "raw_center": center.tolist(), "raw_scale": scale.tolist(),
        "vector_rms": None if rms is None else rms.tolist(),
        "mav_rms": None if mav_rms is None else mav_rms.tolist(),
        "physical_vector_names": names, "physical_vector_pairs": [list(pair) for pair in pairs],
        "bones_parent_child": [list(pair) for pair in BONES.get(dataset, ())],
        "block_widths": {name: values.shape[1] for name, values in blocks.items()},
        "local_intervals": [list(interval) for interval in intervals],
        "occupation": "P2 coded first levels of u, u^2 and three hinges; no cubes, cross-products or energy gates",
        "occupation_knots": [.25, .5, .75] if dataset == "ninapro" else [-.5, 0., .5],
        "occupation_input": ("log1p(MAV/training_RMS)/(1+log1p(MAV/training_RMS))" if dataset == "ninapro"
                             else "gravity direction only" if dataset == "uci_har" else "physical vector directions"),
        "geometry": ("lag1 activation products and signed increments, each with mean/std/P2 standardized trend" if dataset == "ninapro"
                     else "log1p squared RMS-normalized vector norms; pair cosines; sign(dot)*log1p(abs(dot)); lag1 direction dot; each mean/std/P2 standardized trend"),
        "pascal": "Per-channel P3 depth2 endpoints and /2 areas, in whole/left-half/right-half order; each segment uses observations/segment_length",
        "bounded_transform": "tanh(training_standardized_observation/2)",
        "events": "On bounded charges; P3 coded spike rates plus final post-reset state; decays0/.75, strict threshold.5, initial state0; negative states retained",
        "spectral_bounded": "Per-channel P3 normalized one-sided power of bounded observations; HAR sqrt(2) area scaling; energy and log1p energy",
        "external_clock_supplied": clock is not None,
        "clock_policy": "Sample-order clocks; supplied physical duration must be added consistently by runner",
        "storage": "float32; arithmetic and calibration float64",
    }
    return blocks, metadata


def self_check():
    """Direct signature identities, bounded tails, geometry and leakage."""
    rng = np.random.default_rng(6173)
    sample = torch.tensor(rng.normal(size=(3, 11, 2)), dtype=torch.float64)
    q = code(11, 3).matrix
    increments = sample.transpose(1, 2)[:, :, :, None] * q[None, None] / 11
    prefix = increments.cumsum(2) - increments / 2
    second = torch.einsum("ncti,nctj->ncij", prefix, increments)
    left, right = np.triu_indices(3, 1)
    expected = torch.cat((increments.sum(2), (second[:, :, left, right] - second[:, :, right, left]) / 2), 2)
    np.testing.assert_allclose(scalar_logsignature(sample), expected.flatten(1).numpy(), atol=1e-7, rtol=1e-6)
    np.testing.assert_allclose(coded_means(sample, 3).numpy(),
                               np.einsum("ntc,ta->nca", sample.numpy(), q.numpy()) / 11, atol=1e-14)
    witness = np.zeros((2, 8, 1)); witness[0, :4, 0] = [1, -3, 3, -1]; witness[1] = -witness[0]
    np.testing.assert_array_equal(lif_events(witness, .75)[0].sum((1, 2)), [2, 1])
    np.testing.assert_array_equal(lif_events(witness, 0.)[0], witness > .5)
    if lif_events(np.array([[[-1.], [1.]]]), .75)[0].sum() != 0:
        raise ValueError("LIF negative memory was clipped")
    widths = {}
    for dataset, channels in CHANNELS.items():
        signals = rng.normal(size=(6, 8, channels))
        if dataset == "ninapro":
            signals = np.abs(signals)
        before, metadata = build_blocks(signals, 4, dataset, 2)
        changed = signals.copy(); changed[4:] = 3 * changed[4:] + 7
        after, changed_metadata = build_blocks(changed, 4, dataset, 2)
        if metadata != changed_metadata:
            raise ValueError("Held-out observations changed fitted calibration")
        for name in before:
            np.testing.assert_array_equal(before[name][:4], after[name][:4])
        zeros, _ = build_blocks(np.zeros_like(signals), 4, dataset, 2)
        ones, _ = build_blocks(np.ones_like(signals), 4, dataset, 2)
        if not all(np.isfinite(v).all() for v in (*zeros.values(), *ones.values())):
            raise ValueError("Zero or constant input produced a nonfinite feature")
        widths[dataset] = metadata["block_widths"]
    signals = rng.normal(size=(6, 8, 24))
    original, _ = build_blocks(signals, 4, "natops", 2)
    rotation = np.linalg.qr(rng.normal(size=(3, 3)))[0]
    rotated = (signals.reshape(6, 8, 8, 3) @ rotation + rng.normal(size=(6, 1, 1, 3))).reshape(6, 8, 24)
    transformed, _ = build_blocks(rotated, 4, "natops", 2)
    np.testing.assert_allclose(original["geometry"], transformed["geometry"], atol=2e-6, rtol=2e-6)
    previous = legacy.build_features(signals, 4, 2)
    for name in ("moments", "spectral_pool"):
        np.testing.assert_array_equal(original[name], previous[name])
    signals[4:] *= 1e6
    extreme, meta = build_blocks(signals, 4, "natops", 2)
    for i, (start, stop) in enumerate(meta["local_intervals"]):
        values = extreme["pascal_bounded"][4:, i * 6 * 24:(i + 1) * 6 * 24].reshape(2, 24, 6)
        length = stop - start
        if np.max(np.abs(values[:, :, :3])) > 1 / np.sqrt(length) + 1e-7 or np.max(np.abs(values[:, :, 3:])) > .5 / length + 1e-7:
            raise ValueError("Bounded scalar signature exceeded its variation bound")
    if np.max(np.abs(extreme["pascal_unbounded"][4:])) <= 1e6:
        raise ValueError("Tail witness did not separate the unbounded control")
    short, _ = build_blocks(np.abs(rng.normal(size=(4, 6, 16))), 2, "ninapro", 2)
    if short["pascal_bounded"].shape != (4, 288):
        raise ValueError("Six-point MAV histories must support P3 in both halves")
    return {"status": "passed", "block_widths": widths,
            "checks": ["scalar P3 against direct accumulation", "coded occupations against direct sums",
                       "HAR LIF witness and memoryless boundary", "all six dataset calibrations exclude held-out data",
                       "zero/constant paths", "rigid-rotation/translation geometry", "unchanged legacy base arrays",
                       "bounded signatures obey variation bounds under millionfold held-out amplification",
                       "six-point local P3 support"]}


if __name__ == "__main__":
    import json
    torch.set_num_threads(1)
    print(json.dumps(self_check(), indent=2))
