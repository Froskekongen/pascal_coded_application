"""Reuse the sibling tensorsig loaders and their published subject splits."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import shutil
import urllib.request
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DATA = Path(__file__).resolve().parent / "data"
SIBLING = ROOT.parent / "tensorsig"
ARCHIVES = {
    "dsads": (
        "dsads.zip",
        "f42ad7744ecf14151c9fa3a86dfb5b24de9d7cb7ffe956ef5de242983459c77e",
    ),
    "utd_mhad": (
        "Skeleton.zip",
        "f029ea1d4e4c330b2c61307b6d532b34c3920bcac1f4c22c7827f406e2c7ac00",
    ),
}


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load_natops(data_dir: Path = DEFAULT_DATA, download: bool = False) -> dict:
    """Official archive split with five stratified inner training folds."""
    from sklearn.model_selection import StratifiedKFold

    source = ROOT / "examples" / "natops_skeleton_graph_quotient.py"
    spec = importlib.util.spec_from_file_location("transfer_natops_loader", source)
    loader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loader)
    verification = ROOT / "paper" / "evidence" / "natops" / "dataset_verification.json"
    definitions = json.loads(verification.read_text())["files"]
    arrays, targets, files = [], [], []
    for split in ("TRAIN", "TEST"):
        filename = f"NATOPS_{split}.ts"
        path = Path(data_dir) / filename
        entry = definitions[filename]
        if download and not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            partial = path.with_suffix(".ts.part")
            try:
                with (
                    urllib.request.urlopen(entry["url"], timeout=90) as response,
                    partial.open("wb") as stream,
                ):
                    shutil.copyfileobj(response, stream)
                partial.replace(path)
            finally:
                partial.unlink(missing_ok=True)
        if not path.is_file():
            raise FileNotFoundError(f"Missing {path}; rerun with --download")
        digest = sha256(path)
        if digest != entry["sha256"]:
            raise ValueError(f"Official archive hash mismatch for {path}: {digest}")
        paths, labels = loader.load_natops(path)
        arrays.append(paths.numpy())
        targets.append(labels.numpy())
        files.append(
            {"path": str(path.resolve()), "source_url": entry["url"], "sha256": digest}
        )
    signals, labels = np.concatenate(arrays), np.concatenate(targets)
    train, test = np.arange(180), np.arange(180, 360)
    inner_folds = list(
        StratifiedKFold(5, shuffle=True, random_state=20261012).split(
            train, labels[train]
        )
    )
    metadata = {
        "name": "natops",
        "shape": list(signals.shape),
        "classes": 6,
        "protocol": "Official 180 train / 180 test; five stratified training folds (seed 20261012); refit full train after selection.",
        "preprocessing": "Original 51-frame 24-channel paths; no centering, clock, basepoint or scaling added by adapter.",
        "counts": {"train": 180, "validation": 0, "test": 180},
        "subject_ids": "Not provided in the UEA archive; subject independence is not established.",
        "inner_fold_sizes": [[len(fit), len(valid)] for fit, valid in inner_folds],
        "source_files": files,
        "loader": str(source.resolve()),
        "loader_sha256": sha256(source),
        "verification_metadata_sha256": sha256(verification),
    }
    return {
        "name": "natops",
        "signals": signals,
        "labels": labels,
        "subjects": np.full(360, -1, dtype=np.int64),
        "record_ids": [
            f"{split}/{index}" for split in ("TRAIN", "TEST") for index in range(180)
        ],
        "train": train,
        "validation": train[:0],
        "test": test,
        "inner_folds": inner_folds,
        "metadata": metadata,
    }


def load_dataset(
    name: str,
    data_dir: Path = DEFAULT_DATA,
    download: bool = False,
    tensorsig_root: Path = SIBLING,
) -> dict:
    """Return raw paths and global split indices, before train-fitted scaling.

    DSADS has one fixed training/validation pair. UTD-MHAD has four inner
    leave-one-training-subject-out pairs and an empty separate validation set;
    final fitting uses all odd subjects after selecting on the inner folds.
    """
    if name == "natops":
        return load_natops(data_dir, download)
    if name not in ARCHIVES:
        raise ValueError(f"Expected one of {tuple(ARCHIVES)}, got {name!r}")
    source = Path(tensorsig_root) / "examples" / name / "benchmark.py"
    spec = importlib.util.spec_from_file_location(f"transfer_{name}_loader", source)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot import existing dataset loader: {source}")
    loader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loader)
    filename, expected_hash = ARCHIVES[name]
    archive = Path(data_dir) / filename
    if download:
        (loader.download_archive if name == "dsads" else loader.download)(archive)
    if not archive.is_file():
        raise FileNotFoundError(f"Missing {archive}; rerun with --download")
    archive_hash = sha256(archive)
    if archive_hash != expected_hash:
        raise ValueError(
            f"Official archive hash mismatch for {archive}: {archive_hash}"
        )
    paths, targets, people, identifiers = (
        loader.load_data(archive, 60)
        if name == "dsads"
        else loader.load_data(archive, 32)
    )
    signals = paths.numpy().astype(np.float64, copy=False)
    labels = targets.numpy().astype(np.int64, copy=False)
    subjects = people.numpy().astype(np.int64, copy=False)
    indices = np.arange(len(labels), dtype=np.int64)
    if name == "dsads":
        train = indices[subjects <= 6]
        validation = indices[subjects == 7]
        test = indices[subjects == 8]
        inner_folds = [(train, validation)]
        expected_shape, classes = (9120, 125, 45), 19
        preprocessing = "Original 125-frame sensor windows; no centering, clock, basepoint or scaling added by adapter."
        protocol = "Subjects 1–6 train, 7 validation, 8 test; no validation refit."
    else:
        train = indices[subjects % 2 == 1]
        validation = indices[:0]
        test = indices[subjects % 2 == 0]
        inner_folds = [
            (train[subjects[train] != person], train[subjects[train] == person])
            for person in (1, 3, 5, 7)
        ]
        expected_shape, classes = (861, 32, 60), 27
        preprocessing = "Subtract each trial's initial hip-center position; linearly interpolate to 32 frames, aligned endpoints. No clock, basepoint or scaling added by adapter."
        protocol = "Odd subjects train, even subjects test; four inner subject holdouts; refit all odd subjects after selection."
    if signals.shape != expected_shape or not np.isfinite(signals).all():
        raise ValueError(
            f"Unexpected or nonfinite {name} signal array: {signals.shape}"
        )
    if len(set(identifiers)) != len(labels):
        raise ValueError("Duplicate recording identifiers")
    if not np.array_equal(np.sort(np.concatenate((train, validation, test))), indices):
        raise ValueError("Outer splits do not partition the dataset")
    for fit, valid in inner_folds:
        if (
            set(subjects[fit]) & set(subjects[valid])
            or set(subjects[fit]) & set(subjects[test])
            or set(subjects[valid]) & set(subjects[test])
        ):
            raise ValueError("Subject leakage across fitting, validation or test")
        if (
            len(np.unique(labels[fit])) != classes
            or len(np.unique(labels[valid])) != classes
        ):
            raise ValueError("An inner split is missing an activity class")
    metadata = {
        "name": name,
        "source_url": loader.DATA_URL,
        "archive": str(archive.resolve()),
        "archive_sha256": archive_hash,
        "source_files": [
            {
                "path": str(archive.resolve()),
                "source_url": loader.DATA_URL,
                "sha256": archive_hash,
            }
        ],
        "loader": str(source.resolve()),
        "loader_sha256": sha256(source),
        "shape": list(signals.shape),
        "classes": classes,
        "protocol": protocol,
        "preprocessing": preprocessing,
        "counts": {
            "train": len(train),
            "validation": len(validation),
            "test": len(test),
        },
        "subject_ids": {
            key: np.unique(subjects[value]).tolist()
            for key, value in (
                ("train", train),
                ("validation", validation),
                ("test", test),
            )
        },
        "inner_fold_sizes": [[len(fit), len(valid)] for fit, valid in inner_folds],
    }
    return {
        "name": name,
        "signals": signals,
        "labels": labels,
        "subjects": subjects,
        "record_ids": identifiers,
        "train": train,
        "validation": validation,
        "test": test,
        "inner_folds": inner_folds,
        "metadata": metadata,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("datasets", nargs="+", choices=("natops", *ARCHIVES))
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA)
    args = parser.parse_args()
    for dataset_name in args.datasets:
        result = load_dataset(dataset_name, args.data_dir, args.download)
        print(json.dumps(result["metadata"], indent=2), flush=True)
