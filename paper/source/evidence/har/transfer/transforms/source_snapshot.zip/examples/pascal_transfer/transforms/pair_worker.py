"""Compute disjoint cached inner DSADS pairs using the frozen study functions.

This parallelizes only the existing fixed validation computation. The study
coordinator validates all 28 files, then selects and performs final outer fits.
"""
from __future__ import annotations

import argparse
from itertools import combinations
from pathlib import Path
from time import perf_counter

import numpy as np
import study
import torch
from threadpoolctl import threadpool_limits


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--shard", type=int, required=True)
    parser.add_argument("--shards", type=int, default=3)
    parser.add_argument("--output", type=Path, default=study.HERE/"results/dsads")
    args = parser.parse_args()
    if not 0 <= args.shard < args.shards:
        raise ValueError("Invalid shard")
    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        unit = study.get_units("dsads", study.DEFAULT_DATA)[0]
        y, groups = unit["labels"], unit["subjects"]
        ids, names = np.arange(len(y)), study.menu("dsads")
        for number,(a,b) in enumerate(combinations(range(1,9),2)):
            if number % args.shards != args.shard:
                continue
            path = args.output/f"inner_exclude{a}_{b}.csv"
            if path.exists():
                continue
            start = perf_counter()
            fit = ids[(groups!=a)&(groups!=b)]
            va, vb = ids[groups==a], ids[groups==b]
            indices = np.r_[fit,va,vb]
            rows, seen = [], []
            for name, values, _ in study.features(unit,indices,len(fit),64):
                predictions = study.grid_predictions(values,len(fit),y[fit],True)
                for i,(prediction,(clip,penalty)) in enumerate(zip(predictions,study.PARAMS)):
                    for outer,held,actual,pred in ((b,a,y[va],prediction[:len(va)]),(a,b,y[vb],prediction[len(va):])):
                        rows.append({"outer_person":outer,"validation_person":held,"model":name,
                                     "clipped":clip,"penalty":study.previous.finite(penalty),
                                     "parameter_index":i,"loss_sum":study.loss(actual,pred,True),"n":len(pred)})
                seen.append(name)
            assert seen == names
            temporary = path.with_suffix(".tmp")
            study.write_csv(temporary,rows)
            temporary.replace(path)
            study.write_json(path.with_suffix(".worker.json"), {
                "shard":args.shard,"excluded":[a,b],"wall_s":perf_counter()-start,
                "study_sha256":study.sha256(study.HERE/"study.py"),
                "streams_sha256":study.sha256(study.HERE/"streams.py"),
                "worker_sha256":study.sha256(Path(__file__)),"grid_sha256":study.sha256(path),
                "scope":"Identical frozen study feature/grid/loss functions; no outer test scoring or model changes"})
            print(f"PAIR {a},{b} done in {perf_counter()-start:.1f}s",flush=True)


if __name__ == "__main__":
    main()
