"""Transfer the fixed HAR raw/spectral Pascal menu to other real datasets."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
from pathlib import Path
from time import perf_counter

os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import numpy as np
import scipy
import scipy.linalg
import sklearn
import torch
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

from features import MODELS, build_features, self_check as check_features
from datasets import DEFAULT_DATA, load_dataset, sha256

HERE = Path(__file__).resolve().parent
ALPHAS = (.01, .03, .1, .3, 1., 3., 10., 30., 100., 300., 1000.)


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def write_csv(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def ridge_grid(train, target, query, alphas, classification=True):
    """One symmetric decomposition for a grid; direct LU for a selected refit.

    Minimize summed squared error + alpha ||W||², with an unpenalized
    intercept. All calibration and relative constant removal use train only.
    Predictions from this function never depend on query labels.
    """
    train = np.asarray(train, dtype=np.float64)
    query = np.asarray(query, dtype=np.float64)
    if not np.isfinite(train).all() or not np.isfinite(query).all():
        raise ValueError("Nonfinite features")
    magnitude = np.max(np.abs(train), axis=0)
    keep = train.std(0) > 1e-6 * magnitude
    if classification:
        classes = np.unique(target)
        y = 2. * (target[:, None] == classes) - 1.
    else:
        y = np.asarray(target, dtype=np.float64).reshape(len(target), -1)
    intercept = y.mean(0)
    centered = y - intercept
    if not keep.any():
        scores = np.broadcast_to(intercept, (len(query), len(intercept)))
        prediction = classes[scores.argmax(1)] if classification else scores.copy()
        return [prediction.copy() for _ in alphas], {"features": 0, "removed": len(keep)}
    scaler = StandardScaler()
    x = scaler.fit_transform(train[:, keep])
    z = scaler.transform(query[:, keep])
    dual = len(x) < x.shape[1]
    gram = x @ x.T if dual else x.T @ x
    rhs = centered if dual else x.T @ centered
    query_basis = z @ x.T if dual else z
    predictions = []
    if len(alphas) == 1:
        alpha = alphas[0]
        if np.isinf(alpha):
            scores = np.broadcast_to(intercept, (len(z), len(intercept)))
        else:
            gram.flat[::len(gram) + 1] += alpha
            scores = query_basis @ np.linalg.solve(gram, rhs) + intercept
        predictions.append(classes[scores.argmax(1)] if classification else scores)
    else:
        eigenvalues, vectors = scipy.linalg.eigh(gram, driver="evd", check_finite=False,
                                               overwrite_a=True)
        if eigenvalues.min() < -1e-8 * max(1., eigenvalues.max()):
            raise ArithmeticError("Gram matrix has unexpectedly negative eigenvalues")
        eigenvalues = np.maximum(eigenvalues, 0.)
        rhs = vectors.T @ rhs
        query_basis = query_basis @ vectors
        for alpha in alphas:
            scores = query_basis @ (rhs / (eigenvalues[:, None] + alpha)) + intercept
            predictions.append(classes[scores.argmax(1)] if classification else scores)
    return predictions, {"features": int(keep.sum()), "removed": int((~keep).sum())}


def choose_alpha(scores, alphas, classification):
    """Scores are correct counts or MSE; largest penalty breaks ties."""
    if classification:
        return max(range(len(alphas)), key=lambda i: (scores[i], alphas[i]))
    best = min(scores)
    tolerance = 1e-10 * max(1., abs(best))
    return max((i for i in range(len(alphas)) if scores[i] <= best + tolerance),
               key=lambda i: alphas[i])


def make_features(unit, indices, n_train, batch_size):
    clock = None
    if "clock_end" in unit:
        clock = unit["clock_end"][indices, None] * np.linspace(0, 1, unit["signals"].shape[1])
    values = build_features(unit["signals"][indices], n_train, batch_size, clock=clock)
    if "auxiliary" in unit:
        auxiliary = np.asarray(unit["auxiliary"])[indices].reshape(len(indices), -1)
        values = {key: np.column_stack((x, auxiliary)) for key, x in values.items()}
    if unit.get("dataset") == "ninapro":
        # The original strong control sees exactly the same six MAV observations.
        values["lagged_mav"] = unit["signals"][indices].reshape(len(indices), -1)
    return values


def metrics(target, prediction, classification):
    if classification:
        return {"accuracy": accuracy_score(target, prediction),
                "macro_f1": f1_score(target, prediction, average="macro", zero_division=0),
                "errors": int((target != prediction).sum())}
    target = np.asarray(target).reshape(prediction.shape)
    residual = target - prediction
    denominator = np.square(target - target.mean(0)).sum()
    return {"mae": float(np.abs(residual).mean()),
            "rmse": float(np.sqrt(np.square(residual).mean())),
            "r2": float(1 - np.square(residual).sum() / denominator) if denominator else None}


def run_unit(unit, output, batch_size):
    output.mkdir(parents=True, exist_ok=False)
    classification = unit.get("classification", True)
    target = unit["labels"] if classification else unit["target"]
    name = unit["name"]
    train, test = unit["train"], unit["test"]
    folds = unit.get("inner_folds", [(train, unit["validation"])])
    # HAR uses summed-error alpha. Regression preserves the sibling examples'
    # mean-error penalty and broad KIMORE shrinkage range including the mean.
    penalties = (ALPHAS if classification else
                 tuple(10. ** k for k in range(-4, 13)) + (float("inf"),)
                 if unit.get("dataset") == "kimore" else
                 (1e-4, 1e-3, 1e-2, 1e-1, 1., 10.))
    expected_models = (*MODELS, "lagged_mav") if unit.get("dataset") == "ninapro" else MODELS
    protocol = {
        "name": name, "models": expected_models, "classification": classification,
        "penalties": [a if np.isfinite(a) else "infinity" for a in penalties],
        "penalty_convention": "SSE" if classification else "MSE, alpha = penalty * n_train",
        "alpha_tie": "largest penalty", "model_tie": "first in fixed model order",
        "dataset": unit.get("metadata", {}), "shape": list(unit["signals"].shape),
        "train_indices": train.tolist(), "test_indices": test.tolist(),
        "inner_folds": [{"train": a.tolist(), "validation": b.tolist()} for a, b in folds],
        "preprocessing": "Axis scaling, constant mask and feature scaling refit in every inner fold; final fit uses outer training only.",
        "source_sha256": {p.name: sha256(p) for p in HERE.glob("*.py")},
    }
    write_json(output / "protocol.json", protocol)
    started = perf_counter()
    grid = []
    scores = {model: np.zeros(len(penalties)) for model in expected_models}
    count = 0
    for fold, (fit, validation) in enumerate(folds):
        if np.intersect1d(fit, validation).size or np.intersect1d(np.r_[fit, validation], test).size:
            raise ValueError("Training/validation/test leakage")
        tick = perf_counter()
        values = make_features(unit, np.r_[fit, validation], len(fit), batch_size)
        feature_s = perf_counter() - tick
        print(f"{name}: fold {fold + 1}/{len(folds)} features {feature_s:.2f}s", flush=True)
        alphas = penalties if classification else [p * len(fit) for p in penalties]
        for model in expected_models:
            x = values[model]
            predictions, info = ridge_grid(x[:len(fit)], target[fit], x[len(fit):], alphas, classification)
            for j, (penalty, prediction) in enumerate(zip(penalties, predictions)):
                score = int((prediction == target[validation]).sum()) if classification else float(
                    np.square(prediction - target[validation].reshape(prediction.shape)).mean())
                scores[model][j] += score if classification else score * len(validation)
                grid.append({"model": model, "fold": fold, "penalty": penalty,
                             "validation_score": score / len(validation) if classification else score,
                             **info})
            print(f"  {model}: grid complete ({info['features']} features)", flush=True)
        count += len(validation)
        del values
    selected = {model: choose_alpha(scores[model], penalties, classification) for model in expected_models}
    selected_scores = {model: float(scores[model][j] / count) for model, j in selected.items()}
    winner = (max if classification else min)(expected_models, key=lambda model: selected_scores[model])
    choices = {"validation_selected_model": winner,
               "models": {model: {"penalty": penalties[j] if np.isfinite(penalties[j]) else "infinity",
                                   "validation_score": selected_scores[model]}
                          for model, j in selected.items()}}
    # Persist all choices before building test features or inspecting test scores.
    write_json(output / "selection.json", choices)
    write_csv(output / "grid.csv", grid)
    tick = perf_counter()
    values = make_features(unit, np.r_[train, test], len(train), batch_size)
    feature_s = perf_counter() - tick
    rows, predictions_saved, confusions = [], {}, {}
    for model in expected_models:
        tick = perf_counter()
        penalty = penalties[selected[model]]
        alpha = penalty if classification else penalty * len(train)
        x = values[model]
        predictions, info = ridge_grid(x[:len(train)], target[train], x[len(train):], [alpha], classification)
        prediction = predictions[0]
        row = {"dataset": unit.get("dataset", name), "unit": name, "model": model,
               "selected": model == winner, "penalty": penalty, **info,
               "validation_score": selected_scores[model], **metrics(target[test], prediction, classification),
               "fit_predict_s": perf_counter() - tick}
        rows.append(row)
        predictions_saved[model] = prediction
        if classification:
            confusions[model] = confusion_matrix(target[test], prediction, labels=np.unique(target)).tolist()
        print(f"{name} {model}: {metrics(target[test], prediction, classification)}", flush=True)
    predictions_saved.update(target=target[test], test_indices=test, train_indices=train)
    np.savez_compressed(output / "predictions.npz", **predictions_saved)
    write_csv(output / "results.csv", rows)
    write_json(output / "run.json", {
        "wall_s": perf_counter() - started, "final_shared_features_s": feature_s,
        "confusion_matrices": confusions, "selection": choices,
        "software": {"python": platform.python_version(), "numpy": np.__version__,
                     "scipy": scipy.__version__, "torch": torch.__version__, "sklearn": sklearn.__version__,
                     "platform": platform.platform(), "threads": 1},
        "record_ids": list(unit.get("record_ids", [])),
    })
    return rows


def self_check():
    checks = check_features()
    rng = np.random.default_rng(625)
    from sklearn.linear_model import Ridge, RidgeClassifier
    from sklearn.pipeline import make_pipeline
    for width in (7, 80):
        x, query = rng.normal(size=(40, width)), rng.normal(size=(11, width))
        x[:, -1] = 1
        query[:, -1] = 100
        for classification in (True, False):
            y = np.arange(40) % 3 if classification else rng.normal(size=(40, 2))
            predictions, _ = ridge_grid(x, y, query, (.01, 10., 1000.), classification)
            for alpha, actual in zip((.01, 10., 1000.), predictions):
                estimator = RidgeClassifier if classification else Ridge
                model = make_pipeline(StandardScaler(), estimator(alpha=alpha, solver="lsqr", tol=1e-12))
                model.fit(x[:, :-1], y)
                expected = model.predict(query[:, :-1])
                if classification:
                    np.testing.assert_array_equal(actual, expected)
                else:
                    np.testing.assert_allclose(actual, expected, atol=1e-9, rtol=1e-7)
                direct, _ = ridge_grid(x, y, query, [alpha], classification)
                np.testing.assert_allclose(actual, direct[0], atol=1e-9, rtol=1e-7)
    assert choose_alpha([2, 3, 3], (.01, 10., 1000.), True) == 2
    checks["checks"].extend(["ridge grids against sklearn LSQR in primal/dual", "eigen grid versus LU refit", "tie rule"])
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--datasets", nargs="+", default=["natops", "utd_mhad", "dsads"],
                        choices=["natops", "utd_mhad", "dsads", "kimore", "ninapro"])
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA)
    parser.add_argument("--output", type=Path, default=HERE / "results")
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--self-check", action="store_true")
    args = parser.parse_args()
    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        if args.self_check:
            print(json.dumps(self_check(), indent=2))
            return
        for name in args.datasets:
            if name in ("kimore", "ninapro"):
                from regression_datasets import kimore_units, ninapro_units
                units = (kimore_units if name == "kimore" else ninapro_units)(args.data / name)
            else:
                unit = load_dataset(name, args.data, args.download)
                unit.update(dataset=name, classification=True)
                units = [unit]
            for unit in units:
                run_unit(unit, args.output / unit["name"], args.batch_size)


if __name__ == "__main__":
    main()
