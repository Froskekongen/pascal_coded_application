"""Generic raw and spectral versions of the retained HAR Pascal features.

The training prefix alone fits axis scaling. P1/P3 raw features integrate
observations as increments; the geometric control instead follows observed
positions with a clock and a prepended origin. Spectral features use the
supplied axes, without HAR-specific norms, derivatives or sensor geometry.
"""

from pathlib import Path
import sys

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "uci_har"))
from retained_features import (  # noqa: E402
    moment_summary,
    pascal_code,
    pascal_signature,
    raw_logsignature,
    standardize_axes,
)
from tensorsig.classical.signatures import signature
from tensorsig.offset_coded_signatures.plans import LocalRealization


MODELS = (
    "moments", "ordinary_path_log", "ordinary_raw_log", "ordinary_raw_tensor",
    "raw_log", "raw_tensor", "spectral_pool", "spectral_factorized_log",
    "spectral_log", "spectral_tensor", "raw_spectral_factorized_log",
    "raw_spectral_log", "raw_spectral_tensor", "pool_raw_log", "pool_raw_tensor",
)


def ordinary_raw_signature(x: torch.Tensor, batch_size: int) -> np.ndarray:
    """P1 integrated observations, with the same QR and /N scaling as P3."""
    samples, channels = x.shape[1:]
    plan = LocalRealization(pascal_code(samples, 1), channels=channels,
                            max_depth=2).signature(coordinates="dense")
    return np.concatenate([
        plan.evaluate((batch / samples)[:, None])[:, 0].float().numpy().copy()
        for batch in x.split(batch_size)
    ])


def ordinary_path_logsignature(x: torch.Tensor, batch_size: int,
                              clock: torch.Tensor | None = None) -> np.ndarray:
    """Observed positions with a supplied/default clock and prepended origin."""
    if clock is None:
        clock = torch.linspace(0, 1, x.shape[1], dtype=x.dtype)[None].expand(len(x), -1)
    parts = []
    for start in range(0, len(x), batch_size):
        path = torch.cat((x[start:start + batch_size], clock[start:start + batch_size, :, None]), 2)
        path = torch.cat((torch.zeros_like(path[:, :1]), path), 1)
        parts.append(raw_logsignature(signature(path, 2).float().numpy(), width=path.shape[2]))
    return np.concatenate(parts)


def spectrum(x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """One-sided power masses, energy, and HAR's 18 pooled readouts per axis.

    Parseval weighting handles odd and even lengths. A spectrum with energy
    at most 1e-20 gets zero mass, with its actual energy retained separately;
    this defines finite features for missing variation after axis calibration.
    """
    samples, channels = x.shape[1:]
    power = (torch.fft.rfft(x, dim=1).abs() / samples).square()
    power[:, 1:power.shape[1] - (samples % 2 == 0)] *= 2
    energy = power.sum(1)
    mass = torch.where(energy[:, None] > 1e-20,
                       power / energy.clamp_min(1e-20)[:, None], 0.)
    frequency = 2 * torch.fft.rfftfreq(samples, dtype=x.dtype)
    centroid = (mass * frequency[None, :, None]).sum(1)
    spread = (mass * (frequency[None, :, None] - centroid[:, None]).square()).sum(1).sqrt()
    entropy = -(mass * mass.clamp_min(1e-20).log()).sum(1)
    peak = frequency[power.argmax(1)]
    bands = torch.cat([
        mass[:, (frequency >= band / 8) &
             (frequency < (band + 1) / 8 if band < 7 else frequency <= 1)].sum(1)
        for band in range(8)
    ], 1)
    summary = moment_summary(power.sqrt())
    amplitude_statistics = torch.cat((summary[:, :2 * channels],
                                      summary[:, 4 * channels:6 * channels]), 1)
    pool = torch.cat((amplitude_statistics, energy, energy.log1p(), centroid,
                      spread, entropy, peak, bands), 1)
    return mass, energy, pool


def factorized_spectral_logsignature(tensor: np.ndarray, channels: int) -> np.ndarray:
    """Keep within-axis P3 endpoints/areas from the joint spectral tensor.

    The /sqrt(2) area convention matches retained HAR spectral features.
    Zero-mass axes can make the usually constant q0 endpoint variable, so
    constant-column removal is left to the runner's training-only mask.
    """
    width = 3 * channels
    second = tensor[:, width:].reshape(-1, width, width)
    left, right = np.triu_indices(3, 1)
    parts = []
    for channel in range(channels):
        indices = slice(3 * channel, 3 * (channel + 1))
        block = second[:, indices, indices]
        parts.append(np.concatenate((tensor[:, indices],
                                     (block[:, left, right] - block[:, right, left]) / np.sqrt(2)), 1))
    return np.concatenate(parts, 1).astype(np.float32, copy=False)


@torch.inference_mode()
def build_features(signals: np.ndarray, n_train: int,
                   batch_size: int = 64, *,
                   clock: np.ndarray | None = None) -> dict[str, np.ndarray]:
    """Build a fixed comparison menu, fitting every axis scale on training rows.

    Spectral signatures integrate p[k] q[k], not p[k] q[k]/K. Each spectral
    signature map includes energy and log1p(energy) exactly once, since mass
    normalization removes amplitude. Arithmetic is float64 with stored
    feature coordinates float32, matching retained HAR signature storage.
    Optional (N,T) clocks affect only the ordinary geometric path control.
    """
    x = torch.as_tensor(signals, dtype=torch.float64)
    if (x.ndim != 3 or x.shape[1] < 4 or x.shape[2] < 1
            or not 1 <= n_train <= len(x) or batch_size < 1
            or not torch.isfinite(x).all()):
        raise ValueError("Expected finite (N,T,C) signals, T>=4, C>=1, training prefix and positive batch size")
    if clock is not None:
        clock = torch.as_tensor(clock, dtype=x.dtype)
        if clock.shape != x.shape[:2] or not torch.isfinite(clock).all():
            raise ValueError("Expected a finite clock with shape (N,T)")
    channels = x.shape[2]
    x = standardize_axes(x, n_train)
    ordinary_tensor = ordinary_raw_signature(x, batch_size)
    raw_tensor = pascal_signature(x, batch_size)
    raw_log = raw_logsignature(raw_tensor, width=3 * channels)
    mass, energy, pool = spectrum(x)
    spectral_tensor = pascal_signature(mass * mass.shape[1], batch_size)
    spectral_log = raw_logsignature(spectral_tensor, width=3 * channels)
    factorized_log = factorized_spectral_logsignature(spectral_tensor, channels)
    scale = torch.cat((energy, energy.log1p()), 1).float().numpy()
    spectral_log = np.concatenate((spectral_log, scale), 1)
    spectral_tensor = np.concatenate((spectral_tensor, scale), 1)
    factorized_log = np.concatenate((factorized_log, scale), 1)
    pool = pool.float().numpy()
    models = {
        "moments": moment_summary(x).float().numpy(),
        "ordinary_path_log": ordinary_path_logsignature(x, batch_size, clock),
        "ordinary_raw_log": raw_logsignature(ordinary_tensor, width=channels),
        "ordinary_raw_tensor": ordinary_tensor,
        "raw_log": raw_log,
        "raw_tensor": raw_tensor,
        "spectral_pool": pool,
        "spectral_factorized_log": factorized_log,
        "spectral_log": spectral_log,
        "spectral_tensor": spectral_tensor,
        "raw_spectral_factorized_log": np.concatenate((raw_log, factorized_log), 1),
        "raw_spectral_log": np.concatenate((raw_log, spectral_log), 1),
        "raw_spectral_tensor": np.concatenate((raw_tensor, spectral_tensor), 1),
        "pool_raw_log": np.concatenate((pool, raw_log), 1),
        "pool_raw_tensor": np.concatenate((pool, raw_tensor), 1),
    }
    if tuple(models) != MODELS or not all(np.isfinite(a).all() for a in models.values()):
        raise ValueError("Nonfinite feature values or changed model order")
    return models


def self_check() -> dict:
    """Small direct-accumulation, spectrum, geometry and leakage checks."""
    from retained_features import spectral_logsignature

    rng = np.random.default_rng(5071)
    z = torch.as_tensor(rng.normal(size=(5, 13, 3)), dtype=torch.float64)
    for columns, actual in ((1, ordinary_raw_signature(z, 2)), (3, pascal_signature(z, 2))):
        q = pascal_code(z.shape[1], columns).matrix
        increments = ((z / z.shape[1])[..., None] * q[None, :, None]).flatten(2)
        prefix = increments.cumsum(1) - increments / 2
        second = torch.einsum("nti,ntj->nij", prefix, increments).flatten(1)
        expected = torch.cat((increments.sum(1), second), 1).numpy()
        np.testing.assert_allclose(actual, expected, atol=1e-7, rtol=1e-6)
    for samples in (12, 13):
        x = torch.as_tensor(rng.normal(size=(5, samples, 3)), dtype=torch.float64)
        x[0, :, 0] = 0
        mass, energy, pool = spectrum(x)
        np.testing.assert_allclose(energy.numpy(), x.square().mean(1).numpy(), atol=2e-14)
        np.testing.assert_allclose(mass.sum(1).numpy(), (energy > 1e-20).numpy(), atol=2e-14)
        assert pool.shape == (5, 54) and torch.isfinite(pool).all()
        np.testing.assert_array_equal(mass[0, :, 0].numpy(), np.zeros(mass.shape[1]))
        tensor = pascal_signature(mass * mass.shape[1], 2)
        np.testing.assert_allclose(factorized_spectral_logsignature(tensor, 3),
                                   spectral_logsignature(mass, 2), atol=1e-7, rtol=1e-6)
    signals = rng.normal(size=(7, 12, 2))
    models = build_features(signals, 4, 2)
    expected_widths = (16, 6, 3, 6, 21, 42, 36, 16, 25, 46, 37, 46, 88, 57, 78)
    assert tuple(models) == MODELS
    assert tuple(a.shape[1] for a in models.values()) == expected_widths
    assert all(a.dtype == np.float32 for a in models.values())
    clock = np.broadcast_to(np.linspace(0, 2, 12), (7, 12)).copy()
    clocked = build_features(signals, 4, 2, clock=clock)
    for name in MODELS:
        if name != "ordinary_path_log":
            np.testing.assert_array_equal(models[name], clocked[name])
    np.testing.assert_array_equal(clocked["ordinary_path_log"][:, 2], np.full(7, 2.))
    changed = signals.copy()
    changed[4:] = changed[4:] * 3 + 17
    altered = build_features(changed, 4, 2)
    for name, values in models.items():
        np.testing.assert_array_equal(values[:4], altered[name][:4])
    zeros = build_features(np.zeros((3, 8, 2)), 2, 2)
    assert all(np.isfinite(a).all() for a in zeros.values())
    return {"status": "passed", "checks": ["P1/P3 direct accumulation", "odd/even Parseval",
            "zero spectrum", "HAR factorized spectral agreement", "model dimensions",
            "training-prefix independence", "constant signals", "optional clock isolation", "float32 storage"]}


if __name__ == "__main__":
    print(self_check())
