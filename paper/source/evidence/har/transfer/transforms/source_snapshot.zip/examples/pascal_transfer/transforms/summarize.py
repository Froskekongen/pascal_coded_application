"""Recompute saved metrics/selections; summarize the fixed transform study.

No fitting or tuning occurs here. Test-ranked plot rows are descriptive only.
Run with the existing plotting Python, or use --no-plots for NumPy-only tables.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from summary import metrics  # Independent NumPy implementation, not study.py's scorer.

SELECTED = "validation_selected"
EXPECTED = {"natops", "utd_mhad", "uci_har", *(f"dsads_person{i}" for i in range(1, 9)),
            *(f"kimore_ex{e}_fold{f}" for e in range(1, 6) for f in range(5)),
            *(f"ninapro_s1_reps{r}" for r in (1, 2, 5, 10))}
ACTIVITIES = ("sitting", "standing", "lying_back", "lying_right", "stairs_up", "stairs_down",
              "elevator_still", "elevator_moving", "walking_parking", "treadmill_flat",
              "treadmill_incline", "running", "stepper", "cross_trainer", "cycling_horizontal",
              "cycling_vertical", "rowing", "jumping", "basketball")
METRICS = ("accuracy", "macro_f1", "errors", "mae", "rmse", "r2")
KINDS = ("raw_log", "spectral_log", "joint_log", "joint_endpoints", "joint_p1", "joint_tensor")


def read_csv(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def same(actual, expected, context):
    if ((actual is None) != (expected is None) or
            (actual is not None and not np.isclose(float(actual), float(expected), atol=1e-12, rtol=1e-10))):
        raise ValueError(f"{context}: {actual} != {expected}")


def verify_grid(directory, protocol, selection):
    """Recreate each choice from losses, including complete fold/parameter keys."""
    models, parameters, folds = protocol["models"], protocol["parameters"], protocol["folds"]
    parameters = [(bool(clip), float(penalty)) for clip, penalty in parameters]
    scores = {model: np.zeros(len(parameters)) for model in models}
    if protocol["dataset"] == "dsads":
        person = int(protocol["unit"].split("person")[1])
        fold_ids = [p for p in range(1, 9) if p != person]
        fold_key = "validation_person"
    else:
        person, fold_ids, fold_key = None, list(range(len(folds))), "fold"
    counts = dict(zip(fold_ids, [len(fold["validation"]) for fold in folds]))
    expected = {(fold, model, clip, penalty) for fold in fold_ids for model in models for clip, penalty in parameters}
    seen = set()
    grid = read_csv(directory / "grid.csv")
    for row in grid:
        fold, model = int(row[fold_key]), row["model"]
        parameter = (row["clipped"] == "True", float(row["penalty"]))
        key = (fold, model, *parameter)
        if key not in expected or key in seen or int(row["n"]) != counts[fold]:
            raise ValueError(f"{directory}: duplicate/invalid validation grid row {key}")
        index = parameters.index(parameter)
        if person is not None and (int(row["outer_person"]) != person or int(row["parameter_index"]) != index):
            raise ValueError(f"{directory}: wrong outer person or parameter index")
        value = float(row["loss_sum"])
        if not np.isfinite(value) or value < 0 or (protocol["classification"] and (value > counts[fold] or value != int(value))):
            raise ValueError(f"{directory}: invalid validation loss")
        scores[model][index] += value
        seen.add(key)
    if seen != expected:
        raise ValueError(f"{directory}: missing {len(expected - seen)} validation rows")
    n_validation = sum(counts.values())
    if n_validation != selection["n_validation"]:
        raise ValueError(f"{directory}: validation sample count differs")
    losses = {}
    for model, values in scores.items():
        minimum = values.min()
        candidates = np.flatnonzero(values <= minimum + 1e-10 * max(1., abs(minimum)))
        chosen = max(candidates, key=lambda i: (parameters[i][1], not parameters[i][0]))
        choice = selection["models"][model]
        if (choice["parameter_index"] != chosen or (choice["clipped"], float(choice["penalty"])) != parameters[chosen]):
            raise ValueError(f"{directory}/{model}: grid does not reproduce chosen parameters")
        losses[model] = values[chosen] / n_validation
        same(choice["validation_loss"], losses[model], f"{directory}/{model}/validation_loss")
    if selection["winner"] != min(models, key=losses.get):
        raise ValueError(f"{directory}: grid does not reproduce selected model")
    return len(grid)


def load_runs(root):
    runs, incomplete, grid_rows = [], [], 0
    master = json.loads((HERE / "protocol.json").read_text())
    source_hashes = {}
    for file in sorted(root.rglob("protocol.json")):
        directory, protocol = file.parent, json.loads(file.read_text())
        if "unit" not in protocol:  # Study-level protocol is not an evaluation unit.
            continue
        name = protocol["unit"]
        if protocol["models"] != master["models"][protocol["dataset"]] or protocol["parameters"] != master["parameters"]:
            raise ValueError(f"{name}: menu differs from the fixed study protocol")
        for source, expected_hash in protocol["source_sha256"].items():
            if source not in source_hashes:
                source_hashes[source] = hashlib.sha256((HERE.parent.parent / source).read_bytes()).hexdigest()
            if source_hashes[source] != expected_hash:
                raise ValueError(f"{name}: source hash differs for {source}")
            pin = master.get("resolved_source_sha256", master["source_sha256"]).get(Path(source).name)
            if pin is not None and pin != expected_hash:
                raise ValueError(f"{name}: source differs from the resolved master pin for {source}")
        required = ("run.json", "results.csv", "selection.json", "predictions.npz", "grid.csv")
        if not all((directory / item).exists() for item in required):
            incomplete.append(name)
            continue
        if not json.loads((directory / "run.json").read_text())["complete"]:
            raise ValueError(f"{name}: completion marker is false")
        selection = json.loads((directory / "selection.json").read_text())
        rows = read_csv(directory / "results.csv")
        models = protocol["models"]
        if [row["model"] for row in rows] != models or list(selection["models"]) != models:
            raise ValueError(f"{name}: model menu/order differs")
        if [row["model"] for row in rows if row["selected"] == "True"] != [selection["winner"]]:
            raise ValueError(f"{name}: selected result row differs")
        with np.load(directory / "predictions.npz", allow_pickle=False) as archive:
            saved = {key: archive[key] for key in archive.files}
        if set(saved) != {*models, "target", "train_indices", "test_indices"}:
            raise ValueError(f"{name}: unexpected prediction archive keys")
        for split in ("train", "test"):
            np.testing.assert_array_equal(saved[f"{split}_indices"], protocol[f"{split}_indices"])
            if len(np.unique(saved[f"{split}_indices"])) != len(saved[f"{split}_indices"]):
                raise ValueError(f"{name}: repeated {split} index")
        test = saved["test_indices"]
        if np.intersect1d(saved["train_indices"], test).size:
            raise ValueError(f"{name}: outer split overlaps")
        for fold in protocol["folds"]:
            if np.intersect1d(fold["train"], fold["validation"]).size or np.intersect1d(test, fold["train"] + fold["validation"]).size:
                raise ValueError(f"{name}: inner split overlaps itself or test")
        target = saved["target"]
        if len(target) != len(test) or not np.isfinite(target).all():
            raise ValueError(f"{name}: invalid test targets")
        for row in rows:
            model, choice = row["model"], selection["models"][row["model"]]
            prediction = saved[model]
            if prediction.shape != target.shape or not np.isfinite(prediction).all():
                raise ValueError(f"{name}/{model}: invalid prediction shape or values")
            if (row["clipped"] == "True") != choice["clipped"] or float(row["penalty"]) != float(choice["penalty"]):
                raise ValueError(f"{name}/{model}: saved parameters differ")
            same(row["validation_loss"], choice["validation_loss"], f"{name}/{model}/validation_loss")
            for key, value in metrics(target, prediction, protocol["classification"]).items():
                same(None if row[key] == "" else float(row[key]), value, f"{name}/{model}/{key}")
        grid_rows += verify_grid(directory, protocol, selection)
        runs.append({"name": name, "dataset": protocol["dataset"], "protocol": protocol, "selection": selection,
                         "rows": rows, "saved": saved, "directory": directory})
    if len({run["name"] for run in runs}) != len(runs):
        raise ValueError("Duplicate completed unit name")
    return runs, incomplete, grid_rows


def predictions(run):
    return {**{name: run["saved"][name] for name in run["protocol"]["models"]},
            SELECTED: run["saved"][run["selection"]["winner"]]}


def metric_rows(dataset, unit, scope, target, estimates, classification):
    return [dict(dataset=dataset, unit=unit, scope=scope, model=model, n_test=len(target),
                 **metrics(target, value, classification)) for model, value in estimates.items()]


def comparison_pairs(models):
    models = set(models)
    pairs = {}
    for model in sorted(models):
        if "__" not in model:
            continue
        transform, kind = model.split("__")
        for first, second in (("spectral_log", "raw_log"), ("joint_log", "raw_log"),
                              ("joint_log", "spectral_log"), ("joint_log", "joint_endpoints"),
                              ("joint_log", "joint_p1"), ("joint_tensor", "joint_log")):
            a, b = f"{transform}__{first}", f"{transform}__{second}"
            if a in models and b in models:
                pairs[a, b] = "within_transform"
        identity = f"identity__{kind}"
        if transform != "identity" and identity in models:
            pairs[model, identity] = "matched_transform_vs_identity"
        if kind == "joint_log":
            for baseline in sorted(name for name in models if name.startswith("baseline_")):
                pairs[model, baseline] = "joint_vs_baseline"
    if SELECTED in models:
        for baseline in sorted(name for name in models if name.startswith("baseline_")):
            pairs[SELECTED, baseline] = "selected_vs_baseline"
        if "identity__joint_log" in models:
            pairs[SELECTED, "identity__joint_log"] = "selected_vs_identity_joint"
    return [(a, b, purpose) for (a, b), purpose in pairs.items()]


def contrasts(dataset, unit, scope, target, estimates, classification):
    result = []
    for candidate, baseline, purpose in comparison_pairs(estimates):
        new, old = estimates[candidate], estimates[baseline]
        row = {"dataset": dataset, "unit": unit, "scope": scope, "purpose": purpose, "candidate": candidate,
                   "baseline": baseline, "n_test": len(target)}
        if classification:
            good, before = new == target, old == target
            row.update(accuracy_gain_pp=float(100 * (good.mean() - before.mean())),
                       fewer_errors=int(good.sum() - before.sum()),
                       candidate_only_correct=int(np.sum(good & ~before)),
                       baseline_only_correct=int(np.sum(before & ~good)))
        else:
            first, second = metrics(target, new, False), metrics(target, old, False)
            row.update(mae_reduction=second["mae"] - first["mae"], rmse_reduction=second["rmse"] - first["rmse"],
                       r2_gain=first["r2"] - second["r2"] if first["r2"] is not None and second["r2"] is not None else None)
        result.append(row)
    return result


def pool(runs):
    models = list(predictions(runs[0]))
    if any(list(predictions(run)) != models for run in runs):
        raise ValueError("Pooled models differ")
    return np.concatenate([run["saved"]["target"] for run in runs]), {
        model: np.concatenate([predictions(run)[model] for run in runs]) for model in models}


def summarize(runs):
    unit_rows, aggregate, paired, dsads_stats = [], [], [], []
    for run in runs:
        dataset, name = run["dataset"], run["name"]
        classification, estimates = run["protocol"]["classification"], predictions(run)
        rows = metric_rows(dataset, name, "outer_test", run["saved"]["target"], estimates, classification)
        by_model = {row["model"]: row for row in run["rows"]}
        for row in rows:
            actual_model = run["selection"]["winner"] if row["model"] == SELECTED else row["model"]
            fitted = by_model[actual_model]
            row.update(selected_model=actual_model if row["model"] == SELECTED else "",
                       selected=actual_model == run["selection"]["winner"], features=int(fitted["features"]),
                       clipped=fitted["clipped"] == "True", penalty=fitted["penalty"], validation_loss=float(fitted["validation_loss"]))
        unit_rows.extend(rows)
        paired.extend(contrasts(dataset, name, "outer_test", run["saved"]["target"], estimates, classification))
    dsads = sorted((r for r in runs if r["dataset"] == "dsads"), key=lambda r: r["name"])
    if len(dsads) == 8:
        indices = np.concatenate([r["saved"]["test_indices"] for r in dsads])
        np.testing.assert_array_equal(np.sort(indices), np.arange(9120))
        for run in dsads:
            if len(run["saved"]["test_indices"]) != 1140 or len(run["saved"]["train_indices"]) != 7980:
                raise ValueError("DSADS person does not have the full expected outer split")
            for fold in run["protocol"]["folds"]:
                np.testing.assert_array_equal(np.sort(fold["train"] + fold["validation"]), np.sort(run["saved"]["train_indices"]))
            held_people = [r for r in dsads if r["name"] != run["name"]]
            for fold, held in zip(run["protocol"]["folds"], held_people):
                np.testing.assert_array_equal(fold["validation"], held["saved"]["test_indices"])
        target, estimates = pool(dsads)
        aggregate.extend(metric_rows("dsads", "dsads_all8", "pooled_outer_tests", target, estimates, True))
        paired.extend(contrasts("dsads", "dsads_all8", "pooled_outer_tests", target, estimates, True))
        for model in estimates:
            rows = [r for r in unit_rows if r["dataset"] == "dsads" and r["model"] == model]
            row = {"dataset": "dsads", "model": model, "n_people": 8, "n_test": 9120,
                       "worst_accuracy_person": min(rows, key=lambda r: r["accuracy"])["unit"]}
            for key in ("accuracy", "macro_f1", "errors"):
                values = np.array([r[key] for r in rows])
                row.update({f"{key}_mean": float(values.mean()), f"{key}_sd": float(values.std(ddof=1)),
                            f"{key}_min": float(values.min()), f"{key}_max": float(values.max())})
            row["errors_total"] = int(sum(r["errors"] for r in rows))
            validation = 1 - np.array([r["validation_loss"] for r in rows])
            row.update(validation_accuracy_mean=float(validation.mean()), validation_accuracy_sd=float(validation.std(ddof=1)),
                       test_minus_validation_accuracy_pp_mean=float(100 * (row["accuracy_mean"] - validation.mean())))
            dsads_stats.append(row)
    exercises = []
    for exercise in range(1, 6):
        subset = sorted((r for r in runs if r["dataset"] == "kimore" and r["protocol"]["data"]["exercise"] == exercise), key=lambda r: r["name"])
        if len(subset) != 5:
            continue
        metadata = subset[0]["protocol"]["data"]["record_metadata"]
        if any(r["protocol"]["data"]["record_metadata"] != metadata for r in subset):
            raise ValueError(f"KIMORE exercise{exercise}: fold cohorts differ")
        if sorted(r["protocol"]["data"]["test_fold"] for r in subset) != list(range(5)):
            raise ValueError("KIMORE test folds differ")
        np.testing.assert_array_equal(np.sort(np.concatenate([r["saved"]["test_indices"] for r in subset])), np.arange(len(metadata)))
        target, estimates = pool(subset)
        name = f"kimore_ex{exercise}"
        aggregate.extend(metric_rows("kimore", name, "pooled_five_folds", target, estimates, False))
        paired.extend(contrasts("kimore", name, "pooled_five_folds", target, estimates, False))
        exercises.append(name)
    if len(exercises) == 5:
        for model in predictions(next(r for r in runs if r["dataset"] == "kimore")):
            rows = [r for r in aggregate if r["dataset"] == "kimore" and r["model"] == model]
            aggregate.append(dict(dataset="kimore", unit="kimore_macro", scope="mean_of_five_pooled_exercises", model=model,
                                  n_test=sum(r["n_test"] for r in rows), **{key: float(np.mean([r[key] for r in rows])) for key in ("mae", "rmse", "r2")}))
        grouped = defaultdict(list)
        for row in paired:
            if row["dataset"] == "kimore" and row["scope"] == "pooled_five_folds":
                grouped[row["candidate"], row["baseline"], row["purpose"]].append(row)
        for (candidate, baseline, purpose), rows in grouped.items():
            paired.append(dict(dataset="kimore", unit="kimore_macro", scope="mean_of_five_pooled_exercises", purpose=purpose,
                               candidate=candidate, baseline=baseline, n_test=sum(r["n_test"] for r in rows),
                               **{key: float(np.mean([r[key] for r in rows])) for key in ("mae_reduction", "rmse_reduction", "r2_gain")}))
    return unit_rows, aggregate, paired, dsads_stats


def average_ranks(values):
    """Ascending ranks with the average rank assigned to ties."""
    _, inverse, counts = np.unique(values, return_inverse=True, return_counts=True)
    return (np.cumsum(counts) - (counts - 1) / 2)[inverse]


def selection_diagnostics(runs, output):
    gaps, people, ranking_rows = [], [], []
    for run in runs:
        models, winner = run["protocol"]["models"], run["selection"]["winner"]
        classification = run["protocol"]["classification"]
        metric = "accuracy" if classification else "rmse"
        scores = np.array([float(row[metric]) for row in run["rows"]])
        selected = models.index(winner)
        best = scores.max() if classification else scores.min()
        validation_loss = run["selection"]["models"][winner]["validation_loss"]
        row = {"dataset": run["dataset"], "unit": run["name"], "selected_model": winner, "metric": metric,
                   "selected_test_value": float(scores[selected]), "selected_validation_loss": validation_loss,
                   "test_best_fixed_models": "|".join(model for model, value in zip(models, scores) if value == best),
                   "test_best_fixed_value": float(best),
                   "selection_gap": float(best - scores[selected] if classification else scores[selected] - best),
                   "gap_units": "accuracy_fraction" if classification else "RMSE",
                   "interpretation": "Test-best families are diagnostics only; they are not deployable selectors"}
        gaps.append(row)
        if run["dataset"] != "dsads":
            continue
        validation = np.array([1 - run["selection"]["models"][model]["validation_loss"] for model in models])
        vrank, trank = average_ranks(-validation), average_ranks(-scores)
        transform = np.array(["__" in model for model in models])
        correlation = lambda a, b: float(np.corrcoef(a, b)[0, 1]) if np.std(a) and np.std(b) else None
        people.append({"person": int(run["name"].split("person")[1]), "selected_model": winner,
                           "selected_validation_accuracy": float(validation[selected]), "selected_test_accuracy": float(scores[selected]),
                           "test_minus_validation_accuracy_pp": float(100 * (scores[selected] - validation[selected])),
                           "selected_test_rank": float(trank[selected]), "n_models": len(models),
                           "validation_test_spearman_all_models": correlation(vrank, trank),
                           "validation_test_spearman_transformed_models": correlation(average_ranks(-validation[transform]), average_ranks(-scores[transform])),
                           "test_best_fixed_models": row["test_best_fixed_models"], "test_best_fixed_accuracy": float(best),
                           "selected_to_test_best_gap_pp": float(100 * (best - scores[selected]))})
        for i, model in enumerate(models):
            ranking_rows.append({"unit": run["name"], "model": model, "validation_accuracy": float(validation[i]), "test_accuracy": float(scores[i]),
                                     "validation_rank": float(vrank[i]), "test_rank": float(trank[i]),
                                     "test_minus_validation_accuracy_pp": float(100 * (scores[i] - validation[i]))})
    write_csv(output / "validation_selection_gaps.csv", gaps)
    write_csv(output / "dsads_validation_test.csv", people)
    write_csv(output / "dsads_model_validation_test.csv", ranking_rows)
    write_csv(output / "selected_family_counts.csv", [{"dataset": dataset, "model": model, "selected_units": count}
              for (dataset, model), count in sorted(Counter((r["dataset"], r["selection"]["winner"]) for r in runs).items())])


def dsads_details(runs, paired, output):
    dsads = [r for r in runs if r["dataset"] == "dsads"]
    if len(dsads) != 8:
        return
    target, estimates = pool(dsads)
    confusion = np.zeros((19, 19), dtype=int)
    if not np.array_equal(np.unique(target), np.arange(19)) or np.any((estimates[SELECTED] < 0) | (estimates[SELECTED] >= 19)):
        raise ValueError("Expected DSADS class labels 0..18")
    np.add.at(confusion, (target.astype(int), estimates[SELECTED].astype(int)), 1)
    write_csv(output / "dsads_selected_confusion.csv", [dict(true_class=i, activity=name,
              **{f"predicted_{j}": int(count) for j, count in enumerate(confusion[i])}) for i, name in enumerate(ACTIVITIES)])
    write_csv(output / "dsads_selected_class_recall.csv", [{"class_index": i, "activity": name, "n": int(confusion[i].sum()),
              "correct": int(confusion[i, i]), "recall": float(confusion[i, i] / confusion[i].sum())} for i, name in enumerate(ACTIVITIES)])
    groups = defaultdict(list)
    for row in paired:
        if row["dataset"] == "dsads" and row["scope"] == "outer_test":
            groups[row["candidate"], row["baseline"], row["purpose"]].append(row)
    rows = []
    for (candidate, baseline, purpose), values in groups.items():
        delta = np.array([r["accuracy_gain_pp"] for r in values])
        rows.append({"candidate": candidate, "baseline": baseline, "purpose": purpose, "n_people": len(values),
                         "accuracy_gain_pp_mean": float(delta.mean()), "accuracy_gain_pp_sd": float(delta.std(ddof=1)),
                         "accuracy_gain_pp_min": float(delta.min()), "accuracy_gain_pp_max": float(delta.max()),
                         "people_improved": int((delta > 1e-10).sum()), "people_worse": int((delta < -1e-10).sum()),
                         "people_tied": int((np.abs(delta) <= 1e-10).sum()), "fewer_errors": sum(r["fewer_errors"] for r in values)})
    write_csv(output / "dsads_contrast_distribution.csv", rows)
    model_names = dsads[0]["protocol"]["models"]
    scores = {model: np.array([np.mean(r["saved"][model] == r["saved"]["target"]) for r in dsads]) for model in model_names}
    selected_scores = np.array([np.mean(r["saved"][r["selection"]["winner"]] == r["saved"]["target"]) for r in dsads])
    best_transform = max((name for name in model_names if "__" in name), key=lambda name: scores[name].mean(), default=None)
    rows = []
    for baseline, diagnostic in (("baseline_prior_rich", False), ("identity__joint_log", False), (best_transform, True)):
        if baseline not in scores:
            continue
        delta = 100 * (selected_scores - scores[baseline])
        rows.append({"candidate": SELECTED, "baseline": baseline, "baseline_chosen_by_test_mean_diagnostic_only": diagnostic,
                         "candidate_accuracy": float(selected_scores.mean()), "baseline_accuracy": float(scores[baseline].mean()),
                         "candidate_minus_baseline_pp": float(delta.mean()), "difference_sd_pp": float(delta.std(ddof=1)),
                         "difference_min_pp": float(delta.min()), "people_improved": int((delta > 1e-10).sum()),
                         "people_worse": int((delta < -1e-10).sum()), "people_tied": int((np.abs(delta) <= 1e-10).sum()),
                         "fewer_errors": int(np.sum(estimates[SELECTED] == target) - np.sum(estimates[baseline] == target))})
    write_csv(output / "dsads_selected_comparisons.csv", rows)


def plot_tables(unit_rows, aggregate, dsads_stats, output):
    os.environ.setdefault("MPLCONFIGDIR", "/tmp/pascal-transfer-mpl-cache")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 10, "figure.dpi": 150, "savefig.bbox": "tight", "svg.fonttype": "none"})
    choices = {}

    def heatmap(filename, matrix, row_labels, columns, title, caption, higher=True):
        matrix = np.asarray(matrix)
        fig, ax = plt.subplots(figsize=(max(8.8, len(columns) * .85 + 2.8), len(row_labels) * .38 + 2.1))
        artist = ax.imshow(matrix, cmap="YlGnBu" if higher else "YlGnBu_r", aspect="auto")
        ax.set_xticks(range(len(columns)), columns)
        ax.set_yticks(range(len(row_labels)), row_labels)
        ax.tick_params(length=0)
        for (i, j), value in np.ndenumerate(matrix):
            color = "white" if np.isfinite(value) and artist.cmap(artist.norm(value))[:3] @ np.array([.299, .587, .114]) < .5 else "#20262e"
            ax.text(j, i, f"{value:.1f}" if np.isfinite(value) else "—", ha="center", va="center", color=color, fontsize=9)
        ax.set_title(title, loc="left", pad=15, weight="bold")
        fig.text(.02, .015, caption, va="bottom", fontsize=9)
        fig.tight_layout(rect=(0, .07, 1, 1))
        for suffix in ("png", "svg"):
            fig.savefig(output / f"{filename}.{suffix}")
        plt.close(fig)

    if dsads_stats:
        models = [SELECTED, *sorted(r["model"] for r in dsads_stats if r["model"].startswith("baseline_"))]
        top = sorted((r for r in dsads_stats if r["model"] not in models), key=lambda r: (-r["accuracy_mean"], r["model"]))[:3]
        models += [r["model"] for r in top]
        stats = {r["model"]: r for r in dsads_stats}
        lookup = {(r["model"], r["unit"]): r for r in unit_rows if r["dataset"] == "dsads"}
        values = [[100 * lookup[model, f"dsads_person{p}"]["accuracy"] for p in range(1, 9)] +
                  [100 * stats[model][key] for key in ("accuracy_mean", "accuracy_min")] for model in models]
        labels = ["Validation-selected procedure" if model == SELECTED else model.replace("baseline_", "").replace("__", " / ").replace("_", " ") for model in models]
        heatmap("dsads_people", values, labels, [f"P{p}" for p in range(1, 9)] + ["Mean", "Worst"],
                "DSADS: eight held-out people · accuracy (%)",
                "Each cell uses nested validation tuning. Last three rows are ranked by test mean for description only.\nAll eight people were held out once; 1,140 windows/person. Selection uses no outer-test scores.")
        choices["dsads_people"] = {"models": models, "test_ranked_rows_are_descriptive": [r["model"] for r in top]}
    overview = []
    overview += [r for r in aggregate if r["unit"] in ("dsads_all8", "kimore_macro")]
    overview += [r for r in unit_rows if r["unit"] in ("natops", "utd_mhad", "uci_har", "ninapro_s1_reps10")]
    for dataset in sorted({r["dataset"] for r in overview}):
        rows = {r["model"]: r for r in overview if r["dataset"] == dataset}
        names = list(dict.fromkeys(model.split("__")[0] for model in rows if "__" in model))
        classification = dataset not in ("kimore", "ninapro")
        key, scale = ("accuracy", 100) if classification else ("rmse", 1)
        matrix = [[rows[f"{name}__{kind}"][key] * scale if f"{name}__{kind}" in rows else np.nan for kind in KINDS] for name in names]
        scope = {"dsads": "pooled eight people", "kimore": "mean of five exercise RMSEs", "ninapro": "S1, full calibration budget"}.get(dataset, "official outer split")
        title = {"utd_mhad": "UTD-MHAD", "uci_har": "UCI HAR", "ninapro": "NinaPro DB8"}.get(dataset, dataset.upper())
        heatmap(f"{dataset}_transforms", matrix, [name.replace("_", " ") for name in names],
                ["Raw log", "Spectral log", "Joint log", "Endpoints", "P1 log", "Joint tensor"],
                f"{title} · {'accuracy (%)' if classification else 'RMSE'} · {scope}",
                "Every cell is a fixed feature map with validation-tuned ridge/clipping. These test comparisons are exploratory.\nBlank cells were not in the fixed study menu; columns use the same transformed stream and common energy sidecar.", classification)
    return choices


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=HERE / "results")
    parser.add_argument("--output", type=Path, default=HERE / "summary")
    parser.add_argument("--no-plots", action="store_true")
    parser.add_argument("--require-complete", action="store_true")
    args = parser.parse_args()
    runs, incomplete, grid_rows = load_runs(args.results)
    missing = sorted(EXPECTED - {r["name"] for r in runs})
    unexpected = sorted({r["name"] for r in runs} - EXPECTED)
    if unexpected or (args.require_complete and missing):
        raise ValueError(f"Unexpected units {unexpected}; missing units {missing}")
    rows, aggregate, paired, dsads_stats = summarize(runs)
    args.output.mkdir(parents=True, exist_ok=True)
    overview = [r for r in rows if r["dataset"] not in ("kimore", "dsads")]
    overview += [r for r in aggregate if r["unit"] in ("kimore_macro", "dsads_all8")]
    for filename, values in (("unit_metrics", rows), ("aggregate_metrics", aggregate), ("paired_contrasts", paired),
                             ("dsads_people", [r for r in rows if r["dataset"] == "dsads"]),
                             ("dsads_model_distribution", dsads_stats),
                             ("dataset_overview", overview),
                             ("selected_procedures", [r for r in rows + aggregate if r["model"] == SELECTED])):
        write_csv(args.output / f"{filename}.csv", values)
    if dsads_stats:
        lookup = {(r["model"], r["unit"]): r["accuracy"] for r in rows if r["dataset"] == "dsads"}
        write_csv(args.output / "dsads_accuracy_matrix.csv", [dict(model=r["model"],
                  **{f"person{person}_accuracy_pct": 100 * lookup[r["model"], f"dsads_person{person}"] for person in range(1, 9)},
                  mean_accuracy_pct=100 * r["accuracy_mean"], sample_sd_pp=100 * r["accuracy_sd"],
                  worst_accuracy_pct=100 * r["accuracy_min"]) for r in dsads_stats])
    dsads_details(runs, paired, args.output)
    selection_diagnostics(runs, args.output)
    plot_choices = {} if args.no_plots else plot_tables(rows, aggregate, dsads_stats, args.output)
    n_model_rows = sum(len(r["rows"]) for r in runs)
    if not missing and (n_model_rows != 2124 or grid_rows != 141456):
        raise ValueError(f"Full-study evidence counts differ: {n_model_rows} final / {grid_rows} grid rows")
    evidence = {r["name"]: {file: hashlib.sha256((r["directory"] / file).read_bytes()).hexdigest()
                           for file in ("protocol.json", "selection.json", "grid.csv", "results.csv", "predictions.npz")} for r in runs}
    report = {"status": "complete" if not missing else "partial", "completed_units": len(runs), "expected_units": 40,
                  "expected_model_rows": 2124, "expected_grid_rows": 141456, "verified_model_rows": n_model_rows, "verified_grid_rows": grid_rows,
                  "incomplete_started_units": incomplete, "missing_units": missing, "datasets": dict(Counter(r["dataset"] for r in runs)),
                  "checks": ["Saved prediction shape, finiteness and independent metric recomputation",
                          "Fixed master menu, resolved source pins, and current source hashes",
                          "Complete validation fold/model/parameter grid and reproduced choices, including ties",
                          "Saved train/test indices and disjoint inner/outer splits",
                          "Complete DSADS eight-person and KIMORE per-exercise out-of-fold coverage before pooling"],
                  "aggregation": {"dsads": "Eight equal-sized subject holdouts; sample SD across people (ddof=1); pooled macro-F1 is separate from mean subject macro-F1",
                               "kimore": "Pool five disjoint folds per exercise, then average five exercise MAE/RMSE/R2 values; macro RMSE is not RMSE of all residuals pooled",
                               "ninapro": "Four calibration budgets share the same S1/A3 test records; they are not independent replications",
                               "selected": "Each outer unit uses its own validation winner; pooled selected predictions may mix models",
                               "ranking": "Validation/test Spearman correlations rank validation-tuned feature maps, with average ranks for ties; test-best maps and gaps are diagnostics only",
                               "interpretation": "Exploratory reused cohorts; test-ranked fixed-model rows are descriptions, never selectors"},
                  "plot_choices": plot_choices, "input_sha256": evidence,
                  "summary_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    write_json(args.output / "verification.json", report)
    print(json.dumps({key: report[key] for key in ("status", "completed_units", "verified_model_rows", "verified_grid_rows", "datasets")}))


if __name__ == "__main__":
    main()
