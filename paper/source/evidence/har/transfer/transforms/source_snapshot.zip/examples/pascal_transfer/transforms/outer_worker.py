"""Freeze DSADS choices, then parallelize the eight frozen-study outer refits."""
from __future__ import annotations

import argparse
import csv
import json
from itertools import combinations
from pathlib import Path
from time import perf_counter

import numpy as np
import study
import torch
from threadpoolctl import threadpool_limits


def prepare(root, names):
    scores = {p: {name:np.zeros(len(study.PARAMS)) for name in names} for p in range(1,9)}
    rows, hashes = [], {}
    for a,b in combinations(range(1,9),2):
        path = root/f"inner_exclude{a}_{b}.csv"
        with path.open() as stream:
            own = list(csv.DictReader(stream))
        expected = {(outer,held,name,i) for outer,held in ((a,b),(b,a)) for name in names for i in range(len(study.PARAMS))}
        actual = {(int(r["outer_person"]),int(r["validation_person"]),r["model"],int(r["parameter_index"])) for r in own}
        if len(own) != len(expected) or actual != expected:
            raise ValueError(f"Incomplete pair {a},{b}")
        for row in own:
            scores[int(row["outer_person"])][row["model"]][int(row["parameter_index"])] += float(row["loss_sum"])
        rows.extend(own)
        hashes[path.name] = study.sha256(path)
    choices = {p:study.select(v,7*1140,names) for p,v in scores.items()}
    for p,choice in choices.items():
        study.write_json(root/f"person{p}/selection.json",choice)
        study.write_csv(root/f"person{p}/grid.csv",[r for r in rows if int(r["outer_person"])==p])
    study.write_json(root/"selections_before_outer_testing.json",choices)
    study.write_json(root/"outer_prepare.json",{"inner_grid_sha256":hashes,
        "study_sha256":study.sha256(study.HERE/"study.py"),"streams_sha256":study.sha256(study.HERE/"streams.py"),
        "helper_sha256":study.sha256(Path(__file__)),"all_selections_frozen_before_any_outer_fit":True})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepare",action="store_true")
    parser.add_argument("--shard",type=int)
    parser.add_argument("--shards",type=int,default=3)
    parser.add_argument("--finish",action="store_true")
    parser.add_argument("--output",type=Path,default=study.HERE/"results/dsads")
    args = parser.parse_args()
    root = args.output
    if sum((args.prepare,args.shard is not None,args.finish)) != 1:
        raise ValueError("Choose prepare, one shard, or finish")
    if args.prepare:
        if (root/"selections_before_outer_testing.json").exists():
            raise FileExistsError("Choices already frozen")
        prepare(root,study.menu("dsads"))
        return
    if args.finish:
        runs = [json.loads((root/f"person{p}/run.json").read_text()) for p in range(1,9)]
        assert all(r["complete"] for r in runs)
        study.write_json(root/"run.json",{"complete":True,"inner_calibrations":28,"inner_validation_folds":56,
            "outer_refits":8,"outer_refit_sum_wall_s":sum(r["wall_s"] for r in runs),"execution":"disjoint pair and outer workers calling frozen study functions"})
        return
    if not 0 <= args.shard < args.shards:
        raise ValueError("Invalid shard")
    manifest = json.loads((root/"outer_prepare.json").read_text())
    assert manifest["study_sha256"] == study.sha256(study.HERE/"study.py")
    assert manifest["streams_sha256"] == study.sha256(study.HERE/"streams.py")
    assert all(study.sha256(root/name)==digest for name,digest in manifest["inner_grid_sha256"].items())
    choices = json.loads((root/"selections_before_outer_testing.json").read_text())
    assert set(choices)==set(map(str,range(1,9)))
    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        unit = study.get_units("dsads",study.DEFAULT_DATA)[0]
        ids, groups = np.arange(len(unit["labels"])), unit["subjects"]
        for p in range(1,9):
            if (p-1)%args.shards != args.shard:
                continue
            folder = root/f"person{p}"
            if (folder/"run.json").exists():
                continue
            train,test = ids[groups!=p],ids[groups==p]
            own = {**unit,"name":f"dsads_person{p}"}
            tick = perf_counter()
            study.fit_final(own,train,test,choices[str(p)],folder,64)
            study.write_json(folder/"run.json",{"complete":True,"wall_s":perf_counter()-tick,
                "outer_worker_sha256":study.sha256(Path(__file__)),"shard":args.shard})


if __name__ == "__main__":
    main()
