# UCI HAR: compact coded signature families

A small research example using **tensorsig**, NumPy and scikit-learn. We retain
three models, all using training-standardized **ridge, alpha 10**:

| Retained model | Features | Test accuracy | Errors / 2,947 |
|---|---:|---:|---:|
| **Compact raw + spectral Pascal + graph readouts** | **368** | **98.03%** | **58** |
| Reduced spectral/rotation pool + raw Pascal | 803 | 98.10% | 56 |
| Supplied 561 + raw Pascal P3/depth 2 | 903 | 97.12% | 85 |

The first two models do not use the supplied 561 features. The compact model
uses 171 raw and 100 spectral Pascal QR logsignature coordinates, 82 calibrated
graph-moment readouts and 15 coded graph trends. The other two retain the
342-coordinate raw Pascal QR tensor signature. All Pascal signature branches
use P3/depth 2, except the P2/depth-2 graph trends; moment calibration uses
selected graph words through depth 4.

[The consolidated comparison](CONSOLIDATED.md) fixes these recipes and tests
ordinary time, anchored, integrated, delay and lead–lag embeddings, as well as
ordinary frequency-clock signatures. **The full 187-comparison run takes 148 seconds.** The
best conventional raw replacements reach 97.46%, 97.83% and 97.05% in the three
contexts. The last gap is only two test windows. Ordinary spectral depth-4
tensors reach 98.00% with 708 total features. Exact ordinary lifted/projection
controls reproduce the Pascal predictions: the case for coding is a compact,
useful parameterization, not information inaccessible to ordinary signatures.

Read [MOTIVATION.md](MOTIVATION.md) for the observation transforms, signature
identities and roles of the six compact-model blocks. All scores are
exploratory results on the repeatedly used official subject-disjoint test
split, not validation-selected performance estimates.

## Run

From this repository, using the installed sibling tensorsig environment:

```sh
../tensorsig/.venv/bin/python examples/uci_har/benchmark.py --consolidated
../tensorsig/.venv/bin/python examples/uci_har/benchmark.py --consolidated --smoke
../tensorsig/.venv/bin/python examples/uci_har/benchmark.py --self-check
```

If creating an environment instead, use the sibling tensorsig checkout:

```sh
uv run --no-project --python 3.13 --with-editable ../tensorsig --with scikit-learn \
  python examples/uci_har/benchmark.py --consolidated --download
```

`--download` is needed only when the UCI ZIP is not cached under ignored
`data/`. Full consolidated runs replace `consolidated_results/`; smoke runs
write to ignored `smoke_results/`. `--output /tmp/har-check` gives a separate
destination. There is no experiment database, model persistence or new
dependency. Numerical kernels use one thread. The ridge solve uses the
existing float64 NumPy general-LU implementation, avoiding the problematic
Cholesky backend in this environment.

## Files

- [CONSOLIDATED.md](CONSOLIDATED.md): retained recipes, matched ablations,
  paper-derived controls, timings and conclusions.
- [MOTIVATION.md](MOTIVATION.md): the mathematical and application motivation.
- [consolidated_results/RESULTS.md](consolidated_results/RESULTS.md): all results;
  [CSV](consolidated_results/results.csv) and [run metadata](consolidated_results/run.json)
  include dimensions, timings, confusion matrices and paired error counts.
- [consolidated.py](consolidated.py): retained blocks and comparisons;
  [ordinary_controls.py](ordinary_controls.py) and
  [ordinary_spectral.py](ordinary_spectral.py): ordinary-signature controls.
- [tensorsig_suggestions.md](tensorsig_suggestions.md): separate library proposals.
- [EXPERIMENT_HISTORY.md](EXPERIMENT_HISTORY.md): the previous README, preserved
  with earlier sweeps, three-head comparisons, reports and reproduction commands.

Earlier modes and result directories remain available. The current experiment
entry point is `benchmark.py --consolidated`.
