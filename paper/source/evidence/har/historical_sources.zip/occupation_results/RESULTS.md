# UCI HAR exploratory results

7,352 training / 2,947 test windows; official subject-disjoint split, fixed classifier settings, exploratory feature comparisons.

Accuracy and macro F1 are percentages. Times are seconds on this machine. Extraction includes train and test, with full calculations shared across readouts; do not sum extraction columns across heads or claim sparse quotient acceleration. The 561-feature extraction time is unmeasured (CSV placeholder 0); hybrid timings measure only the additional features.

## Best row per input/augmentation and head

These are descriptive test-set maxima over representations, not validation-selected models.

| Input / augmentation | Head | Representation | Features | Accuracy | Macro F1 | Extract | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|---:|
| engineered_561 | ridge | uci_features | 561 | 95.72 | 95.85 | 0.000 | 0.021 | 0.002 |
| no_pool | ridge | raw_log__spectral_log | 271 | 93.48 | 93.48 | 2.763 | 0.006 | 0.001 |
| direct_pool | ridge | four_families102 | 373 | 97.79 | 97.81 | 2.763 | 0.009 | 0.002 |
| log_energy_only | ridge | P3_first | 331 | 95.49 | 95.55 | 3.592 | 0.009 | 0.001 |
| only_amplitude | ridge | log_d3 | 331 | 95.69 | 95.74 | 7.406 | 0.008 | 0.001 |
| replace_amplitude | ridge | calibrated | 373 | 97.79 | 97.81 | 7.406 | 0.009 | 0.002 |
| only_cosine | ridge | calibrated | 277 | 95.79 | 95.69 | 4.204 | 0.007 | 0.001 |
| replace_cosine | ridge | calibrated | 373 | 97.79 | 97.81 | 4.204 | 0.009 | 0.001 |
| only_invariant | ridge | calibrated | 307 | 95.55 | 95.59 | 8.244 | 0.007 | 0.001 |
| replace_invariant | ridge | calibrated | 373 | 97.79 | 97.81 | 8.244 | 0.009 | 0.001 |
| all_signature_families | ridge | calibrated102 | 373 | 97.79 | 97.81 | 14.932 | 0.009 | 0.002 |
| calibrated_plus_order | ridge | cosine+invariant | 412 | 97.83 | 97.85 | 14.932 | 0.010 | 0.002 |
| calibrated_plus_normalized_order | ridge | amplitude+invariant | 429 | 98.00 | 98.02 | 14.932 | 0.011 | 0.002 |
| calibrated_coded_energy | ridge | P2_log | 413 | 97.83 | 97.85 | 15.103 | 0.011 | 0.002 |

## Every comparison

| Input / augmentation | Representation | Head | Features | Accuracy | Macro F1 | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|
| engineered_561 | uci_features | ridge | 561 | 95.72 | 95.85 | 0.021 | 0.002 |
| no_pool | raw_log__spectral_log | ridge | 271 | 93.48 | 93.48 | 0.006 | 0.001 |
| direct_pool | four_families102 | ridge | 373 | 97.79 | 97.81 | 0.009 | 0.002 |
| log_energy_only | P1_endpoint | ridge | 291 | 95.11 | 95.15 | 0.007 | 0.001 |
| log_energy_only | P2_first | ridge | 311 | 95.45 | 95.51 | 0.009 | 0.001 |
| log_energy_only | P2_log | ridge | 331 | 95.42 | 95.48 | 0.009 | 0.001 |
| log_energy_only | P3_first | ridge | 331 | 95.49 | 95.55 | 0.009 | 0.001 |
| log_energy_only | P3_log | ridge | 391 | 95.45 | 95.52 | 0.010 | 0.002 |
| only_amplitude | moments | ridge | 311 | 95.45 | 95.47 | 0.008 | 0.001 |
| replace_amplitude | moments | ridge | 373 | 97.59 | 97.61 | 0.009 | 0.002 |
| only_amplitude | calibrated | ridge | 311 | 95.52 | 95.58 | 0.008 | 0.001 |
| replace_amplitude | calibrated | ridge | 373 | 97.79 | 97.81 | 0.009 | 0.002 |
| only_amplitude | log_d3 | ridge | 331 | 95.69 | 95.74 | 0.008 | 0.001 |
| replace_amplitude | log_d3 | ridge | 393 | 97.73 | 97.75 | 0.010 | 0.002 |
| only_amplitude | log_d4 | ridge | 391 | 95.59 | 95.62 | 0.010 | 0.002 |
| replace_amplitude | log_d4 | ridge | 453 | 97.56 | 97.57 | 0.012 | 0.002 |
| only_cosine | moments | ridge | 277 | 95.11 | 95.03 | 0.007 | 0.001 |
| replace_cosine | moments | ridge | 373 | 97.05 | 97.09 | 0.009 | 0.002 |
| only_cosine | calibrated | ridge | 277 | 95.79 | 95.69 | 0.007 | 0.001 |
| replace_cosine | calibrated | ridge | 373 | 97.79 | 97.81 | 0.009 | 0.001 |
| only_cosine | log_d3 | ridge | 280 | 95.15 | 95.06 | 0.006 | 0.001 |
| replace_cosine | log_d3 | ridge | 376 | 97.18 | 97.22 | 0.009 | 0.002 |
| only_cosine | log_d4 | ridge | 289 | 95.39 | 95.30 | 0.007 | 0.001 |
| replace_cosine | log_d4 | ridge | 385 | 97.29 | 97.32 | 0.010 | 0.002 |
| only_invariant | moments | ridge | 307 | 95.15 | 95.18 | 0.007 | 0.001 |
| replace_invariant | moments | ridge | 373 | 97.49 | 97.50 | 0.009 | 0.002 |
| only_invariant | calibrated | ridge | 307 | 95.55 | 95.59 | 0.007 | 0.001 |
| replace_invariant | calibrated | ridge | 373 | 97.79 | 97.81 | 0.009 | 0.001 |
| only_invariant | log_d3 | ridge | 307 | 95.05 | 95.07 | 0.007 | 0.001 |
| replace_invariant | log_d3 | ridge | 373 | 97.46 | 97.45 | 0.009 | 0.001 |
| only_invariant | log_d4 | ridge | 343 | 95.15 | 95.17 | 0.008 | 0.001 |
| replace_invariant | log_d4 | ridge | 409 | 97.52 | 97.53 | 0.010 | 0.002 |
| all_signature_families | selected_moments102 | ridge | 373 | 97.01 | 97.05 | 0.009 | 0.002 |
| all_signature_families | calibrated102 | ridge | 373 | 97.79 | 97.81 | 0.009 | 0.002 |
| all_signature_families | graph_d3 | ridge | 396 | 96.98 | 97.01 | 0.010 | 0.002 |
| all_signature_families | graph_d4 | ridge | 501 | 97.22 | 97.25 | 0.014 | 0.002 |
| all_signature_families | graph_mixed | ridge | 432 | 96.98 | 97.02 | 0.011 | 0.002 |
| calibrated_plus_order | amplitude | ridge | 393 | 97.79 | 97.82 | 0.010 | 0.002 |
| calibrated_plus_normalized_order | amplitude | ridge | 393 | 97.93 | 97.96 | 0.010 | 0.002 |
| calibrated_plus_order | cosine | ridge | 376 | 97.79 | 97.81 | 0.009 | 0.002 |
| calibrated_plus_normalized_order | cosine | ridge | 376 | 97.73 | 97.75 | 0.009 | 0.001 |
| calibrated_plus_order | invariant | ridge | 409 | 97.83 | 97.85 | 0.010 | 0.002 |
| calibrated_plus_normalized_order | invariant | ridge | 409 | 97.96 | 97.97 | 0.011 | 0.002 |
| calibrated_plus_order | amplitude+cosine | ridge | 396 | 97.62 | 97.64 | 0.010 | 0.002 |
| calibrated_plus_normalized_order | amplitude+cosine | ridge | 396 | 97.96 | 97.99 | 0.010 | 0.002 |
| calibrated_plus_order | amplitude+invariant | ridge | 429 | 97.79 | 97.81 | 0.011 | 0.002 |
| calibrated_plus_normalized_order | amplitude+invariant | ridge | 429 | 98.00 | 98.02 | 0.011 | 0.002 |
| calibrated_plus_order | cosine+invariant | ridge | 412 | 97.83 | 97.85 | 0.010 | 0.002 |
| calibrated_plus_normalized_order | cosine+invariant | ridge | 412 | 97.93 | 97.94 | 0.010 | 0.002 |
| calibrated_plus_order | amplitude+cosine+invariant | ridge | 432 | 97.66 | 97.68 | 0.011 | 0.002 |
| calibrated_plus_normalized_order | amplitude+cosine+invariant | ridge | 432 | 97.96 | 97.99 | 0.011 | 0.002 |
| calibrated_plus_order | all_depth4 | ridge | 478 | 97.66 | 97.68 | 0.013 | 0.002 |
| calibrated_plus_normalized_order | all_depth4 | ridge | 478 | 97.86 | 97.89 | 0.013 | 0.002 |
| calibrated_coded_energy | P2_first | ridge | 393 | 97.69 | 97.71 | 0.010 | 0.002 |
| calibrated_coded_energy | P2_log | ridge | 413 | 97.83 | 97.85 | 0.011 | 0.002 |
| calibrated_coded_energy | P3_first | ridge | 413 | 97.56 | 97.58 | 0.010 | 0.002 |
| calibrated_coded_energy | P3_log | ridge | 473 | 97.76 | 97.78 | 0.013 | 0.002 |
