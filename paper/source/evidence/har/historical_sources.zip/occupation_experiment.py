"""Small ridge comparison of observable graph logs and log-energy paths."""

from itertools import combinations
from time import perf_counter

import numpy as np
import torch
from families import _power, _with_norm, build_families
from features import _coordinates, _standardize, extract_coded_features
from generators import coded_integration, temporal_code
from moment_lifts import _cosines
from occupation_graph import occupation_readouts
from pooled_blocks import spectral_pool
from spectral_readouts import signature_readouts


@torch.inference_mode()
def log_energy_readouts(power, P, batch_size=256):
    """Scalar spectral energy -> log cumulative energy -> QR coded log.

    The constant code endpoint, divided by its QR constant, is log1p(total
    energy). Channels are independent paths, not one large cross-channel lift.
    """
    start = perf_counter()
    windows, length, channels = power.shape
    cumulative = power.cumsum(1).log1p()
    increments = torch.diff(cumulative, dim=1, prepend=torch.zeros_like(cumulative[:, :1]))
    scalar = increments.transpose(1, 2).reshape(windows * channels, length, 1)
    code = temporal_code(length, P)
    tensor, _ = extract_coded_features(scalar, code, batch_size, depth=2)
    first = tensor[:, :P]
    second = tensor[:, P:].reshape(-1, P, P)
    i, j = np.triu_indices(P, 1)
    log = np.concatenate((first, (second[:, i, j] - second[:, j, i]) / np.sqrt(2)), 1)
    endpoint = first[:, 0].reshape(windows, channels).astype(np.float64) / float(code.matrix[0, 0])
    return {"endpoint": endpoint, "first": first.reshape(windows, -1),
            "log": log.reshape(windows, -1)}, perf_counter() - start


def calibrated_moments(moments, centered_moments):
    """Stable mean/std/skew from raw and centered graph coordinates."""
    mean = moments[:, :, 0]
    variance = np.maximum(centered_moments[:, :, 1], 0)
    std = np.sqrt(variance)
    central_third = centered_moments[:, :, 2]
    skew = np.where(variance > 1e-12, central_third / np.maximum(std, 1e-8)**3, 0)
    return np.stack((mean, std, skew), -1)


@torch.inference_mode()
def run(evaluate, signals, n_train, engineered, args, metadata):
    start = perf_counter()
    raw = _standardize(torch.as_tensor(signals[..., [6, 7, 8, 3, 4, 5]], dtype=torch.float64), n_train)
    raw_tensor, _ = coded_integration(raw, 3, 2, batch_size=args.batch_size)
    raw_log = _coordinates(torch.as_tensor(raw_tensor), ("accel",) * 9 + ("gyro",) * 9)["full_logsignature"].numpy()
    families = build_families(signals, n_train)
    spectral, _ = signature_readouts(families["spectral"]["observations"], 3, 2, args.batch_size)
    base = np.concatenate((raw_log, spectral["within_channel_first_areas"]), 1)
    vectors = [obs[:, :, :3] for obs in families["moments"]["observations"]]
    vectors += [obs[:, :, :3] for obs in families["filters_delays"]["observations"][:2]]
    powers = [_power(_with_norm(vector)) for vector in vectors]
    rotation = families["rotation"]
    cosines = _cosines(*rotation["observations"][:2])
    observations = {"amplitude": [p.sqrt() for p in powers], "cosine": [cosines],
                    "invariant": rotation["observations"]}
    counts = {"amplitude": 2, "cosine": 2, "invariant": 3}

    # Direct controls exactly preserve the previous 20+40+6+36 feature pool.
    summary = rotation["pooled"][:, :96].reshape(len(signals), 4, 8, 3)
    direct = {
        "energy": spectral_pool(families, statistics=("log_energy",)),
        "amplitude": spectral_pool(families, statistics=("amplitude_mean", "amplitude_std")),
        "cosine": rotation["pooled"][:, 96:102],
        "invariant": summary[:, :, [0, 1, 4]].reshape(len(signals), -1),
    }
    base_seconds = perf_counter() - start
    cat = lambda arrays: np.concatenate(list(arrays), 1)

    def compare(variant, name, extra, elapsed=0):
        evaluate(variant, name, cat((base, extra)), base_seconds + elapsed)

    evaluate("no_pool", "raw_log__spectral_log", base, base_seconds)
    compare("direct_pool", "four_families102", cat(direct.values()))
    settings = {
        "base": "Raw Pascal P3 QR depth2 log171 + within-channel spectral P3 QR depth2 log100",
        "head": "Fixed ridge alpha10, train-only StandardScaler; no supplied561 in constructions",
        "graph": "Separate closed value-clock graph per scalar stream; x,t Lyndon words through depth4",
        "graph_depths": [3, 4], "energy_P": [1, 2, 3], "energy_depths": [1, 2],
        "moments": "xt, 2*xxt, 6*xxxt are exact first, second, third raw moments",
        "calibration": "Mean from raw graph; second/third central moments from a second graph after subtracting that mean",
        "normalized_order": "Centered graph ordering words divided by std to the number of x letters; zero when variance<=1e-12",
        "timings": "All windows; shared baseline preparation included. Graph depth3 slices share depth4 extraction.",
        "families": {name: sum(obs.shape[2] for obs in groups) for name, groups in observations.items()},
    }
    metadata["occupation_settings"] = settings

    energy = {}
    energy_times = {}
    for p in (1, 2, 3):
        chunks, elapsed = [], 0.
        for power in powers:
            value, seconds = log_energy_readouts(power, p, args.batch_size)
            chunks.append(value)
            elapsed += seconds
        energy[p] = {key: cat(value[key] for value in chunks) for key in chunks[0]}
        energy_times[p] = elapsed
        for name in ("first", "log") if p > 1 else ("endpoint",):
            compare("log_energy_only", f"P{p}_{name}", energy[p][name], elapsed)
    settings["energy_extraction_s"] = sum(energy_times.values())
    settings["energy_endpoint_max_error"] = float(np.max(np.abs(energy[1]["endpoint"] - direct["energy"])))
    if not np.allclose(energy[1]["endpoint"], direct["energy"], rtol=2e-6, atol=2e-7):
        raise AssertionError("Log-energy path does not reproduce existing log-energy")

    graph, graph_seconds, moment_errors = {}, {}, {}
    for family, groups in observations.items():
        tick = perf_counter()
        chunks = [occupation_readouts(obs, args.batch_size)[0] for obs in groups]
        moments = cat(chunk["moments"] for chunk in chunks)  # windows, channels, powers
        centered = [occupation_readouts(obs - torch.as_tensor(chunk["moments"][:, :, 0])[:, None],
                                       args.batch_size)[0] for obs, chunk in zip(groups, chunks)]
        central_moments = cat(chunk["moments"] for chunk in centered)
        calibrated = calibrated_moments(moments, central_moments)
        count = counts[family]
        graph[family] = {
            "moments": moments[:, :, :count].reshape(len(signals), -1),
            "calibrated": calibrated[:, :, :count].reshape(len(signals), -1),
            **{key: cat(chunk[key] for chunk in chunks) for key in ("log_d3", "log_d4", "order_d3", "order_d4")},
        }
        sd = calibrated[:, :, 1]
        normalized = cat(chunk["order_d4"].reshape(len(signals), -1, 3) for chunk in centered)
        normalized /= np.maximum(sd, 1e-8)[:, :, None] ** np.array([1, 2, 1])
        normalized = np.where((central_moments[:, :, 1] > 1e-12)[:, :, None], normalized, 0)
        graph[family]["normalized_order_d3"] = normalized[:, :, :1].reshape(len(signals), -1)
        graph[family]["normalized_order_d4"] = normalized.reshape(len(signals), -1)
        graph_seconds[family] = perf_counter() - tick
        expected = torch.cat([torch.stack([obs.pow(r).mean(1) for r in (1, 2, 3)], -1)
                              for obs in groups], 1).numpy()
        moment_errors[family] = float(np.max(np.abs(moments - expected) / np.maximum(1, np.abs(expected))))
        if not np.allclose(moments, expected, rtol=2e-9, atol=2e-9):
            raise AssertionError(f"Graph moments mismatch: {family}")
        # Stable direct mean/std/skew are checks, never model inputs below.
        stable = []
        for obs in groups:
            mean = obs.mean(1)
            centered = obs - mean[:, None]
            variance = centered.square().mean(1)
            sd = variance.sqrt()
            skew = torch.where(variance > 1e-12,
                               (centered / sd.clamp_min(1e-8)[:, None]).pow(3).mean(1), 0.)
            stable.append(torch.stack((mean, sd, skew), -1).numpy())
        settings.setdefault("calibration_max_error", {})[family] = np.max(
            np.abs(calibrated - cat(stable)), axis=(0, 1)).tolist()
        if not np.allclose(calibrated, cat(stable), rtol=2e-6, atol=2e-6):
            raise AssertionError(f"Centered graph calibration mismatch: {family}")
    settings["graph_extraction_s"] = graph_seconds
    settings["moment_relative_error"] = moment_errors
    elapsed = energy_times[1] + sum(graph_seconds.values())
    endpoint = energy[1]["endpoint"]

    # Add each family alone and replace one block of the established pool.
    for family, values in graph.items():
        for name in ("moments", "calibrated", "log_d3", "log_d4"):
            compare("only_" + family, name, values[name], graph_seconds[family])
            others = [value for key, value in direct.items() if key != family]
            compare("replace_" + family, name, cat((*others, values[name])), graph_seconds[family])

    # Compact selected coordinates versus fuller logs retaining arrangement.
    all_sets = {
        "selected_moments102": cat((endpoint, *(graph[f]["moments"] for f in graph))),
        "calibrated102": cat((endpoint, *(graph[f]["calibrated"] for f in graph))),
        "graph_d3": cat((endpoint, *(graph[f]["log_d3"] for f in graph))),
        "graph_d4": cat((endpoint, *(graph[f]["log_d4"] for f in graph))),
        "graph_mixed": cat((endpoint, graph["amplitude"]["log_d3"], graph["cosine"]["log_d3"],
                            graph["invariant"]["log_d4"])),
    }
    for name, extra in all_sets.items():
        compare("all_signature_families", name, extra, elapsed)
    calibrated = all_sets["calibrated102"]
    for size in (1, 2, 3):
        for names in combinations(graph, size):
            for prefix in ("", "normalized_"):
                order = cat(graph[f][prefix + ("order_d4" if f == "invariant" else "order_d3")] for f in names)
                compare("calibrated_plus_" + prefix + "order", "+".join(names), cat((calibrated, order)), elapsed)
    compare("calibrated_plus_order", "all_depth4",
            cat((calibrated, *(graph[f]["order_d4"] for f in graph))), elapsed)
    compare("calibrated_plus_normalized_order", "all_depth4",
            cat((calibrated, *(graph[f]["normalized_order_d4"] for f in graph))), elapsed)
    # Coded log energy tests whether its spectral location adds useful signal.
    rest = cat(graph[f]["calibrated"] for f in graph)
    for p in (2, 3):
        for name in ("first", "log"):
            compare("calibrated_coded_energy", f"P{p}_{name}", cat((energy[p][name], rest)),
                    energy_times[p] + sum(graph_seconds.values()))


def self_check():
    rng = torch.Generator().manual_seed(183)
    power = torch.rand(5, 17, 4, generator=rng, dtype=torch.float64)
    for p in (1, 2, 3):
        values, _ = log_energy_readouts(power, p, 3)
        np.testing.assert_allclose(values["endpoint"], power.sum(1).log1p(), rtol=2e-7, atol=2e-7)
        assert values["log"].shape == (5, 4 * (p + p * (p - 1) // 2))
    values, _ = log_energy_readouts(torch.zeros_like(power), 3, 3)
    assert not np.any(values["log"])
    # Near-constant streams amplify cancellation in raw-moment subtraction.
    obs = 1 + 2e-6 * torch.randn(3, 128, 2, generator=rng, dtype=torch.float64)
    raw, _ = occupation_readouts(obs)
    centered, _ = occupation_readouts(obs - torch.as_tensor(raw["moments"][:, :, 0])[:, None])
    actual = calibrated_moments(raw["moments"], centered["moments"])
    centered_obs = obs - obs.mean(1, keepdim=True)
    sd = centered_obs.square().mean(1).sqrt()
    expected = torch.stack((obs.mean(1), sd, (centered_obs / sd[:, None]).pow(3).mean(1)), -1)
    np.testing.assert_allclose(actual, expected, atol=2e-8, rtol=2e-8)


if __name__ == "__main__":
    torch.set_num_threads(1)
    self_check()
    print("Log-energy path checks passed.")
