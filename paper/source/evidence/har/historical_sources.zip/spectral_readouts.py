"""Small readouts of frequency-ordered, QR Pascal-coded spectral measures.

The input convention is the one used by ``families._spectrum``: observations
are bin probabilities times the number of bins. Their integrated mass is one.
Group and channel selection belongs to the caller. Every signature is evaluated
by tensorsig; the additional readouts are inexpensive tensor projections.
"""

from time import perf_counter

import numpy as np
import torch
from generators import coded_integration, temporal_code


def _within_channel(values: np.ndarray, channels: int, P: int, depth: int) -> np.ndarray:
    """Retain words whose letters have the same original signal channel."""
    width = channels * P
    parts, offset = [], 0
    for level in range(1, depth + 1):
        coordinates = np.indices((P,) * level).reshape(level, -1)
        for channel in range(channels):
            indices = np.ravel_multi_index(coordinates + channel * P, (width,) * level)
            parts.append(values[:, offset + indices])
        offset += width**level
    return np.concatenate(parts, axis=1)


def _compact_second_level(
    first: np.ndarray, second: np.ndarray, constant: np.ndarray, value: float,
) -> np.ndarray:
    """An orthonormal projection onto the nonconstant affine signature span.

    Let I be the constant-endpoint coordinates, each equal to c, and J the
    others. Shuffle gives S_ij + S_ji = c L_j for i in I, j in J. Thus each
    L_j has 1 + |I| c²/2 copies of its squared norm across endpoint and
    symmetric tensor coordinates. Keep their normalized common direction,
    the symmetric J-by-J tensor and every antisymmetric tensor coordinate.

    Differences between signatures keep their Euclidean norms exactly.
    Standardizing the new columns afterwards changes the ridge penalty; this
    is an affine-span reduction, not equivalence of the benchmark classifiers.
    """
    width = first.shape[1]
    variable = np.setdiff1d(np.arange(width), constant)
    endpoint = first[:, variable] * np.sqrt(1 + len(constant) * value**2 / 2)
    diagonal = second[:, variable, variable]
    left, right = np.triu_indices(len(variable), 1)
    i, j = variable[left], variable[right]
    symmetric = (second[:, i, j] + second[:, j, i]) / np.sqrt(2)
    i, j = np.triu_indices(width, 1)
    areas = (second[:, i, j] - second[:, j, i]) / np.sqrt(2)
    return np.concatenate((endpoint, diagonal, symmetric, areas), axis=1)


def signature_readouts(
    observations: list[torch.Tensor], P: int = 3, depth: int = 2,
    batch_size: int = 256,
) -> tuple[dict[str, np.ndarray], float]:
    """Return concatenated readouts of independently coded spectral groups.

    ``full`` and ``within_channel`` retain the requested depth. ``first_only``
    contains coded spectral-location moments. At depth >=2, ``first_products``
    adds all unordered endpoint products within each group, and ``first_areas``
    instead adds signed frequency-pair ordering. They are depth-two controls.
    Their ``within_channel_`` versions restrict these interactions to each
    original signal channel, giving matched controls for channelwise tensors.
    Endpoint products involving the constant mass remain, so these controls
    contain affine redundancy, just like their groupwise counterparts.

    At depth 2, ``full_compact`` removes known affine redundancy without losing
    the full tensor's linear readouts. ``within_channel_compact`` does the same
    after dropping interactions between different signal channels. For C
    channels and P codes, these have n + n(n+1)/2 + CP(CP-1)/2 and C(P²-1)
    columns, respectively, where n=C(P-1). At P3/C4 this is 110 or 32 columns,
    compared with 156 in the full tensor. All are computed from that tensor;
    reduced extraction algorithms are not implemented here.
    ``within_channel_compact_no_areas`` retains only the endpoint and symmetric
    columns of that compact readout. At P3 it has five columns per channel,
    giving a direct removal-of-ordering control without duplicate reweighting.

    Compact readouts require unit integrated mass in every window and channel;
    an all-zero spectrum does not satisfy this contract and is rejected. QR
    ensures the first code is constant. Its sign and value are read from the
    actual code rather than assumed.
    """
    if not observations:
        raise ValueError("Expected at least one spectral observation group")
    if not isinstance(P, int) or P < 1 or depth not in (1, 2, 3):
        raise ValueError("Expected positive integer P and depth 1, 2, or 3")
    start = perf_counter()
    outputs: dict[str, list[np.ndarray]] = {}

    def add(name: str, values: np.ndarray) -> None:
        outputs.setdefault(name, []).append(values)

    windows = len(observations[0])
    for observation in observations:
        if (observation.ndim != 3 or len(observation) != windows
                or observation.shape[2] < 1 or not torch.isfinite(observation).all()
                or (observation < 0).any()):
            raise ValueError("Expected finite nonnegative spectral groups with matching windows")
        if not torch.allclose(observation.mean(1), torch.ones_like(observation.mean(1)),
                              atol=1e-8, rtol=1e-7):
            raise ValueError("Spectral groups must have unit integrated mass, including every channel")
        channels = observation.shape[2]
        width = channels * P
        values, _ = coded_integration(observation, P, depth=depth, batch_size=batch_size)
        first = values[:, :width]
        add("full", values)
        add("within_channel", _within_channel(values, channels, P, depth))
        add("first_only", first)
        if depth < 2:
            continue
        second = values[:, width:width + width**2].reshape(-1, width, width)
        i, j = np.triu_indices(width)
        add("first_products", np.concatenate((first, first[:, i] * first[:, j]), axis=1))
        i, j = np.triu_indices(width, 1)
        add("first_areas", np.concatenate((first, (second[:, i, j] - second[:, j, i]) / np.sqrt(2)), axis=1))
        products, areas = [], []
        for channel in range(channels):
            indices = slice(channel * P, (channel + 1) * P)
            endpoint = first[:, indices]
            tensor = second[:, indices, indices]
            i, j = np.triu_indices(P)
            products.append(np.concatenate((endpoint, endpoint[:, i] * endpoint[:, j]), axis=1))
            i, j = np.triu_indices(P, 1)
            areas.append(np.concatenate((endpoint, (tensor[:, i, j] - tensor[:, j, i]) / np.sqrt(2)), axis=1))
        add("within_channel_first_products", np.concatenate(products, axis=1))
        add("within_channel_first_areas", np.concatenate(areas, axis=1))
        if depth != 2:
            continue
        code = temporal_code(observation.shape[1], P).matrix
        constant_value = float(code[0, 0])
        add("full_compact", _compact_second_level(
            first, second, np.arange(0, width, P), constant_value,
        ))
        channelwise, channelwise_no_areas = [], []
        for channel in range(channels):
            indices = slice(channel * P, (channel + 1) * P)
            compact = _compact_second_level(
                first[:, indices], second[:, indices, indices], np.array([0]), constant_value,
            )
            channelwise.append(compact)
            symmetric_end = P - 1 + (P - 1) * P // 2
            channelwise_no_areas.append(compact[:, :symmetric_end])
        add("within_channel_compact", np.concatenate(channelwise, axis=1))
        add("within_channel_compact_no_areas", np.concatenate(channelwise_no_areas, axis=1))
    return {name: np.concatenate(parts, axis=1) for name, parts in outputs.items()}, perf_counter() - start


def self_check() -> None:
    """Check channel restriction and compact affine span against dense tensors."""
    generator = torch.Generator().manual_seed(712)
    observation = torch.rand(7, 13, 2, generator=generator, dtype=torch.float64)
    observation /= observation.mean(1, keepdim=True)
    for P in (1, 2, 3, 4):
        result, _ = signature_readouts([observation], P=P, batch_size=3)
        assert result["within_channel_compact"].shape == (7, 2 * (P**2 - 1))
        symmetric_end = P - 1 + (P - 1) * P // 2
        assert result["within_channel_compact_no_areas"].shape == (7, 2 * symmetric_end)
        expected_no_areas = result["within_channel_compact"].reshape(7, 2, P**2 - 1)[:, :, :symmetric_end].reshape(7, -1)
        np.testing.assert_array_equal(result["within_channel_compact_no_areas"], expected_no_areas)
        n, width = 2 * (P - 1), 2 * P
        assert result["full_compact"].shape == (7, n + n * (n + 1) // 2 + width * (width - 1) // 2)
        # Orthogonal reduction preserves distances, including cross-channel
        # frequency ordering in the full representation. Constants cancel.
        for full, compact in (("full", "full_compact"),
                              ("within_channel", "within_channel_compact")):
            original = result[full].astype(np.float64) - result[full][:1]
            projected = result[compact].astype(np.float64) - result[compact][:1]
            np.testing.assert_allclose(original @ original.T, projected @ projected.T,
                                       atol=2e-8, rtol=2e-5)
    for depth in (1, 2, 3):
        result, _ = signature_readouts([observation], P=3, depth=depth)
        separate = [coded_integration(observation[:, :, c:c + 1], 3, depth=depth)[0]
                    for c in range(2)]
        expected, offset = [], 0
        for level in range(1, depth + 1):
            expected.extend(item[:, offset:offset + 3**level] for item in separate)
            offset += 3**level
        np.testing.assert_allclose(result["within_channel"], np.concatenate(expected, axis=1),
                                   atol=1e-7, rtol=1e-6)
        if depth >= 2:
            channel_results = [signature_readouts([observation[:, :, c:c + 1]], P=3, depth=depth)[0]
                               for c in range(2)]
            for name in ("first_products", "first_areas"):
                expected = np.concatenate([item[name] for item in channel_results], axis=1)
                np.testing.assert_array_equal(result[f"within_channel_{name}"], expected)
            assert result["within_channel_first_products"].shape == (7, 18)
            assert result["within_channel_first_areas"].shape == (7, 12)
    # Pascal P5 spans degree <=4 frequency-location moments, irrespective of
    # the QR basis; no FFT peak or band boundaries are needed for these.
    result, _ = signature_readouts([observation], P=5, depth=1)
    location = torch.linspace(0, 1, observation.shape[1], dtype=torch.float64)
    code = temporal_code(observation.shape[1], 5).matrix
    for degree in range(1, 5):
        weights = (code.T @ location**degree).numpy()
        expected = (observation * location[None, :, None]**degree).mean(1)
        actual = np.einsum("ncp,p->nc", result["first_only"].reshape(7, 2, 5), weights)
        np.testing.assert_allclose(actual, expected.numpy(), atol=1e-7)
    try:
        signature_readouts([torch.zeros_like(observation)])
    except ValueError:
        pass
    else:
        raise AssertionError("Zero spectral mass must not silently enter the compact contract")


if __name__ == "__main__":
    torch.set_num_threads(1)
    self_check()
    print("Spectral readout checks passed.")
