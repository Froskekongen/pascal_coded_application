"""Value-clock graph logsignatures containing occupation moments and ordering.

For each scalar stream z, start at (0, 0), jump to each observed value,
advance the clock by 1/N there, then return the value coordinate to zero.
The resulting staircase has log-signature coefficient
``logS[x**r, t] = mean(z**r) / r!``. Closing the value coordinate makes
these tensor-log coefficients equal to the corresponding signature ones.
The other Lyndon words retain how the values were ordered in the window.
"""

from time import perf_counter

import numpy as np
import torch
from tensorsig.algebra.lyndon_words import lyndon_words
from tensorsig.classical.signatures import log_signature

WORDS = ("x", "t", "xt", "xxt", "xtt", "xxxt", "xxtt", "xttt")
MOMENT_INDICES = (2, 3, 5)


def occupation_readouts(
    observations: torch.Tensor, batch_size: int = 256,
) -> tuple[dict[str, np.ndarray], float]:
    """Return channelwise graph logsignatures and first three raw moments.

    Inputs have shape (windows, samples, channels). Output ``full_log`` has
    shape (windows, channels, 8), in ``WORDS`` order; ``moments`` has shape
    (windows, channels, 3). Other outputs flatten channel-major coordinates:
    ``log_d3`` has 3/channel, ``log_d4`` has 6/channel, ``order_d3`` has
    1/channel (xtt), and ``order_d4`` has 3/channel (xtt, xxtt, xttt).
    The known endpoints x=0 and t=1 are omitted from the flattened outputs.

    Everything is computed in float64 using tensorsig. This helper neither
    centers nor rescales observations. For numerically stable central moments
    of almost constant streams, pass centered observations in a separate call
    rather than subtracting nearly equal large raw moments afterwards.
    ``batch_size`` counts scalar paths, with channels included in that count.
    """
    started = perf_counter()
    observations = torch.as_tensor(observations, dtype=torch.float64)
    if observations.ndim != 3 or min(observations.shape) < 1:
        raise ValueError("Expected nonempty (windows, samples, channels) observations")
    if batch_size < 1 or not torch.isfinite(observations).all():
        raise ValueError("Expected positive batch_size and finite observations")
    windows, samples, channels = observations.shape
    scalar_paths = observations.transpose(1, 2).reshape(-1, samples)
    clock = torch.arange(samples + 1, dtype=torch.float64, device=observations.device)
    clock /= samples
    staircase_clock = torch.stack((clock[:-1], clock[1:]), dim=-1).flatten()
    parts = []
    with torch.no_grad():
        for values in scalar_paths.split(batch_size):
            path = values.new_zeros((len(values), 2 * samples + 2, 2))
            path[:, 1:-1, 0] = values.repeat_interleave(2, dim=1)
            path[:, 1:-1, 1] = staircase_clock
            path[:, -1, 1] = 1
            parts.append(log_signature(path, depth=4, mode="words").cpu().numpy())
    full = np.concatenate(parts).reshape(windows, channels, 8)
    readouts = {
        "full_log": full,
        "moments": full[..., MOMENT_INDICES] * np.array([1.0, 2.0, 6.0]),
        "log_d3": full[..., 2:5].reshape(windows, -1),
        "log_d4": full[..., 2:].reshape(windows, -1),
        "order_d3": full[..., 4:5].reshape(windows, -1),
        "order_d4": full[..., (4, 6, 7)].reshape(windows, -1),
    }
    return readouts, perf_counter() - started


def self_check() -> None:
    """Check moment identities, channel layout, and information beyond moments."""
    labels = tuple("".join("xt"[letter - 1] for letter in word)
                   for word in lyndon_words(2, 4))
    assert labels == WORDS
    rng = torch.Generator().manual_seed(31)
    z = torch.randn(4, 17, 3, generator=rng, dtype=torch.float64)
    values, _ = occupation_readouts(z, batch_size=5)
    expected = torch.stack([(z**r).mean(dim=1) for r in (1, 2, 3)], dim=-1)
    np.testing.assert_allclose(values["moments"], expected.numpy(), atol=2e-13, rtol=2e-13)
    np.testing.assert_allclose(values["full_log"][..., :2],
                               np.broadcast_to([0.0, 1.0], (4, 3, 2)), atol=2e-14)
    assert values["log_d3"].shape == (4, 9)
    assert values["log_d4"].shape == (4, 18)
    assert values["order_d3"].shape == (4, 3)
    assert values["order_d4"].shape == (4, 9)

    reversed_values, _ = occupation_readouts(z.flip(1))
    np.testing.assert_allclose(values["moments"], reversed_values["moments"], atol=3e-13)
    assert not np.allclose(values["order_d3"], reversed_values["order_d3"])
    np.testing.assert_allclose(values["order_d3"], -reversed_values["order_d3"], atol=2e-13)

    constant = torch.tensor([0.0, 2.0, -3.0], dtype=torch.float64).expand(2, 11, 3)
    edge, _ = occupation_readouts(constant)
    powers = np.array([[0.0, 0.0, 0.0], [2.0, 4.0, 8.0], [-3.0, 9.0, -27.0]])
    np.testing.assert_allclose(edge["moments"], np.broadcast_to(powers, (2, 3, 3)), atol=1e-13)
    assert all(np.isfinite(array).all() for array in edge.values())


if __name__ == "__main__":
    torch.set_num_threads(1)
    self_check()
    print("Occupation graph checks passed")
