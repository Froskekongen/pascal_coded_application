# UCI HAR: signature feature generators

A small, disposable research experiment using **tensorsig** and scikit-learn.
The current comparison uses **ridge only**. `--coded-occupations` sweeps Pascal
QR clock codes and graph depths while keeping raw log171 + spectral log100 fixed.
**365 features recover 98.00%**, versus the previous 429; **368 give 98.03%**.
The smaller model uses 82 calibrated moment readouts and just 12 P2/depth-2
invariant-trend coordinates. All **310 comparisons took 22.54 seconds**.
See [the coded graph report](CODED_OCCUPATIONS.md) and
[complete results](coded_occupation_results/RESULTS.md). Graph depths 3/4 are
still used for the calibrated moment readouts; depth 2 describes the extra
coded trend branch.

The preceding `--occupations` constructs genuine
logsignature families for the remaining energy, amplitude, cosine and Gram
readouts. **Raw log171 + spectral log100 + calibrated graph readouts102 gives
97.79%**; adding **20 normalized amplitude-order coordinates gives 97.93% with
393 total features**. Adding 36 invariant-order coordinates as well reaches
**98.00% with 429**. All 57 comparisons take about 20 seconds, without supplied
561 features. See [the experiment](OCCUPATIONS.md),
[the path constructions and proofs](occupation_theory.md), and
[complete results](occupation_results/RESULTS.md).

The preceding `--pool-story` ablates the remaining
234-feature pool and tests spectral logsignatures and observable-integral
replacements. **Raw log171 + spectral log100 + moment readouts142 reaches
97.90% with 413 features**; a 102-readout version gives **97.79% with 373**.
The compact raw/spectral log pair alone gives 93.48%, so the moment readouts
remain important. All **414 fits took 18.01 seconds**, without appending the
supplied 561 columns. See the [small-pool report](POOL_STORY.md),
[complete results](pool_results/RESULTS.md), and [moment implementation](moment_lifts.py).

The earlier `--ablations` tests which pooled
blocks matter and compares compact raw/spectral signature constructions.
**803 features retain 98.10% accuracy** without supplied 561 columns; a band-free
raw Pascal + spectral Pascal + pooling model gives **97.93% with 736 features**,
or **97.86% with 565** using the raw logsignature. All **438 fits take 31.75 seconds**.
See the [ablation report](ABLATIONS.md) and [complete results](ablation_results/RESULTS.md).

The earlier `--families` comparison tests generic moment,
filter/delay, spectral and rotation-invariant generators, with QR Pascal codes
and a small P/depth sweep. It includes pooled summaries, signatures, and hybrids
with the 342-coordinate raw Pascal P3 QR depth-two reference. The aim is to
replace the supplied 561 columns with reusable generators.
See [family results](family_results/RESULTS.md) and the
[feature-family investigation](feature_families.md).

The earlier `--pascal-sweep` compares **85 models** using simpler pre-transforms;
its [ridge results](pascal_results/RESULTS.md) are retained separately.

The earlier experiments below retain their recorded three-head results. The
original suite evaluated **234 models** in about **132 seconds**. The command-line
default is now ridge, so reproducing those older three-head runs requires
`--heads ridge rbf_svm random_forest`. Classifier settings remain fixed.

A separate **Fourier, short-delay and Pascal extension** is available with
`--temporal`; its measurements are in [temporal_results/RESULTS.md](temporal_results/RESULTS.md).
It leaves the original result files intact. See the extension discussion below
and [pascal_investigation.md](pascal_investigation.md) for the deeper Pascal connections.
A further `--observables` comparison integrates energy envelopes and delayed
products before coding; it saves [observable_results/RESULTS.md](observable_results/RESULTS.md).

## Run

From `pascal_coded_application`, with the sibling `tensorsig` checkout:

```sh
uv run --no-project --python 3.13 --with-editable ../tensorsig --with scikit-learn \
  python examples/uci_har/benchmark.py --download
```

The recorded run used the already installed sibling environment:

```sh
uv pip install --python ../tensorsig/.venv/bin/python scikit-learn
../tensorsig/.venv/bin/python examples/uci_har/benchmark.py --download
```

Useful subsets (use either Python environment above):

```sh
python examples/uci_har/benchmark.py --self-check
python examples/uci_har/benchmark.py --coded-occupations
python examples/uci_har/benchmark.py --coded-occupations --smoke
python examples/uci_har/benchmark.py --occupations
python examples/uci_har/benchmark.py --occupations --smoke
python examples/uci_har/benchmark.py --pool-story
python examples/uci_har/benchmark.py --pool-story --smoke
python examples/uci_har/benchmark.py --ablations
python examples/uci_har/benchmark.py --ablations --smoke
python examples/uci_har/benchmark.py --families
python examples/uci_har/benchmark.py --families --smoke
python examples/uci_har/benchmark.py --pascal-sweep
python examples/uci_har/benchmark.py --pascal-sweep --smoke
python examples/uci_har/benchmark.py --smoke --trees 10
python examples/uci_har/benchmark.py --variants total_basepoint --heads ridge rbf_svm \
  --output /tmp/har-small
python examples/uci_har/benchmark.py --temporal
python examples/uci_har/benchmark.py --observables
```

The download is cached under ignored `data/`; the ZIP is read without extraction.
The smoke run automatically writes to `smoke_results/`, away from measured results.
Normal reruns replace `results/`. There is no experiment framework, database,
cross-validation loop or model persistence.
The current runner uses one thread for numerical kernels and four forest workers.
It also defaults Apple's Accelerate thread limit to one before importing NumPy;
`threadpoolctl` alone does not control that backend in this environment.

## Generic families: recorded comparison

Run `python examples/uci_har/benchmark.py --families`. **All 133 comparisons
finished in 48.08 seconds.** The combined generic pooled features reach
**97.79%**, and appending the raw Pascal P3 QR depth-two reference reaches
**98.07%**, without any of the supplied 561 columns. These have 724 and 1,066
features respectively, versus 561 and 903 for the previous controls; they are
generic replacements, not dimension-matched comparisons.

| Main reference or replacement | Features | Accuracy | Macro F1 |
|---|---:|---:|---:|
| Supplied 561 | 561 | 95.72 | 95.85 |
| 561 + raw Pascal P3 QR, depth 2 | 903 | 97.12 | 97.16 |
| Generic pooled families | 724 | 97.79 | 97.83 |
| **Generic pooled families + raw Pascal P3 QR, depth 2** | **1,066** | **98.07** | **98.13** |
| 561 + generic pooled families | 1,285 | 98.37 | 98.42 |
| 561 + generic pooled families + raw Pascal | 1,627 | 98.17 | 98.22 |

The strongest replacement makes 57 test errors, versus 85 for 561 + raw Pascal.
The broader generic pooled representation does most of the work; the raw coded
signature gives eight more correctly classified windows, or 0.27 percentage points.
Appending the 561 table further improves this fixed head: the
98.37% hybrid corrects 89 errors and introduces 11 relative to 561 alone.
Adding every available block is therefore not automatically better.

### What the four families contain

[families.py](families.py) implements reusable transforms and readouts;
[family_sweep.py](family_sweep.py) composes them with tensorsig. Gravity is total
minus body acceleration. The moment and filter pools use the same eight
statistics everywhere: mean, std, mean absolute value, RMS, skewness, kurtosis,
minimum and maximum. The family-specific additions are correlations and
spectral/geometric readouts, with conventions documented in
[feature_families.md](feature_families.md).

| Family | Observation sequences signed independently | Pooled coordinates |
|---|---|---:|
| Moments/order | Axes and squares of body acceleration, gravity and gyro | 105 |
| Filters/delays | Axes/squares after differences or trailing-five-mean subtraction; valid lag-2/5 products | 146 |
| Spectral | Normalized FFT power along frequency, for xyz and norms of the three triads plus the two dynamic derivatives | 359 |
| Rotation | Triad energies, cross-triad dot products and lag-2/5 dot products | 114 |

Spectral pooling retains amplitude moments, absolute energy, log-energy,
centroid, spread, entropy, peak location and eight band masses. Its constant
training column is removed (360 before removal). Rotation pooling adds summaries
of normalized dot products. There is no hidden shared posture block. The moment
family supplies signed means; spectral power retains axis energy but loses phase
and signs; the rotation family removes device-axis orientation altogether.

Every observation sequence is integrated before signing. Codes are **QR Pascal**,
including P1 as the ordinary control. We sweep **P = 1,2,3,4** and **depth = 1,2,3**,
keeping at most 7,000 signature coordinates per family or combined construction.
The whole P/depth grid is retained where it fits that cap, rather than selecting
P/depth separately using labels. Small groups are signed independently and
concatenated; this omits words spanning groups and keeps extraction fast.
Classifier settings stay fixed: training-standardized ridge, alpha 10.

### Where coding and ordering help

In this table, "own" means signatures of that family's transformed observations.
"Raw" means the fixed 342-coordinate total-acceleration/gyro Pascal P3 QR depth-two
reference. **None of these rows uses the 561 columns.** All numbers are accuracy %.

| Family | Pooled only | + own P1/d2 | + own P3/d2 | Pooled + raw | + own P3/d2 + raw |
|---|---:|---:|---:|---:|---:|
| Moments/order | 85.88 | 87.78 | 90.84 | 92.23 | 91.79 |
| Filters/delays | 81.64 | 87.04 | 86.60 | 93.04 | 93.59 |
| Spectral | 95.25 | 95.55 | 96.06 | 96.54 | 96.95 |
| Rotation | 87.58 | 88.12 | 89.55 | 96.44 | 96.17 |
| Combined | 97.79 | 96.44 | 95.62 | **98.07** | 96.37 |

The P/depth sweep gives different answers by family:

| Family | Best pooled + own signature | Accuracy | Best with raw reference as well | Accuracy |
|---|---|---:|---|---:|
| Moments/order | P4/d2 | 91.11 | P3/d1 | 93.04 |
| Filters/delays | P1/d2 | 87.04 | P1/d1 | 94.71 |
| Spectral | **P1/d3** | **96.27** | **P3/d2** | **96.95** |
| Rotation | P2/d3 | 90.23 | P4/d1 | 96.64 |

The spectral family is the strongest individual family. Ordinary frequency-order
signatures at depth three work well; Pascal P3/depth two is strongest when paired
with the raw reference. On normalized spectral power, P3 first levels span mass,
centroid and second moment; the shuffle identity makes frequency variance a
linear depth-two readout. Additional coordinates describe ordered cross-band
relationships within each group. The mathematical identity is checked numerically.

P3 first-level-product controls give 88.70/85.68/95.76/89.14 for
moments/filters/spectral/rotation, versus 90.84/86.60/96.06/89.55 for their full
P3/depth-two tensors, all added to the same pooled block. Thus ordered tensors
are useful in those four comparisons, beyond this particular product control.
This is not an information-theoretic separation: coordinate redundancy and
regularization geometry still differ. For the combined family, products give
96.06%, while full P3/depth-two tensors give 95.62%; expanding everything hurts.

Without pooled readouts, concatenated P3/depth-two family signatures reach only
**93.86%**, or **94.33%** with the raw reference. The 98.07% result should therefore
be credited to **generic pooled features plus a compact signature complement**,
not to a pure signature replacement. The pooled block includes nonlinear
readouts such as standard deviations, extrema and normalized correlations.

Rotation invariance is exact for a common fixed orthogonal transformation of all
triads in each window: raw vectors receive one training RMS scale per triad,
then contractions are formed before coding. The standalone invariant family
improves from 87.58% to 90.23% over the sweep. Appending raw coordinates gives up
that invariance and restores orientation information. The pooled invariant
model makes 252 confusions among the three static postures; pooled + raw makes 71. A different
future generalization contracts spatial indices *after* a vector signature;
that remains a separate proposal in [tensorsig_suggestions.md](tensorsig_suggestions.md).

### Speed and verification

For the 98.07% replacement, shared preprocessing plus raw-signature extraction
takes **2.21 seconds** over all 10,299 windows; fitting takes **0.042 seconds** and
prediction **0.004 seconds** over the 2,947 test windows. Across the full sweep,
the largest fit takes 2.27 seconds and prediction at most 0.045 seconds. The
largest reported shared extraction is 9.33 seconds. Related rows reuse the
largest depth computed for their P, and every family row includes the shared
1.90-second preparation of all families: do not add these extraction timings.
The cost of extracting the supplied 561 features remains unmeasured.

The default numerical backend crashed and later corrupted cached arrays during
an initial run. The recorded family run uses an equivalent float64 ridge solve
through NumPy's **general LU** route, avoiding the Cholesky route used in those
failed runs. This changes the numerical solver, not the alpha-10 objective or
intercept treatment. Primal and dual versions are checked against scikit-learn;
an independent fresh-process LSQR run reproduced every prediction of the two
headline models and their saved confusion matrices. Cache checksums passed for
all combined inputs in the recorded run. Legacy experiments keep their original
scikit-learn solver.

Tests also verify training-only scaling, valid delay indices, Parseval's identity,
finite zero-input behavior, rotation invariance and the spectral-moment readouts.
Train-only relative constant-column filtering removes numerical variation in
fixed spectral mass without discarding coordinates merely because they are small.
All 133 accuracy/F1 rows were checked against their confusion matrices.
These remain exploratory observations on the supplied test split.

See [all comparisons](family_results/RESULTS.md), [CSV](family_results/results.csv)
and [settings and confusion matrices](family_results/run.json).

## Earlier ridge comparison: P, depth and individual pre-transforms

Run `python examples/uci_har/benchmark.py --pascal-sweep`. This keeps the original
561 + **Pascal P3 QR, depth 2, full tensor** as the reference. The supplied split,
training-global input scaling and standardized ridge with alpha 10 are unchanged.
All new fits use float64; signature arithmetic is float64 and extracted tensors
are stored as float32. No classifier tuning or extra head is introduced.

For the main grid, inputs are six total-acceleration/gyro channels. Integrating
samples means increments `x[r]/128`, without an added clock. Pascal uses `P`
QR-orthonormal polynomial columns. We try `P = 1,2,3,4,6` and depths `1,2,3`,
retaining combinations with at most 7,000 signature coordinates, plus `P1/depth4`.
For width `w = 6P`, the full tensor count is `w + ... + w**depth`.
P1 is the ordinary integrated signature up to fixed level scales removed by the
classifier's standardization.

| Pascal QR | Signature features | Alone | Added to 561 |
|---|---:|---:|---:|
| P1, depth 1 | 6 | 53.75 | 95.76 |
| P1, depth 2 | 42 | 67.93 | 96.67 |
| P1, depth 3 | 258 | 77.16 | 95.11 |
| P1, depth 4 | 1,554 | 81.81 | 95.15 |
| P2, depth 2 | 156 | 79.88 | 97.01 |
| **P3, depth 2** | **342** | **84.22** | **97.12** |
| P4, depth 2 | 600 | 87.48 | 97.01 |
| P6, depth 2 | 1,332 | 88.29 | 97.01 |
| P2, depth 3 | 1,884 | 84.46 | 95.28 |
| P3, depth 3 | 6,174 | 85.82 | 94.23 |

All entries are test accuracy percentages. The 561-only and 561 + ordinary
basepoint controls reproduce **95.72%** and **97.05%**. P3/depth2 remains the best
hybrid in this sweep, with 903 total features and 97.16% macro F1. It corrects
59 errors and introduces 18 relative to 561 alone. Increasing P helps standalone
depth-two models, but neither wider P nor greater depth improves the hybrid.
At fixed alpha, adding many correlated tensor coordinates also changes ridge's
regularization geometry; a lower score does not imply less information.

The Fourier–Pascal grid uses `P` polynomial orders around a fixed four-cycle
carrier, plus DC: `[1, t**a*cos(8*pi*t), t**a*sin(8*pi*t)]`, `a=0,...,P-1`.
Its actual code width is **1+2P**, and we QR-orthonormalize the whole matrix.
This is a different ridge geometry from the earlier unnormalized carrier run.
The same P/depth grid and feature cap apply. Its strongest standalone result is
**89.68% at P2/depth2** (930 features), and its strongest hybrid is **96.88% at
P1/depth2** (903 total features). Higher depth does not help that hybrid either.

The reusable implementation is [generators.py](generators.py):

```python
# x: (windows, samples, channels), already scaled using training windows
observations = transform_observations(x, "spectral_power")
features, seconds = coded_integration(observations, P=3, depth=2)
```

It separates the observation sequence from its integration and coding. Four
additional pre-transforms each get Pascal P1/P3 at depths 1/2, alone and added to
561. They keep all six axes, and do not append a special posture block:

| Pre-transform | Definition | P3/depth2 alone | P3/depth2 + 561 | Best hybrid in its four settings |
|---|---|---:|---:|---:|
| Differences | Consecutive differences, 127 valid rows | 62.40 | 95.83 | 96.10 (P1/d2) |
| Energy | Per-axis squared values, 128 rows | 69.19 | 95.32 | 95.79 (d1) |
| Delayed products | Per-axis lag-two products, 126 valid rows | 69.83 | 95.15 | 95.83 (P3/d1) |
| Spectral power | One-sided FFT power, 65 frequency-ordered rows | 78.01 | 95.79 | 96.10 (P3/d1) |

Differences omit the fixed 50 Hz factor. Lag products use valid pairs, without
padding. Their positions are reindexed over the shorter sequence. FFT power
includes DC and Nyquist; interior bins count both positive and negative
frequencies. The observations are scaled so their average equals the input's
mean square (Parseval). Consequently energy and spectral-power P1/depth1 have
the same standardized features up to numerical precision and record the same accuracy. Polynomial
codes on FFT power weight **frequency position**; Fourier time codes instead
weight **sample position**. These are different families.

None of these small pre-transform trials improves the P3/depth2 reference.
They are individual blocks, not a reproduction of all 561 upstream transforms
or a test of concatenating several generic families. The promising generalization
is to vary **pre-transform, observable dictionary, ordering axis, code and
statistical readout** separately. The [feature-family investigation](feature_families.md)
audits the actual 561 columns and develops moments, spectra, delay-correlation,
occupation/histogram and geometric families. Proposed tensorsig conveniences
remain separate in [tensorsig_suggestions.md](tensorsig_suggestions.md).

All **85 fits completed in 37.39 seconds**. The largest shared extraction took
3.71 seconds, the largest fit 2.35 seconds, and prediction at most 0.044 seconds.
For each P, the largest retained depth is extracted once and smaller depths are
prefix slices; their repeated extraction timings are shared, not incremental
costs. Supplied-561 extraction remains unmeasured. An initial run encountered
a native numerical-library crash; the recorded rerun completed with consistently
float64 ridge inputs, also avoiding a float32 conditioning warning in deeper fits.
That does not establish a fix for intermittent native crashes in this environment.
The self-check verifies Parseval normalization and depth-three coded coordinates
against the classical signature of the explicitly lifted path. The original
P3/depth2 features also match the new depth-prefix implementation exactly.

See [all 85 rows](pascal_results/RESULTS.md), [CSV](pascal_results/results.csv) and
[settings/confusion matrices](pascal_results/run.json). Scores remain descriptive
observations on the supplied test split; no validation-selection protocol is added.

## Earlier comparisons

The [official UCI HAR dataset](https://archive.ics.uci.edu/dataset/240/human+activity+recognition+using+smartphones)
contains 30 people, six activities, 128-point windows at 50 Hz and 50% overlap.
We keep the supplied 7,352/2,947 train/test windows and their separate subjects.
The six classes are walking, upstairs, downstairs, sitting, standing and lying.
The supplied signals are already filtered. Body acceleration excludes the
estimated gravity component; total acceleration retains it.

The earlier suites compared these three fixed heads; the current sweep uses only ridge:

- **Linear:** standardized ridge classifier, alpha 10.
- **SVM:** standardized RBF SVM, C 10, gamma `scale`.
- **Random forest:** 100 trees, maximum depth 20, minimum leaf size 2,
  square-root feature sampling, seed 2025, four workers.

Channel scaling uses all official training windows, never test windows. Features
for ridge/SVM are standardized on training rows. There is no per-window centering:
that would erase the level information we are trying to retain. The RF sees the
unstandardized extracted features. The 561-feature baseline uses the supplied
feature table, with no attempt to reproduce its upstream feature engineering.
Its extraction cost is therefore **not measured**, despite the CSV placeholder 0.

### Augmentations actually run

All signature variants include a normalized clock. `body` means body acceleration
xyz plus gyroscope xyz; `total` replaces body acceleration with total acceleration.

| Variant | Path | Purpose |
|---|---|---|
| `body_time` | Six body/gyro channels + time | Closest shallow comparison to the reference paper; no level anchor |
| `body_basepoint` | Same path, preceded by the origin | Retain levels through an initial jump |
| `total_basepoint` | Total acceleration + gyro, time and origin | Keep gravity-related posture information |
| `total_integrated` | Cumulative standardized samples divided by 128, starting at zero | Make sample means first-level features |
| `total_integrated_covariation` | Integrated path features, plus the 42 direct second-moment/roughness coordinates below | Add simultaneous products and increment energy without doubling channels |
| `total_integrated_leadlag` | Lead/lag of the integrated path, starting at zero | Make sample second moments accessible through areas |
| `total_leadlag` | Staircase lead/lag of the six signals, one clock, then origin | Expose squared increments and cross-variation |
| `total_magnitude` | Six axes plus acceleration and gyro norms, time and origin | Add direction-insensitive intensity summaries |

Magnitudes are computed **before** per-axis scaling and then standardized using
training statistics. They supplement the axes, so the representation as a whole
is not rotation invariant. Integrated signals are a feature construction, not
physical estimates of velocity or orientation.

Lead-lag is the sequence `(x0,x0), (x1,x0), (x1,x1), ...`. Only sensor channels
are doubled; the clock advances evenly through the half steps. Raw lead-lag gets
its basepoint afterward, so it does not introduce spurious same-channel lead-lag
variation. Integrated lead-lag already starts at zero and needs no extra anchor.
Both have 13 channels rather than the reference paper's 14: the clock is not doubled.
No claim is made to reproduce that paper's inconsistent printed lead-lag definition.

### Direct moments and quadratic covariation

For the six globally standardized channels, let `mu = mean(x)`,
`M = mean(x x.T)`, `C = mean((x-mu)(x-mu).T)` and
`Q = mean(diff(x) diff(x).T)`. `M` and `C` divide by 128; `Q` divides by 127.
Here `Q` means normalized **sampled increment covariation**, a roughness summary
on this fixed sampling grid. It is not a claim about a continuous-time limit.
Upper triangles include the diagonal, giving 21 entries per symmetric matrix.

Both body and total signals get three direct controls, each with all three heads:

| Representation | Coordinates | Count |
|---|---|---:|
| `mean_second_moment` | Means + upper `M` | 27 |
| `mean_second_moment_roughness` | Means + upper `M` + upper `Q` | 48 |
| `mean_std_covariation` | Means + std + upper `C` + upper `Q` | 54 |

The 48- and 54-feature versions contain the same underlying moments, but their
relationship is nonlinear. The 54-feature version exposes standard deviations
and centered covariance directly to a linear head. The original 12-feature
mean/std controls are retained.

For integrated samples, increments are `x/N`: first level is `mu`, and the
symmetrized lead-lag areas recover `M` exactly. Raw lead-lag instead recovers
increment covariation. Thus the two lifts address different statistics. The
identity, including off-diagonal channel pairs, is checked by `--self-check` and
explained in [tensorsig_suggestions.md](tensorsig_suggestions.md).

`total_integrated_covariation` appends upper `M` and upper `Q` (42 coordinates)
to every signature construction. This always supplies the **full cross-modality
moment block**: rows named modality quotient quotient only their signature
component, not the entire concatenated representation.

### Signatures and quotients

In the original suite, signatures have **depth two**. Ordinary features use
`tensorsig.classical.signatures.signature`. Offset features use an actual
`OffsetCode` and `LocalRealization(...).signature(coordinates="dense")` plan.
For R path increments, the code is `(1, r/(R-1))`, including the basepoint increment
where present. All channels, including time, get both copies.

For each path we compare ordinary/offset, full/modality, and tensor/log coordinates.
The log coordinates are net increments and signed areas
`(S_ij - S_ji)/2`. At this depth they are exact projections of the tensorsig output.

The modality graph keeps all acceleration-acceleration, gyro-gyro and time-sensor
brackets. It removes acceleration-gyro brackets; lead/lag and offset copies retain
their original modality. A tensor quotient keeps the nonedge symmetric coordinate
`(S_ij + S_ji)/sqrt(2)`, rather than deleting both ordered words. Those products
remain available to tensor-feature heads even when the area is removed.

| Six sensors + clock | Full tensor | Modality tensor | Full log | Modality log |
|---|---:|---:|---:|---:|
| Ordinary | 56 | 47 | 28 | 19 |
| Offset | 210 | 174 | 105 | 69 |

The graph is a hypothesis about dispensable ordering interactions, not sensor
independence or a rotation symmetry. These are colocated sensors, so the graph
has a weaker physical motivation than a multi-location body graph. Tensor/log
features encode the same unquotiented group element, but a linear head has
different expressive power on their different coordinates.

The quotient is a cheap readout of the full tensor calculation. This example
measures feature-size and head-cost reductions, **not sparse quotient extraction**.
Related rows share extraction work, and their extraction timings are not additive.
Timings include augmentation and shared signature/projection calculations but omit
small plan setup and output packing costs; end-to-end run time includes everything
except the initial download and dependency setup.

### What adds to the handcrafted baseline?

Five fixed hybrid controls append features to the supplied 561 columns, each with
all three heads: the 54 direct statistics; ordinary/offset full tensors on
`total_basepoint`; and ordinary/offset full log coordinates on `total_leadlag`.
The report also counts errors each hybrid corrects and introduces relative to
the same head on 561 alone. This is a small descriptive comparison, with no
search over feature combinations.

## Recorded results

See [all results](results/RESULTS.md), [machine-readable rows](results/results.csv)
and [settings, versions and confusion matrices](results/run.json).
These are exploratory single-split observations. Listed maxima are descriptive
test-set maxima, not results from model selection on a validation set.

Holding the path fixed at **total acceleration + gyro, time and basepoint** gives
the following test accuracies (%):

| Representation | Features | Ridge | RBF SVM | RF |
|---|---:|---:|---:|---:|
| Ordinary full tensor | 56 | 75.57 | 87.44 | 87.92 |
| Ordinary modality tensor | 47 | 75.67 | 84.32 | 84.05 |
| Ordinary full log | 28 | 76.86 | 87.11 | 87.51 |
| Ordinary modality log | 19 | 77.30 | 83.85 | 82.25 |
| Offset full tensor | 210 | **86.29** | **88.29** | **88.73** |
| Offset modality tensor | 174 | 83.34 | 87.48 | 86.73 |
| Offset full log | 105 | 82.97 | 88.12 | 87.14 |
| Offset modality log | 69 | 79.27 | 86.94 | 83.24 |
| Total-signal mean/std | 12 | 76.42 | 81.95 | 81.10 |
| Supplied engineered features | 561 | **95.72** | **95.49** | **92.43** |

The clearest offset gain is for the linear head: full tensor accuracy rises by
10.72 percentage points, with 210 instead of 56 features. For SVM and RF the same
gain is below one point. Quotients reduce feature counts but usually lose accuracy.
This does not establish that every extra coded interaction is useful.

The strongest signature row uses total-signal lead-lag, full offset log features
and an RBF SVM: **90.09% accuracy, 90.04% macro F1, 351 features**. Ordinary full
lead-lag log features already reach **89.79% with 91 features**. Magnitude-augmented
offset log features reach **90.02% with 171 features**. Lead-lag and magnitudes are
therefore useful alternatives, but the tiny differences between their top rows
do not justify a reliable ranking. All still trail the engineered-feature baseline.

Restoring gravity-bearing levels is more consequential than anchoring body signals
alone: full offset tensor RF gives 79.81% on `body_time`, 81.54% on
`body_basepoint`, and 88.73% on `total_basepoint`. The raw results should be consulted
when comparing other heads or representations; the best modality row can differ.

### Do the new features close the gap?

| Representation | Features | Ridge | RBF SVM | RF |
|---|---:|---:|---:|---:|
| Supplied engineered features | 561 | 95.72 | 95.49 | 92.43 |
| Total means + second moments | 27 | 72.28 | 86.70 | 84.02 |
| Total means + second moments + roughness | 48 | 82.93 | 86.94 | 87.07 |
| Total means + std + covariance + roughness | 54 | 88.53 | 89.85 | **92.77** |
| Integrated lead-lag, ordinary full log | 91 | 73.16 | 87.92 | 84.66 |
| Integrated lead-lag, offset full log | 351 | 87.00 | 88.39 | 83.03 |
| Integrated + direct block, offset full log | 147 | 87.99 | 89.24 | 87.89 |
| 561 + direct statistics | 615 | 95.86 | 96.17 | 92.47 |
| 561 + basepoint ordinary full tensor | 617 | **97.05** | **96.91** | 92.94 |
| 561 + basepoint offset full tensor | 771 | 97.01 | 96.64 | 92.57 |
| 561 + raw lead-lag ordinary full log | 652 | 95.96 | 96.88 | **93.62** |
| 561 + raw lead-lag offset full log | 912 | 95.86 | 96.03 | 92.09 |

**Direct statistics close the RF gap; integrated lead-lag does not.** The compact
54-feature RF slightly exceeds its 561-feature counterpart, while ridge and SVM
still trail the 561 baselines. Adding the 42 direct moments to integrated
signatures does not improve on the small direct model's best result. Explicit
standard deviations and centered covariance help more here than merely making
raw second moments algebraically recoverable.

**Signatures complement the 561 features, but these hybrids show no offset-specific
advantage.** Basepoint offset tensors improve ridge by 1.29 points, correcting
61 baseline errors and introducing 23. Ordinary tensors improve it by 1.32 points,
correcting 59 and introducing 20. Both outperform the 561 + direct-statistics
ridge control, whose gain is 0.14 points. Ordinary hybrids beat the corresponding
offset hybrids for all three heads on both chosen paths. This is evidence for
useful signature features under these fixed heads, not proof of information
absent from the 561 columns: changed parameterization and regularization also
matter.

**Some offset gains have a familiar explanation.** For the origin-anchored path
and linear code used here, sample means and all raw second moments are exact
linear readouts of the depth-two offset tensor. The large standalone ridge gain
therefore need not be evidence of new temporal information. Coded directed
interactions remain candidates for useful extras; this run does not isolate a
benefit unique to them. Modality quotients discard some of those interactions
and generally remain a compression tradeoff rather than an accuracy improvement.

The recorded suite took **131.9 seconds** across a 231-model run (118.7 seconds)
and a supplemental 561 + direct-statistics control (13.2 seconds, including 27
repeated baseline fits with identical scores). The saved table contains 234 unique
comparisons. The slowest individual fit took **1.43 seconds** and the slowest
prediction over all 2,947 test windows took **2.96 seconds**. The largest reported
feature extraction took **1.35 seconds** for train and test together. These are
observed CPU timings, not a dedicated performance benchmark.

Software checks cover the actual offset lift, graph commutation, level anchoring,
integration means, full-matrix lead-lag identities, direct moment controls,
anchored offset recovery of means/second moments and train-only scaling.

## Signature-like generalizations and tensorsig suggestions

The separate [tensorsig_suggestions.md](tensorsig_suggestions.md) maps the
handcrafted families to signatures: integrating chosen observables supplies
moments, energy and magnitude summaries; lead-lag or direct covariation supplies
same-sample products; delay channels supply lagged products; Fourier codes on
sample-integrated paths supply Fourier coefficients. Higher levels retain
ordered interactions between these observables. Extrema, quantiles and fitted
autoregression coefficients require additional nonlinear operations.

That document also distinguishes existing tensorsig capabilities from small
proposed additions. No tensorsig library code was changed for this experiment.

## Fourier, short-delay and Pascal extension

`--temporal` runs a fixed small comparison with the same split, scaling and heads.
It includes standalone and 561-feature hybrids for every temporal readout. The
original basepoint and integrated signatures are rerun as controls; the new coded
sample paths also get an exactly matching uncoded, six-channel integrated control.
This extension uses full tensor/log coordinates and omits modality quotients.
The original suite retains all quotient comparisons.
Use `--temporal-codes fourier24`, `fourier4`, or `pascal` to restrict coded
experiments, and `--variants` with no following values to omit the path sweep.

- **Delays:** append each signal delayed by 2 or 5 samples (40 or 100 ms), retaining
  current values, one clock and the origin anchor. Pad with the first observed
  sample within each window; nothing is borrowed from another window.
- **Fourier:** code sample-integrated increments `x[r]/128` with a constant and
  sine/cosine pairs at DFT bins `(2,4)` or `(4,)`: 0.78125 and 1.5625 Hz. These
  are fixed illustrative frequencies, not a tuned or comprehensive gait spectrum.
  First levels are normalized complex Fourier coefficients. A separate compact
  readout keeps means and all real/imaginary cross-channel spectral products,
  including powers. It removes a common cyclic phase while retaining relative
  channel phases. Full tensor/log readouts additionally retain ordered interactions.
- **Pascal:** use the certified `OffsetCode.pascal(128,3)` basis, and transform both
  tensor factors into bounded Newton coordinates `[1,t,t*(t-1/128)]`, `t=r/128`.
  Both bases carry the same information. A 78-feature readout retains means and
  directed cross-channel products weighted by the first two powers of time gap.
- **Fourier–Pascal:** use `[1,cos(8*pi*t),sin(8*pi*t),t*cos(8*pi*t),t*sin(8*pi*t)]`.
  This changes the code span. Its compact 78-feature readout weights directed
  interactions by `gap*cos(8*pi*gap)` and `gap*sin(8*pi*gap)`. The fixed bin-4
  Fourier control isolates what the linear time weights add. First-level controls
  for both Pascal variants and Fourier–Pascal help distinguish simple temporal
  moments from ordered second-level features.

All Fourier/Pascal constructions use six globally scaled sensors, integrated
from zero, with no clock or additional anchor. Normalizing sample integration
does not convert the sensors into physical displacement or orientation.

The two compact Pascal readouts are **linear projections** of their full tensor
features. Any improvement from selecting them is a modeling/regularization effect;
they add no information to those tensors. Their weights depend on time differences,
so changing the numerical time origin has no effect. Changing which samples fall
inside a window can still change the result.

The [Pascal investigation](pascal_investigation.md) develops two concrete reasons
to try these transforms: gap moments expose selected deep time-augmented ordinary
signature words at shallow coded depth, and Fourier–Pascal weights expose local
frequency derivatives of ordered cross-channel correlations. These are exact
identities for the stated embeddings, not guarantees of classification gains.

### Extension results

The successful run completed **252 comparisons in 233.6 seconds**. Selected
standalone accuracies (%) are:

| Representation | Features | Ridge | RBF SVM | RF |
|---|---:|---:|---:|---:|
| Ordinary log, 40 ms delay | 91 | 85.34 | 90.77 | 92.06 |
| Linear-offset log, 40 ms delay | 351 | 87.21 | **91.41** | 91.99 |
| Fourier bins 2,4: first levels | 30 | 57.01 | 90.91 | 88.77 |
| Fourier bins 2,4: cross-spectrum | 78 | 80.62 | 90.26 | **92.87** |
| Fourier bin 4: full tensor | 342 | 85.34 | 88.70 | 90.02 |
| Pascal P3 QR: full tensor | 342 | 84.22 | 88.39 | 84.87 |
| Pascal gap moments | 78 | 65.35 | 80.12 | 79.71 |
| Fourier–Pascal: full tensor | 930 | **90.30** | 89.31 | 90.63 |
| Fourier–Pascal: gap readout | 78 | 68.41 | 84.59 | 89.01 |

Adding features to the supplied 561 columns gives:

| Added representation | Total features | Ridge | RBF SVM | RF |
|---|---:|---:|---:|---:|
| Nothing | 561 | 95.72 | 95.49 | 92.43 |
| Ordinary basepoint tensor | 617 | 97.05 | 96.91 | 92.94 |
| Ordinary tensor, 40 ms delay | 743 | 96.91 | 96.95 | 93.65 |
| Fourier bins 2,4: cross-spectrum | 639 | 96.67 | **97.05** | **94.10** |
| Pascal P3 QR: full tensor | 903 | **97.12** | 96.57 | 91.48 |
| Pascal P3 Newton: full tensor | 903 | 97.01 | 95.52 | 89.96 |
| Fourier–Pascal: full tensor | 1491 | 96.78 | 95.39 | 92.16 |
| Fourier–Pascal: gap readout | 639 | 96.95 | 96.47 | 92.47 |

**The compact Fourier cross-spectrum is the most useful new practical control.**
Its SVM hybrid corrects 53 baseline errors and introduces 7; its RF hybrid
corrects 80 and introduces 31. It also beats the corresponding full Fourier
tensor hybrid (96.67 / 96.13 / 91.86), despite having only 78 added features
instead of 930. The gains here favor selecting phase-invariant spectral products,
not retaining every ordered Fourier coordinate. Standalone cross-spectrum RF
is only 0.10 points above the earlier 54-feature statistics RF, so that tiny
difference should not drive a choice.

**Short delays help standalone signatures, with limited extra hybrid benefit.**
At 40 ms, ordinary log SVM reaches 90.77 and offset log SVM 91.41, versus 89.79
and 90.09 for the earlier raw lead-lag models. The 100 ms delay is generally
weaker here. Adding ordinary 40 ms tensor features to 561 improves RF more than
the simple basepoint tensor does, but its SVM gain over that hybrid is just 0.04
points and ridge is slightly worse. This does not justify a delay search.

**Pascal has an interpretable effect, but no material demonstrated advantage over
the strongest simpler hybrid.** QR-Pascal ridge reaches 97.12, only two additional
correct test windows beyond the ordinary hybrid's 97.05. QR and Newton carry
exactly the same full-tensor information, yet their standalone ridge scores are
84.22 and 80.05: coordinate geometry matters. The compact pure gap readout is
weak on its own and does not unlock a better hybrid.

**Fourier–Pascal does improve the matched standalone Fourier construction.**
Adding the time-weighted carrier columns raises full-tensor ridge from 85.34 to
90.30, and SVM/RF each improve by 0.61 points. However, all three corresponding
561 hybrids get worse. Its first levels alone reach only 53.72 / 87.78 / 87.58;
second-level features matter under these heads. This does not isolate directed
order from products of first-level features, both of which occur in the full
tensor. The current evidence supports a useful standalone embedding, not a
unique advantage over the engineered baseline or its ordinary-signature hybrid.

These are descriptive results from the fixed comparison on one supplied split.
The slowest fit took **2.02 seconds**, and the slowest prediction over all 2,947
test windows took **5.41 seconds**. The slowest reported extraction took **0.60 seconds**
for train and test together, with work shared across readouts; upstream 561-feature
engineering remains unmeasured.

Two earlier attempts with multiple numerical threads stopped with native runtime
crashes. The complete saved run uses one numerical thread, including the
Accelerate limit, and four forest workers. The exact underlying native fault
was not identified; the full rerun and feature checks passed with these settings.

## Integrating energy envelopes and delayed products

`--observables` uses the same three heads and supplied split, without tuning.
It compares three small observable paths, each with ordinary, QR-Pascal P3 and
Fourier–Pascal bin-4 codes, alone and appended to 561. Depth remains two. The
default also reruns the small statistics/561 baselines and the raw total-signal
basepoint controls. The earlier result folders remain intact.

Raw channels are standardized using training windows only. Dynamics use **body
acceleration and gyroscope**, while six total-acceleration/gyro window means
are appended to every feature vector to retain posture levels. For each dynamic
triad `g`, form:

- **Energy envelopes (2 channels):** `sum_axis x_g[r]^2`, followed by a trailing
  five-sample average. This is a fixed 100 ms smoothing window.
- **Delayed products (4 channels):** `dot(x_g[r], x_g[r-lag])` at lags 2 and 5
  (40 and 100 ms), for both triads.
- **Combined (6 channels):** concatenate those two sets of observables.

All boundary indices before the window are replaced by the first sample; the
energy smoother similarly pads its first energy value. No data are borrowed
from adjacent windows. These are energies/products of globally axis-scaled
signals, not physical-unit energies or rotation-invariant features. There is
no extra observable centering/scaling and no per-window centering.

For an observable sequence `phi`, use increments `phi[r]/128`, starting at zero.
The ordinary first level is exactly its pooled mean. No clock is appended,
matching the earlier integrated coded-sample comparison. Pascal and Fourier–Pascal
therefore add temporal weightings as part of their construction; an ordinary
time-augmented path is a different possible control, not part of this sweep.

Each observable path gets ten readouts: pooled means, plus tensor, log and
**products of first levels** for each of the three codes. The last retains coded
first levels and their upper-triangle pair products, including squares, but no
additional antisymmetric level-two information. All include the identical six
posture means. This helps distinguish pooled coded moments from extra ordering;
different feature dimensions and regularization still affect the comparison.

| Combined path, including posture means | Ordinary | Pascal | Fourier–Pascal |
|---|---:|---:|---:|
| Tensor | 48 | 348 | 936 |
| Log | 27 | 177 | 471 |
| First-level products | 33 | 195 | 501 |

The combined pooled-mean control has 12 features. Hybrids add 561 to each count.
Since each observable is quadratic in the sensor readings, its second signature
level contains fourth-order sensor products, including ordered interactions
between different times. This is a substantive embedding change from coding
raw samples. Pascal changes the temporal weights applied to these interactions.

### Observable results

The complete **234-comparison run took 181.4 seconds**, with no native runtime
failure. For the combined six-channel observable path, full-tensor accuracies
are (%):

| Representation | Features | Ridge | RBF SVM | RF |
|---|---:|---:|---:|---:|
| Pooled observables + posture | 12 | 79.71 | 85.78 | 83.64 |
| Ordinary tensor | 48 | 82.83 | 85.65 | 84.42 |
| Pascal tensor | 348 | 83.54 | 87.04 | 86.09 |
| Fourier–Pascal tensor | 936 | **85.04** | **90.50** | 87.00 |
| Fourier–Pascal first-level products | 501 | 84.93 | 90.16 | **87.68** |

Adding those same feature vectors to 561 gives:

| Added representation | Total features | Ridge | RBF SVM | RF |
|---|---:|---:|---:|---:|
| Nothing | 561 | 95.72 | 95.49 | 92.43 |
| Pooled observables + posture | 573 | 96.20 | 95.83 | 92.60 |
| Ordinary tensor | 609 | 96.23 | 96.00 | 93.18 |
| Pascal tensor | 909 | 96.03 | 95.93 | 92.57 |
| Fourier–Pascal tensor | 1497 | 96.00 | 96.03 | 93.52 |
| Fourier–Pascal first-level products | 1062 | **96.27** | **96.06** | **93.65** |

**Coding helps these standalone observable models, but the hybrids do not improve
the best earlier results.** On energy alone, full-tensor RF increases from 77.91
ordinary to 80.39 Pascal and 85.61 Fourier–Pascal. On delayed products alone,
full-tensor SVM increases from 84.02 to 86.53 and 90.02. The combined path gives
the strongest observable SVM, but its 90.50 still trails the earlier raw delayed
signature SVM at 91.41. Its ridge/RF also trail the strongest earlier standalone
representations. Pooling triads discards axis-specific dynamics; that is a
plausible limitation, not an explanation isolated by this experiment.

The best new observable hybrid RF uses **delayed products with Fourier–Pascal log
features: 93.79%**, with 777 total features. That improves the 561-only RF, but
is below the earlier Fourier cross-spectrum hybrid's 94.10 with 639 features.
The best new ridge and SVM hybrids reach 96.34 and 96.13 (different readouts),
below the earlier ordinary-signature ridge at 97.05 and cross-spectrum SVM at
97.05. These are descriptive maxima over the fixed sweep, not validation-selected
models or significance claims.

**The ordering control weakens the case for retaining all second-level terms.**
For the combined Fourier–Pascal path, full tensors beat products of first levels
by only 0.11 ridge and 0.34 SVM points, while RF favors the products. All three
561 hybrids favor the product control. This shows no consistent extra predictive
benefit from the full tensor's directed terms here; it does not establish that
those terms are uninformative, because feature geometry and regularization also
change. The delayed-product log RF result shows that some smaller directed
readouts can still be useful.

The slowest fit took **1.93 seconds**, the slowest prediction over all 2,947 test
windows **3.92 seconds**, and the slowest reported feature extraction **0.80
seconds** for train and test together. Extraction is shared across readouts.
The complete [rows](observable_results/results.csv) and
[settings/confusion matrices](observable_results/run.json) are saved separately
from the earlier experiments. This particular observable embedding does not
justify replacing the existing stronger models.
