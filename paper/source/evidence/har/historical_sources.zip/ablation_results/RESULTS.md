# UCI HAR exploratory results

7,352 training / 2,947 test windows; official subject-disjoint split, fixed classifier settings, exploratory feature comparisons.

Accuracy and macro F1 are percentages. Times are seconds on this machine. Extraction includes train and test, with full calculations shared across readouts; do not sum extraction columns across heads or claim sparse quotient acceleration. The 561-feature extraction time is unmeasured (CSV placeholder 0); hybrid timings measure only the additional features.

## Best row per input/augmentation and head

These are descriptive test-set maxima over representations, not validation-selected models.

| Input / augmentation | Head | Representation | Features | Accuracy | Macro F1 | Extract | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|---:|
| engineered_561 | ridge | uci_features | 561 | 95.72 | 95.85 | 0.000 | 0.022 | 0.002 |
| pool_all | ridge | raw_pascal_P3_d2 | 1066 | 98.07 | 98.13 | 2.331 | 0.048 | 0.004 |
| raw_signature | ridge | raw_pascal_P3_d2 | 342 | 84.22 | 84.33 | 0.323 | 0.010 | 0.001 |
| pool_moments | ridge | raw_pascal_P3_d2 | 447 | 92.23 | 92.32 | 2.331 | 0.013 | 0.001 |
| pool_filters_delays | ridge | raw_pascal_P3_d2 | 488 | 93.04 | 93.04 | 2.331 | 0.015 | 0.001 |
| pool_spectral | ridge | raw_ordinary_anchored_d2 | 413 | 96.57 | 96.59 | 2.153 | 0.011 | 0.002 |
| pool_rotation | ridge | raw_pascal_P3_d2 | 456 | 96.44 | 96.44 | 2.331 | 0.014 | 0.001 |
| pool_moments+filters_delays | ridge | raw_pascal_P3_d2 | 593 | 94.16 | 94.25 | 2.331 | 0.021 | 0.002 |
| pool_moments+spectral | ridge | raw_pascal_P3_d2 | 806 | 96.61 | 96.68 | 2.331 | 0.029 | 0.003 |
| pool_moments+rotation | ridge | raw_pascal_P3_d2 | 561 | 96.98 | 96.98 | 2.331 | 0.018 | 0.002 |
| pool_filters_delays+spectral | ridge | raw_ordinary_anchored_d2 | 559 | 96.88 | 96.91 | 2.153 | 0.017 | 0.002 |
| pool_filters_delays+rotation | ridge | raw_pascal_P3_d2 | 602 | 97.05 | 97.07 | 2.331 | 0.020 | 0.002 |
| pool_spectral+rotation | ridge | raw_pascal_P3_d2 | 815 | 98.07 | 98.11 | 2.331 | 0.028 | 0.003 |
| pool_moments+filters_delays+spectral | ridge | raw_pascal_P3_d2 | 952 | 97.08 | 97.15 | 2.331 | 0.036 | 0.003 |
| pool_moments+filters_delays+rotation | ridge | raw_pascal_P3_d2 | 707 | 97.15 | 97.20 | 2.331 | 0.026 | 0.002 |
| pool_moments+spectral+rotation | ridge | raw_pascal_P3_d2 | 920 | 98.07 | 98.11 | 2.331 | 0.034 | 0.003 |
| pool_filters_delays+spectral+rotation | ridge | raw_pascal_P3_d2 | 961 | 98.03 | 98.09 | 2.331 | 0.038 | 0.003 |
| drop_moments_mean_std | ridge | raw_pascal_P3_d2 | 1042 | 98.07 | 98.13 | 2.331 | 0.044 | 0.004 |
| drop_moments_absolute_rms | ridge | raw_pascal_P3_d2 | 1042 | 97.93 | 97.99 | 2.331 | 0.042 | 0.004 |
| drop_moments_skew_kurtosis | ridge | raw_pascal_P3_d2 | 1042 | 98.10 | 98.16 | 2.331 | 0.043 | 0.004 |
| drop_moments_extrema | ridge | raw_pascal_P3_d2 | 1042 | 98.07 | 98.12 | 2.331 | 0.045 | 0.004 |
| drop_moments_correlations | ridge | raw_pascal_P3_d2 | 1057 | 98.20 | 98.26 | 2.331 | 0.047 | 0.004 |
| drop_filters_delays_difference | ridge | raw_pascal_P3_d2 | 1002 | 97.96 | 98.01 | 2.331 | 0.039 | 0.003 |
| drop_filters_delays_residual5 | ridge | raw_pascal_P3_d2 | 1002 | 98.03 | 98.09 | 2.331 | 0.040 | 0.004 |
| drop_filters_delays_lag_correlations | ridge | raw_pascal_P3_d2 | 1048 | 98.10 | 98.16 | 2.331 | 0.042 | 0.004 |
| drop_spectral_amplitude_shape | ridge | raw_pascal_P3_d2 | 986 | 97.96 | 98.02 | 2.331 | 0.040 | 0.003 |
| drop_spectral_energy | ridge | raw_pascal_P3_d2 | 1026 | 97.83 | 97.88 | 2.331 | 0.043 | 0.004 |
| drop_spectral_location | ridge | raw_pascal_P3_d2 | 1026 | 98.00 | 98.06 | 2.331 | 0.042 | 0.004 |
| drop_spectral_entropy_peak | ridge | raw_pascal_P3_d2 | 1027 | 98.00 | 98.06 | 2.331 | 0.044 | 0.003 |
| drop_spectral_bands | ridge | pooled | 564 | 97.76 | 97.80 | 2.008 | 0.019 | 0.002 |
| drop_rotation_instantaneous_moments | ridge | raw_pascal_P3_d2 | 1018 | 98.00 | 98.05 | 2.331 | 0.042 | 0.004 |
| drop_rotation_delayed_moments | ridge | raw_pascal_P3_d2 | 1018 | 98.00 | 98.06 | 2.331 | 0.042 | 0.003 |
| drop_rotation_cross_cosines | ridge | raw_pascal_P3_d2 | 1060 | 97.25 | 97.34 | 2.331 | 0.044 | 0.004 |
| drop_rotation_lag_cosines | ridge | raw_pascal_P3_d2 | 1054 | 98.17 | 98.23 | 2.331 | 0.044 | 0.004 |
| pool_time_core | ridge | raw_pascal_P3_d2 | 458 | 96.98 | 96.98 | 2.331 | 0.014 | 0.001 |
| pool_spectral_core | ridge | raw_pascal_P3_d2 | 422 | 94.23 | 94.28 | 2.331 | 0.013 | 0.001 |
| pool_compact_core | ridge | raw_pascal_P3_d2 | 538 | 97.35 | 97.39 | 2.331 | 0.018 | 0.002 |
| pool_compact_shape | ridge | raw_pascal_P3_d2 | 642 | 97.59 | 97.62 | 2.331 | 0.022 | 0.002 |
| pool_compact_shape_bands | ridge | raw_pascal_P3_d2 | 802 | 97.86 | 97.90 | 2.331 | 0.030 | 0.002 |
| pool_compact_full_spectrum | ridge | raw_pascal_P3_d2 | 817 | 97.86 | 97.90 | 2.331 | 0.029 | 0.003 |
| spectral_pool_only_amplitude_shape | ridge | raw_pascal_P3_d2 | 538 | 97.18 | 97.19 | 2.331 | 0.018 | 0.002 |
| spectral_pool_only_energy | ridge | raw_pascal_P3_d2 | 498 | 97.05 | 97.06 | 2.331 | 0.016 | 0.001 |
| spectral_pool_only_location | ridge | raw_pascal_P3_d2 | 498 | 97.08 | 97.08 | 2.331 | 0.016 | 0.001 |
| spectral_pool_only_entropy_peak | ridge | raw_pascal_P3_d2 | 497 | 96.98 | 96.98 | 2.331 | 0.015 | 0.002 |
| spectral_pool_only_bands | ridge | raw_pascal_P3_d2 | 618 | 97.42 | 97.44 | 2.331 | 0.021 | 0.002 |
| spectral_pool_groups_all | ridge | raw_pascal_P3_d2 | 817 | 97.86 | 97.90 | 2.331 | 0.029 | 0.003 |
| spectral_pool_groups_dynamic | ridge | raw_pascal_P3_d2 | 602 | 97.42 | 97.45 | 2.331 | 0.020 | 0.002 |
| spectral_pool_groups_base | ridge | raw_pascal_P3_d2 | 673 | 97.66 | 97.69 | 2.331 | 0.022 | 0.003 |
| spectral_pool_groups_dynamic_jerk | ridge | raw_pascal_P3_d2 | 746 | 97.83 | 97.85 | 2.331 | 0.027 | 0.002 |
| spectral_pool_groups_jerk | ridge | raw_pascal_P3_d2 | 602 | 97.52 | 97.53 | 2.331 | 0.020 | 0.002 |
| spectral_pool_channels_axes | ridge | raw_pascal_P3_d2 | 728 | 97.73 | 97.75 | 2.331 | 0.026 | 0.002 |
| spectral_pool_channels_norms | ridge | raw_pascal_P3_d2 | 547 | 97.08 | 97.08 | 2.331 | 0.017 | 0.002 |
| triple_time_core_spectral_ordinary_d2 | ridge | raw_pascal_P3_d2 | 518 | 96.71 | 96.72 | 2.595 | 0.015 | 0.002 |
| triple_time_core_spectral_pascal_P3_d2 | ridge | raw_pascal_P3_d2 | 1198 | 97.62 | 97.63 | 2.853 | 0.061 | 0.005 |
| triple_time_core_spectral_pascal_P3_d2_channel_compact | ridge | raw_pascal_P3_d2 | 618 | 97.42 | 97.45 | 2.853 | 0.020 | 0.002 |
| triple_compact_core_spectral_ordinary_d2 | ridge | raw_pascal_P3_d2 | 598 | 97.56 | 97.58 | 2.595 | 0.018 | 0.002 |
| triple_compact_core_spectral_pascal_P3_d2 | ridge | raw_pascal_P3_d2 | 1278 | 98.00 | 98.03 | 2.853 | 0.066 | 0.005 |
| triple_compact_core_spectral_pascal_P3_d2_channel_compact | ridge | raw_pascal_P3_d2 | 698 | 97.62 | 97.67 | 2.853 | 0.028 | 0.002 |
| triple_compact_shape_spectral_ordinary_d2 | ridge | raw_ordinary_d2 | 402 | 97.49 | 97.50 | 2.436 | 0.012 | 0.002 |
| triple_compact_shape_spectral_pascal_P3_d2 | ridge | raw_pascal_P3_d2 | 1382 | 97.86 | 97.90 | 2.853 | 0.077 | 0.006 |
| triple_compact_shape_spectral_pascal_P3_d2_channel_compact | ridge | raw_pascal_P3_d2 | 802 | 97.83 | 97.86 | 2.853 | 0.030 | 0.002 |
| triple_compact_shape_bands_spectral_ordinary_d2 | ridge | raw_pascal_P3_d2 | 862 | 97.86 | 97.90 | 2.595 | 0.031 | 0.003 |
| triple_compact_shape_bands_spectral_pascal_P3_d2 | ridge | raw_pascal_P3_d2 | 1542 | 97.86 | 97.90 | 2.853 | 0.088 | 0.006 |
| triple_compact_shape_bands_spectral_pascal_P3_d2_channel_compact | ridge | raw_pascal_P3_d2 | 962 | 97.93 | 97.97 | 2.853 | 0.048 | 0.003 |
| spectral_signature_only | ridge | full | 740 | 87.61 | 87.75 | 2.530 | 0.026 | 0.003 |
| spectral_readout_time_core_full | ridge | raw_pascal_P3_d2 | 1198 | 97.62 | 97.63 | 2.853 | 0.054 | 0.004 |
| spectral_readout_compact_shape_full | ridge | raw_pascal_P3_d2 | 1382 | 97.86 | 97.90 | 2.853 | 0.077 | 0.008 |
| spectral_readout_time_core_within_channel | ridge | raw_pascal_P3_d2 | 658 | 97.39 | 97.41 | 2.853 | 0.021 | 0.003 |
| spectral_readout_compact_shape_within_channel | ridge | raw_pascal_P3_d2 | 842 | 97.79 | 97.82 | 2.853 | 0.030 | 0.003 |
| spectral_readout_time_core_first_only | ridge | raw_pascal_P3_d2 | 498 | 96.98 | 96.98 | 2.853 | 0.014 | 0.002 |
| spectral_readout_compact_shape_first_only | ridge | raw_pascal_P3_d2 | 682 | 97.69 | 97.72 | 2.853 | 0.022 | 0.002 |
| spectral_readout_time_core_first_products | ridge | raw_pascal_P3_d2 | 838 | 97.29 | 97.31 | 2.853 | 0.030 | 0.003 |
| spectral_readout_compact_shape_first_products | ridge | raw_pascal_P3_d2 | 1022 | 97.62 | 97.67 | 2.853 | 0.046 | 0.005 |
| spectral_readout_time_core_first_areas | ridge | raw_pascal_P3_d2 | 828 | 97.49 | 97.50 | 2.853 | 0.032 | 0.003 |
| spectral_readout_compact_shape_first_areas | ridge | raw_pascal_P3_d2 | 1012 | 97.83 | 97.86 | 2.853 | 0.043 | 0.004 |
| spectral_readout_time_core_within_channel_first_products | ridge | raw_pascal_P3_d2 | 598 | 97.32 | 97.33 | 2.853 | 0.019 | 0.002 |
| spectral_readout_compact_shape_within_channel_first_products | ridge | raw_pascal_P3_d2 | 782 | 97.56 | 97.59 | 2.853 | 0.029 | 0.003 |
| spectral_readout_time_core_within_channel_first_areas | ridge | raw_pascal_P3_d2 | 558 | 97.32 | 97.32 | 2.853 | 0.017 | 0.002 |
| spectral_readout_compact_shape_within_channel_first_areas | ridge | raw_pascal_P3_d2 | 742 | 97.73 | 97.76 | 2.853 | 0.035 | 0.003 |
| spectral_readout_time_core_full_compact | ridge | raw_pascal_P3_d2 | 1008 | 97.62 | 97.64 | 2.853 | 0.042 | 0.003 |
| spectral_readout_compact_shape_full_compact | ridge | raw_pascal_P3_d2 | 1192 | 97.86 | 97.90 | 2.853 | 0.056 | 0.003 |
| spectral_readout_time_core_within_channel_compact | ridge | raw_pascal_P3_d2 | 618 | 97.42 | 97.45 | 2.853 | 0.021 | 0.002 |
| spectral_readout_compact_shape_within_channel_compact | ridge | raw_pascal_P3_d2 | 802 | 97.83 | 97.86 | 2.853 | 0.031 | 0.002 |
| spectral_readout_time_core_within_channel_compact_no_areas | ridge | raw_pascal_P3_d2 | 558 | 97.32 | 97.33 | 2.853 | 0.019 | 0.002 |
| spectral_readout_compact_shape_within_channel_compact_no_areas | ridge | raw_pascal_P3_d2 | 742 | 97.59 | 97.62 | 2.853 | 0.028 | 0.003 |
| spectral_compact_groups_time_core_dynamic | ridge | raw_pascal_P3_d2 | 522 | 97.05 | 97.05 | 2.542 | 0.017 | 0.002 |
| spectral_compact_groups_compact_shape_dynamic | ridge | raw_pascal_P3_d2 | 706 | 97.62 | 97.65 | 2.542 | 0.025 | 0.002 |
| spectral_compact_groups_time_core_base | ridge | raw_pascal_P3_d2 | 554 | 97.01 | 97.01 | 2.665 | 0.018 | 0.002 |
| spectral_compact_groups_compact_shape_base | ridge | raw_pascal_P3_d2 | 738 | 97.69 | 97.71 | 2.665 | 0.031 | 0.003 |
| spectral_compact_groups_time_core_dynamic_jerk | ridge | raw_pascal_P3_d2 | 586 | 97.32 | 97.34 | 2.750 | 0.020 | 0.002 |
| spectral_compact_groups_compact_shape_dynamic_jerk | ridge | raw_pascal_P3_d2 | 770 | 97.73 | 97.76 | 2.750 | 0.043 | 0.002 |
| spectral_compact_groups_time_core_jerk | ridge | raw_pascal_P3_d2 | 522 | 97.25 | 97.27 | 2.539 | 0.017 | 0.002 |
| spectral_compact_groups_compact_shape_jerk | ridge | raw_pascal_P3_d2 | 706 | 97.59 | 97.62 | 2.539 | 0.026 | 0.002 |
| spectral_compact_groups_time_core_axes | ridge | raw_pascal_P3_d2 | 578 | 97.22 | 97.24 | 2.797 | 0.019 | 0.002 |
| spectral_compact_groups_compact_shape_axes | ridge | raw_pascal_P3_d2 | 762 | 97.69 | 97.72 | 2.797 | 0.027 | 0.002 |
| spectral_compact_groups_time_core_norms | ridge | raw_pascal_P3_d2 | 498 | 96.98 | 96.97 | 2.568 | 0.015 | 0.001 |
| spectral_compact_groups_compact_shape_norms | ridge | raw_pascal_P3_d2 | 682 | 97.62 | 97.65 | 2.568 | 0.024 | 0.002 |
| spectral_sweep_P2_d1_full | ridge | raw_pascal_P3_d2 | 662 | 97.59 | 97.62 | 2.495 | 0.021 | 0.002 |
| spectral_sweep_P3_d1_full | ridge | raw_pascal_P3_d2 | 682 | 97.69 | 97.72 | 2.505 | 0.023 | 0.003 |
| spectral_sweep_P4_d1_full | ridge | raw_pascal_P3_d2 | 702 | 97.73 | 97.75 | 2.531 | 0.024 | 0.002 |
| spectral_sweep_P5_d1_full | ridge | raw_pascal_P3_d2 | 722 | 97.73 | 97.76 | 2.543 | 0.025 | 0.003 |
| spectral_sweep_P2_d2_within_channel_compact | ridge | raw_pascal_P3_d2 | 702 | 97.69 | 97.72 | 2.710 | 0.025 | 0.002 |
| spectral_sweep_P4_d2_within_channel_compact | ridge | raw_pascal_P3_d2 | 942 | 97.86 | 97.90 | 3.028 | 0.038 | 0.003 |
| spectral_sweep_P5_d2_within_channel_compact | ridge | raw_pascal_P3_d2 | 1122 | 97.93 | 97.97 | 3.309 | 0.068 | 0.003 |
| spectral_sweep_P1_d3_full | ridge | raw_pascal_P3_d2 | 1002 | 97.96 | 98.00 | 2.886 | 0.041 | 0.004 |
| spectral_sweep_P2_d3_full | ridge | raw_pascal_P3_d2 | 3502 | 97.93 | 97.97 | 3.603 | 0.531 | 0.019 |
| spectral_sweep_P2_d3_within_channel | ridge | raw_pascal_P3_d2 | 862 | 97.66 | 97.69 | 3.603 | 0.037 | 0.003 |
| raw_sweep_compact_shape | ridge | P2_d2 | 456 | 97.66 | 97.70 | 2.236 | 0.014 | 0.001 |
| focused_drop_spectral_amplitude_shape | ridge | raw_pascal_P3_d2 | 735 | 97.86 | 97.91 | 2.331 | 0.026 | 0.003 |
| focused_drop_spectral_energy | ridge | raw_pascal_P3_d2 | 775 | 97.76 | 97.79 | 2.331 | 0.029 | 0.003 |
| focused_drop_spectral_location | ridge | raw_pascal_P3_d2 | 775 | 98.00 | 98.03 | 2.331 | 0.027 | 0.003 |
| focused_drop_spectral_entropy_peak | ridge | raw_pascal_P3_d2 | 776 | 98.03 | 98.07 | 2.331 | 0.028 | 0.002 |
| focused_drop_spectral_bands | ridge | raw_pascal_P3_d2 | 655 | 97.62 | 97.66 | 2.331 | 0.021 | 0.003 |
| focused_drop_rotation_instantaneous_moments | ridge | raw_pascal_P3_d2 | 767 | 97.93 | 97.97 | 2.331 | 0.028 | 0.003 |
| focused_drop_rotation_delayed_moments | ridge | raw_pascal_P3_d2 | 767 | 97.96 | 97.99 | 2.331 | 0.030 | 0.003 |
| focused_drop_rotation_cross_cosines | ridge | raw_pascal_P3_d2 | 809 | 96.95 | 97.03 | 2.331 | 0.031 | 0.003 |
| focused_drop_rotation_lag_cosines | ridge | raw_pascal_P3_d2 | 803 | 98.10 | 98.14 | 2.331 | 0.029 | 0.003 |
| focused_spectral_plus_cross_cosines | ridge | raw_pascal_P3_d2 | 707 | 97.73 | 97.74 | 2.331 | 0.025 | 0.003 |
| focused_spectral_plus_cosines | ridge | raw_pascal_P3_d2 | 719 | 97.76 | 97.78 | 2.331 | 0.024 | 0.003 |
| focused_spectral_plus_instant_cross | ridge | raw_pascal_P3_d2 | 755 | 97.76 | 97.78 | 2.331 | 0.026 | 0.003 |
| focused_spectral_plus_delayed_cross | ridge | raw_pascal_P3_d2 | 755 | 97.96 | 98.00 | 2.331 | 0.026 | 0.003 |
| focused_rotation_plus_energy_shape | ridge | raw_pascal_P3_d2 | 576 | 97.08 | 97.10 | 2.331 | 0.019 | 0.002 |
| focused_rotation_plus_energy_shape_location | ridge | raw_pascal_P3_d2 | 616 | 97.42 | 97.46 | 2.331 | 0.020 | 0.002 |
| focused_rotation_plus_energy_bands | ridge | raw_pascal_P3_d2 | 656 | 97.59 | 97.63 | 2.331 | 0.022 | 0.003 |
| focused_rotation_plus_energy_shape_bands | ridge | raw_pascal_P3_d2 | 736 | 97.90 | 97.93 | 2.331 | 0.027 | 0.002 |
| focused_triple_rotation_plus_energy_shape_full | ridge | raw_pascal_P3_d2 | 1316 | 97.90 | 97.94 | 2.853 | 0.063 | 0.005 |
| focused_triple_rotation_plus_energy_shape_full_compact | ridge | raw_pascal_P3_d2 | 1126 | 98.10 | 98.14 | 2.853 | 0.053 | 0.003 |
| focused_triple_rotation_plus_energy_shape_within_channel_compact | ridge | raw_pascal_P3_d2 | 736 | 97.93 | 97.97 | 2.853 | 0.027 | 0.002 |
| focused_triple_rotation_plus_energy_shape_first_only | ridge | pooled | 274 | 97.39 | 97.38 | 2.530 | 0.007 | 0.001 |
| focused_triple_rotation_plus_energy_shape_first_products | ridge | raw_pascal_P3_d2 | 956 | 97.66 | 97.71 | 2.853 | 0.037 | 0.003 |
| focused_triple_rotation_plus_energy_shape_within_channel_first_products | ridge | raw_pascal_P3_d2 | 716 | 97.62 | 97.66 | 2.853 | 0.025 | 0.003 |
| focused_triple_rotation_plus_energy_shape_within_channel_first_areas | ridge | raw_pascal_P3_d2 | 676 | 97.83 | 97.86 | 2.853 | 0.021 | 0.002 |
| focused_triple_rotation_plus_energy_shape_within_channel_compact_no_areas | ridge | raw_pascal_P3_d2 | 676 | 97.62 | 97.66 | 2.853 | 0.023 | 0.002 |
| focused_triple_rotation_plus_energy_shape_ordinary | ridge | raw_pascal_P3_d2 | 606 | 96.91 | 96.96 | 2.595 | 0.019 | 0.002 |
| focused_triple_rotation_plus_energy_shape_location_full | ridge | raw_pascal_P3_d2 | 1356 | 98.03 | 98.08 | 2.853 | 0.068 | 0.005 |
| focused_triple_rotation_plus_energy_shape_location_full_compact | ridge | raw_pascal_P3_d2 | 1166 | 98.07 | 98.11 | 2.853 | 0.052 | 0.003 |
| focused_triple_rotation_plus_energy_shape_location_within_channel_compact | ridge | raw_pascal_P3_d2 | 776 | 97.69 | 97.74 | 2.853 | 0.027 | 0.002 |
| focused_triple_rotation_plus_energy_shape_location_first_only | ridge | raw_pascal_P3_d2 | 656 | 97.66 | 97.70 | 2.853 | 0.020 | 0.002 |
| focused_triple_rotation_plus_energy_shape_location_first_products | ridge | raw_pascal_P3_d2 | 996 | 97.59 | 97.64 | 2.853 | 0.042 | 0.004 |
| focused_triple_rotation_plus_energy_shape_location_within_channel_first_products | ridge | raw_pascal_P3_d2 | 756 | 97.59 | 97.64 | 2.853 | 0.026 | 0.003 |
| focused_triple_rotation_plus_energy_shape_location_within_channel_first_areas | ridge | raw_pascal_P3_d2 | 716 | 97.83 | 97.86 | 2.853 | 0.024 | 0.002 |
| focused_triple_rotation_plus_energy_shape_location_within_channel_compact_no_areas | ridge | raw_pascal_P3_d2 | 716 | 97.59 | 97.64 | 2.853 | 0.026 | 0.002 |
| focused_triple_rotation_plus_energy_shape_location_ordinary | ridge | raw_pascal_P3_d2 | 646 | 97.49 | 97.53 | 2.595 | 0.022 | 0.002 |
| focused_triple_drop_spectral_bands_full | ridge | raw_pascal_P3_d2 | 1395 | 98.00 | 98.04 | 2.853 | 0.072 | 0.005 |
| focused_triple_drop_spectral_bands_full_compact | ridge | raw_pascal_P3_d2 | 1205 | 98.00 | 98.04 | 2.853 | 0.053 | 0.004 |
| focused_triple_drop_spectral_bands_within_channel_compact | ridge | raw_pascal_P3_d2 | 815 | 97.90 | 97.94 | 2.853 | 0.028 | 0.003 |
| focused_triple_drop_spectral_bands_first_only | ridge | raw_pascal_P3_d2 | 695 | 97.76 | 97.80 | 2.853 | 0.023 | 0.002 |
| focused_triple_drop_spectral_bands_first_products | ridge | raw_pascal_P3_d2 | 1035 | 97.76 | 97.81 | 2.853 | 0.042 | 0.004 |
| focused_triple_drop_spectral_bands_within_channel_first_products | ridge | raw_pascal_P3_d2 | 795 | 97.76 | 97.81 | 2.853 | 0.027 | 0.003 |
| focused_triple_drop_spectral_bands_within_channel_first_areas | ridge | raw_pascal_P3_d2 | 755 | 97.90 | 97.93 | 2.853 | 0.026 | 0.003 |
| focused_triple_drop_spectral_bands_within_channel_compact_no_areas | ridge | raw_pascal_P3_d2 | 755 | 97.79 | 97.84 | 2.853 | 0.026 | 0.003 |
| focused_triple_drop_spectral_bands_ordinary | ridge | raw_pascal_P3_d2 | 685 | 97.59 | 97.63 | 2.595 | 0.022 | 0.003 |
| focused_triple_spectral_plus_cross_cosines_full | ridge | raw_pascal_P3_d2 | 1447 | 97.93 | 97.95 | 2.853 | 0.071 | 0.005 |
| focused_triple_spectral_plus_cross_cosines_full_compact | ridge | raw_pascal_P3_d2 | 1257 | 97.96 | 97.99 | 2.853 | 0.059 | 0.005 |
| focused_triple_spectral_plus_cross_cosines_within_channel_compact | ridge | raw_pascal_P3_d2 | 867 | 97.83 | 97.85 | 2.853 | 0.033 | 0.003 |
| focused_triple_spectral_plus_cross_cosines_first_only | ridge | raw_pascal_P3_d2 | 747 | 97.62 | 97.64 | 2.853 | 0.027 | 0.003 |
| focused_triple_spectral_plus_cross_cosines_first_products | ridge | raw_pascal_P3_d2 | 1087 | 97.83 | 97.85 | 2.853 | 0.045 | 0.004 |
| focused_triple_spectral_plus_cross_cosines_within_channel_first_products | ridge | raw_pascal_P3_d2 | 847 | 97.79 | 97.81 | 2.853 | 0.030 | 0.003 |
| focused_triple_spectral_plus_cross_cosines_within_channel_first_areas | ridge | raw_pascal_P3_d2 | 807 | 97.76 | 97.78 | 2.853 | 0.029 | 0.003 |
| focused_triple_spectral_plus_cross_cosines_within_channel_compact_no_areas | ridge | raw_pascal_P3_d2 | 807 | 97.79 | 97.81 | 2.853 | 0.029 | 0.003 |
| focused_triple_spectral_plus_cross_cosines_ordinary | ridge | raw_pascal_P3_d2 | 737 | 97.76 | 97.76 | 2.595 | 0.025 | 0.003 |
| raw_readout_spectral_rotation | ridge | P3_full_signature | 803 | 98.10 | 98.14 | 2.349 | 0.028 | 0.003 |
| raw_readout_coded_spectral | ridge | P3_full_signature | 736 | 97.93 | 97.97 | 2.871 | 0.027 | 0.002 |
| 561_plus_pool_all | ridge | pooled | 1285 | 98.37 | 98.42 | 2.008 | 0.061 | 0.004 |
| 561_plus_pool_compact_shape | ridge | raw_pascal_P3_d2 | 1203 | 98.13 | 98.19 | 2.331 | 0.055 | 0.003 |

## Every comparison

| Input / augmentation | Representation | Head | Features | Accuracy | Macro F1 | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|
| engineered_561 | uci_features | ridge | 561 | 95.72 | 95.85 | 0.022 | 0.002 |
| pool_all | raw_pascal_P3_d2 | ridge | 1066 | 98.07 | 98.13 | 0.048 | 0.004 |
| raw_signature | raw_ordinary_d2 | ridge | 42 | 67.93 | 66.29 | 0.001 | 0.000 |
| raw_signature | raw_pascal_P3_d2 | ridge | 342 | 84.22 | 84.33 | 0.010 | 0.001 |
| raw_signature | raw_ordinary_anchored_d2 | ridge | 54 | 75.57 | 75.49 | 0.001 | 0.000 |
| pool_moments | pooled | ridge | 105 | 85.88 | 85.93 | 0.003 | 0.000 |
| pool_moments | raw_ordinary_d2 | ridge | 147 | 88.56 | 88.49 | 0.004 | 0.001 |
| pool_moments | raw_pascal_P3_d2 | ridge | 447 | 92.23 | 92.32 | 0.013 | 0.001 |
| pool_moments | raw_ordinary_anchored_d2 | ridge | 159 | 90.16 | 90.13 | 0.004 | 0.001 |
| pool_filters_delays | pooled | ridge | 146 | 81.64 | 81.40 | 0.004 | 0.001 |
| pool_filters_delays | raw_ordinary_d2 | ridge | 188 | 91.01 | 90.97 | 0.005 | 0.001 |
| pool_filters_delays | raw_pascal_P3_d2 | ridge | 488 | 93.04 | 93.04 | 0.015 | 0.001 |
| pool_filters_delays | raw_ordinary_anchored_d2 | ridge | 200 | 91.99 | 91.89 | 0.005 | 0.001 |
| pool_spectral | pooled | ridge | 359 | 95.25 | 95.23 | 0.009 | 0.001 |
| pool_spectral | raw_ordinary_d2 | ridge | 401 | 95.86 | 95.86 | 0.011 | 0.002 |
| pool_spectral | raw_pascal_P3_d2 | ridge | 701 | 96.54 | 96.59 | 0.023 | 0.003 |
| pool_spectral | raw_ordinary_anchored_d2 | ridge | 413 | 96.57 | 96.59 | 0.011 | 0.002 |
| pool_rotation | pooled | ridge | 114 | 87.58 | 87.47 | 0.003 | 0.000 |
| pool_rotation | raw_ordinary_d2 | ridge | 156 | 95.11 | 95.06 | 0.004 | 0.000 |
| pool_rotation | raw_pascal_P3_d2 | ridge | 456 | 96.44 | 96.44 | 0.014 | 0.001 |
| pool_rotation | raw_ordinary_anchored_d2 | ridge | 168 | 95.05 | 94.96 | 0.004 | 0.001 |
| pool_moments+filters_delays | pooled | ridge | 251 | 92.43 | 92.63 | 0.012 | 0.001 |
| pool_moments+filters_delays | raw_ordinary_d2 | ridge | 293 | 93.25 | 93.34 | 0.010 | 0.001 |
| pool_moments+filters_delays | raw_pascal_P3_d2 | ridge | 593 | 94.16 | 94.25 | 0.021 | 0.002 |
| pool_moments+filters_delays | raw_ordinary_anchored_d2 | ridge | 305 | 93.96 | 94.02 | 0.008 | 0.001 |
| pool_moments+spectral | pooled | ridge | 464 | 96.23 | 96.30 | 0.013 | 0.002 |
| pool_moments+spectral | raw_ordinary_d2 | ridge | 506 | 96.17 | 96.20 | 0.015 | 0.002 |
| pool_moments+spectral | raw_pascal_P3_d2 | ridge | 806 | 96.61 | 96.68 | 0.029 | 0.003 |
| pool_moments+spectral | raw_ordinary_anchored_d2 | ridge | 518 | 96.47 | 96.50 | 0.015 | 0.002 |
| pool_moments+rotation | pooled | ridge | 219 | 95.22 | 95.29 | 0.006 | 0.001 |
| pool_moments+rotation | raw_ordinary_d2 | ridge | 261 | 95.89 | 95.86 | 0.007 | 0.001 |
| pool_moments+rotation | raw_pascal_P3_d2 | ridge | 561 | 96.98 | 96.98 | 0.018 | 0.002 |
| pool_moments+rotation | raw_ordinary_anchored_d2 | ridge | 273 | 96.34 | 96.33 | 0.007 | 0.001 |
| pool_filters_delays+spectral | pooled | ridge | 505 | 96.37 | 96.44 | 0.015 | 0.002 |
| pool_filters_delays+spectral | raw_ordinary_d2 | ridge | 547 | 96.78 | 96.82 | 0.018 | 0.002 |
| pool_filters_delays+spectral | raw_pascal_P3_d2 | ridge | 847 | 96.84 | 96.91 | 0.031 | 0.003 |
| pool_filters_delays+spectral | raw_ordinary_anchored_d2 | ridge | 559 | 96.88 | 96.91 | 0.017 | 0.002 |
| pool_filters_delays+rotation | pooled | ridge | 260 | 91.52 | 91.50 | 0.007 | 0.001 |
| pool_filters_delays+rotation | raw_ordinary_d2 | ridge | 302 | 95.45 | 95.43 | 0.008 | 0.001 |
| pool_filters_delays+rotation | raw_pascal_P3_d2 | ridge | 602 | 97.05 | 97.07 | 0.020 | 0.002 |
| pool_filters_delays+rotation | raw_ordinary_anchored_d2 | ridge | 314 | 95.32 | 95.25 | 0.008 | 0.001 |
| pool_spectral+rotation | pooled | ridge | 473 | 97.29 | 97.26 | 0.014 | 0.002 |
| pool_spectral+rotation | raw_ordinary_d2 | ridge | 515 | 97.56 | 97.56 | 0.015 | 0.002 |
| pool_spectral+rotation | raw_pascal_P3_d2 | ridge | 815 | 98.07 | 98.11 | 0.028 | 0.003 |
| pool_spectral+rotation | raw_ordinary_anchored_d2 | ridge | 527 | 97.66 | 97.65 | 0.015 | 0.002 |
| pool_moments+filters_delays+spectral | pooled | ridge | 610 | 96.78 | 96.86 | 0.019 | 0.002 |
| pool_moments+filters_delays+spectral | raw_ordinary_d2 | ridge | 652 | 96.98 | 97.03 | 0.021 | 0.002 |
| pool_moments+filters_delays+spectral | raw_pascal_P3_d2 | ridge | 952 | 97.08 | 97.15 | 0.036 | 0.003 |
| pool_moments+filters_delays+spectral | raw_ordinary_anchored_d2 | ridge | 664 | 96.71 | 96.74 | 0.022 | 0.003 |
| pool_moments+filters_delays+rotation | pooled | ridge | 365 | 96.10 | 96.22 | 0.010 | 0.001 |
| pool_moments+filters_delays+rotation | raw_ordinary_d2 | ridge | 407 | 96.74 | 96.78 | 0.012 | 0.001 |
| pool_moments+filters_delays+rotation | raw_pascal_P3_d2 | ridge | 707 | 97.15 | 97.20 | 0.026 | 0.002 |
| pool_moments+filters_delays+rotation | raw_ordinary_anchored_d2 | ridge | 419 | 96.84 | 96.83 | 0.012 | 0.002 |
| pool_moments+spectral+rotation | pooled | ridge | 578 | 97.73 | 97.74 | 0.018 | 0.003 |
| pool_moments+spectral+rotation | raw_ordinary_d2 | ridge | 620 | 97.90 | 97.92 | 0.020 | 0.002 |
| pool_moments+spectral+rotation | raw_pascal_P3_d2 | ridge | 920 | 98.07 | 98.11 | 0.034 | 0.003 |
| pool_moments+spectral+rotation | raw_ordinary_anchored_d2 | ridge | 632 | 97.59 | 97.59 | 0.020 | 0.002 |
| pool_filters_delays+spectral+rotation | pooled | ridge | 619 | 97.69 | 97.70 | 0.019 | 0.002 |
| pool_filters_delays+spectral+rotation | raw_ordinary_d2 | ridge | 661 | 97.59 | 97.61 | 0.038 | 0.003 |
| pool_filters_delays+spectral+rotation | raw_pascal_P3_d2 | ridge | 961 | 98.03 | 98.09 | 0.038 | 0.003 |
| pool_filters_delays+spectral+rotation | raw_ordinary_anchored_d2 | ridge | 673 | 97.52 | 97.52 | 0.022 | 0.002 |
| pool_all | pooled | ridge | 724 | 97.79 | 97.83 | 0.024 | 0.003 |
| pool_all | raw_ordinary_d2 | ridge | 766 | 97.66 | 97.69 | 0.028 | 0.003 |
| pool_all | raw_ordinary_anchored_d2 | ridge | 778 | 97.56 | 97.56 | 0.028 | 0.003 |
| drop_moments_mean_std | pooled | ridge | 700 | 97.69 | 97.73 | 0.023 | 0.003 |
| drop_moments_mean_std | raw_pascal_P3_d2 | ridge | 1042 | 98.07 | 98.13 | 0.044 | 0.004 |
| drop_moments_absolute_rms | pooled | ridge | 700 | 97.86 | 97.90 | 0.023 | 0.003 |
| drop_moments_absolute_rms | raw_pascal_P3_d2 | ridge | 1042 | 97.93 | 97.99 | 0.042 | 0.004 |
| drop_moments_skew_kurtosis | pooled | ridge | 700 | 97.66 | 97.70 | 0.022 | 0.003 |
| drop_moments_skew_kurtosis | raw_pascal_P3_d2 | ridge | 1042 | 98.10 | 98.16 | 0.043 | 0.004 |
| drop_moments_extrema | pooled | ridge | 700 | 97.76 | 97.79 | 0.023 | 0.003 |
| drop_moments_extrema | raw_pascal_P3_d2 | ridge | 1042 | 98.07 | 98.12 | 0.045 | 0.004 |
| drop_moments_correlations | pooled | ridge | 715 | 97.66 | 97.71 | 0.024 | 0.003 |
| drop_moments_correlations | raw_pascal_P3_d2 | ridge | 1057 | 98.20 | 98.26 | 0.047 | 0.004 |
| drop_filters_delays_difference | pooled | ridge | 660 | 97.90 | 97.93 | 0.021 | 0.002 |
| drop_filters_delays_difference | raw_pascal_P3_d2 | ridge | 1002 | 97.96 | 98.01 | 0.039 | 0.003 |
| drop_filters_delays_residual5 | pooled | ridge | 660 | 97.76 | 97.80 | 0.021 | 0.003 |
| drop_filters_delays_residual5 | raw_pascal_P3_d2 | ridge | 1002 | 98.03 | 98.09 | 0.040 | 0.004 |
| drop_filters_delays_lag_correlations | pooled | ridge | 706 | 97.83 | 97.86 | 0.023 | 0.003 |
| drop_filters_delays_lag_correlations | raw_pascal_P3_d2 | ridge | 1048 | 98.10 | 98.16 | 0.042 | 0.004 |
| drop_spectral_amplitude_shape | pooled | ridge | 644 | 97.69 | 97.74 | 0.021 | 0.002 |
| drop_spectral_amplitude_shape | raw_pascal_P3_d2 | ridge | 986 | 97.96 | 98.02 | 0.040 | 0.003 |
| drop_spectral_energy | pooled | ridge | 684 | 96.88 | 97.00 | 0.022 | 0.003 |
| drop_spectral_energy | raw_pascal_P3_d2 | ridge | 1026 | 97.83 | 97.88 | 0.043 | 0.004 |
| drop_spectral_location | pooled | ridge | 684 | 97.83 | 97.86 | 0.022 | 0.003 |
| drop_spectral_location | raw_pascal_P3_d2 | ridge | 1026 | 98.00 | 98.06 | 0.042 | 0.004 |
| drop_spectral_entropy_peak | pooled | ridge | 685 | 97.76 | 97.80 | 0.024 | 0.002 |
| drop_spectral_entropy_peak | raw_pascal_P3_d2 | ridge | 1027 | 98.00 | 98.06 | 0.044 | 0.003 |
| drop_spectral_bands | pooled | ridge | 564 | 97.76 | 97.80 | 0.019 | 0.002 |
| drop_spectral_bands | raw_pascal_P3_d2 | ridge | 906 | 97.62 | 97.68 | 0.035 | 0.004 |
| drop_rotation_instantaneous_moments | pooled | ridge | 676 | 97.96 | 98.01 | 0.023 | 0.002 |
| drop_rotation_instantaneous_moments | raw_pascal_P3_d2 | ridge | 1018 | 98.00 | 98.05 | 0.042 | 0.004 |
| drop_rotation_delayed_moments | pooled | ridge | 676 | 97.76 | 97.81 | 0.023 | 0.002 |
| drop_rotation_delayed_moments | raw_pascal_P3_d2 | ridge | 1018 | 98.00 | 98.06 | 0.042 | 0.003 |
| drop_rotation_cross_cosines | pooled | ridge | 718 | 96.57 | 96.66 | 0.023 | 0.003 |
| drop_rotation_cross_cosines | raw_pascal_P3_d2 | ridge | 1060 | 97.25 | 97.34 | 0.044 | 0.004 |
| drop_rotation_lag_cosines | pooled | ridge | 712 | 97.73 | 97.77 | 0.024 | 0.003 |
| drop_rotation_lag_cosines | raw_pascal_P3_d2 | ridge | 1054 | 98.17 | 98.23 | 0.044 | 0.004 |
| pool_time_core | pooled | ridge | 116 | 94.30 | 94.36 | 0.003 | 0.001 |
| pool_time_core | raw_ordinary_d2 | ridge | 158 | 95.55 | 95.51 | 0.004 | 0.001 |
| pool_time_core | raw_pascal_P3_d2 | ridge | 458 | 96.98 | 96.98 | 0.014 | 0.001 |
| pool_time_core | raw_ordinary_anchored_d2 | ridge | 170 | 96.50 | 96.48 | 0.004 | 0.001 |
| pool_spectral_core | pooled | ridge | 80 | 92.43 | 92.30 | 0.002 | 0.000 |
| pool_spectral_core | raw_ordinary_d2 | ridge | 122 | 93.01 | 92.94 | 0.003 | 0.000 |
| pool_spectral_core | raw_pascal_P3_d2 | ridge | 422 | 94.23 | 94.28 | 0.013 | 0.001 |
| pool_spectral_core | raw_ordinary_anchored_d2 | ridge | 134 | 93.89 | 93.89 | 0.003 | 0.001 |
| pool_compact_core | pooled | ridge | 196 | 96.20 | 96.24 | 0.005 | 0.001 |
| pool_compact_core | raw_ordinary_d2 | ridge | 238 | 96.40 | 96.38 | 0.006 | 0.001 |
| pool_compact_core | raw_pascal_P3_d2 | ridge | 538 | 97.35 | 97.39 | 0.018 | 0.002 |
| pool_compact_core | raw_ordinary_anchored_d2 | ridge | 250 | 97.12 | 97.10 | 0.006 | 0.001 |
| pool_compact_shape | pooled | ridge | 300 | 97.01 | 97.03 | 0.008 | 0.001 |
| pool_compact_shape | raw_ordinary_d2 | ridge | 342 | 97.49 | 97.49 | 0.010 | 0.001 |
| pool_compact_shape | raw_pascal_P3_d2 | ridge | 642 | 97.59 | 97.62 | 0.022 | 0.002 |
| pool_compact_shape | raw_ordinary_anchored_d2 | ridge | 354 | 97.46 | 97.46 | 0.009 | 0.001 |
| pool_compact_shape_bands | pooled | ridge | 460 | 97.32 | 97.33 | 0.013 | 0.002 |
| pool_compact_shape_bands | raw_ordinary_d2 | ridge | 502 | 97.69 | 97.71 | 0.016 | 0.001 |
| pool_compact_shape_bands | raw_pascal_P3_d2 | ridge | 802 | 97.86 | 97.90 | 0.030 | 0.002 |
| pool_compact_shape_bands | raw_ordinary_anchored_d2 | ridge | 514 | 97.62 | 97.62 | 0.015 | 0.002 |
| pool_compact_full_spectrum | pooled | ridge | 475 | 97.18 | 97.19 | 0.013 | 0.002 |
| pool_compact_full_spectrum | raw_ordinary_d2 | ridge | 517 | 97.49 | 97.50 | 0.016 | 0.002 |
| pool_compact_full_spectrum | raw_pascal_P3_d2 | ridge | 817 | 97.86 | 97.90 | 0.029 | 0.003 |
| pool_compact_full_spectrum | raw_ordinary_anchored_d2 | ridge | 529 | 97.69 | 97.69 | 0.016 | 0.002 |
| spectral_pool_only_amplitude_shape | pooled | ridge | 196 | 95.66 | 95.71 | 0.004 | 0.001 |
| spectral_pool_only_amplitude_shape | raw_pascal_P3_d2 | ridge | 538 | 97.18 | 97.19 | 0.018 | 0.002 |
| spectral_pool_only_energy | pooled | ridge | 156 | 95.45 | 95.47 | 0.004 | 0.001 |
| spectral_pool_only_energy | raw_pascal_P3_d2 | ridge | 498 | 97.05 | 97.06 | 0.016 | 0.001 |
| spectral_pool_only_location | pooled | ridge | 156 | 94.88 | 94.94 | 0.004 | 0.001 |
| spectral_pool_only_location | raw_pascal_P3_d2 | ridge | 498 | 97.08 | 97.08 | 0.016 | 0.001 |
| spectral_pool_only_entropy_peak | pooled | ridge | 155 | 95.11 | 95.19 | 0.004 | 0.001 |
| spectral_pool_only_entropy_peak | raw_pascal_P3_d2 | ridge | 497 | 96.98 | 96.98 | 0.015 | 0.002 |
| spectral_pool_only_bands | pooled | ridge | 276 | 95.28 | 95.34 | 0.007 | 0.001 |
| spectral_pool_only_bands | raw_pascal_P3_d2 | ridge | 618 | 97.42 | 97.44 | 0.021 | 0.002 |
| spectral_pool_groups_all | pooled | ridge | 475 | 97.18 | 97.19 | 0.013 | 0.002 |
| spectral_pool_groups_all | raw_pascal_P3_d2 | ridge | 817 | 97.86 | 97.90 | 0.029 | 0.003 |
| spectral_pool_groups_dynamic | pooled | ridge | 260 | 96.06 | 96.16 | 0.006 | 0.001 |
| spectral_pool_groups_dynamic | raw_pascal_P3_d2 | ridge | 602 | 97.42 | 97.45 | 0.020 | 0.002 |
| spectral_pool_groups_base | pooled | ridge | 331 | 97.22 | 97.22 | 0.008 | 0.002 |
| spectral_pool_groups_base | raw_pascal_P3_d2 | ridge | 673 | 97.66 | 97.69 | 0.022 | 0.003 |
| spectral_pool_groups_dynamic_jerk | pooled | ridge | 404 | 96.27 | 96.36 | 0.011 | 0.002 |
| spectral_pool_groups_dynamic_jerk | raw_pascal_P3_d2 | ridge | 746 | 97.83 | 97.85 | 0.027 | 0.002 |
| spectral_pool_groups_jerk | pooled | ridge | 260 | 95.72 | 95.79 | 0.006 | 0.001 |
| spectral_pool_groups_jerk | raw_pascal_P3_d2 | ridge | 602 | 97.52 | 97.53 | 0.020 | 0.002 |
| spectral_pool_channels_axes | pooled | ridge | 386 | 97.01 | 97.05 | 0.010 | 0.002 |
| spectral_pool_channels_axes | raw_pascal_P3_d2 | ridge | 728 | 97.73 | 97.75 | 0.026 | 0.002 |
| spectral_pool_channels_norms | pooled | ridge | 205 | 94.88 | 94.94 | 0.005 | 0.001 |
| spectral_pool_channels_norms | raw_pascal_P3_d2 | ridge | 547 | 97.08 | 97.08 | 0.017 | 0.002 |
| triple_time_core_spectral_ordinary_d2 | pooled | ridge | 176 | 94.71 | 94.78 | 0.004 | 0.001 |
| triple_time_core_spectral_ordinary_d2 | raw_ordinary_d2 | ridge | 218 | 95.69 | 95.67 | 0.005 | 0.001 |
| triple_time_core_spectral_ordinary_d2 | raw_pascal_P3_d2 | ridge | 518 | 96.71 | 96.72 | 0.015 | 0.002 |
| triple_time_core_spectral_pascal_P3_d2 | pooled | ridge | 856 | 95.83 | 95.89 | 0.030 | 0.003 |
| triple_time_core_spectral_pascal_P3_d2 | raw_ordinary_d2 | ridge | 898 | 96.81 | 96.78 | 0.036 | 0.003 |
| triple_time_core_spectral_pascal_P3_d2 | raw_pascal_P3_d2 | ridge | 1198 | 97.62 | 97.63 | 0.061 | 0.005 |
| triple_time_core_spectral_pascal_P3_d2_channel_compact | pooled | ridge | 276 | 95.11 | 95.19 | 0.007 | 0.001 |
| triple_time_core_spectral_pascal_P3_d2_channel_compact | raw_ordinary_d2 | ridge | 318 | 96.30 | 96.27 | 0.009 | 0.001 |
| triple_time_core_spectral_pascal_P3_d2_channel_compact | raw_pascal_P3_d2 | ridge | 618 | 97.42 | 97.45 | 0.020 | 0.002 |
| triple_compact_core_spectral_ordinary_d2 | pooled | ridge | 256 | 96.17 | 96.22 | 0.006 | 0.001 |
| triple_compact_core_spectral_ordinary_d2 | raw_ordinary_d2 | ridge | 298 | 96.78 | 96.77 | 0.007 | 0.001 |
| triple_compact_core_spectral_ordinary_d2 | raw_pascal_P3_d2 | ridge | 598 | 97.56 | 97.58 | 0.018 | 0.002 |
| triple_compact_core_spectral_pascal_P3_d2 | pooled | ridge | 936 | 96.44 | 96.49 | 0.035 | 0.003 |
| triple_compact_core_spectral_pascal_P3_d2 | raw_ordinary_d2 | ridge | 978 | 97.25 | 97.23 | 0.037 | 0.003 |
| triple_compact_core_spectral_pascal_P3_d2 | raw_pascal_P3_d2 | ridge | 1278 | 98.00 | 98.03 | 0.066 | 0.005 |
| triple_compact_core_spectral_pascal_P3_d2_channel_compact | pooled | ridge | 356 | 96.40 | 96.45 | 0.009 | 0.001 |
| triple_compact_core_spectral_pascal_P3_d2_channel_compact | raw_ordinary_d2 | ridge | 398 | 96.91 | 96.89 | 0.011 | 0.001 |
| triple_compact_core_spectral_pascal_P3_d2_channel_compact | raw_pascal_P3_d2 | ridge | 698 | 97.62 | 97.67 | 0.028 | 0.002 |
| triple_compact_shape_spectral_ordinary_d2 | pooled | ridge | 360 | 97.25 | 97.25 | 0.010 | 0.001 |
| triple_compact_shape_spectral_ordinary_d2 | raw_ordinary_d2 | ridge | 402 | 97.49 | 97.50 | 0.012 | 0.002 |
| triple_compact_shape_spectral_ordinary_d2 | raw_pascal_P3_d2 | ridge | 702 | 97.46 | 97.48 | 0.024 | 0.002 |
| triple_compact_shape_spectral_pascal_P3_d2 | pooled | ridge | 1040 | 97.15 | 97.16 | 0.041 | 0.004 |
| triple_compact_shape_spectral_pascal_P3_d2 | raw_ordinary_d2 | ridge | 1082 | 97.35 | 97.36 | 0.049 | 0.004 |
| triple_compact_shape_spectral_pascal_P3_d2 | raw_pascal_P3_d2 | ridge | 1382 | 97.86 | 97.90 | 0.077 | 0.006 |
| triple_compact_shape_spectral_pascal_P3_d2_channel_compact | pooled | ridge | 460 | 97.18 | 97.21 | 0.014 | 0.002 |
| triple_compact_shape_spectral_pascal_P3_d2_channel_compact | raw_ordinary_d2 | ridge | 502 | 97.62 | 97.63 | 0.017 | 0.002 |
| triple_compact_shape_spectral_pascal_P3_d2_channel_compact | raw_pascal_P3_d2 | ridge | 802 | 97.83 | 97.86 | 0.030 | 0.002 |
| triple_compact_shape_bands_spectral_ordinary_d2 | pooled | ridge | 520 | 97.29 | 97.31 | 0.015 | 0.002 |
| triple_compact_shape_bands_spectral_ordinary_d2 | raw_ordinary_d2 | ridge | 562 | 97.69 | 97.70 | 0.018 | 0.002 |
| triple_compact_shape_bands_spectral_ordinary_d2 | raw_pascal_P3_d2 | ridge | 862 | 97.86 | 97.90 | 0.031 | 0.003 |
| triple_compact_shape_bands_spectral_pascal_P3_d2 | pooled | ridge | 1200 | 97.22 | 97.26 | 0.054 | 0.004 |
| triple_compact_shape_bands_spectral_pascal_P3_d2 | raw_ordinary_d2 | ridge | 1242 | 97.49 | 97.50 | 0.056 | 0.004 |
| triple_compact_shape_bands_spectral_pascal_P3_d2 | raw_pascal_P3_d2 | ridge | 1542 | 97.86 | 97.90 | 0.088 | 0.006 |
| triple_compact_shape_bands_spectral_pascal_P3_d2_channel_compact | pooled | ridge | 620 | 97.25 | 97.29 | 0.020 | 0.002 |
| triple_compact_shape_bands_spectral_pascal_P3_d2_channel_compact | raw_ordinary_d2 | ridge | 662 | 97.66 | 97.67 | 0.023 | 0.003 |
| triple_compact_shape_bands_spectral_pascal_P3_d2_channel_compact | raw_pascal_P3_d2 | ridge | 962 | 97.93 | 97.97 | 0.048 | 0.003 |
| spectral_signature_only | full | ridge | 740 | 87.61 | 87.75 | 0.026 | 0.003 |
| spectral_readout_time_core_full | pooled | ridge | 856 | 95.83 | 95.89 | 0.036 | 0.004 |
| spectral_readout_time_core_full | raw_pascal_P3_d2 | ridge | 1198 | 97.62 | 97.63 | 0.054 | 0.004 |
| spectral_readout_compact_shape_full | pooled | ridge | 1040 | 97.15 | 97.16 | 0.042 | 0.004 |
| spectral_readout_compact_shape_full | raw_pascal_P3_d2 | ridge | 1382 | 97.86 | 97.90 | 0.077 | 0.008 |
| spectral_signature_only | within_channel | ridge | 200 | 83.95 | 84.03 | 0.007 | 0.001 |
| spectral_readout_time_core_within_channel | pooled | ridge | 316 | 95.18 | 95.26 | 0.014 | 0.002 |
| spectral_readout_time_core_within_channel | raw_pascal_P3_d2 | ridge | 658 | 97.39 | 97.41 | 0.021 | 0.003 |
| spectral_readout_compact_shape_within_channel | pooled | ridge | 500 | 97.15 | 97.18 | 0.016 | 0.002 |
| spectral_readout_compact_shape_within_channel | raw_pascal_P3_d2 | ridge | 842 | 97.79 | 97.82 | 0.030 | 0.003 |
| spectral_signature_only | first_only | ridge | 40 | 79.30 | 79.10 | 0.001 | 0.000 |
| spectral_readout_time_core_first_only | pooled | ridge | 156 | 95.05 | 95.12 | 0.004 | 0.001 |
| spectral_readout_time_core_first_only | raw_pascal_P3_d2 | ridge | 498 | 96.98 | 96.98 | 0.014 | 0.002 |
| spectral_readout_compact_shape_first_only | pooled | ridge | 340 | 97.25 | 97.28 | 0.008 | 0.001 |
| spectral_readout_compact_shape_first_only | raw_pascal_P3_d2 | ridge | 682 | 97.69 | 97.72 | 0.022 | 0.002 |
| spectral_signature_only | first_products | ridge | 380 | 83.51 | 83.56 | 0.010 | 0.002 |
| spectral_readout_time_core_first_products | pooled | ridge | 496 | 95.15 | 95.22 | 0.014 | 0.002 |
| spectral_readout_time_core_first_products | raw_pascal_P3_d2 | ridge | 838 | 97.29 | 97.31 | 0.030 | 0.003 |
| spectral_readout_compact_shape_first_products | pooled | ridge | 680 | 97.18 | 97.23 | 0.023 | 0.002 |
| spectral_readout_compact_shape_first_products | raw_pascal_P3_d2 | ridge | 1022 | 97.62 | 97.67 | 0.046 | 0.005 |
| spectral_signature_only | first_areas | ridge | 370 | 87.04 | 87.19 | 0.017 | 0.002 |
| spectral_readout_time_core_first_areas | pooled | ridge | 486 | 95.55 | 95.62 | 0.015 | 0.002 |
| spectral_readout_time_core_first_areas | raw_pascal_P3_d2 | ridge | 828 | 97.49 | 97.50 | 0.032 | 0.003 |
| spectral_readout_compact_shape_first_areas | pooled | ridge | 670 | 97.15 | 97.18 | 0.022 | 0.003 |
| spectral_readout_compact_shape_first_areas | raw_pascal_P3_d2 | ridge | 1012 | 97.83 | 97.86 | 0.043 | 0.004 |
| spectral_signature_only | within_channel_first_products | ridge | 140 | 81.74 | 81.71 | 0.003 | 0.001 |
| spectral_readout_time_core_within_channel_first_products | pooled | ridge | 256 | 94.94 | 95.01 | 0.006 | 0.001 |
| spectral_readout_time_core_within_channel_first_products | raw_pascal_P3_d2 | ridge | 598 | 97.32 | 97.33 | 0.019 | 0.002 |
| spectral_readout_compact_shape_within_channel_first_products | pooled | ridge | 440 | 97.39 | 97.42 | 0.012 | 0.002 |
| spectral_readout_compact_shape_within_channel_first_products | raw_pascal_P3_d2 | ridge | 782 | 97.56 | 97.59 | 0.029 | 0.003 |
| spectral_signature_only | within_channel_first_areas | ridge | 100 | 82.90 | 82.91 | 0.002 | 0.000 |
| spectral_readout_time_core_within_channel_first_areas | pooled | ridge | 216 | 95.08 | 95.16 | 0.005 | 0.001 |
| spectral_readout_time_core_within_channel_first_areas | raw_pascal_P3_d2 | ridge | 558 | 97.32 | 97.32 | 0.017 | 0.002 |
| spectral_readout_compact_shape_within_channel_first_areas | pooled | ridge | 400 | 97.25 | 97.28 | 0.012 | 0.001 |
| spectral_readout_compact_shape_within_channel_first_areas | raw_pascal_P3_d2 | ridge | 742 | 97.73 | 97.76 | 0.035 | 0.003 |
| spectral_signature_only | full_compact | ridge | 550 | 87.38 | 87.54 | 0.018 | 0.002 |
| spectral_readout_time_core_full_compact | pooled | ridge | 666 | 95.93 | 95.99 | 0.022 | 0.003 |
| spectral_readout_time_core_full_compact | raw_pascal_P3_d2 | ridge | 1008 | 97.62 | 97.64 | 0.042 | 0.003 |
| spectral_readout_compact_shape_full_compact | pooled | ridge | 850 | 97.18 | 97.20 | 0.033 | 0.003 |
| spectral_readout_compact_shape_full_compact | raw_pascal_P3_d2 | ridge | 1192 | 97.86 | 97.90 | 0.056 | 0.003 |
| spectral_signature_only | within_channel_compact | ridge | 160 | 83.85 | 83.93 | 0.003 | 0.001 |
| spectral_readout_time_core_within_channel_compact | pooled | ridge | 276 | 95.11 | 95.19 | 0.007 | 0.001 |
| spectral_readout_time_core_within_channel_compact | raw_pascal_P3_d2 | ridge | 618 | 97.42 | 97.45 | 0.021 | 0.002 |
| spectral_readout_compact_shape_within_channel_compact | pooled | ridge | 460 | 97.18 | 97.21 | 0.013 | 0.002 |
| spectral_readout_compact_shape_within_channel_compact | raw_pascal_P3_d2 | ridge | 802 | 97.83 | 97.86 | 0.031 | 0.002 |
| spectral_signature_only | within_channel_compact_no_areas | ridge | 100 | 81.54 | 81.49 | 0.002 | 0.000 |
| spectral_readout_time_core_within_channel_compact_no_areas | pooled | ridge | 216 | 94.91 | 94.98 | 0.005 | 0.001 |
| spectral_readout_time_core_within_channel_compact_no_areas | raw_pascal_P3_d2 | ridge | 558 | 97.32 | 97.33 | 0.019 | 0.002 |
| spectral_readout_compact_shape_within_channel_compact_no_areas | pooled | ridge | 400 | 97.35 | 97.39 | 0.015 | 0.001 |
| spectral_readout_compact_shape_within_channel_compact_no_areas | raw_pascal_P3_d2 | ridge | 742 | 97.59 | 97.62 | 0.028 | 0.003 |
| spectral_compact_groups_time_core_dynamic | pooled | ridge | 180 | 94.77 | 94.84 | 0.004 | 0.001 |
| spectral_compact_groups_time_core_dynamic | raw_pascal_P3_d2 | ridge | 522 | 97.05 | 97.05 | 0.017 | 0.002 |
| spectral_compact_groups_compact_shape_dynamic | pooled | ridge | 364 | 97.05 | 97.06 | 0.010 | 0.001 |
| spectral_compact_groups_compact_shape_dynamic | raw_pascal_P3_d2 | ridge | 706 | 97.62 | 97.65 | 0.025 | 0.002 |
| spectral_compact_groups_time_core_base | pooled | ridge | 212 | 94.98 | 95.04 | 0.005 | 0.001 |
| spectral_compact_groups_time_core_base | raw_pascal_P3_d2 | ridge | 554 | 97.01 | 97.01 | 0.018 | 0.002 |
| spectral_compact_groups_compact_shape_base | pooled | ridge | 396 | 97.12 | 97.12 | 0.010 | 0.002 |
| spectral_compact_groups_compact_shape_base | raw_pascal_P3_d2 | ridge | 738 | 97.69 | 97.71 | 0.031 | 0.003 |
| spectral_compact_groups_time_core_dynamic_jerk | pooled | ridge | 244 | 95.08 | 95.16 | 0.006 | 0.001 |
| spectral_compact_groups_time_core_dynamic_jerk | raw_pascal_P3_d2 | ridge | 586 | 97.32 | 97.34 | 0.020 | 0.002 |
| spectral_compact_groups_compact_shape_dynamic_jerk | pooled | ridge | 428 | 97.12 | 97.14 | 0.012 | 0.002 |
| spectral_compact_groups_compact_shape_dynamic_jerk | raw_pascal_P3_d2 | ridge | 770 | 97.73 | 97.76 | 0.043 | 0.002 |
| spectral_compact_groups_time_core_jerk | pooled | ridge | 180 | 94.67 | 94.74 | 0.004 | 0.001 |
| spectral_compact_groups_time_core_jerk | raw_pascal_P3_d2 | ridge | 522 | 97.25 | 97.27 | 0.017 | 0.002 |
| spectral_compact_groups_compact_shape_jerk | pooled | ridge | 364 | 97.12 | 97.15 | 0.010 | 0.001 |
| spectral_compact_groups_compact_shape_jerk | raw_pascal_P3_d2 | ridge | 706 | 97.59 | 97.62 | 0.026 | 0.002 |
| spectral_compact_groups_time_core_axes | pooled | ridge | 236 | 95.01 | 95.09 | 0.006 | 0.001 |
| spectral_compact_groups_time_core_axes | raw_pascal_P3_d2 | ridge | 578 | 97.22 | 97.24 | 0.019 | 0.002 |
| spectral_compact_groups_compact_shape_axes | pooled | ridge | 420 | 97.25 | 97.29 | 0.013 | 0.002 |
| spectral_compact_groups_compact_shape_axes | raw_pascal_P3_d2 | ridge | 762 | 97.69 | 97.72 | 0.027 | 0.002 |
| spectral_compact_groups_time_core_norms | pooled | ridge | 156 | 94.33 | 94.39 | 0.004 | 0.001 |
| spectral_compact_groups_time_core_norms | raw_pascal_P3_d2 | ridge | 498 | 96.98 | 96.97 | 0.015 | 0.001 |
| spectral_compact_groups_compact_shape_norms | pooled | ridge | 340 | 97.22 | 97.24 | 0.009 | 0.002 |
| spectral_compact_groups_compact_shape_norms | raw_pascal_P3_d2 | ridge | 682 | 97.62 | 97.65 | 0.024 | 0.002 |
| spectral_sweep_P2_d1_full | pooled | ridge | 320 | 97.01 | 97.03 | 0.008 | 0.001 |
| spectral_sweep_P2_d1_full | raw_pascal_P3_d2 | ridge | 662 | 97.59 | 97.62 | 0.021 | 0.002 |
| spectral_sweep_P3_d1_full | pooled | ridge | 340 | 97.25 | 97.28 | 0.009 | 0.002 |
| spectral_sweep_P3_d1_full | raw_pascal_P3_d2 | ridge | 682 | 97.69 | 97.72 | 0.023 | 0.003 |
| spectral_sweep_P4_d1_full | pooled | ridge | 360 | 97.12 | 97.15 | 0.009 | 0.002 |
| spectral_sweep_P4_d1_full | raw_pascal_P3_d2 | ridge | 702 | 97.73 | 97.75 | 0.024 | 0.002 |
| spectral_sweep_P5_d1_full | pooled | ridge | 380 | 97.25 | 97.27 | 0.010 | 0.002 |
| spectral_sweep_P5_d1_full | raw_pascal_P3_d2 | ridge | 722 | 97.73 | 97.76 | 0.025 | 0.003 |
| spectral_sweep_P2_d2_within_channel_compact | pooled | ridge | 360 | 97.15 | 97.18 | 0.011 | 0.001 |
| spectral_sweep_P2_d2_within_channel_compact | raw_pascal_P3_d2 | ridge | 702 | 97.69 | 97.72 | 0.025 | 0.002 |
| spectral_sweep_P4_d2_within_channel_compact | pooled | ridge | 600 | 97.39 | 97.40 | 0.019 | 0.002 |
| spectral_sweep_P4_d2_within_channel_compact | raw_pascal_P3_d2 | ridge | 942 | 97.86 | 97.90 | 0.038 | 0.003 |
| spectral_sweep_P5_d2_within_channel_compact | pooled | ridge | 780 | 97.46 | 97.49 | 0.030 | 0.003 |
| spectral_sweep_P5_d2_within_channel_compact | raw_pascal_P3_d2 | ridge | 1122 | 97.93 | 97.97 | 0.068 | 0.003 |
| spectral_sweep_P1_d3_full | pooled | ridge | 660 | 97.32 | 97.32 | 0.022 | 0.002 |
| spectral_sweep_P1_d3_full | raw_pascal_P3_d2 | ridge | 1002 | 97.96 | 98.00 | 0.041 | 0.004 |
| spectral_sweep_P2_d3_full | pooled | ridge | 3160 | 97.59 | 97.61 | 0.368 | 0.020 |
| spectral_sweep_P2_d3_full | raw_pascal_P3_d2 | ridge | 3502 | 97.93 | 97.97 | 0.531 | 0.019 |
| spectral_sweep_P2_d3_within_channel | pooled | ridge | 520 | 97.22 | 97.26 | 0.025 | 0.002 |
| spectral_sweep_P2_d3_within_channel | raw_pascal_P3_d2 | ridge | 862 | 97.66 | 97.69 | 0.037 | 0.003 |
| raw_sweep_compact_shape | P2_d1 | ridge | 312 | 97.15 | 97.18 | 0.010 | 0.001 |
| raw_sweep_compact_shape | P3_d1 | ridge | 318 | 97.15 | 97.17 | 0.011 | 0.001 |
| raw_sweep_compact_shape | P4_d1 | ridge | 324 | 97.08 | 97.11 | 0.011 | 0.001 |
| raw_sweep_compact_shape | P2_d2 | ridge | 456 | 97.66 | 97.70 | 0.014 | 0.001 |
| raw_sweep_compact_shape | P4_d2 | ridge | 900 | 97.49 | 97.52 | 0.036 | 0.003 |
| raw_sweep_compact_shape | P1_d3 | ridge | 558 | 95.59 | 95.61 | 0.018 | 0.002 |
| raw_sweep_compact_shape | P2_d3 | ridge | 2184 | 95.45 | 95.51 | 0.164 | 0.006 |
| focused_drop_spectral_amplitude_shape | pooled | ridge | 393 | 97.25 | 97.24 | 0.012 | 0.001 |
| focused_drop_spectral_amplitude_shape | raw_ordinary_d2 | ridge | 435 | 97.25 | 97.25 | 0.013 | 0.002 |
| focused_drop_spectral_amplitude_shape | raw_pascal_P3_d2 | ridge | 735 | 97.86 | 97.91 | 0.026 | 0.003 |
| focused_drop_spectral_energy | pooled | ridge | 433 | 96.95 | 96.95 | 0.014 | 0.002 |
| focused_drop_spectral_energy | raw_ordinary_d2 | ridge | 475 | 97.35 | 97.36 | 0.014 | 0.002 |
| focused_drop_spectral_energy | raw_pascal_P3_d2 | ridge | 775 | 97.76 | 97.79 | 0.029 | 0.003 |
| focused_drop_spectral_location | pooled | ridge | 433 | 97.49 | 97.47 | 0.013 | 0.002 |
| focused_drop_spectral_location | raw_ordinary_d2 | ridge | 475 | 97.52 | 97.53 | 0.014 | 0.002 |
| focused_drop_spectral_location | raw_pascal_P3_d2 | ridge | 775 | 98.00 | 98.03 | 0.027 | 0.003 |
| focused_drop_spectral_entropy_peak | pooled | ridge | 434 | 97.39 | 97.37 | 0.013 | 0.001 |
| focused_drop_spectral_entropy_peak | raw_ordinary_d2 | ridge | 476 | 97.73 | 97.73 | 0.014 | 0.001 |
| focused_drop_spectral_entropy_peak | raw_pascal_P3_d2 | ridge | 776 | 98.03 | 98.07 | 0.028 | 0.002 |
| focused_drop_spectral_bands | pooled | ridge | 313 | 97.39 | 97.36 | 0.008 | 0.001 |
| focused_drop_spectral_bands | raw_ordinary_d2 | ridge | 355 | 97.46 | 97.46 | 0.010 | 0.001 |
| focused_drop_spectral_bands | raw_pascal_P3_d2 | ridge | 655 | 97.62 | 97.66 | 0.021 | 0.003 |
| focused_drop_rotation_instantaneous_moments | pooled | ridge | 425 | 97.29 | 97.27 | 0.012 | 0.002 |
| focused_drop_rotation_instantaneous_moments | raw_ordinary_d2 | ridge | 467 | 97.62 | 97.62 | 0.014 | 0.002 |
| focused_drop_rotation_instantaneous_moments | raw_pascal_P3_d2 | ridge | 767 | 97.93 | 97.97 | 0.028 | 0.003 |
| focused_drop_rotation_delayed_moments | pooled | ridge | 425 | 97.49 | 97.48 | 0.012 | 0.002 |
| focused_drop_rotation_delayed_moments | raw_ordinary_d2 | ridge | 467 | 97.73 | 97.74 | 0.014 | 0.002 |
| focused_drop_rotation_delayed_moments | raw_pascal_P3_d2 | ridge | 767 | 97.96 | 97.99 | 0.030 | 0.003 |
| focused_drop_rotation_cross_cosines | pooled | ridge | 467 | 96.30 | 96.31 | 0.014 | 0.002 |
| focused_drop_rotation_cross_cosines | raw_ordinary_d2 | ridge | 509 | 96.54 | 96.57 | 0.015 | 0.002 |
| focused_drop_rotation_cross_cosines | raw_pascal_P3_d2 | ridge | 809 | 96.95 | 97.03 | 0.031 | 0.003 |
| focused_drop_rotation_lag_cosines | pooled | ridge | 461 | 97.18 | 97.14 | 0.013 | 0.002 |
| focused_drop_rotation_lag_cosines | raw_ordinary_d2 | ridge | 503 | 97.42 | 97.41 | 0.015 | 0.002 |
| focused_drop_rotation_lag_cosines | raw_pascal_P3_d2 | ridge | 803 | 98.10 | 98.14 | 0.029 | 0.003 |
| focused_spectral_plus_cross_cosines | pooled | ridge | 365 | 96.91 | 96.87 | 0.010 | 0.001 |
| focused_spectral_plus_cross_cosines | raw_ordinary_d2 | ridge | 407 | 97.29 | 97.25 | 0.011 | 0.002 |
| focused_spectral_plus_cross_cosines | raw_pascal_P3_d2 | ridge | 707 | 97.73 | 97.74 | 0.025 | 0.003 |
| focused_spectral_plus_cosines | pooled | ridge | 377 | 97.25 | 97.26 | 0.010 | 0.001 |
| focused_spectral_plus_cosines | raw_ordinary_d2 | ridge | 419 | 97.49 | 97.48 | 0.011 | 0.002 |
| focused_spectral_plus_cosines | raw_pascal_P3_d2 | ridge | 719 | 97.76 | 97.78 | 0.024 | 0.003 |
| focused_spectral_plus_instant_cross | pooled | ridge | 413 | 97.25 | 97.23 | 0.011 | 0.002 |
| focused_spectral_plus_instant_cross | raw_ordinary_d2 | ridge | 455 | 97.35 | 97.34 | 0.012 | 0.002 |
| focused_spectral_plus_instant_cross | raw_pascal_P3_d2 | ridge | 755 | 97.76 | 97.78 | 0.026 | 0.003 |
| focused_spectral_plus_delayed_cross | pooled | ridge | 413 | 97.08 | 97.06 | 0.011 | 0.002 |
| focused_spectral_plus_delayed_cross | raw_ordinary_d2 | ridge | 455 | 97.49 | 97.46 | 0.012 | 0.002 |
| focused_spectral_plus_delayed_cross | raw_pascal_P3_d2 | ridge | 755 | 97.96 | 98.00 | 0.026 | 0.003 |
| focused_rotation_plus_energy_shape | pooled | ridge | 234 | 97.01 | 96.99 | 0.006 | 0.001 |
| focused_rotation_plus_energy_shape | raw_ordinary_d2 | ridge | 276 | 96.78 | 96.79 | 0.007 | 0.001 |
| focused_rotation_plus_energy_shape | raw_pascal_P3_d2 | ridge | 576 | 97.08 | 97.10 | 0.019 | 0.002 |
| focused_rotation_plus_energy_shape_location | pooled | ridge | 274 | 97.29 | 97.27 | 0.007 | 0.001 |
| focused_rotation_plus_energy_shape_location | raw_ordinary_d2 | ridge | 316 | 97.22 | 97.23 | 0.009 | 0.001 |
| focused_rotation_plus_energy_shape_location | raw_pascal_P3_d2 | ridge | 616 | 97.42 | 97.46 | 0.020 | 0.002 |
| focused_rotation_plus_energy_bands | pooled | ridge | 314 | 96.91 | 96.88 | 0.008 | 0.001 |
| focused_rotation_plus_energy_bands | raw_ordinary_d2 | ridge | 356 | 97.05 | 97.04 | 0.010 | 0.001 |
| focused_rotation_plus_energy_bands | raw_pascal_P3_d2 | ridge | 656 | 97.59 | 97.63 | 0.022 | 0.003 |
| focused_rotation_plus_energy_shape_bands | pooled | ridge | 394 | 97.35 | 97.34 | 0.011 | 0.001 |
| focused_rotation_plus_energy_shape_bands | raw_ordinary_d2 | ridge | 436 | 97.32 | 97.33 | 0.013 | 0.001 |
| focused_rotation_plus_energy_shape_bands | raw_pascal_P3_d2 | ridge | 736 | 97.90 | 97.93 | 0.027 | 0.002 |
| focused_triple_rotation_plus_energy_shape_full | pooled | ridge | 974 | 97.56 | 97.53 | 0.037 | 0.003 |
| focused_triple_rotation_plus_energy_shape_full | raw_pascal_P3_d2 | ridge | 1316 | 97.90 | 97.94 | 0.063 | 0.005 |
| focused_triple_rotation_plus_energy_shape_full_compact | pooled | ridge | 784 | 97.62 | 97.61 | 0.029 | 0.002 |
| focused_triple_rotation_plus_energy_shape_full_compact | raw_pascal_P3_d2 | ridge | 1126 | 98.10 | 98.14 | 0.053 | 0.003 |
| focused_triple_rotation_plus_energy_shape_within_channel_compact | pooled | ridge | 394 | 97.35 | 97.34 | 0.011 | 0.001 |
| focused_triple_rotation_plus_energy_shape_within_channel_compact | raw_pascal_P3_d2 | ridge | 736 | 97.93 | 97.97 | 0.027 | 0.002 |
| focused_triple_rotation_plus_energy_shape_first_only | pooled | ridge | 274 | 97.39 | 97.38 | 0.007 | 0.001 |
| focused_triple_rotation_plus_energy_shape_first_only | raw_pascal_P3_d2 | ridge | 616 | 97.25 | 97.29 | 0.019 | 0.003 |
| focused_triple_rotation_plus_energy_shape_first_products | pooled | ridge | 614 | 97.46 | 97.46 | 0.020 | 0.002 |
| focused_triple_rotation_plus_energy_shape_first_products | raw_pascal_P3_d2 | ridge | 956 | 97.66 | 97.71 | 0.037 | 0.003 |
| focused_triple_rotation_plus_energy_shape_within_channel_first_products | pooled | ridge | 374 | 97.39 | 97.38 | 0.010 | 0.001 |
| focused_triple_rotation_plus_energy_shape_within_channel_first_products | raw_pascal_P3_d2 | ridge | 716 | 97.62 | 97.66 | 0.025 | 0.003 |
| focused_triple_rotation_plus_energy_shape_within_channel_first_areas | pooled | ridge | 334 | 97.29 | 97.27 | 0.008 | 0.001 |
| focused_triple_rotation_plus_energy_shape_within_channel_first_areas | raw_pascal_P3_d2 | ridge | 676 | 97.83 | 97.86 | 0.021 | 0.002 |
| focused_triple_rotation_plus_energy_shape_within_channel_compact_no_areas | pooled | ridge | 334 | 97.39 | 97.38 | 0.009 | 0.001 |
| focused_triple_rotation_plus_energy_shape_within_channel_compact_no_areas | raw_pascal_P3_d2 | ridge | 676 | 97.62 | 97.66 | 0.023 | 0.002 |
| focused_triple_rotation_plus_energy_shape_ordinary | pooled | ridge | 264 | 96.95 | 96.92 | 0.007 | 0.001 |
| focused_triple_rotation_plus_energy_shape_ordinary | raw_pascal_P3_d2 | ridge | 606 | 96.91 | 96.96 | 0.019 | 0.002 |
| focused_triple_rotation_plus_energy_shape_location_full | pooled | ridge | 1014 | 97.62 | 97.62 | 0.041 | 0.004 |
| focused_triple_rotation_plus_energy_shape_location_full | raw_pascal_P3_d2 | ridge | 1356 | 98.03 | 98.08 | 0.068 | 0.005 |
| focused_triple_rotation_plus_energy_shape_location_full_compact | pooled | ridge | 824 | 97.69 | 97.67 | 0.030 | 0.002 |
| focused_triple_rotation_plus_energy_shape_location_full_compact | raw_pascal_P3_d2 | ridge | 1166 | 98.07 | 98.11 | 0.052 | 0.003 |
| focused_triple_rotation_plus_energy_shape_location_within_channel_compact | pooled | ridge | 434 | 97.52 | 97.51 | 0.013 | 0.001 |
| focused_triple_rotation_plus_energy_shape_location_within_channel_compact | raw_pascal_P3_d2 | ridge | 776 | 97.69 | 97.74 | 0.027 | 0.002 |
| focused_triple_rotation_plus_energy_shape_location_first_only | pooled | ridge | 314 | 97.35 | 97.34 | 0.008 | 0.001 |
| focused_triple_rotation_plus_energy_shape_location_first_only | raw_pascal_P3_d2 | ridge | 656 | 97.66 | 97.70 | 0.020 | 0.002 |
| focused_triple_rotation_plus_energy_shape_location_first_products | pooled | ridge | 654 | 97.56 | 97.55 | 0.021 | 0.002 |
| focused_triple_rotation_plus_energy_shape_location_first_products | raw_pascal_P3_d2 | ridge | 996 | 97.59 | 97.64 | 0.042 | 0.004 |
| focused_triple_rotation_plus_energy_shape_location_within_channel_first_products | pooled | ridge | 414 | 97.29 | 97.29 | 0.011 | 0.002 |
| focused_triple_rotation_plus_energy_shape_location_within_channel_first_products | raw_pascal_P3_d2 | ridge | 756 | 97.59 | 97.64 | 0.026 | 0.003 |
| focused_triple_rotation_plus_energy_shape_location_within_channel_first_areas | pooled | ridge | 374 | 97.42 | 97.41 | 0.010 | 0.001 |
| focused_triple_rotation_plus_energy_shape_location_within_channel_first_areas | raw_pascal_P3_d2 | ridge | 716 | 97.83 | 97.86 | 0.024 | 0.002 |
| focused_triple_rotation_plus_energy_shape_location_within_channel_compact_no_areas | pooled | ridge | 374 | 97.35 | 97.35 | 0.011 | 0.001 |
| focused_triple_rotation_plus_energy_shape_location_within_channel_compact_no_areas | raw_pascal_P3_d2 | ridge | 716 | 97.59 | 97.64 | 0.026 | 0.002 |
| focused_triple_rotation_plus_energy_shape_location_ordinary | pooled | ridge | 304 | 97.22 | 97.19 | 0.008 | 0.001 |
| focused_triple_rotation_plus_energy_shape_location_ordinary | raw_pascal_P3_d2 | ridge | 646 | 97.49 | 97.53 | 0.022 | 0.002 |
| focused_triple_drop_spectral_bands_full | pooled | ridge | 1053 | 97.73 | 97.72 | 0.043 | 0.004 |
| focused_triple_drop_spectral_bands_full | raw_pascal_P3_d2 | ridge | 1395 | 98.00 | 98.04 | 0.072 | 0.005 |
| focused_triple_drop_spectral_bands_full_compact | pooled | ridge | 863 | 97.62 | 97.61 | 0.031 | 0.003 |
| focused_triple_drop_spectral_bands_full_compact | raw_pascal_P3_d2 | ridge | 1205 | 98.00 | 98.04 | 0.053 | 0.004 |
| focused_triple_drop_spectral_bands_within_channel_compact | pooled | ridge | 473 | 97.46 | 97.44 | 0.013 | 0.002 |
| focused_triple_drop_spectral_bands_within_channel_compact | raw_pascal_P3_d2 | ridge | 815 | 97.90 | 97.94 | 0.028 | 0.003 |
| focused_triple_drop_spectral_bands_first_only | pooled | ridge | 353 | 97.39 | 97.37 | 0.009 | 0.001 |
| focused_triple_drop_spectral_bands_first_only | raw_pascal_P3_d2 | ridge | 695 | 97.76 | 97.80 | 0.023 | 0.002 |
| focused_triple_drop_spectral_bands_first_products | pooled | ridge | 693 | 97.62 | 97.63 | 0.023 | 0.003 |
| focused_triple_drop_spectral_bands_first_products | raw_pascal_P3_d2 | ridge | 1035 | 97.76 | 97.81 | 0.042 | 0.004 |
| focused_triple_drop_spectral_bands_within_channel_first_products | pooled | ridge | 453 | 97.42 | 97.42 | 0.013 | 0.002 |
| focused_triple_drop_spectral_bands_within_channel_first_products | raw_pascal_P3_d2 | ridge | 795 | 97.76 | 97.81 | 0.027 | 0.003 |
| focused_triple_drop_spectral_bands_within_channel_first_areas | pooled | ridge | 413 | 97.73 | 97.72 | 0.011 | 0.002 |
| focused_triple_drop_spectral_bands_within_channel_first_areas | raw_pascal_P3_d2 | ridge | 755 | 97.90 | 97.93 | 0.026 | 0.003 |
| focused_triple_drop_spectral_bands_within_channel_compact_no_areas | pooled | ridge | 413 | 97.39 | 97.38 | 0.011 | 0.002 |
| focused_triple_drop_spectral_bands_within_channel_compact_no_areas | raw_pascal_P3_d2 | ridge | 755 | 97.79 | 97.84 | 0.026 | 0.003 |
| focused_triple_drop_spectral_bands_ordinary | pooled | ridge | 343 | 97.42 | 97.41 | 0.009 | 0.001 |
| focused_triple_drop_spectral_bands_ordinary | raw_pascal_P3_d2 | ridge | 685 | 97.59 | 97.63 | 0.022 | 0.003 |
| focused_triple_spectral_plus_cross_cosines_full | pooled | ridge | 1105 | 97.29 | 97.28 | 0.047 | 0.004 |
| focused_triple_spectral_plus_cross_cosines_full | raw_pascal_P3_d2 | ridge | 1447 | 97.93 | 97.95 | 0.071 | 0.005 |
| focused_triple_spectral_plus_cross_cosines_full_compact | pooled | ridge | 915 | 97.46 | 97.44 | 0.033 | 0.003 |
| focused_triple_spectral_plus_cross_cosines_full_compact | raw_pascal_P3_d2 | ridge | 1257 | 97.96 | 97.99 | 0.059 | 0.005 |
| focused_triple_spectral_plus_cross_cosines_within_channel_compact | pooled | ridge | 525 | 97.18 | 97.18 | 0.016 | 0.002 |
| focused_triple_spectral_plus_cross_cosines_within_channel_compact | raw_pascal_P3_d2 | ridge | 867 | 97.83 | 97.85 | 0.033 | 0.003 |
| focused_triple_spectral_plus_cross_cosines_first_only | pooled | ridge | 405 | 96.91 | 96.88 | 0.012 | 0.002 |
| focused_triple_spectral_plus_cross_cosines_first_only | raw_pascal_P3_d2 | ridge | 747 | 97.62 | 97.64 | 0.027 | 0.003 |
| focused_triple_spectral_plus_cross_cosines_first_products | pooled | ridge | 745 | 96.84 | 96.84 | 0.026 | 0.003 |
| focused_triple_spectral_plus_cross_cosines_first_products | raw_pascal_P3_d2 | ridge | 1087 | 97.83 | 97.85 | 0.045 | 0.004 |
| focused_triple_spectral_plus_cross_cosines_within_channel_first_products | pooled | ridge | 505 | 97.05 | 97.04 | 0.014 | 0.002 |
| focused_triple_spectral_plus_cross_cosines_within_channel_first_products | raw_pascal_P3_d2 | ridge | 847 | 97.79 | 97.81 | 0.030 | 0.003 |
| focused_triple_spectral_plus_cross_cosines_within_channel_first_areas | pooled | ridge | 465 | 97.15 | 97.14 | 0.013 | 0.002 |
| focused_triple_spectral_plus_cross_cosines_within_channel_first_areas | raw_pascal_P3_d2 | ridge | 807 | 97.76 | 97.78 | 0.029 | 0.003 |
| focused_triple_spectral_plus_cross_cosines_within_channel_compact_no_areas | pooled | ridge | 465 | 97.05 | 97.04 | 0.013 | 0.002 |
| focused_triple_spectral_plus_cross_cosines_within_channel_compact_no_areas | raw_pascal_P3_d2 | ridge | 807 | 97.79 | 97.81 | 0.029 | 0.003 |
| focused_triple_spectral_plus_cross_cosines_ordinary | pooled | ridge | 395 | 97.25 | 97.21 | 0.010 | 0.002 |
| focused_triple_spectral_plus_cross_cosines_ordinary | raw_pascal_P3_d2 | ridge | 737 | 97.76 | 97.76 | 0.025 | 0.003 |
| raw_readout_spectral_rotation | P1_full_signature | ridge | 503 | 97.42 | 97.41 | 0.015 | 0.002 |
| raw_readout_spectral_rotation | P1_full_logsignature | ridge | 482 | 97.32 | 97.32 | 0.014 | 0.002 |
| raw_readout_spectral_rotation | P1_modality_logsignature | ridge | 473 | 97.22 | 97.22 | 0.013 | 0.002 |
| raw_readout_spectral_rotation | P1_modality_signature | ridge | 494 | 97.35 | 97.33 | 0.014 | 0.002 |
| raw_readout_spectral_rotation | P1_within_modality | ridge | 485 | 97.42 | 97.40 | 0.014 | 0.002 |
| raw_readout_spectral_rotation | P1_first_products | ridge | 488 | 97.29 | 97.26 | 0.014 | 0.002 |
| raw_readout_spectral_rotation | P1_first_only | ridge | 467 | 97.12 | 97.10 | 0.013 | 0.002 |
| raw_readout_spectral_rotation | P3_full_signature | ridge | 803 | 98.10 | 98.14 | 0.028 | 0.003 |
| raw_readout_spectral_rotation | P3_full_logsignature | ridge | 632 | 97.83 | 97.85 | 0.019 | 0.002 |
| raw_readout_spectral_rotation | P3_modality_logsignature | ridge | 551 | 97.52 | 97.51 | 0.017 | 0.002 |
| raw_readout_spectral_rotation | P3_modality_signature | ridge | 722 | 97.52 | 97.52 | 0.025 | 0.003 |
| raw_readout_spectral_rotation | P3_within_modality | ridge | 641 | 97.73 | 97.73 | 0.021 | 0.002 |
| raw_readout_spectral_rotation | P3_first_products | ridge | 650 | 97.66 | 97.66 | 0.021 | 0.002 |
| raw_readout_spectral_rotation | P3_first_only | ridge | 479 | 97.12 | 97.10 | 0.014 | 0.002 |
| raw_readout_coded_spectral | P1_full_signature | ridge | 436 | 97.35 | 97.36 | 0.013 | 0.001 |
| raw_readout_coded_spectral | P1_full_logsignature | ridge | 415 | 97.18 | 97.19 | 0.012 | 0.001 |
| raw_readout_coded_spectral | P1_modality_logsignature | ridge | 406 | 97.15 | 97.16 | 0.011 | 0.001 |
| raw_readout_coded_spectral | P1_modality_signature | ridge | 427 | 97.35 | 97.35 | 0.012 | 0.001 |
| raw_readout_coded_spectral | P1_within_modality | ridge | 418 | 97.35 | 97.35 | 0.012 | 0.001 |
| raw_readout_coded_spectral | P1_first_products | ridge | 421 | 97.29 | 97.28 | 0.012 | 0.001 |
| raw_readout_coded_spectral | P1_first_only | ridge | 400 | 97.12 | 97.12 | 0.011 | 0.001 |
| raw_readout_coded_spectral | P3_full_signature | ridge | 736 | 97.93 | 97.97 | 0.027 | 0.002 |
| raw_readout_coded_spectral | P3_full_logsignature | ridge | 565 | 97.86 | 97.90 | 0.018 | 0.002 |
| raw_readout_coded_spectral | P3_modality_logsignature | ridge | 484 | 97.29 | 97.27 | 0.015 | 0.001 |
| raw_readout_coded_spectral | P3_modality_signature | ridge | 655 | 97.66 | 97.68 | 0.022 | 0.002 |
| raw_readout_coded_spectral | P3_within_modality | ridge | 574 | 97.52 | 97.55 | 0.018 | 0.002 |
| raw_readout_coded_spectral | P3_first_products | ridge | 583 | 97.49 | 97.51 | 0.019 | 0.002 |
| raw_readout_coded_spectral | P3_first_only | ridge | 412 | 97.08 | 97.09 | 0.012 | 0.001 |
| 561_plus_pool_all | pooled | ridge | 1285 | 98.37 | 98.42 | 0.061 | 0.004 |
| 561_plus_pool_all | raw_pascal_P3_d2 | ridge | 1627 | 98.17 | 98.22 | 0.089 | 0.006 |
| 561_plus_pool_compact_shape | pooled | ridge | 861 | 98.03 | 98.07 | 0.033 | 0.002 |
| 561_plus_pool_compact_shape | raw_pascal_P3_d2 | ridge | 1203 | 98.13 | 98.19 | 0.055 | 0.003 |

## Adding features to the 561 features

Corrected and lost predictions compare the hybrid with the same head on the 561 features alone. They are descriptive counts on this test split, not significance tests.

| Hybrid / representation / head | Corrected errors | Introduced errors |
|---|---:|---:|
| 561_plus_pool_all/pooled/ridge | 89 | 11 |
| 561_plus_pool_all/raw_pascal_P3_d2/ridge | 87 | 15 |
| 561_plus_pool_compact_shape/pooled/ridge | 79 | 11 |
| 561_plus_pool_compact_shape/raw_pascal_P3_d2/ridge | 84 | 13 |
