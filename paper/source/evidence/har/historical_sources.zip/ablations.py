"""Fixed, inexpensive pooled/spectral ablations; all heads are alpha-10 ridge."""

from hashlib import sha256
from itertools import combinations
from time import perf_counter

import numpy as np
import torch
from families import build_families
from features import _coordinates, _standardize, augment
from generators import coded_integration
from pooled_blocks import pooled_blocks, pooling_sets, spectral_pool
from spectral_readouts import signature_readouts
from tensorsig.classical.signatures import signature


def run(evaluate, signals, n_train, engineered, args, metadata):
    start = perf_counter()
    raw = _standardize(torch.as_tensor(signals[..., [6, 7, 8, 3, 4, 5]],
                                      dtype=torch.float64), n_train)
    raw_scaling = perf_counter() - start
    additions, addition_times = {}, {}
    for p, name in ((1, "raw_ordinary_d2"), (3, "raw_pascal_P3_d2")):
        additions[name], seconds = coded_integration(raw, p, 2, batch_size=args.batch_size)
        addition_times[name] = raw_scaling + seconds
    start = perf_counter()
    paths, _ = augment(signals[..., [6, 7, 8, 3, 4, 5]], "basepoint", n_train)
    additions["raw_ordinary_anchored_d2"] = np.concatenate([
        signature(batch, depth=2).float().numpy() for batch in paths.split(args.batch_size)
    ])
    addition_times["raw_ordinary_anchored_d2"] = perf_counter() - start
    del paths
    start = perf_counter()
    families = build_families(signals, n_train)
    blocks, presets = pooled_blocks(families), pooling_sets(families)
    preparation = perf_counter() - start
    pools = {name: family["pooled"] for name, family in families.items()}
    checksums = {name: sha256(values).digest() for name, values in pools.items()}
    all_pool = np.concatenate(list(pools.values()), axis=1)
    metadata["ablation_settings"] = {
        "supplied_561": "Excluded except engineered_561 and explicitly named 561_plus controls",
        "raw_input": "total_acc xyz and body_gyro xyz, training-global affine scaling",
        "ordinary_control": "P1 QR on the same integrated observations; anchored raw path + clock is also tested",
        "codes": "All coded signatures use QR Pascal, channel-major code order",
        "main_reference": "pool_all/raw_pascal_P3_d2: previous 98.07%, no supplied 561",
        "pool_subsets": "All 15 nonempty subsets of the four families",
        "pool_block_ablation": "Leave one named block out of the complete pool; with and without raw Pascal",
        "spectral_normalization": "Unit mass per channel; absolute energy remains in pooling",
        "spectral_compact": "Exact affine-span reduction at depth2; StandardScaler changes ridge geometry",
        "spectral_groups": families["spectral"]["groups"],
        "pool_blocks": {f: {k: v.shape[1] for k, v in b.items()} for f, b in blocks.items()},
        "pool_presets": {k: v.shape[1] for k, v in presets.items()},
        "preparation_s": preparation,
        "timings": "Shared full-family preparation and dense extraction, including readout projection; no sparse speed claim",
        "selection": "Fixed descriptive ablations on the existing test split, no hyperparameter selection protocol",
    }

    def compare(name, values, seconds=preparation, heads=None):
        evaluate(name, "pooled", values, seconds)
        for label in additions if heads is None else heads:
            evaluate(name, label, np.concatenate((values, additions[label]), axis=1),
                     seconds + addition_times[label])

    # Evaluate the old result first so every subsequent row has paired errors.
    evaluate("pool_all", "raw_pascal_P3_d2",
             np.concatenate((all_pool, additions["raw_pascal_P3_d2"]), axis=1),
             preparation + addition_times["raw_pascal_P3_d2"])
    for name, values in additions.items():
        evaluate("raw_signature", name, values, addition_times[name])
    for size in range(1, 5):
        for names in combinations(pools, size):
            name = "pool_all" if size == 4 else "pool_" + "+".join(names)
            values = np.concatenate([pools[key] for key in names], axis=1)
            labels = [key for key in additions if not (size == 4 and key == "raw_pascal_P3_d2")]
            compare(name, values, heads=labels)
    for family, parts in blocks.items():
        for removed in parts:
            values = np.concatenate([
                pools[key] if key != family else np.concatenate(
                    [v for k, v in parts.items() if k != removed], axis=1)
                for key in pools
            ], axis=1)
            compare(f"drop_{family}_{removed}", values, heads=["raw_pascal_P3_d2"])
    for name, values in presets.items():
        compare("pool_" + name, values)

    # Which spectral statistics, triads and axes provide the gain?
    time_pool = presets["time_core"]
    for statistic, values in blocks["spectral"].items():
        compare("spectral_pool_only_" + statistic, np.concatenate((time_pool, values), axis=1),
                heads=["raw_pascal_P3_d2"])
    group_sets = {
        "all": tuple(range(5)), "dynamic": (0, 2), "base": (0, 1, 2),
        "dynamic_jerk": (0, 2, 3, 4), "jerk": (3, 4),
    }
    for name, indices in group_sets.items():
        selected = [families["spectral"]["groups"][i] for i in indices]
        values = np.concatenate((time_pool, spectral_pool(families, groups=selected)), axis=1)
        compare("spectral_pool_groups_" + name, values, heads=["raw_pascal_P3_d2"])
    for name, channels in (("axes", (0, 1, 2)), ("norms", (3,))):
        values = np.concatenate((time_pool, spectral_pool(families, channels=channels)), axis=1)
        compare("spectral_pool_channels_" + name, values, heads=["raw_pascal_P3_d2"])

    observations = families["spectral"]["observations"]
    spectral, spectral_seconds = signature_readouts(observations, 3, 2, args.batch_size)
    # Exact requested triple, and its ordinary/coded two-by-two control.
    spectral_ordinary, ordinary_seconds = signature_readouts(observations, 1, 2, args.batch_size)
    for pool_name in ("time_core", "compact_core", "compact_shape", "compact_shape_bands"):
        pool = presets[pool_name]
        for spec_name, readout, elapsed in (
            ("ordinary_d2", spectral_ordinary["full"], ordinary_seconds),
            ("pascal_P3_d2", spectral["full"], spectral_seconds),
            ("pascal_P3_d2_channel_compact", spectral["within_channel_compact"], spectral_seconds),
        ):
            values = np.concatenate((pool, readout), axis=1)
            compare(f"triple_{pool_name}_spectral_{spec_name}", values, preparation + elapsed,
                    heads=["raw_ordinary_d2", "raw_pascal_P3_d2"])
    for label, values in spectral.items():
        evaluate("spectral_signature_only", label, values, preparation + spectral_seconds)
        for pool_name in ("time_core", "compact_shape"):
            compare(f"spectral_readout_{pool_name}_{label}",
                    np.concatenate((presets[pool_name], values), axis=1),
                    preparation + spectral_seconds, heads=["raw_pascal_P3_d2"])

    # Retain within-channel coded moments/areas while removing groups/channels.
    selections = [(name, [observations[i] for i in indices])
                  for name, indices in group_sets.items() if name != "all"]
    selections += [("axes", [obs[:, :, :3] for obs in observations]),
                   ("norms", [obs[:, :, 3:] for obs in observations])]
    for name, selected in selections:
        readouts, elapsed = signature_readouts(selected, 3, 2, args.batch_size)
        for pool_name in ("time_core", "compact_shape"):
            compare(f"spectral_compact_groups_{pool_name}_{name}",
                    np.concatenate((presets[pool_name], readouts["within_channel_compact"]), axis=1),
                    preparation + elapsed, heads=["raw_pascal_P3_d2"])

    # Degree P-1 and interaction order are separate, small controls.
    for p, depth in ((2, 1), (3, 1), (4, 1), (5, 1), (2, 2), (4, 2), (5, 2), (1, 3), (2, 3)):
        readouts, elapsed = signature_readouts(observations, p, depth, args.batch_size)
        selections = (["within_channel_compact"] if depth == 2 else
                      ["full", "within_channel"] if depth == 3 and p > 1 else ["full"])
        for selection in selections:
            compare(f"spectral_sweep_P{p}_d{depth}_{selection}",
                    np.concatenate((presets["compact_shape"], readouts[selection]), axis=1),
                    preparation + elapsed, heads=["raw_pascal_P3_d2"])
    for p, depth in ((2, 1), (3, 1), (4, 1), (2, 2), (4, 2), (1, 3), (2, 3)):
        values, seconds = coded_integration(raw, p, depth, batch_size=args.batch_size)
        evaluate("raw_sweep_compact_shape", f"P{p}_d{depth}",
                 np.concatenate((presets["compact_shape"], values), axis=1),
                 preparation + raw_scaling + seconds)

    # Follow-up prompted by the first run: spectral + rotation + raw P3 already
    # matches 98.07%. These are descriptive test-informed reductions, not a
    # separately validated model selection exercise.
    focused = {}
    for family in ("spectral", "rotation"):
        for removed in blocks[family]:
            focused[f"drop_{family}_{removed}"] = np.concatenate([
                np.concatenate([v for k, v in blocks[key].items() if k != removed], axis=1)
                if key == family else pools[key] for key in ("spectral", "rotation")
            ], axis=1)
    for name, rotation_parts in {
        "cross_cosines": ["cross_cosines"],
        "cosines": ["cross_cosines", "lag_cosines"],
        "instant_cross": ["instantaneous_moments", "cross_cosines"],
        "delayed_cross": ["delayed_moments", "cross_cosines"],
    }.items():
        focused["spectral_plus_" + name] = np.concatenate(
            [pools["spectral"], *(blocks["rotation"][key] for key in rotation_parts)], axis=1)
    for name, stats in {
        "energy_shape": ("energy", "amplitude_shape"),
        "energy_shape_location": ("energy", "amplitude_shape", "location"),
        "energy_bands": ("energy", "bands"),
        "energy_shape_bands": ("energy", "amplitude_shape", "bands"),
    }.items():
        focused["rotation_plus_" + name] = np.concatenate(
            (pools["rotation"], spectral_pool(families, statistics=stats)), axis=1)
    for name, pool in focused.items():
        compare("focused_" + name, pool, heads=["raw_ordinary_d2", "raw_pascal_P3_d2"])
    # Band-free pools test the desired raw code + spectral code + pooling setup.
    for pool_name in ("rotation_plus_energy_shape", "rotation_plus_energy_shape_location",
                      "drop_spectral_bands", "spectral_plus_cross_cosines"):
        pool = focused[pool_name]
        for readout_name in ("full", "full_compact", "within_channel_compact", "first_only", "first_products",
                             "within_channel_first_products", "within_channel_first_areas",
                             "within_channel_compact_no_areas"):
            compare(f"focused_triple_{pool_name}_{readout_name}",
                    np.concatenate((pool, spectral[readout_name]), axis=1),
                    preparation + spectral_seconds, heads=["raw_pascal_P3_d2"])
        compare("focused_triple_" + pool_name + "_ordinary",
                np.concatenate((pool, spectral_ordinary["full_compact"]), axis=1),
                preparation + ordinary_seconds, heads=["raw_pascal_P3_d2"])
    metadata["ablation_settings"]["focused_followup"] = {
        "reason": "Initial 270-row run: spectral + rotation + raw P3 matched 98.07% in 815 features",
        "scope": "Remove each block from that pool, retain cosine subsets, replace spectral bands with coded readouts",
    }
    # The surviving spectral + rotation pool makes 98.10% with P3 (803
    # coordinates). Check standard signature quotients before increasing P.
    compact_pool = focused["drop_rotation_lag_cosines"]
    coded_pool = np.concatenate((focused["rotation_plus_energy_shape"],
                                 spectral["within_channel_compact"]), axis=1)
    for label, pool, elapsed in (("spectral_rotation", compact_pool, preparation),
                                  ("coded_spectral", coded_pool, preparation + spectral_seconds)):
        for p, raw_name in ((1, "raw_ordinary_d2"), (3, "raw_pascal_P3_d2")):
            projection_start = perf_counter()
            values = additions[raw_name]
            width = 6 * p
            first, second = values[:, :width], values[:, width:].reshape(-1, width, width)
            readouts = {k: v.numpy() for k, v in _coordinates(
                torch.as_tensor(values), ("accel",) * (3 * p) + ("gyro",) * (3 * p)).items()}
            readouts["within_modality"] = np.concatenate((first,
                second[:, :3*p, :3*p].reshape(len(values), -1),
                second[:, 3*p:, 3*p:].reshape(len(values), -1)), axis=1)
            i, j = np.triu_indices(width)
            readouts["first_products"] = np.concatenate((first, first[:, i] * first[:, j]), axis=1)
            readouts["first_only"] = first
            projection_seconds = perf_counter() - projection_start
            for name, readout in readouts.items():
                evaluate("raw_readout_" + label, f"P{p}_{name}",
                         np.concatenate((pool, readout), axis=1),
                         elapsed + addition_times[raw_name] + projection_seconds)

    for pool_name, pool in (("all", all_pool), ("compact_shape", presets["compact_shape"])):
        evaluate("561_plus_pool_" + pool_name, "pooled", np.concatenate((engineered, pool), axis=1), preparation)
        evaluate("561_plus_pool_" + pool_name, "raw_pascal_P3_d2",
                 np.concatenate((engineered, pool, additions["raw_pascal_P3_d2"]), axis=1),
                 preparation + addition_times["raw_pascal_P3_d2"])
    for name, values in pools.items():
        if sha256(values).digest() != checksums[name]:
            raise RuntimeError("Pooled features changed during fitting")
