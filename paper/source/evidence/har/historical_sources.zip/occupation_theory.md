# Genuine signature families for the remaining readouts

Keep raw Pascal P3/depth-2 logsignatures and normalized spectral Pascal
P3/depth-2 logsignatures as the starting representation. The remaining useful
features describe **absolute scale, the distribution of spectral amplitudes,
and relative sensor geometry**. These suggest reusable path constructions,
with explicit nonlinear readouts where needed. This note gives identities;
it does not report classification results. The new experiments are in
[OCCUPATIONS.md](OCCUPATIONS.md); preceding measurements are in
[POOL_STORY.md](POOL_STORY.md).

## A value–clock path contains empirical moments

For any scalar sequence \(z_1,\ldots,z_N\), construct a two-dimensional path
with coordinates clock \(t\) and value \(x\). Start at \((0,0)\), move vertically
to \((0,z_1)\), then horizontally to \((1/N,z_1)\). Move vertically to the next
value and repeat. After the last horizontal segment, return vertically from
\((1,z_N)\) to \((1,0)\). All segments are straight. The value coordinate
returns to zero; the complete path does not close, because its clock advances
by one. We call this the **closed-value graph**.

Write signature words in chronological order: \(x^r t\) means \(r\) value
integrals followed by one clock integral. Only horizontal segments contribute
to the last integral. On those segments the preceding pure-value signature is
\(x^r/r!\), so

\[
S^{x^r t}=\frac{1}{r!}\int_0^1 x(t)^r\,dt
           =\frac{1}{r!N}\sum_{k=1}^N z_k^r.
\]

The same identity holds for the corresponding **tensor coordinate of the
genuine path logsignature**:

\[
(\log S)^{x^r t}=S^{x^r t}.
\]

To see this, expand \(\log S\) using concatenation multiplication. Every
nontrivial split of the word \(x^r t\) has a nonempty pure-value prefix. Every
pure-value signature coordinate of the complete path vanishes, because its
total value displacement is zero. Consequently all correction terms vanish.

Thus depth 2 contains the empirical mean, depth 3 adds the second raw moment,
and depth 4 adds the third raw moment. The construction is exact for finite
samples; it uses horizontal holds, not straight interpolation between adjacent
observations. Equal clock intervals give unweighted moments. Nonnegative
intervals summing to one give weighted moments instead.

The complete two-coordinate logsignature has five independent Lie coordinates
through depth 3 and eight through depth 4. Two first-level coordinates are
fixed at \((1,0)\), leaving at most three and six nonconstant coordinates per
stream, respectively. Moment coordinates are selected tensor coefficients of
this Lie element, so a compressed Lie basis may require a fixed linear map to
read them. The other coordinates can distinguish arrangements with the same
moments: for example,

\[
(\log S)^{xtt}=\int_0^1 (1/2-t)x(t)\,dt
\]

detects whether large values occur early or late. This separates occupation
information from ordering without building a large joint tensor over all
streams.

## Applying the construction to the four families

| Existing readouts | Scalar observations | Sufficient construction |
|---|---|---|
| 20 spectral log-energies | Nonnegative spectral bin powers | Log cumulative-energy path; first level |
| 40 spectral-amplitude means/stds | Spectral amplitudes \(a_k=\sqrt{p_k}\) | Closed-value graph through depth 3, followed by the variance/std readout |
| 6 cross-triad cosine means/stds | Three pairwise cosine streams | Closed-value graph through depth 3, followed by the variance/std readout |
| 36 invariant-stream means/stds/skews | Twelve energy, instantaneous Gram and delayed Gram streams | Closed-value graph through depth 4, followed by centered moment readouts |

For spectral amplitudes the clock is frequency-bin order. For cosine and Gram
streams it is sample order. Valid delayed pairs use their own clock, normalized
to one, without padding fabricated values at either boundary.

The 20 spectral channels in this example come from xyz and norm in five groups:
body acceleration, gravity, gyroscope, acceleration difference and gyroscope
difference. The spectral branch takes norms after training axis scaling, so
that branch is not a rotation-invariant representation.

For the invariant branch, write the three sensor vectors as \(v_g(k)\). Apply
one fixed training RMS scale per triad, without axiswise centering. The streams
are

\[
e_g(k)=\|v_g(k)\|^2,\qquad
h_{gh}(k)=\langle v_g(k),v_h(k)\rangle,\qquad
\ell_{g,\tau}(k)=\langle v_g(k),v_g(k-\tau)\rangle.
\]

There are three energies, three simultaneous cross-triad products, and three
lagged products at each of lags 2 and 5: twelve streams. Three normalized
cross-triad products give the cosine streams. A fixed small denominator floor
and a zero-vector convention make those streams defined everywhere.

These observables, and every signature of paths built from them, are unchanged
by a common orthogonal rotation of the vectors. Delayed products require the
same rotation at both members of a lag pair. Simultaneous products also tolerate
a common rotation that changes with time. This invariance is a property of the
extra branch, not of the complete classifier containing raw axis signatures.

## Absolute energy as a logsignature endpoint

Let \(p_k\geq0\) be spectral powers with \(E=\sum_k p_k\). For a positive fixed
reference \(\varepsilon\), form a scalar path whose vertices are

\[
y_j=\log\!\left(1+\frac{\sum_{k\leq j}p_k}{\varepsilon}\right),
\qquad y_0=0.
\]

Its first signature and logsignature level is exactly
\(\log(1+E/\varepsilon)\). Choosing \(\varepsilon=1\) in the example's scaled
units gives its current log-energy readout. This is a nonlinear transform of
cumulative energy, applied before the signature. A scalar path has no higher
Lie information by itself. Coding its increments with QR Pascal columns,

\[
\Delta Y_j^p=q_p(j)\,[y_j-y_{j-1}],
\]

creates a multidimensional path. The constant code column preserves log-energy
up to a known fixed factor; other columns and areas describe where the
compressed energy accumulates. Unlike the endpoint, these additional features
depend on bin order. The same construction applies to temporal energy
increments \(\|v_k\|^2/N\).

There is useful overlap between the energy and amplitude branches. With
\(K\) bins and \(a_k=\sqrt{p_k}\),

\[
\operatorname{Var}(a)=E/K-\bigl(\operatorname{mean}(a)\bigr)^2.
\]

Consequently log-energy and amplitude mean already determine amplitude std
through nonlinear reconstruction. That information sufficiency does not imply
that a linear ridge head can recover the desired decision rule from those two
coordinates alone.

## What needs a nonlinear readout?

For raw moments \(m_r=N^{-1}\sum_k z_k^r\), the existing readouts are

\[
\mu=m_1,\qquad
\sigma=\sqrt{\max(m_2-m_1^2,0)},\qquad
\gamma=\frac{m_3-3m_1m_2+2m_1^3}{\sigma^3}.
\]

Set skewness to zero for a constant stream and use a documented variance
threshold in numerical code. The graph logsignature linearly exposes the raw
moments. Std and skewness are nonlinear functions of them. A fixed ridge head
therefore makes the readout choice part of the model; exact reconstruction of
the old features is not evidence that unprocessed logsignature coordinates will
achieve the same accuracy.

For nearly constant streams, subtracting large raw moments is numerically
unstable even in float64. The implementation obtains the mean from the first
graph, then takes a second graph of the centered observations. Its second and
third moment coordinates directly give the central moments. This changes the
numerical calculation, not the intended statistics.

The centered graph also supports a natural normalization of ordering. A word
with \(r\) value letters scales by \(\sigma^r\) when all values are multiplied
by \(\sigma\). Consequently dividing the centered coordinates for
\(xtt,xxtt,xttt\) by \(\sigma,\sigma^2,\sigma\), respectively, gives exactly
the logsignature coordinates of the standardized sequence
\((z_k-\mu)/\sigma\). These describe arrangement independently of magnitude;
retain mean and std separately. The implementation sets these coordinates to
zero when variance is at most \(10^{-12}\). This is a generic path
normalization, not a fitted transformation.

One could calculate std first, then use it as a clock duration or scale a graph
so that an area equals std. That supplies the desired statistic through the
embedding itself. It is mathematically legitimate, but it neither explains how
signatures discover std nor removes its nonlinear calculation. We do not use
that device to claim linear recovery. Generic moment readouts stated openly
are clearer.

## Expected signatures offer a different moment family

Another construction treats the samples as an empirical distribution rather
than a single ordered path. Give sample \(z_k\) the straight-line path
\(s\mapsto sz_k\) starting at zero. Its scalar signature is
\(\exp(z_k e)\). The empirical expected signature and its tensor logarithm are

\[
M=\frac1N\sum_k\exp(z_k e),\qquad
\log M=m_1e+\frac{m_2-m_1^2}{2}e^{\otimes2}
 +\frac{m_3-3m_1m_2+2m_1^3}{6}e^{\otimes3}+\cdots.
\]

Depth 3 gives the mean, variance and third central moment, with known factorial
factors. These are empirical cumulants. **This tensor logarithm is not a path
logsignature:** an average of signatures need not be group-like, and its
logarithm need not be a Lie element. In particular a nonzero scalar variance
cannot occur as the second level of a scalar path logsignature.

Expected signatures of vector observations can also capture joint moments.
Attaching frequency or time codes to those observations gives location-weighted
distribution information. Averaging still discards ordering beyond the attached
locations. Taking a logsignature separately for each scalar straight segment
and then averaging would retain only the mean and would miss the variance.

## Small parameters with a mathematical interpretation

The closed-value graph depths are dictated by the desired observable moments:
depth 3 for mean/variance and depth 4 for third moments. These are depths of a
two-coordinate path, not of the large raw coded path. Use one graph per scalar
stream initially, and add selected joint paths only if cross-stream ordering
helps empirically.

For cumulative-energy coding, P1 is the exact log-energy endpoint baseline.
QR Pascal P3 adds polynomial location weights through degree two, with depth 2
adding pairwise ordered effects. QR changes the conditioning and basis of this
fixed polynomial space. It does not establish that P3 is statistically optimal.

There is also a direct coded extension of occupation graphs. Replace the
single clock by \(P\) clock coordinates whose holding-segment increments are
\(q_a(k)/N\), leaving the value jumps uncoded. The same proof gives

\[
(\log S)^{x^r t_a}=\frac{1}{r!N}\sum_k q_a(k)z_k^r.
\]

QR Pascal columns therefore expose polynomially weighted occupation moments.
The coded clocks may move backwards, which is allowed for a signature path;
they are no longer probability weights. Selecting these words costs only
\(P\) coordinates per retained moment and stream. Their higher interactions
are a further extension, without any need to instantiate a large joint tensor.
This extension is a mathematical construction; the current run codes the
cumulative-energy path and uses ordinary two-coordinate occupation graphs.

The resulting recipe is reusable: choose a time/frequency transform; choose
scalar observables with the required geometry; construct energy or value–clock
paths; take a small signature; select linear or explicitly nonlinear readouts.
There is no need to recreate the supplied 561 columns. The broader design
choices are discussed in [feature_families.md](feature_families.md), and library
ideas remain in [tensorsig_suggestions.md](tensorsig_suggestions.md).
