# Can Pascal coding contribute something different to UCI HAR?

**The promising change is to choose which temporal interactions the classifier
sees. Merely changing the basis of a fixed Pascal code adds no information.**
Two concrete constructions follow from this distinction: compress the coded
signature to polynomial functions of the time gap, or combine Pascal codes with
a Fourier carrier. The latter moves polynomial sensitivity from zero frequency
to an oscillatory band. These are testable mechanisms, not a theorem that either
must improve activity recognition.

The experiment and measured results are described in [README.md](README.md).
Library suggestions remain in [tensorsig_suggestions.md](tensorsig_suggestions.md).
This note derives the mechanisms and their limits.

**Measured outcome:** the Fourier–Pascal embedding raises standalone full-tensor
ridge accuracy from 85.34% for the matched Fourier carrier to 90.30%, but does
not improve that carrier's 561-feature hybrid. Pure QR-Pascal plus 561 reaches
97.12% with ridge, versus 97.05% for 561 plus ordinary basepoint signatures:
only two test windows separate them. The compact Fourier cross-spectrum hybrid
is better for SVM and RF. Thus the mathematical mechanisms below are real, but
this small experiment does not establish a material Pascal advantage over the
strongest simpler alternatives. See [the comparison](README.md#extension-results).

The subsequent energy/delayed-product embedding also helps standalone coded
models, but none of its hybrids beats the best earlier additions to 561. On the
combined observable path, Fourier–Pascal full tensors reach 90.50% SVM; products
of their first levels already reach 90.16%, and those products beat full tensors
under every hybrid head. This gives no consistent extra benefit from retaining
all directed second-level coordinates. See [the observable results](README.md#observable-results).

## Fix the representation first

Let the scaled sensor samples be \(x_0,\ldots,x_{N-1}\in\mathbb R^d\), and set
\(z_r=x_r/N\), \(t_r=r/N\). Integrate the samples: the path starts at zero and
its successive increments are \(z_r\). A code \(c_a(t_r)\) produces lifted
increments \(v_r^{i,a}=c_a(t_r)z_r^i\). At depth two, the piecewise-linear
signature is exactly

\[
S_{i,a;j,b}
=\sum_{r<s}c_a(t_r)c_b(t_s)z_r^iz_s^j
+\frac12\sum_r c_a(t_r)c_b(t_r)z_r^iz_r^j.
\]

Thus a linear readout chooses a two-time weighting of ordered sensor products.
The second term matters: geometric signatures include a half-weighted
same-segment contribution. Some readouts below cancel it exactly.

Integration is substantive here. Coding the increments of the original signal
would weight *changes* of sensor readings. Coding integrated samples weights the
readings themselves, making moments, spectral coefficients and correlations
accessible without a differencing factor. No equivalence between the two
embeddings is assumed.

The UCI windows contain 128 readings at 50 Hz, nominally 2.56 seconds. Their 561
features already include temporal and spectral summaries, computed from body and
gravity acceleration and other derived signals. This makes improved access to
means or spectral energy an insufficient argument for unique added information.
The pertinent comparison is the same head on 561 alone, 561 plus ordinary
signatures, and 561 plus the new construction. [Official UCI dataset](https://archive.ics.uci.edu/dataset/240/human+activity+recognition+using+smartphones).

## What a Pascal basis can and cannot change

The columns \(\binom r0,\ldots,\binom r{P-1}\) span all polynomials in the
integer offset of degree at most \(P-1\). Monomials, shifted Legendre
polynomials, Bernstein polynomials of degree \(P-1\), and a QR basis span the
same space on a fixed grid. Suppose \(\widetilde C=CB\), with \(B\) invertible.
The new lifted path is an invertible linear transformation of the old one.
Signature level \(m\) transforms by the corresponding \(m\)-fold tensor power.
Consequently, full signatures through a fixed depth have exactly the same
information and span the same linear prediction functions in these bases.

This does **not** make fitted models identical: ridge changes its coefficient
penalty, RBF SVM changes its distance metric, and an axis-aligned forest changes
its permitted splits. Featurewise scaling does not remove a general basis
rotation. A measured improvement from QR is a useful conditioning or model
geometry effect, not a new separation theorem.

For a 128-row, three-column raw Pascal matrix the measured 2-norm condition
number is about 10,618; normalized monomials \((1,t,t^2)\) give about 22.7;
QR columns give 1. `OffsetCode.pascal(..., orthonormal=True)` already provides
QR conditioning in tensorsig. Bernstein columns become a different modeling
choice only if one adds a coordinate restriction, a coefficient constraint, a
norm, or another readout. At fixed small degree they are broad polynomial
weights, not sharply localized windows.

Pascal codes do have structural value: exact finite-dimensional rebasing under
position shifts, a polynomial-degree ordering, and transparent rank formulas.
The local theory explains these in
[offset coding and shift-equivariant reset codes](../../../local_offset_coded_signatures/markdown/offset-coding-shifts-and-reset-codes.md).
Those properties support efficient summaries and controlled temporal
complexity. Maximal algebraic rank does not establish a predictive advantage;
the same theory explicitly notes that generic codes can attain the same rank.

The implementation compares certified QR Pascal with the normalized Newton
basis \((1,t,t(t-1/N))\), converting both tensor factors exactly. First-level-only
controls isolate what comes from 18 polynomial moments rather than ordered
pairs. Their ambient dimensions differ from ordinary signatures, so this is an
investigation of a feature budget and an inductive bias, not a matched-dimension
expressivity contest.

## Unlocking a different readout: moments of the time gap

Use a polynomial code spanning \(1,t,\ldots,t^q\). Write its coordinates in that
basis, even if the computation uses QR. Define

\[
D_q^{ij}=\sum_{r<s}(t_s-t_r)^qz_r^iz_s^j,\qquad q\ge1.
\]

Expanding the binomial gives an exact **linear signature readout**:

\[
D_q^{ij}=\sum_{a=0}^{q}(-1)^a\binom qa S_{i,a;j,q-a}.
\]

The same-segment contributions vanish because their weight is
\((t_r-t_r)^q=0\). In particular,

\[
D_1^{ij}=S_{i,0;j,1}-S_{i,1;j,0},\qquad
D_2^{ij}=S_{i,0;j,2}-2S_{i,1;j,1}+S_{i,2;j,0}.
\]

A compact construction is \(\mu\), every entry of \(D_1\), and every entry of
\(D_2\): \(6+36+36=78\) coordinates for six sensors. This restricts the model
to smooth lag-weighted interactions. It removes dependence on the absolute
origin of the position labels, since only differences remain. Moving a complete
pattern within zero padding preserves these quantities when normalization is
held fixed. Clipping samples at a window boundary or cyclically moving them
through that boundary need not preserve them. This is not an exact invariance
to arbitrary HAR cropping.

There is an exact connection to deeper ordinary signatures. Make an **event
staircase**: add each sensor increment at fixed time \(t_r\), and move the clock
between these events. If \(\tau\) denotes the clock letter, then

\[
D_q^{ij}=q!\,S_{i\,\tau^q\,j}.
\]

After choosing the first and last sensor events, the \(q\) intervening clock
integrals give \((t_s-t_r)^q/q!\). Therefore a coded depth-two readout exposes a
feature that this ordinary representation stores at depth \(q+2\): **Pascal
trades temporal depth for code width.** This is not information unavailable to
all ordinary signatures. The identity uses the event staircase; the example's
usual simultaneously interpolated clock/sensor segments are a different path.

The entries are not all new independent information. Put
\(m_i^{(a)}=\sum_rt_r^az_r^i\), so \(m_i^{(0)}=\mu_i\). Then

\[
D_1^{ij}-D_1^{ji}=\mu_i m_j^{(1)}-m_i^{(1)}\mu_j,
\]

\[
D_2^{ij}+D_2^{ji}
=\mu_i m_j^{(2)}+m_i^{(2)}\mu_j-2m_i^{(1)}m_j^{(1)}.
\]

These follow by splitting the sum over every ordered pair of sample indices
into its two time orderings. The symmetric part of \(D_1\) and antisymmetric
part of \(D_2\) are the parts not fixed by these first-level polynomial moments.
Keeping all entries is convenient and cheap; calling them 72 independent new
interactions would be incorrect.

There is another useful limitation. For a scalar mean-zero window, let
\(Y_k=\sum_{r<k}z_r\). Counting the cuts crossed by each pair gives

\[
D_1=-\frac1N\sum_{k=1}^{N-1}Y_k^2.
\]

The statistic is energy of the accumulated signal, with a minus sign. It is
therefore a transformed energy statistic, strongly sensitive to slow structure.
This can be useful without being a fundamentally unfamiliar observable.

### A checked separation example

Consider two scalar sample windows:

```text
A = [-1, -1, -1, -1,  1,  1,  1, 1, -1, 1]
B = [-1, -1, -1,  1,  1, -1, -1, 1,  1, 1]
```

Both have mean 0, population standard deviation 1, identical first/last samples,
and mean squared successive difference \(4/3\). After sample integration and
appending a linear clock, their entire ordinary depth-two signatures agree.
Their weighted first moments both equal 0.17, which accounts for the identical
mixed time/signal coordinates. Yet

\[
D_1(A)=-0.045,\qquad D_1(B)=-0.037.
\]

Pascal coding therefore separates some sequences that those statistics and the
ordinary depth-two representation cannot separate, even with a nonlinear head.
This is a finite-depth example, not a collision of all 561 handcrafted features,
and not a demonstration that HAR labels depend on the distinction.

## Why Fourier times Pascal is more plausible than more raw polynomial terms

Introduce the causal spectral summary

\[
H_{ij}(\omega)=\sum_{r<s}e^{i\omega(t_s-t_r)}z_r^iz_s^j.
\]

Termwise differentiation of this finite sum gives

\[
H_{ij}^{(q)}(0)=i^qD_q^{ij}.
\]

Thus polynomial gap moments describe derivatives of a causal cross-spectrum at
**zero frequency**. For one real channel,
\(F_i(\omega)=\sum_rz_r^ie^{i\omega t_r}\) obeys

\[
|F_i(\omega)|^2=\sum_r(z_r^i)^2+2\operatorname{Re}H_{ii}(\omega).
\]

In particular, its even-order derivatives at zero are
\(2(-1)^kD_{2k}^{ii}\) for \(k\ge1\). These identities reveal direct overlap
with spectral features. A few low-degree terms around zero are a weak basis
for oscillations several cycles across a window; adding more polynomial terms
blindly is not an especially targeted HAR strategy.

For different channels, the exact identity is

\[
\overline{F_i(\omega)}F_j(\omega)
=Q_{ij}+H_{ij}(\omega)+\overline{H_{ji}(\omega)},
\qquad Q_{ij}=\sum_r z_r^iz_r^j.
\]

The diagonal term appears because \(H\) was defined using strict time order.
Thus the Hermitian part of \(H\) is already cross-spectral information. Its
remaining part keeps the direction of the time ordering. For the weighted
readout below, the cross-spectrum derivative is
\(i[D_1^{ij}(\omega)-\overline{D_1^{ji}(\omega)}]\); that part is likewise
familiar spectral information. Every one of these features is determined by
the full aperiodic directed cross-correlation sequence: they are compact
weighted summaries of it, not information beyond it. The provided 561 table
does not supply that entire sequence.

Instead center the spectral expansion at a chosen carrier \(\omega_0\). Set

\[
D_q^{ij}(\omega_0)=
\sum_{r<s}(t_s-t_r)^qe^{i\omega_0(t_s-t_r)}z_r^iz_s^j.
\]

Then \(H_{ij}^{(q)}(\omega_0)=i^qD_q^{ij}(\omega_0)\). This is a concrete reason
to combine Fourier and Pascal codes: the polynomial part describes variation
*near the carrier*, including spectral slope and ordered envelope interactions.
It is not just another basis of the original polynomial space.

For example, the first-order real code

\[
c(t)=(1,\cos\omega_0t,\sin\omega_0t,
       t\cos\omega_0t,t\sin\omega_0t)
\]

contains a Fourier pair and that pair multiplied by a linear polynomial. The
first levels include both a Fourier coefficient and its frequency derivative.
At level two, abbreviate the four nonconstant labels by \(c,s,tc,ts\). The exact
readout is

\[
\operatorname{Re}D_1^{ij}(\omega_0)
=S_{i,c;j,tc}+S_{i,s;j,ts}-S_{i,tc;j,c}-S_{i,ts;j,s},
\]

\[
\operatorname{Im}D_1^{ij}(\omega_0)
=S_{i,c;j,ts}-S_{i,s;j,tc}-S_{i,tc;j,s}+S_{i,ts;j,c}.
\]

Again the diagonal halves cancel. Appending all real and imaginary entries to
six means gives 78 coordinates. All channel pairs are retained because these
causal matrices need not be symmetric. The code is closed under position
rebasing: sine/cosine rotate, while the polynomial factor undergoes a Pascal
shift. The combined action is a rotation times a polynomial shear.

A fixed carrier of four cycles per 128-sample window corresponds to 1.5625 Hz.
That is a small exploratory choice, not an estimated optimal gait frequency.
One carrier can miss activities with different cadence or harmonics. A future
small bank or per-window cadence normalization would test a different hypothesis
and requires its own comparison. Normalizing cadence may also discard a useful
class distinction.

The derivative interpretation is exact. Its usefulness as a local spectral
approximation is quantified by Taylor's formula: after order \(Q\), the error
in approximating \(H_{ij}(\omega_0+\delta)\) is at most

\[
\frac{|\delta|^{Q+1}}{(Q+1)!}
\sum_{r<s}|z_r^iz_s^j|\,|t_s-t_r|^{Q+1}.
\]

Thus a low-order expansion is locally justified, but this bound provides no
reason to expect a two-term expansion around zero to resolve many cycles.
One DFT bin is a change of \(2\pi\) in this normalized angular frequency;
it is not automatically a small increment for this Taylor expansion.

## Testing an observable embedding

Pascal coefficients may be more useful on slowly varying **observables** than
on signed oscillatory sensor samples. Examples are a small vector of body
acceleration energy, gyroscope energy and their delayed products. Integrate
those observables, retain their means, and apply a short polynomial or modulated
code. A second-level coordinate then describes, for example, acceleration
energy building before rotational energy, with a selected time-gap weighting.
This preserves the familiar energy statistic at first level and adds its
ordered behavior at the next level. It is a substantive embedding change.

This is now tested by `benchmark.py --observables`, using two smoothed triad
energies, four short-lag triad dot products, and their six-channel combination.
Each path is integrated before ordinary, Pascal or Fourier–Pascal coding.
The common posture means, pooled-mean controls, and products-of-coded-first-levels
controls are described in [README.md](README.md#integrating-energy-envelopes-and-delayed-products).
The complete measurements are in [observable_results/RESULTS.md](observable_results/RESULTS.md).
Because the observables are quadratic in the standardized readings, level two
contains fourth-order products across times. A polynomial time code changes
their temporal weighting rather than their degree in the signal values.

An ordinary signature of the same observable path and direct pooled observable
moments are required controls: otherwise an apparent coding gain may come from
squaring, separating body/gravity, or supplying the delay rather than the code.
Keeping posture means beside a centered dynamic path is also sensible; replacing
all channels by window-centered versions would discard level information that
already proved valuable here.

These constructions fit the broader approach of choosing augmentations and
readouts around a signature, as studied by the
[generalised signature method](https://arxiv.org/abs/2006.00873).
Kernel-weighted histories are also the motivation of the recent
[Volterra signature](https://arxiv.org/abs/2603.04525).
Our finite polynomial readouts are derived directly above; they are not an
implementation of that paper's different all-level Volterra object, and none of
its injectivity or universality claims is being imported into this experiment.

## Verification and practical conclusion

The binomial gap and real modulated formulas were checked against actual
tensorsig depth-two tensors on five random windows of length 17 with six
channels. Maximum absolute errors were below \(9\times10^{-17}\). The QR-to-
monomial transformation was checked at levels one and two (errors below
\(5\times10^{-16}\)). The scalar collision above was checked independently;
its ordinary-signature discrepancy was below \(3\times10^{-17}\).
The event-staircase identity was checked against ordinary depths three and four
(errors below \(2\times10^{-17}\)), and the cross-spectrum identity was checked
including its diagonal term (error below \(3\times10^{-16}\)).

The strongest theoretical case for Pascal here is **a controlled low-degree
family of temporal interactions, with exact transforms and selective readouts**.
A full polynomial feature map can provide distinctions unavailable at the same
ordinary depth. But basis conditioning alone supplies no new information, and
some coded coordinates are recognizable moment or spectral statistics. The
experiment tests whether the new distinctions help beyond the 561 features.
Here Fourier modulation helps a standalone linear classifier, while the best
hybrid gains mostly favor compact spectral readouts or ordinary signatures.
First-level Fourier–Pascal features alone are much weaker for ridge, but the
full tensor contains both products and directed interactions, so their relative
contribution is not isolated by that control. The separate observable experiment
adds products-of-first-levels controls: much of its gain remains with those
products, and its best hybrids do not improve the earlier alternatives. These
small, fixed experiments support the mathematical mechanisms but do not show
that they provide a material HAR advantage over the strongest existing controls.
