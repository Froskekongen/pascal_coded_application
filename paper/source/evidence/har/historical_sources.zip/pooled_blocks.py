"""Named slices of the existing generic pools; no extra fitted transforms.

The selectors retain the exact columns from ``families.build_families``.
Compact presets keep low-order moments, short-lag correlations and spectral
location/scale, then add shape or frequency resolution in separate controls.
Their sizes are design choices for this small experiment, not optimality claims.
"""

import numpy as np

SPECTRAL_STATISTICS = (
    "amplitude_mean", "amplitude_std", "amplitude_skew", "amplitude_kurtosis",
    "energy", "log_energy", "centroid", "spread", "entropy", "peak",
    *(f"band_{j}" for j in range(8)),
)
SPECTRAL_BLOCKS = {
    "amplitude_shape": tuple(range(4)),
    "energy": (4, 5),
    "location": (6, 7),
    "entropy_peak": (8, 9),
    "bands": tuple(range(10, 18)),
}
EXPECTED_WIDTHS = {"moments": 105, "filters_delays": 146,
                   "spectral": 360, "rotation": 114}


def _summary_columns(starts, channels, statistics):
    return [start + statistic * channels + channel
            for start in starts for statistic in statistics
            for channel in range(channels)]


def block_columns() -> dict[str, dict[str, list[int]]]:
    """Indices forming a disjoint, exhaustive partition of each pooled family."""
    moments = {name: _summary_columns((0, 35, 70), 4, statistics)
               for name, statistics in {
                   "mean_std": (0, 1), "absolute_rms": (2, 3),
                   "skew_kurtosis": (4, 5), "extrema": (6, 7),
               }.items()}
    moments["correlations"] = [start + j for start in (0, 35, 70)
                               for j in range(32, 35)]
    return {
        "moments": moments,
        "filters_delays": {
            "difference": list(range(64)),
            "residual5": list(range(64, 128)),
            "lag_correlations": list(range(128, 146)),
        },
        "spectral": {
            name: _summary_columns(range(0, 360, 72), 4, statistics)
            for name, statistics in SPECTRAL_BLOCKS.items()
        },
        "rotation": {
            "instantaneous_moments": list(range(48)),
            "delayed_moments": list(range(48, 96)),
            "cross_cosines": list(range(96, 102)),
            "lag_cosines": list(range(102, 114)),
        },
    }


def pooled_blocks(families: dict) -> dict[str, dict[str, np.ndarray]]:
    """Return named blocks; concatenating them reorders the original columns."""
    result = {}
    for family, blocks in block_columns().items():
        pool = families[family]["pooled"]
        if pool.shape[1] != EXPECTED_WIDTHS[family]:
            raise ValueError(f"Unexpected {family} pool width: {pool.shape[1]}")
        result[family] = {name: pool[:, columns] for name, columns in blocks.items()}
    return result


def spectral_pool(families: dict, *, groups=None, statistics=None,
                  channels=None) -> np.ndarray:
    """Select spectral groups, statistic blocks and xyz/norm channels.

    ``groups`` uses the names in the spectral family's ``groups`` list.
    ``statistics`` accepts block names from ``SPECTRAL_BLOCKS`` or individual
    names from ``SPECTRAL_STATISTICS``. The block name ``energy`` includes both
    energy and log-energy; use ``raw_energy`` to select energy alone.
    ``channels`` is a sequence of indices: xyz = (0, 1, 2), norm = (3,).
    Omitted arguments select everything in its original order.
    """
    family = families["spectral"]
    selected_groups = family["groups"] if groups is None else groups
    selected_channels = tuple(range(4)) if channels is None else tuple(channels)
    if not selected_channels or any(c not in range(4) for c in selected_channels):
        raise ValueError("Spectral channels must be selected from 0, 1, 2, 3")
    selected_statistics = []
    for name in SPECTRAL_STATISTICS if statistics is None else statistics:
        if name == "raw_energy" or (statistics is None and name == "energy"):
            selected_statistics.append(4)
        elif name in SPECTRAL_BLOCKS:
            selected_statistics.extend(SPECTRAL_BLOCKS[name])
        else:
            selected_statistics.append(SPECTRAL_STATISTICS.index(name))
    columns = [family["groups"].index(group) * 72 + statistic * 4 + channel
               for group in selected_groups for statistic in selected_statistics
               for channel in selected_channels]
    if len(set(columns)) != len(columns):
        raise ValueError("Spectral selections must not repeat columns")
    return family["pooled"][:, columns]


def pooling_sets(families: dict) -> dict[str, np.ndarray]:
    """Small cumulative pools, all without supplied 561-feature columns.

    Core (196 columns): means/stds of raw, filtered and Gram observations;
    lag correlations and Gram cosines; spectral energy/log-energy and location.
    Shape adds skew/kurtosis of raw channels and four amplitude statistics.
    Bands add an eight-bin mass partition. Full spectrum retains every spectral
    pool column while reducing the three time-domain pools to their core.
    """
    blocks = pooled_blocks(families)
    filter_mean_std = families["filters_delays"]["pooled"][:,
        _summary_columns((0, 32, 64, 96), 4, (0, 1))]
    gram_mean_std = families["rotation"]["pooled"][:,
        _summary_columns((0, 24, 48, 72), 3, (0, 1))]
    time_core = np.concatenate((
        blocks["moments"]["mean_std"], filter_mean_std,
        blocks["filters_delays"]["lag_correlations"], gram_mean_std,
        blocks["rotation"]["cross_cosines"], blocks["rotation"]["lag_cosines"],
    ), axis=1)
    spectral_core = spectral_pool(families, statistics=("energy", "location"))
    core = np.concatenate((time_core, spectral_core), axis=1)
    shape = np.concatenate((core, blocks["moments"]["skew_kurtosis"],
                            blocks["spectral"]["amplitude_shape"]), axis=1)
    return {
        "time_core": time_core,
        "spectral_core": spectral_core,
        "compact_core": core,
        "compact_shape": shape,
        "compact_shape_bands": np.concatenate((shape, blocks["spectral"]["bands"]), axis=1),
        "compact_full_spectrum": np.concatenate((time_core, families["spectral"]["pooled"]), axis=1),
    }


def self_check() -> None:
    """Ensure each pool is partitioned exactly and selectors preserve values."""
    groups = ["body_acc", "gravity", "body_gyro", "body_acc_difference", "gyro_difference"]
    families = {name: {"pooled": np.arange(3 * width).reshape(3, width)}
                for name, width in EXPECTED_WIDTHS.items()}
    families["spectral"]["groups"] = groups
    blocks = pooled_blocks(families)
    for family, indices in block_columns().items():
        columns = np.concatenate(list(indices.values()))
        np.testing.assert_array_equal(np.sort(columns), np.arange(EXPECTED_WIDTHS[family]))
        reordered = np.concatenate(list(blocks[family].values()), axis=1)
        np.testing.assert_array_equal(reordered[:, np.argsort(columns)], families[family]["pooled"])
    np.testing.assert_array_equal(spectral_pool(families), families["spectral"]["pooled"])
    selected = spectral_pool(families, groups=("gravity", "gyro_difference"),
                             statistics=("location", "raw_energy"), channels=(3,))
    np.testing.assert_array_equal(selected, families["spectral"]["pooled"][:,
        [72 + 27, 72 + 31, 72 + 19, 288 + 27, 288 + 31, 288 + 19]])
    expected = {"time_core": 116, "spectral_core": 80, "compact_core": 196,
                "compact_shape": 300, "compact_shape_bands": 460,
                "compact_full_spectrum": 476}
    for name, pool in pooling_sets(families).items():
        assert pool.shape == (3, expected[name]), (name, pool.shape)


if __name__ == "__main__":
    self_check()
    print("Pooled block checks passed.")
