"""Small observation families for QR-coded signatures and pooled ridge controls.

Each family supplies independent low-dimensional observation sequences. Apply
``generators.coded_integration`` to each and concatenate: this retains ordering
within a group without constructing one enormous tensor across all modalities.
The pooled readouts are explicit nonlinear statistics, not extra signatures.
No filtering attempts to reconstruct undocumented upstream UCI processing.
"""

import numpy as np
import torch


def _scale(x: torch.Tensor, train_size: int) -> torch.Tensor:
    """One affine map per channel fitted on training windows and time points."""
    reference = x[:train_size]
    return (x - reference.mean((0, 1))) / reference.std(
        (0, 1), correction=0,
    ).clamp_min(1e-8)


def _summary(x: torch.Tensor) -> torch.Tensor:
    """Channelwise mean, std, mean absolute value, RMS, skew, kurtosis, min/max."""
    mean = x.mean(1)
    centered = x - mean[:, None]
    variance = centered.square().mean(1)
    z = centered / variance.sqrt().clamp_min(1e-8)[:, None]
    active = variance > 1e-12
    skew = torch.where(active, z.pow(3).mean(1), 0.)
    kurtosis = torch.where(active, z.pow(4).mean(1), 0.)
    return torch.cat((mean, variance.sqrt(), x.abs().mean(1),
                      x.square().mean(1).sqrt(), skew, kurtosis,
                      x.amin(1), x.amax(1)), 1)


def _correlations(x: torch.Tensor) -> torch.Tensor:
    centered = x - x.mean(1, keepdim=True)
    z = centered / centered.square().mean(1, keepdim=True).sqrt().clamp_min(1e-8)
    return torch.stack([(z[:, :, i] * z[:, :, j]).mean(1)
                        for i, j in ((0, 1), (0, 2), (1, 2))], 1)


def _with_norm(x: torch.Tensor) -> torch.Tensor:
    return torch.cat((x, x.norm(dim=2, keepdim=True)), 2)


def _lag_product(x: torch.Tensor, lag: int) -> torch.Tensor:
    return x[:, lag:] * x[:, :-lag]


def _causal_residual(x: torch.Tensor, width: int = 5) -> torch.Tensor:
    """Subtract trailing mean, repeating the first sample for missing history."""
    padded = torch.cat((x[:, :1].expand(-1, width - 1, -1), x), 1)
    sums = torch.cat((torch.zeros_like(padded[:, :1]), padded.cumsum(1)), 1)
    return x - (sums[:, width:] - sums[:, :-width]) / width


def _power(x: torch.Tensor) -> torch.Tensor:
    """One-sided bin energies; their sum equals the time-domain mean square."""
    power = (torch.fft.rfft(x, dim=1).abs() / x.shape[1]).square()
    power[:, 1:power.shape[1] - (x.shape[1] % 2 == 0)] *= 2
    return power


def _spectrum(x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Frequency-ordered power measure and scale/shape readouts.

    Frequency is measured as a fraction of the 25 Hz Nyquist frequency. Eight
    uniform bands partition [0, 1]; the last includes Nyquist. Integration of
    the observations gives one for every nonzero spectrum. Consequently the
    first Pascal coordinates are spectral-location moments, up to QR's fixed
    change of polynomial basis. Absolute energy remains in pooled readouts.
    """
    power = _power(x)
    energy = power.sum(1)
    mass = power / energy.clamp_min(1e-20)[:, None]
    frequency = 2 * torch.fft.rfftfreq(x.shape[1], dtype=x.dtype)
    mean = (mass * frequency[None, :, None]).sum(1)
    spread = (mass * (frequency[None, :, None] - mean[:, None]).square()).sum(1).sqrt()
    entropy = -(mass * mass.clamp_min(1e-20).log()).sum(1)
    peak = frequency[power.argmax(1)]
    bands = torch.cat([mass[:, (frequency >= j / 8) &
                               (frequency < (j + 1) / 8 if j < 7 else frequency <= 1)].sum(1)
                       for j in range(8)], 1)
    amplitude = power.sqrt()
    amplitude_stats = _summary(amplitude)
    # Mean/std/skew/kurtosis of bin amplitudes, plus total energy and shape.
    channels = x.shape[2]
    selected = torch.cat((amplitude_stats[:, :2 * channels],
                          amplitude_stats[:, 4 * channels:6 * channels]), 1)
    pooled = torch.cat((selected, energy, energy.log1p(), mean, spread,
                        entropy, peak, bands), 1)
    return mass * power.shape[1], pooled


def _rotation_family(vectors: list[torch.Tensor], train_size: int) -> dict:
    """Norms and inner products invariant under one common orthogonal rotation.

    A single training RMS scalar rescales each triad. No axiswise centering or
    rescaling precedes the contractions. The same rotation must act on every
    sample and triad in a window; independently rotating each time point would
    change the lagged products. Rotation about the gravity direction is not
    imposed separately. Device-axis posture coordinates are deliberately absent.
    """
    scaled = [v / v[:train_size].square().mean().sqrt().clamp_min(1e-8)
              for v in vectors]
    energy = torch.stack([v.square().sum(2) for v in scaled], 2)
    dots = torch.stack([(scaled[i] * scaled[j]).sum(2)
                        for i, j in ((0, 1), (0, 2), (1, 2))], 2)
    observations = [energy, dots]
    normalized = []
    for lag in (2, 5):
        pairs = [(v[:, lag:], v[:, :-lag]) for v in scaled]
        dot = torch.stack([(left * right).sum(2) for left, right in pairs], 2)
        denominator = torch.stack([left.norm(dim=2) * right.norm(dim=2)
                                   for left, right in pairs], 2).clamp_min(1e-12)
        observations.append(dot)
        normalized.extend(((dot / denominator).mean(1),
                           (dot / denominator).std(1, correction=0)))
    norms = energy.sqrt()
    denominator = torch.stack([norms[:, :, i] * norms[:, :, j]
                               for i, j in ((0, 1), (0, 2), (1, 2))], 2).clamp_min(1e-12)
    cosines = dots / denominator
    pooled = torch.cat([*(_summary(x) for x in observations),
                        cosines.mean(1), cosines.std(1, correction=0), *normalized], 1)
    return {"observations": observations, "pooled": pooled.float().numpy(),
            "groups": ["energies", "cross_triads", "lag2", "lag5"],
            "scaling": "One training RMS scalar per raw triad, without centering",
            "description": "Common-rotation invariant energies, Gram products, and lag-2/5 products"}


@torch.inference_mode()
def build_families(signals: np.ndarray | torch.Tensor, train_size: int) -> dict[str, dict]:
    """Build four families from UCI body-acc, gyro, total-acc xyz channels.

    Gravity is the supplied total acceleration minus supplied body acceleration.
    Statistics use population moments; kurtosis is the standardized fourth
    moment, without subtracting three. Axis-sensitive transforms use training
    affine scaling and never center each window. No shared posture block is
    appended: moment pooled features contain body/gravity/gyro means, while
    the rotation family remains invariant and spectral power loses axis signs.
    """
    x = torch.as_tensor(signals, dtype=torch.float64)
    if (x.ndim != 3 or x.shape[1] < 8 or x.shape[2] != 9
            or not 1 <= train_size <= len(x) or not torch.isfinite(x).all()):
        raise ValueError("Expected finite (windows, >=8 samples, 9) signals and a training prefix")
    vectors = [x[:, :, :3], x[:, :, 6:9] - x[:, :, :3], x[:, :, 3:6]]
    scaled = [_scale(v, train_size) for v in vectors]
    moment_observations = [torch.cat((v, v.square()), 2) for v in scaled]
    moments = torch.cat([item for v in scaled
                         for item in (_summary(_with_norm(v)), _correlations(v))], 1)

    dynamic = [vectors[0], vectors[2]]
    filtered = [_scale(transform(v), train_size)
                for transform in (lambda v: v.diff(dim=1), _causal_residual)
                for v in dynamic]
    filter_observations = [torch.cat((v, v.square()), 2) for v in filtered]
    dynamic_scaled = torch.cat((scaled[0], scaled[2]), 2)
    filter_observations.extend([
        _scale(_lag_product(v, lag), train_size)
        for lag in (2, 5) for v in (scaled[0], scaled[2])
    ])
    lag_correlations = []
    for lag in (1, 2, 5):
        left, right = dynamic_scaled[:, lag:], dynamic_scaled[:, :-lag]
        left, right = left - left.mean(1, keepdim=True), right - right.mean(1, keepdim=True)
        denominator = (left.square().mean(1) * right.square().mean(1)).sqrt().clamp_min(1e-12)
        lag_correlations.append((left * right).mean(1) / denominator)
    filter_pooled = torch.cat([*(_summary(_with_norm(v)) for v in filtered),
                               *lag_correlations], 1)

    spectral_vectors = scaled + [_scale(v.diff(dim=1), train_size) for v in dynamic]
    spectra = [_spectrum(_with_norm(v)) for v in spectral_vectors]
    spectral_pooled = torch.cat([item[1] for item in spectra], 1)
    return {
        "moments": {"observations": moment_observations, "pooled": moments.float().numpy(),
                    "groups": ["body_acc", "gravity", "body_gyro"],
                    "scaling": "Training mean/std per axis before squares and norms",
                    "description": "Body/gravity/gyro axes and squares, grouped by triad"},
        "filters_delays": {"observations": filter_observations, "pooled": filter_pooled.float().numpy(),
                           "groups": ["body_acc_difference", "gyro_difference", "body_acc_residual5", "gyro_residual5",
                                      "body_acc_lag2_product", "gyro_lag2_product", "body_acc_lag5_product", "gyro_lag5_product"],
                           "scaling": "Training mean/std per filtered axis; lag products of scaled axes are separately train-scaled",
                           "description": "Differences, trailing-5 residuals, lag-2/5 products; lag-1/2/5 correlations pooled"},
        "spectral": {"observations": [item[0] for item in spectra],
                     "pooled": spectral_pooled.float().numpy(),
                     "groups": ["body_acc", "gravity", "body_gyro", "body_acc_difference", "gyro_difference"],
                     "scaling": "Training mean/std per time-domain axis, then per-window spectral mass normalization",
                     "description": "Normalized power along frequency for five triads, axes plus norm"},
        "rotation": _rotation_family(vectors, train_size),
    }


def self_check() -> None:
    """Verify the mathematical contracts rather than repeat implementation."""
    from generators import coded_integration, temporal_code

    generator = torch.Generator().manual_seed(2026)
    sequence = torch.tensor([2., 3., 5., 7.]).reshape(1, 4, 1)
    torch.testing.assert_close(_lag_product(sequence, 2), torch.tensor([10., 21.]).reshape(1, 2, 1))
    x = torch.randn(8, 32, 9, generator=generator, dtype=torch.float64)
    original = build_families(x, 5)
    altered = x.clone()
    altered[5:] = 100 * altered[5:] + 50
    rebuilt = build_families(altered, 5)
    for name, family in original.items():
        np.testing.assert_array_equal(family["pooled"][:5], rebuilt[name]["pooled"][:5])
        for before, after in zip(family["observations"], rebuilt[name]["observations"]):
            torch.testing.assert_close(before[:5], after[:5])
    for n in (31, 32):
        signal = x[:, :n, :3]
        torch.testing.assert_close(_power(signal).sum(1), signal.square().mean(1))
        observations, _ = _spectrum(signal)
        torch.testing.assert_close(observations.mean(1), torch.ones_like(signal.mean(1)))
    # At P3, first levels linearly recover frequency moments. Shuffle recovers
    # the squared mean from level two, so variance is another linear readout.
    observations, _ = _spectrum(x[:3, :, :2])
    length = observations.shape[1]
    values, _ = coded_integration(observations, 3, depth=2, batch_size=2)
    first = values[:, :6].reshape(3, 2, 3).astype(np.float64)
    second = values[:, 6:].reshape(3, 2, 3, 2, 3).astype(np.float64)
    frequency = 2 * torch.fft.rfftfreq(x.shape[1], dtype=x.dtype)
    basis = temporal_code(length, 3).matrix
    b1, b2 = (basis.T @ frequency).numpy(), (basis.T @ frequency.square()).numpy()
    actual_mean = np.einsum("nca,a->nc", first, b1)
    actual_variance = np.einsum("nca,a->nc", first, b2) - 2 * np.stack([
        np.einsum("nab,a,b->n", second[:, c, :, c, :], b1, b1) for c in range(2)
    ], 1)
    mass = observations / length
    expected_mean = (mass * frequency[None, :, None]).sum(1)
    expected_variance = (mass * (frequency[None, :, None] - expected_mean[:, None]).square()).sum(1)
    np.testing.assert_allclose(actual_mean, expected_mean.numpy(), atol=1e-6)
    np.testing.assert_allclose(actual_variance, expected_variance.numpy(), atol=1e-6)
    rotation, _ = torch.linalg.qr(torch.randn(3, 3, generator=generator, dtype=x.dtype))
    rotation[:, 0] *= -1  # Include an orthogonal reflection: all contractions are O(3)-invariant.
    rotated = (x.reshape(8, 32, 3, 3) @ rotation).reshape_as(x)
    invariant = build_families(rotated, 5)["rotation"]
    np.testing.assert_allclose(original["rotation"]["pooled"], invariant["pooled"], atol=2e-6)
    for before, after in zip(original["rotation"]["observations"], invariant["observations"]):
        torch.testing.assert_close(before, after)
    for family in build_families(torch.zeros_like(x), 5).values():
        assert np.isfinite(family["pooled"]).all()
        assert all(torch.isfinite(observation).all() for observation in family["observations"])


if __name__ == "__main__":
    torch.set_num_threads(1)
    self_check()
    print("Feature family checks passed.")
