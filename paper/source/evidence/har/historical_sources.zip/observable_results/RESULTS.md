# UCI HAR exploratory results

7,352 training / 2,947 test windows; official subject-disjoint split, fixed settings, no hyperparameter search.

Accuracy and macro F1 are percentages. Times are seconds on this machine. Extraction includes train and test, with full calculations shared across readouts; do not sum extraction columns across heads or claim sparse quotient acceleration. The 561-feature extraction time is unmeasured (CSV placeholder 0); hybrid timings measure only the additional features.

## Best row per input/augmentation and head

These are descriptive test-set maxima over representations, not validation-selected models.

| Input / augmentation | Head | Representation | Features | Accuracy | Macro F1 | Extract | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|---:|
| body_mean_std | ridge | mean_std | 12 | 53.68 | 50.32 | 0.040 | 0.006 | 0.000 |
| body_mean_std | rbf_svm | mean_std | 12 | 77.57 | 77.48 | 0.040 | 0.262 | 0.338 |
| body_mean_std | random_forest | mean_std | 12 | 80.18 | 79.92 | 0.040 | 0.265 | 0.013 |
| body_direct_covariation | ridge | mean_std_covariation | 54 | 74.11 | 73.01 | 0.259 | 0.004 | 0.000 |
| body_direct_covariation | rbf_svm | mean_std_covariation | 54 | 78.79 | 79.11 | 0.259 | 0.377 | 0.459 |
| body_direct_covariation | random_forest | mean_std_covariation | 54 | 85.99 | 86.08 | 0.259 | 0.428 | 0.013 |
| total_mean_std | ridge | mean_std | 12 | 76.42 | 75.62 | 0.014 | 0.002 | 0.000 |
| total_mean_std | rbf_svm | mean_std | 12 | 81.95 | 81.29 | 0.014 | 0.089 | 0.146 |
| total_mean_std | random_forest | mean_std | 12 | 81.10 | 80.55 | 0.014 | 0.194 | 0.013 |
| total_direct_covariation | ridge | mean_std_covariation | 54 | 88.53 | 88.46 | 0.071 | 0.002 | 0.000 |
| total_direct_covariation | rbf_svm | mean_std_covariation | 54 | 89.85 | 89.72 | 0.071 | 0.116 | 0.179 |
| total_direct_covariation | random_forest | mean_std_covariation | 54 | 92.77 | 92.69 | 0.071 | 0.389 | 0.014 |
| engineered_561 | ridge | uci_features | 561 | 95.72 | 95.85 | 0.000 | 0.025 | 0.003 |
| engineered_561 | rbf_svm | uci_features | 561 | 95.49 | 95.40 | 0.000 | 0.733 | 0.889 |
| engineered_561 | random_forest | uci_features | 561 | 92.43 | 92.21 | 0.000 | 1.202 | 0.014 |
| 561_plus_total_covariation | ridge | mean_std_covariation | 615 | 95.86 | 96.01 | 0.071 | 0.031 | 0.003 |
| 561_plus_total_covariation | rbf_svm | mean_std_covariation | 615 | 96.17 | 96.15 | 0.071 | 0.751 | 0.920 |
| 561_plus_total_covariation | random_forest | mean_std_covariation | 615 | 92.47 | 92.32 | 0.071 | 1.250 | 0.014 |
| total_basepoint | ridge | offset_full_signature | 210 | 86.29 | 86.32 | 0.297 | 0.009 | 0.001 |
| total_basepoint | rbf_svm | offset_full_signature | 210 | 88.29 | 88.17 | 0.297 | 0.385 | 0.455 |
| total_basepoint | random_forest | offset_full_signature | 210 | 88.73 | 88.58 | 0.297 | 0.709 | 0.014 |
| 561_plus_total_basepoint | ridge | ordinary_full_signature | 617 | 97.05 | 97.07 | 0.175 | 0.035 | 0.002 |
| 561_plus_total_basepoint | rbf_svm | offset_full_logsignature | 666 | 96.98 | 97.00 | 0.297 | 0.825 | 0.951 |
| 561_plus_total_basepoint | random_forest | offset_full_logsignature | 666 | 93.15 | 93.18 | 0.297 | 1.252 | 0.014 |
| observable_energy_envelopes | ridge | fourier_pascal_full_signature | 116 | 78.96 | 78.30 | 0.325 | 0.006 | 0.000 |
| observable_energy_envelopes | rbf_svm | fourier_pascal_full_logsignature | 61 | 86.05 | 85.70 | 0.325 | 0.183 | 0.268 |
| observable_energy_envelopes | random_forest | fourier_pascal_full_signature | 116 | 85.61 | 85.30 | 0.325 | 0.591 | 0.014 |
| 561_plus_observable_energy_envelopes | ridge | pascal_qr_full_logsignature | 588 | 95.96 | 96.10 | 0.287 | 0.030 | 0.002 |
| 561_plus_observable_energy_envelopes | rbf_svm | pooled_means | 569 | 95.76 | 95.67 | 0.153 | 0.733 | 0.890 |
| 561_plus_observable_energy_envelopes | random_forest | pascal_qr_full_logsignature | 588 | 92.40 | 92.23 | 0.287 | 1.264 | 0.014 |
| observable_delayed_products | ridge | fourier_pascal_full_signature | 426 | 82.93 | 82.17 | 0.489 | 0.015 | 0.001 |
| observable_delayed_products | rbf_svm | fourier_pascal_full_signature | 426 | 90.02 | 89.94 | 0.489 | 0.603 | 0.789 |
| observable_delayed_products | random_forest | fourier_pascal_full_signature | 426 | 88.02 | 87.79 | 0.489 | 1.189 | 0.012 |
| 561_plus_observable_delayed_products | ridge | pascal_qr_full_logsignature | 645 | 96.20 | 96.34 | 0.347 | 0.034 | 0.002 |
| 561_plus_observable_delayed_products | rbf_svm | fourier_pascal_first_level_products | 797 | 96.00 | 95.95 | 0.489 | 0.982 | 1.189 |
| 561_plus_observable_delayed_products | random_forest | fourier_pascal_full_logsignature | 777 | 93.79 | 93.63 | 0.489 | 1.370 | 0.014 |
| observable_energy_delayed_products | ridge | fourier_pascal_full_logsignature | 471 | 85.00 | 84.26 | 0.796 | 0.020 | 0.001 |
| observable_energy_delayed_products | rbf_svm | fourier_pascal_full_signature | 936 | 90.50 | 90.39 | 0.796 | 1.268 | 3.917 |
| observable_energy_delayed_products | random_forest | fourier_pascal_full_logsignature | 471 | 87.78 | 87.51 | 0.796 | 1.261 | 0.014 |
| 561_plus_observable_energy_delayed_products | ridge | ordinary_full_logsignature | 588 | 96.34 | 96.47 | 0.280 | 0.029 | 0.002 |
| 561_plus_observable_energy_delayed_products | rbf_svm | pascal_qr_full_logsignature | 738 | 96.13 | 96.09 | 0.456 | 0.950 | 1.092 |
| 561_plus_observable_energy_delayed_products | random_forest | fourier_pascal_first_level_products | 1062 | 93.65 | 93.51 | 0.796 | 1.647 | 0.015 |

## Every comparison

| Input / augmentation | Representation | Head | Features | Accuracy | Macro F1 | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|
| body_mean_std | mean_std | ridge | 12 | 53.68 | 50.32 | 0.006 | 0.000 |
| body_mean_std | mean_std | rbf_svm | 12 | 77.57 | 77.48 | 0.262 | 0.338 |
| body_mean_std | mean_std | random_forest | 12 | 80.18 | 79.92 | 0.265 | 0.013 |
| body_direct_covariation | mean_second_moment | ridge | 27 | 57.41 | 55.32 | 0.003 | 0.000 |
| body_direct_covariation | mean_second_moment | rbf_svm | 27 | 66.03 | 64.15 | 0.328 | 0.364 |
| body_direct_covariation | mean_second_moment | random_forest | 27 | 83.85 | 83.92 | 0.350 | 0.013 |
| body_direct_covariation | mean_second_moment_roughness | ridge | 48 | 60.06 | 58.36 | 0.003 | 0.000 |
| body_direct_covariation | mean_second_moment_roughness | rbf_svm | 48 | 65.32 | 63.09 | 0.367 | 0.429 |
| body_direct_covariation | mean_second_moment_roughness | random_forest | 48 | 85.34 | 85.43 | 0.385 | 0.013 |
| body_direct_covariation | mean_std_covariation | ridge | 54 | 74.11 | 73.01 | 0.004 | 0.000 |
| body_direct_covariation | mean_std_covariation | rbf_svm | 54 | 78.79 | 79.11 | 0.377 | 0.459 |
| body_direct_covariation | mean_std_covariation | random_forest | 54 | 85.99 | 86.08 | 0.428 | 0.013 |
| total_mean_std | mean_std | ridge | 12 | 76.42 | 75.62 | 0.002 | 0.000 |
| total_mean_std | mean_std | rbf_svm | 12 | 81.95 | 81.29 | 0.089 | 0.146 |
| total_mean_std | mean_std | random_forest | 12 | 81.10 | 80.55 | 0.194 | 0.013 |
| total_direct_covariation | mean_second_moment | ridge | 27 | 72.28 | 70.08 | 0.002 | 0.000 |
| total_direct_covariation | mean_second_moment | rbf_svm | 27 | 86.70 | 86.39 | 0.109 | 0.138 |
| total_direct_covariation | mean_second_moment | random_forest | 27 | 84.02 | 83.75 | 0.300 | 0.013 |
| total_direct_covariation | mean_second_moment_roughness | ridge | 48 | 82.93 | 82.87 | 0.003 | 0.000 |
| total_direct_covariation | mean_second_moment_roughness | rbf_svm | 48 | 86.94 | 86.78 | 0.130 | 0.169 |
| total_direct_covariation | mean_second_moment_roughness | random_forest | 48 | 87.07 | 86.79 | 0.336 | 0.013 |
| total_direct_covariation | mean_std_covariation | ridge | 54 | 88.53 | 88.46 | 0.002 | 0.000 |
| total_direct_covariation | mean_std_covariation | rbf_svm | 54 | 89.85 | 89.72 | 0.116 | 0.179 |
| total_direct_covariation | mean_std_covariation | random_forest | 54 | 92.77 | 92.69 | 0.389 | 0.014 |
| engineered_561 | uci_features | ridge | 561 | 95.72 | 95.85 | 0.025 | 0.003 |
| engineered_561 | uci_features | rbf_svm | 561 | 95.49 | 95.40 | 0.733 | 0.889 |
| engineered_561 | uci_features | random_forest | 561 | 92.43 | 92.21 | 1.202 | 0.014 |
| 561_plus_total_covariation | mean_std_covariation | ridge | 615 | 95.86 | 96.01 | 0.031 | 0.003 |
| 561_plus_total_covariation | mean_std_covariation | rbf_svm | 615 | 96.17 | 96.15 | 0.751 | 0.920 |
| 561_plus_total_covariation | mean_std_covariation | random_forest | 615 | 92.47 | 92.32 | 1.250 | 0.014 |
| total_basepoint | ordinary_full_signature | ridge | 56 | 75.57 | 75.49 | 0.004 | 0.000 |
| total_basepoint | ordinary_full_signature | rbf_svm | 56 | 87.44 | 87.31 | 0.155 | 0.221 |
| total_basepoint | ordinary_full_signature | random_forest | 56 | 87.92 | 87.83 | 0.367 | 0.013 |
| 561_plus_total_basepoint | ordinary_full_signature | ridge | 617 | 97.05 | 97.07 | 0.035 | 0.002 |
| 561_plus_total_basepoint | ordinary_full_signature | rbf_svm | 617 | 96.91 | 96.93 | 0.777 | 0.909 |
| 561_plus_total_basepoint | ordinary_full_signature | random_forest | 617 | 92.94 | 92.97 | 1.192 | 0.013 |
| total_basepoint | ordinary_full_logsignature | ridge | 28 | 76.86 | 76.76 | 0.002 | 0.000 |
| total_basepoint | ordinary_full_logsignature | rbf_svm | 28 | 87.11 | 86.99 | 0.108 | 0.162 |
| total_basepoint | ordinary_full_logsignature | random_forest | 28 | 87.51 | 87.33 | 0.286 | 0.014 |
| 561_plus_total_basepoint | ordinary_full_logsignature | ridge | 589 | 96.23 | 96.36 | 0.028 | 0.003 |
| 561_plus_total_basepoint | ordinary_full_logsignature | rbf_svm | 589 | 96.74 | 96.75 | 0.750 | 0.896 |
| 561_plus_total_basepoint | ordinary_full_logsignature | random_forest | 589 | 92.98 | 92.91 | 1.196 | 0.014 |
| total_basepoint | offset_full_signature | ridge | 210 | 86.29 | 86.32 | 0.009 | 0.001 |
| total_basepoint | offset_full_signature | rbf_svm | 210 | 88.29 | 88.17 | 0.385 | 0.455 |
| total_basepoint | offset_full_signature | random_forest | 210 | 88.73 | 88.58 | 0.709 | 0.014 |
| 561_plus_total_basepoint | offset_full_signature | ridge | 771 | 97.01 | 97.04 | 0.054 | 0.003 |
| 561_plus_total_basepoint | offset_full_signature | rbf_svm | 771 | 96.64 | 96.64 | 0.988 | 1.139 |
| 561_plus_total_basepoint | offset_full_signature | random_forest | 771 | 92.57 | 92.56 | 1.344 | 0.014 |
| total_basepoint | offset_full_logsignature | ridge | 105 | 82.97 | 82.91 | 0.005 | 0.000 |
| total_basepoint | offset_full_logsignature | rbf_svm | 105 | 88.12 | 88.03 | 0.205 | 0.358 |
| total_basepoint | offset_full_logsignature | random_forest | 105 | 87.14 | 86.91 | 0.528 | 0.013 |
| 561_plus_total_basepoint | offset_full_logsignature | ridge | 666 | 96.17 | 96.28 | 0.033 | 0.003 |
| 561_plus_total_basepoint | offset_full_logsignature | rbf_svm | 666 | 96.98 | 97.00 | 0.825 | 0.951 |
| 561_plus_total_basepoint | offset_full_logsignature | random_forest | 666 | 93.15 | 93.18 | 1.252 | 0.014 |
| observable_energy_envelopes | pooled_means | ridge | 8 | 64.37 | 59.90 | 0.002 | 0.000 |
| observable_energy_envelopes | pooled_means | rbf_svm | 8 | 78.62 | 77.98 | 0.103 | 0.172 |
| observable_energy_envelopes | pooled_means | random_forest | 8 | 77.60 | 76.81 | 0.165 | 0.014 |
| 561_plus_observable_energy_envelopes | pooled_means | ridge | 569 | 95.79 | 95.92 | 0.031 | 0.002 |
| 561_plus_observable_energy_envelopes | pooled_means | rbf_svm | 569 | 95.76 | 95.67 | 0.733 | 0.890 |
| 561_plus_observable_energy_envelopes | pooled_means | random_forest | 569 | 91.75 | 91.58 | 1.191 | 0.014 |
| observable_energy_envelopes | ordinary_full_signature | ridge | 12 | 71.60 | 70.74 | 0.002 | 0.000 |
| observable_energy_envelopes | ordinary_full_signature | rbf_svm | 12 | 78.55 | 77.87 | 0.112 | 0.194 |
| observable_energy_envelopes | ordinary_full_signature | random_forest | 12 | 77.91 | 77.15 | 0.205 | 0.013 |
| 561_plus_observable_energy_envelopes | ordinary_full_signature | ridge | 573 | 95.79 | 95.92 | 0.031 | 0.002 |
| 561_plus_observable_energy_envelopes | ordinary_full_signature | rbf_svm | 573 | 95.72 | 95.65 | 0.753 | 0.894 |
| 561_plus_observable_energy_envelopes | ordinary_full_signature | random_forest | 573 | 92.37 | 92.17 | 1.222 | 0.014 |
| observable_energy_envelopes | ordinary_full_logsignature | ridge | 9 | 64.27 | 59.82 | 0.002 | 0.000 |
| observable_energy_envelopes | ordinary_full_logsignature | rbf_svm | 9 | 79.67 | 79.09 | 0.111 | 0.178 |
| observable_energy_envelopes | ordinary_full_logsignature | random_forest | 9 | 78.01 | 77.32 | 0.201 | 0.013 |
| 561_plus_observable_energy_envelopes | ordinary_full_logsignature | ridge | 570 | 95.79 | 95.92 | 0.028 | 0.002 |
| 561_plus_observable_energy_envelopes | ordinary_full_logsignature | rbf_svm | 570 | 95.72 | 95.63 | 0.738 | 0.861 |
| 561_plus_observable_energy_envelopes | ordinary_full_logsignature | random_forest | 570 | 92.20 | 92.04 | 1.206 | 0.014 |
| observable_energy_envelopes | ordinary_first_level_products | ridge | 11 | 71.63 | 70.76 | 0.002 | 0.000 |
| observable_energy_envelopes | ordinary_first_level_products | rbf_svm | 11 | 78.76 | 78.11 | 0.112 | 0.186 |
| observable_energy_envelopes | ordinary_first_level_products | random_forest | 11 | 77.71 | 76.91 | 0.208 | 0.014 |
| 561_plus_observable_energy_envelopes | ordinary_first_level_products | ridge | 572 | 95.79 | 95.92 | 0.027 | 0.002 |
| 561_plus_observable_energy_envelopes | ordinary_first_level_products | rbf_svm | 572 | 95.72 | 95.65 | 0.722 | 0.857 |
| 561_plus_observable_energy_envelopes | ordinary_first_level_products | random_forest | 572 | 92.20 | 92.04 | 1.199 | 0.013 |
| observable_energy_envelopes | pascal_qr_full_signature | ridge | 48 | 74.11 | 72.76 | 0.003 | 0.000 |
| observable_energy_envelopes | pascal_qr_full_signature | rbf_svm | 48 | 81.81 | 81.16 | 0.183 | 0.267 |
| observable_energy_envelopes | pascal_qr_full_signature | random_forest | 48 | 80.39 | 79.87 | 0.361 | 0.013 |
| 561_plus_observable_energy_envelopes | pascal_qr_full_signature | ridge | 609 | 95.89 | 96.03 | 0.034 | 0.002 |
| 561_plus_observable_energy_envelopes | pascal_qr_full_signature | rbf_svm | 609 | 95.66 | 95.57 | 0.817 | 0.961 |
| 561_plus_observable_energy_envelopes | pascal_qr_full_signature | random_forest | 609 | 92.09 | 91.91 | 1.237 | 0.014 |
| observable_energy_envelopes | pascal_qr_full_logsignature | ridge | 27 | 72.79 | 71.83 | 0.003 | 0.000 |
| observable_energy_envelopes | pascal_qr_full_logsignature | rbf_svm | 27 | 81.98 | 81.42 | 0.152 | 0.219 |
| observable_energy_envelopes | pascal_qr_full_logsignature | random_forest | 27 | 79.57 | 78.99 | 0.302 | 0.014 |
| 561_plus_observable_energy_envelopes | pascal_qr_full_logsignature | ridge | 588 | 95.96 | 96.10 | 0.030 | 0.002 |
| 561_plus_observable_energy_envelopes | pascal_qr_full_logsignature | rbf_svm | 588 | 95.69 | 95.62 | 0.746 | 0.887 |
| 561_plus_observable_energy_envelopes | pascal_qr_full_logsignature | random_forest | 588 | 92.40 | 92.23 | 1.264 | 0.014 |
| observable_energy_envelopes | pascal_qr_first_level_products | ridge | 33 | 73.70 | 72.47 | 0.003 | 0.000 |
| observable_energy_envelopes | pascal_qr_first_level_products | rbf_svm | 33 | 81.64 | 81.01 | 0.163 | 0.238 |
| observable_energy_envelopes | pascal_qr_first_level_products | random_forest | 33 | 80.15 | 79.62 | 0.313 | 0.014 |
| 561_plus_observable_energy_envelopes | pascal_qr_first_level_products | ridge | 594 | 95.89 | 96.03 | 0.030 | 0.002 |
| 561_plus_observable_energy_envelopes | pascal_qr_first_level_products | rbf_svm | 594 | 95.66 | 95.57 | 0.764 | 0.892 |
| 561_plus_observable_energy_envelopes | pascal_qr_first_level_products | random_forest | 594 | 92.03 | 91.84 | 1.257 | 0.014 |
| observable_energy_envelopes | fourier_pascal_full_signature | ridge | 116 | 78.96 | 78.30 | 0.006 | 0.000 |
| observable_energy_envelopes | fourier_pascal_full_signature | rbf_svm | 116 | 85.82 | 85.42 | 0.250 | 0.437 |
| observable_energy_envelopes | fourier_pascal_full_signature | random_forest | 116 | 85.61 | 85.30 | 0.591 | 0.014 |
| 561_plus_observable_energy_envelopes | fourier_pascal_full_signature | ridge | 677 | 95.93 | 96.06 | 0.042 | 0.002 |
| 561_plus_observable_energy_envelopes | fourier_pascal_full_signature | rbf_svm | 677 | 95.66 | 95.58 | 0.885 | 1.070 |
| 561_plus_observable_energy_envelopes | fourier_pascal_full_signature | random_forest | 677 | 92.06 | 91.86 | 1.343 | 0.014 |
| observable_energy_envelopes | fourier_pascal_full_logsignature | ridge | 61 | 72.58 | 71.75 | 0.003 | 0.000 |
| observable_energy_envelopes | fourier_pascal_full_logsignature | rbf_svm | 61 | 86.05 | 85.70 | 0.183 | 0.268 |
| observable_energy_envelopes | fourier_pascal_full_logsignature | random_forest | 61 | 83.34 | 82.87 | 0.428 | 0.012 |
| 561_plus_observable_energy_envelopes | fourier_pascal_full_logsignature | ridge | 622 | 95.79 | 95.92 | 0.034 | 0.002 |
| 561_plus_observable_energy_envelopes | fourier_pascal_full_logsignature | rbf_svm | 622 | 95.62 | 95.53 | 0.806 | 0.946 |
| 561_plus_observable_energy_envelopes | fourier_pascal_full_logsignature | random_forest | 622 | 91.45 | 91.25 | 1.252 | 0.017 |
| observable_energy_envelopes | fourier_pascal_first_level_products | ridge | 71 | 77.84 | 77.12 | 0.003 | 0.000 |
| observable_energy_envelopes | fourier_pascal_first_level_products | rbf_svm | 71 | 84.53 | 84.04 | 0.206 | 0.330 |
| observable_energy_envelopes | fourier_pascal_first_level_products | random_forest | 71 | 84.12 | 83.81 | 0.472 | 0.014 |
| 561_plus_observable_energy_envelopes | fourier_pascal_first_level_products | ridge | 632 | 95.93 | 96.07 | 0.038 | 0.002 |
| 561_plus_observable_energy_envelopes | fourier_pascal_first_level_products | rbf_svm | 632 | 95.49 | 95.40 | 0.812 | 0.948 |
| 561_plus_observable_energy_envelopes | fourier_pascal_first_level_products | random_forest | 632 | 92.03 | 91.82 | 1.286 | 0.017 |
| observable_delayed_products | pooled_means | ridge | 10 | 74.65 | 73.56 | 0.002 | 0.000 |
| observable_delayed_products | pooled_means | rbf_svm | 10 | 84.70 | 84.13 | 0.085 | 0.131 |
| observable_delayed_products | pooled_means | random_forest | 10 | 81.64 | 80.82 | 0.192 | 0.016 |
| 561_plus_observable_delayed_products | pooled_means | ridge | 571 | 96.13 | 96.26 | 0.027 | 0.002 |
| 561_plus_observable_delayed_products | pooled_means | rbf_svm | 571 | 95.83 | 95.75 | 0.715 | 0.883 |
| 561_plus_observable_delayed_products | pooled_means | random_forest | 571 | 92.23 | 92.05 | 1.182 | 0.017 |
| observable_delayed_products | ordinary_full_signature | ridge | 26 | 80.05 | 79.14 | 0.002 | 0.000 |
| observable_delayed_products | ordinary_full_signature | rbf_svm | 26 | 84.02 | 83.37 | 0.097 | 0.146 |
| observable_delayed_products | ordinary_full_signature | random_forest | 26 | 84.02 | 83.39 | 0.287 | 0.016 |
| 561_plus_observable_delayed_products | ordinary_full_signature | ridge | 587 | 96.17 | 96.30 | 0.032 | 0.003 |
| 561_plus_observable_delayed_products | ordinary_full_signature | rbf_svm | 587 | 96.00 | 95.94 | 0.720 | 0.884 |
| 561_plus_observable_delayed_products | ordinary_full_signature | random_forest | 587 | 92.37 | 92.25 | 1.224 | 0.017 |
| observable_delayed_products | ordinary_full_logsignature | ridge | 16 | 74.86 | 73.79 | 0.002 | 0.000 |
| observable_delayed_products | ordinary_full_logsignature | rbf_svm | 16 | 85.68 | 85.25 | 0.102 | 0.149 |
| observable_delayed_products | ordinary_full_logsignature | random_forest | 16 | 83.68 | 83.03 | 0.248 | 0.016 |
| 561_plus_observable_delayed_products | ordinary_full_logsignature | ridge | 577 | 96.20 | 96.33 | 0.027 | 0.003 |
| 561_plus_observable_delayed_products | ordinary_full_logsignature | rbf_svm | 577 | 95.86 | 95.78 | 0.738 | 0.892 |
| 561_plus_observable_delayed_products | ordinary_full_logsignature | random_forest | 577 | 92.20 | 92.02 | 1.230 | 0.017 |
| observable_delayed_products | ordinary_first_level_products | ridge | 20 | 79.84 | 78.90 | 0.002 | 0.000 |
| observable_delayed_products | ordinary_first_level_products | rbf_svm | 20 | 83.95 | 83.28 | 0.094 | 0.137 |
| observable_delayed_products | ordinary_first_level_products | random_forest | 20 | 83.78 | 83.09 | 0.247 | 0.015 |
| 561_plus_observable_delayed_products | ordinary_first_level_products | ridge | 581 | 96.20 | 96.33 | 0.026 | 0.003 |
| 561_plus_observable_delayed_products | ordinary_first_level_products | rbf_svm | 581 | 96.00 | 95.93 | 0.724 | 0.883 |
| 561_plus_observable_delayed_products | ordinary_first_level_products | random_forest | 581 | 92.74 | 92.63 | 1.212 | 0.016 |
| observable_delayed_products | pascal_qr_full_signature | ridge | 162 | 81.20 | 80.31 | 0.006 | 0.000 |
| observable_delayed_products | pascal_qr_full_signature | rbf_svm | 162 | 86.53 | 86.20 | 0.288 | 0.377 |
| observable_delayed_products | pascal_qr_full_signature | random_forest | 162 | 85.54 | 85.03 | 0.692 | 0.016 |
| 561_plus_observable_delayed_products | pascal_qr_full_signature | ridge | 723 | 96.10 | 96.23 | 0.046 | 0.003 |
| 561_plus_observable_delayed_products | pascal_qr_full_signature | rbf_svm | 723 | 95.96 | 95.90 | 0.906 | 1.087 |
| 561_plus_observable_delayed_products | pascal_qr_full_signature | random_forest | 723 | 93.28 | 93.16 | 1.310 | 0.016 |
| observable_delayed_products | pascal_qr_full_logsignature | ridge | 84 | 81.24 | 80.47 | 0.004 | 0.000 |
| observable_delayed_products | pascal_qr_full_logsignature | rbf_svm | 84 | 87.07 | 86.74 | 0.192 | 0.279 |
| observable_delayed_products | pascal_qr_full_logsignature | random_forest | 84 | 85.31 | 84.79 | 0.508 | 0.016 |
| 561_plus_observable_delayed_products | pascal_qr_full_logsignature | ridge | 645 | 96.20 | 96.34 | 0.034 | 0.002 |
| 561_plus_observable_delayed_products | pascal_qr_full_logsignature | rbf_svm | 645 | 95.86 | 95.79 | 0.812 | 0.982 |
| 561_plus_observable_delayed_products | pascal_qr_full_logsignature | random_forest | 645 | 92.81 | 92.72 | 1.272 | 0.013 |
| observable_delayed_products | pascal_qr_first_level_products | ridge | 96 | 80.56 | 79.56 | 0.004 | 0.000 |
| observable_delayed_products | pascal_qr_first_level_products | rbf_svm | 96 | 85.65 | 85.16 | 0.220 | 0.333 |
| observable_delayed_products | pascal_qr_first_level_products | random_forest | 96 | 85.14 | 84.65 | 0.524 | 0.015 |
| 561_plus_observable_delayed_products | pascal_qr_first_level_products | ridge | 657 | 96.20 | 96.33 | 0.037 | 0.002 |
| 561_plus_observable_delayed_products | pascal_qr_first_level_products | rbf_svm | 657 | 95.76 | 95.68 | 0.839 | 1.007 |
| 561_plus_observable_delayed_products | pascal_qr_first_level_products | random_forest | 657 | 92.81 | 92.68 | 1.314 | 0.017 |
| observable_delayed_products | fourier_pascal_full_signature | ridge | 426 | 82.93 | 82.17 | 0.015 | 0.001 |
| observable_delayed_products | fourier_pascal_full_signature | rbf_svm | 426 | 90.02 | 89.94 | 0.603 | 0.789 |
| observable_delayed_products | fourier_pascal_full_signature | random_forest | 426 | 88.02 | 87.79 | 1.189 | 0.012 |
| 561_plus_observable_delayed_products | fourier_pascal_full_signature | ridge | 987 | 96.00 | 96.11 | 0.068 | 0.003 |
| 561_plus_observable_delayed_products | fourier_pascal_full_signature | rbf_svm | 987 | 95.89 | 95.85 | 1.097 | 2.975 |
| 561_plus_observable_delayed_products | fourier_pascal_full_signature | random_forest | 987 | 92.81 | 92.69 | 1.612 | 0.012 |
| observable_delayed_products | fourier_pascal_full_logsignature | ridge | 216 | 81.17 | 80.45 | 0.007 | 0.001 |
| observable_delayed_products | fourier_pascal_full_logsignature | rbf_svm | 216 | 89.24 | 89.04 | 0.337 | 0.446 |
| observable_delayed_products | fourier_pascal_full_logsignature | random_forest | 216 | 87.78 | 87.53 | 0.840 | 0.016 |
| 561_plus_observable_delayed_products | fourier_pascal_full_logsignature | ridge | 777 | 96.13 | 96.27 | 0.042 | 0.004 |
| 561_plus_observable_delayed_products | fourier_pascal_full_logsignature | rbf_svm | 777 | 96.00 | 95.94 | 1.032 | 1.228 |
| 561_plus_observable_delayed_products | fourier_pascal_full_logsignature | random_forest | 777 | 93.79 | 93.63 | 1.370 | 0.014 |
| observable_delayed_products | fourier_pascal_first_level_products | ridge | 236 | 82.42 | 81.63 | 0.008 | 0.001 |
| observable_delayed_products | fourier_pascal_first_level_products | rbf_svm | 236 | 88.90 | 88.69 | 0.371 | 0.488 |
| observable_delayed_products | fourier_pascal_first_level_products | random_forest | 236 | 87.82 | 87.53 | 0.872 | 0.016 |
| 561_plus_observable_delayed_products | fourier_pascal_first_level_products | ridge | 797 | 96.20 | 96.33 | 0.042 | 0.003 |
| 561_plus_observable_delayed_products | fourier_pascal_first_level_products | rbf_svm | 797 | 96.00 | 95.95 | 0.982 | 1.189 |
| 561_plus_observable_delayed_products | fourier_pascal_first_level_products | random_forest | 797 | 92.94 | 92.81 | 1.434 | 0.014 |
| observable_energy_delayed_products | pooled_means | ridge | 12 | 79.71 | 79.18 | 0.002 | 0.000 |
| observable_energy_delayed_products | pooled_means | rbf_svm | 12 | 85.78 | 85.34 | 0.084 | 0.135 |
| observable_energy_delayed_products | pooled_means | random_forest | 12 | 83.64 | 82.91 | 0.194 | 0.013 |
| 561_plus_observable_energy_delayed_products | pooled_means | ridge | 573 | 96.20 | 96.33 | 0.037 | 0.003 |
| 561_plus_observable_energy_delayed_products | pooled_means | rbf_svm | 573 | 95.83 | 95.75 | 0.750 | 0.888 |
| 561_plus_observable_energy_delayed_products | pooled_means | random_forest | 573 | 92.60 | 92.44 | 1.187 | 0.014 |
| observable_energy_delayed_products | ordinary_full_signature | ridge | 48 | 82.83 | 81.67 | 0.003 | 0.000 |
| observable_energy_delayed_products | ordinary_full_signature | rbf_svm | 48 | 85.65 | 85.09 | 0.114 | 0.176 |
| observable_energy_delayed_products | ordinary_full_signature | random_forest | 48 | 84.42 | 83.84 | 0.341 | 0.014 |
| 561_plus_observable_energy_delayed_products | ordinary_full_signature | ridge | 609 | 96.23 | 96.37 | 0.034 | 0.002 |
| 561_plus_observable_energy_delayed_products | ordinary_full_signature | rbf_svm | 609 | 96.00 | 95.94 | 0.759 | 0.915 |
| 561_plus_observable_energy_delayed_products | ordinary_full_signature | random_forest | 609 | 93.18 | 93.06 | 1.206 | 0.014 |
| observable_energy_delayed_products | ordinary_full_logsignature | ridge | 27 | 80.22 | 79.65 | 0.003 | 0.000 |
| observable_energy_delayed_products | ordinary_full_logsignature | rbf_svm | 27 | 87.14 | 86.78 | 0.121 | 0.162 |
| observable_energy_delayed_products | ordinary_full_logsignature | random_forest | 27 | 84.76 | 84.23 | 0.303 | 0.014 |
| 561_plus_observable_energy_delayed_products | ordinary_full_logsignature | ridge | 588 | 96.34 | 96.47 | 0.029 | 0.002 |
| 561_plus_observable_energy_delayed_products | ordinary_full_logsignature | rbf_svm | 588 | 95.79 | 95.72 | 0.742 | 0.877 |
| 561_plus_observable_energy_delayed_products | ordinary_full_logsignature | random_forest | 588 | 92.30 | 92.18 | 1.255 | 0.014 |
| observable_energy_delayed_products | ordinary_first_level_products | ridge | 33 | 82.80 | 81.64 | 0.003 | 0.000 |
| observable_energy_delayed_products | ordinary_first_level_products | rbf_svm | 33 | 85.07 | 84.47 | 0.100 | 0.152 |
| observable_energy_delayed_products | ordinary_first_level_products | random_forest | 33 | 83.54 | 82.86 | 0.297 | 0.013 |
| 561_plus_observable_energy_delayed_products | ordinary_first_level_products | ridge | 594 | 96.23 | 96.37 | 0.026 | 0.003 |
| 561_plus_observable_energy_delayed_products | ordinary_first_level_products | rbf_svm | 594 | 96.00 | 95.94 | 0.741 | 0.863 |
| 561_plus_observable_energy_delayed_products | ordinary_first_level_products | random_forest | 594 | 92.74 | 92.63 | 1.227 | 0.014 |
| observable_energy_delayed_products | pascal_qr_full_signature | ridge | 348 | 83.54 | 82.52 | 0.013 | 0.001 |
| observable_energy_delayed_products | pascal_qr_full_signature | rbf_svm | 348 | 87.04 | 86.69 | 0.560 | 0.710 |
| observable_energy_delayed_products | pascal_qr_full_signature | random_forest | 348 | 86.09 | 85.50 | 0.995 | 0.014 |
| 561_plus_observable_energy_delayed_products | pascal_qr_full_signature | ridge | 909 | 96.03 | 96.16 | 0.056 | 0.004 |
| 561_plus_observable_energy_delayed_products | pascal_qr_full_signature | rbf_svm | 909 | 95.93 | 95.88 | 1.106 | 2.965 |
| 561_plus_observable_energy_delayed_products | pascal_qr_full_signature | random_forest | 909 | 92.57 | 92.45 | 1.514 | 0.012 |
| observable_energy_delayed_products | pascal_qr_full_logsignature | ridge | 177 | 83.07 | 81.96 | 0.008 | 0.001 |
| observable_energy_delayed_products | pascal_qr_full_logsignature | rbf_svm | 177 | 87.99 | 87.75 | 0.298 | 0.388 |
| observable_energy_delayed_products | pascal_qr_full_logsignature | random_forest | 177 | 85.99 | 85.44 | 0.710 | 0.014 |
| 561_plus_observable_energy_delayed_products | pascal_qr_full_logsignature | ridge | 738 | 96.23 | 96.38 | 0.043 | 0.002 |
| 561_plus_observable_energy_delayed_products | pascal_qr_full_logsignature | rbf_svm | 738 | 96.13 | 96.09 | 0.950 | 1.092 |
| 561_plus_observable_energy_delayed_products | pascal_qr_full_logsignature | random_forest | 738 | 92.57 | 92.46 | 1.359 | 0.014 |
| observable_energy_delayed_products | pascal_qr_first_level_products | ridge | 195 | 82.76 | 81.54 | 0.008 | 0.001 |
| observable_energy_delayed_products | pascal_qr_first_level_products | rbf_svm | 195 | 86.02 | 85.53 | 0.345 | 0.454 |
| observable_energy_delayed_products | pascal_qr_first_level_products | random_forest | 195 | 85.88 | 85.38 | 0.733 | 0.014 |
| 561_plus_observable_energy_delayed_products | pascal_qr_first_level_products | ridge | 756 | 96.13 | 96.27 | 0.043 | 0.003 |
| 561_plus_observable_energy_delayed_products | pascal_qr_first_level_products | rbf_svm | 756 | 95.49 | 95.40 | 0.961 | 1.147 |
| 561_plus_observable_energy_delayed_products | pascal_qr_first_level_products | random_forest | 756 | 92.50 | 92.35 | 1.378 | 0.014 |
| observable_energy_delayed_products | fourier_pascal_full_signature | ridge | 936 | 85.04 | 84.17 | 0.031 | 0.003 |
| observable_energy_delayed_products | fourier_pascal_full_signature | rbf_svm | 936 | 90.50 | 90.39 | 1.268 | 3.917 |
| observable_energy_delayed_products | fourier_pascal_full_signature | random_forest | 936 | 87.00 | 86.75 | 1.756 | 0.014 |
| 561_plus_observable_energy_delayed_products | fourier_pascal_full_signature | ridge | 1497 | 96.00 | 96.09 | 0.141 | 0.007 |
| 561_plus_observable_energy_delayed_products | fourier_pascal_full_signature | rbf_svm | 1497 | 96.03 | 96.03 | 1.391 | 3.612 |
| 561_plus_observable_energy_delayed_products | fourier_pascal_full_signature | random_forest | 1497 | 93.52 | 93.39 | 1.928 | 0.015 |
| observable_energy_delayed_products | fourier_pascal_full_logsignature | ridge | 471 | 85.00 | 84.26 | 0.020 | 0.001 |
| observable_energy_delayed_products | fourier_pascal_full_logsignature | rbf_svm | 471 | 89.24 | 88.98 | 0.741 | 0.981 |
| observable_energy_delayed_products | fourier_pascal_full_logsignature | random_forest | 471 | 87.78 | 87.51 | 1.261 | 0.014 |
| 561_plus_observable_energy_delayed_products | fourier_pascal_full_logsignature | ridge | 1032 | 96.06 | 96.17 | 0.064 | 0.003 |
| 561_plus_observable_energy_delayed_products | fourier_pascal_full_logsignature | rbf_svm | 1032 | 95.93 | 95.88 | 1.205 | 3.150 |
| 561_plus_observable_energy_delayed_products | fourier_pascal_full_logsignature | random_forest | 1032 | 93.35 | 93.18 | 1.618 | 0.016 |
| observable_energy_delayed_products | fourier_pascal_first_level_products | ridge | 501 | 84.93 | 84.14 | 0.018 | 0.001 |
| observable_energy_delayed_products | fourier_pascal_first_level_products | rbf_svm | 501 | 90.16 | 90.00 | 0.773 | 1.035 |
| observable_energy_delayed_products | fourier_pascal_first_level_products | random_forest | 501 | 87.68 | 87.43 | 1.303 | 0.013 |
| 561_plus_observable_energy_delayed_products | fourier_pascal_first_level_products | ridge | 1062 | 96.27 | 96.40 | 0.073 | 0.005 |
| 561_plus_observable_energy_delayed_products | fourier_pascal_first_level_products | rbf_svm | 1062 | 96.06 | 96.04 | 1.192 | 3.058 |
| 561_plus_observable_energy_delayed_products | fourier_pascal_first_level_products | random_forest | 1062 | 93.65 | 93.51 | 1.647 | 0.015 |

## Adding features to the 561 features

Corrected and lost predictions compare the hybrid with the same head on the 561 features alone. They are descriptive counts on this test split, not significance tests.

| Hybrid / representation / head | Corrected errors | Introduced errors |
|---|---:|---:|
| 561_plus_total_covariation/mean_std_covariation/ridge | 23 | 19 |
| 561_plus_total_covariation/mean_std_covariation/rbf_svm | 35 | 15 |
| 561_plus_total_covariation/mean_std_covariation/random_forest | 47 | 46 |
| 561_plus_total_basepoint/ordinary_full_signature/ridge | 59 | 20 |
| 561_plus_total_basepoint/ordinary_full_signature/rbf_svm | 47 | 5 |
| 561_plus_total_basepoint/ordinary_full_signature/random_forest | 74 | 59 |
| 561_plus_total_basepoint/ordinary_full_logsignature/ridge | 25 | 10 |
| 561_plus_total_basepoint/ordinary_full_logsignature/rbf_svm | 40 | 3 |
| 561_plus_total_basepoint/ordinary_full_logsignature/random_forest | 60 | 44 |
| 561_plus_total_basepoint/offset_full_signature/ridge | 61 | 23 |
| 561_plus_total_basepoint/offset_full_signature/rbf_svm | 53 | 19 |
| 561_plus_total_basepoint/offset_full_signature/random_forest | 92 | 88 |
| 561_plus_total_basepoint/offset_full_logsignature/ridge | 28 | 15 |
| 561_plus_total_basepoint/offset_full_logsignature/rbf_svm | 52 | 8 |
| 561_plus_total_basepoint/offset_full_logsignature/random_forest | 86 | 65 |
| 561_plus_observable_energy_envelopes/pooled_means/ridge | 2 | 0 |
| 561_plus_observable_energy_envelopes/pooled_means/rbf_svm | 8 | 0 |
| 561_plus_observable_energy_envelopes/pooled_means/random_forest | 34 | 54 |
| 561_plus_observable_energy_envelopes/ordinary_full_signature/ridge | 2 | 0 |
| 561_plus_observable_energy_envelopes/ordinary_full_signature/rbf_svm | 8 | 1 |
| 561_plus_observable_energy_envelopes/ordinary_full_signature/random_forest | 36 | 38 |
| 561_plus_observable_energy_envelopes/ordinary_full_logsignature/ridge | 2 | 0 |
| 561_plus_observable_energy_envelopes/ordinary_full_logsignature/rbf_svm | 7 | 0 |
| 561_plus_observable_energy_envelopes/ordinary_full_logsignature/random_forest | 39 | 46 |
| 561_plus_observable_energy_envelopes/ordinary_first_level_products/ridge | 2 | 0 |
| 561_plus_observable_energy_envelopes/ordinary_first_level_products/rbf_svm | 8 | 1 |
| 561_plus_observable_energy_envelopes/ordinary_first_level_products/random_forest | 38 | 45 |
| 561_plus_observable_energy_envelopes/pascal_qr_full_signature/ridge | 6 | 1 |
| 561_plus_observable_energy_envelopes/pascal_qr_full_signature/rbf_svm | 9 | 4 |
| 561_plus_observable_energy_envelopes/pascal_qr_full_signature/random_forest | 36 | 46 |
| 561_plus_observable_energy_envelopes/pascal_qr_full_logsignature/ridge | 7 | 0 |
| 561_plus_observable_energy_envelopes/pascal_qr_full_logsignature/rbf_svm | 8 | 2 |
| 561_plus_observable_energy_envelopes/pascal_qr_full_logsignature/random_forest | 40 | 41 |
| 561_plus_observable_energy_envelopes/pascal_qr_first_level_products/ridge | 6 | 1 |
| 561_plus_observable_energy_envelopes/pascal_qr_first_level_products/rbf_svm | 7 | 2 |
| 561_plus_observable_energy_envelopes/pascal_qr_first_level_products/random_forest | 36 | 48 |
| 561_plus_observable_energy_envelopes/fourier_pascal_full_signature/ridge | 12 | 6 |
| 561_plus_observable_energy_envelopes/fourier_pascal_full_signature/rbf_svm | 13 | 8 |
| 561_plus_observable_energy_envelopes/fourier_pascal_full_signature/random_forest | 33 | 44 |
| 561_plus_observable_energy_envelopes/fourier_pascal_full_logsignature/ridge | 6 | 4 |
| 561_plus_observable_energy_envelopes/fourier_pascal_full_logsignature/rbf_svm | 14 | 10 |
| 561_plus_observable_energy_envelopes/fourier_pascal_full_logsignature/random_forest | 26 | 55 |
| 561_plus_observable_energy_envelopes/fourier_pascal_first_level_products/ridge | 7 | 1 |
| 561_plus_observable_energy_envelopes/fourier_pascal_first_level_products/rbf_svm | 6 | 6 |
| 561_plus_observable_energy_envelopes/fourier_pascal_first_level_products/random_forest | 32 | 44 |
| 561_plus_observable_delayed_products/pooled_means/ridge | 15 | 3 |
| 561_plus_observable_delayed_products/pooled_means/rbf_svm | 12 | 2 |
| 561_plus_observable_delayed_products/pooled_means/random_forest | 39 | 45 |
| 561_plus_observable_delayed_products/ordinary_full_signature/ridge | 15 | 2 |
| 561_plus_observable_delayed_products/ordinary_full_signature/rbf_svm | 16 | 1 |
| 561_plus_observable_delayed_products/ordinary_full_signature/random_forest | 53 | 55 |
| 561_plus_observable_delayed_products/ordinary_full_logsignature/ridge | 17 | 3 |
| 561_plus_observable_delayed_products/ordinary_full_logsignature/rbf_svm | 11 | 0 |
| 561_plus_observable_delayed_products/ordinary_full_logsignature/random_forest | 33 | 40 |
| 561_plus_observable_delayed_products/ordinary_first_level_products/ridge | 15 | 1 |
| 561_plus_observable_delayed_products/ordinary_first_level_products/rbf_svm | 16 | 1 |
| 561_plus_observable_delayed_products/ordinary_first_level_products/random_forest | 52 | 43 |
| 561_plus_observable_delayed_products/pascal_qr_full_signature/ridge | 19 | 8 |
| 561_plus_observable_delayed_products/pascal_qr_full_signature/rbf_svm | 21 | 7 |
| 561_plus_observable_delayed_products/pascal_qr_full_signature/random_forest | 63 | 38 |
| 561_plus_observable_delayed_products/pascal_qr_full_logsignature/ridge | 20 | 6 |
| 561_plus_observable_delayed_products/pascal_qr_full_logsignature/rbf_svm | 17 | 6 |
| 561_plus_observable_delayed_products/pascal_qr_full_logsignature/random_forest | 59 | 48 |
| 561_plus_observable_delayed_products/pascal_qr_first_level_products/ridge | 18 | 4 |
| 561_plus_observable_delayed_products/pascal_qr_first_level_products/rbf_svm | 14 | 6 |
| 561_plus_observable_delayed_products/pascal_qr_first_level_products/random_forest | 50 | 39 |
| 561_plus_observable_delayed_products/fourier_pascal_full_signature/ridge | 19 | 11 |
| 561_plus_observable_delayed_products/fourier_pascal_full_signature/rbf_svm | 29 | 17 |
| 561_plus_observable_delayed_products/fourier_pascal_full_signature/random_forest | 58 | 47 |
| 561_plus_observable_delayed_products/fourier_pascal_full_logsignature/ridge | 21 | 9 |
| 561_plus_observable_delayed_products/fourier_pascal_full_logsignature/rbf_svm | 28 | 13 |
| 561_plus_observable_delayed_products/fourier_pascal_full_logsignature/random_forest | 67 | 27 |
| 561_plus_observable_delayed_products/fourier_pascal_first_level_products/ridge | 21 | 7 |
| 561_plus_observable_delayed_products/fourier_pascal_first_level_products/rbf_svm | 26 | 11 |
| 561_plus_observable_delayed_products/fourier_pascal_first_level_products/random_forest | 51 | 36 |
| 561_plus_observable_energy_delayed_products/pooled_means/ridge | 17 | 3 |
| 561_plus_observable_energy_delayed_products/pooled_means/rbf_svm | 12 | 2 |
| 561_plus_observable_energy_delayed_products/pooled_means/random_forest | 45 | 40 |
| 561_plus_observable_energy_delayed_products/ordinary_full_signature/ridge | 18 | 3 |
| 561_plus_observable_energy_delayed_products/ordinary_full_signature/rbf_svm | 16 | 1 |
| 561_plus_observable_energy_delayed_products/ordinary_full_signature/random_forest | 64 | 42 |
| 561_plus_observable_energy_delayed_products/ordinary_full_logsignature/ridge | 19 | 1 |
| 561_plus_observable_energy_delayed_products/ordinary_full_logsignature/rbf_svm | 12 | 3 |
| 561_plus_observable_energy_delayed_products/ordinary_full_logsignature/random_forest | 49 | 53 |
| 561_plus_observable_energy_delayed_products/ordinary_first_level_products/ridge | 17 | 2 |
| 561_plus_observable_energy_delayed_products/ordinary_first_level_products/rbf_svm | 16 | 1 |
| 561_plus_observable_energy_delayed_products/ordinary_first_level_products/random_forest | 54 | 45 |
| 561_plus_observable_energy_delayed_products/pascal_qr_full_signature/ridge | 18 | 9 |
| 561_plus_observable_energy_delayed_products/pascal_qr_full_signature/rbf_svm | 29 | 16 |
| 561_plus_observable_energy_delayed_products/pascal_qr_full_signature/random_forest | 56 | 52 |
| 561_plus_observable_energy_delayed_products/pascal_qr_full_logsignature/ridge | 20 | 5 |
| 561_plus_observable_energy_delayed_products/pascal_qr_full_logsignature/rbf_svm | 27 | 8 |
| 561_plus_observable_energy_delayed_products/pascal_qr_full_logsignature/random_forest | 54 | 50 |
| 561_plus_observable_energy_delayed_products/pascal_qr_first_level_products/ridge | 17 | 5 |
| 561_plus_observable_energy_delayed_products/pascal_qr_first_level_products/rbf_svm | 15 | 15 |
| 561_plus_observable_energy_delayed_products/pascal_qr_first_level_products/random_forest | 52 | 50 |
| 561_plus_observable_energy_delayed_products/fourier_pascal_full_signature/ridge | 23 | 15 |
| 561_plus_observable_energy_delayed_products/fourier_pascal_full_signature/rbf_svm | 40 | 24 |
| 561_plus_observable_energy_delayed_products/fourier_pascal_full_signature/random_forest | 72 | 40 |
| 561_plus_observable_energy_delayed_products/fourier_pascal_full_logsignature/ridge | 21 | 11 |
| 561_plus_observable_energy_delayed_products/fourier_pascal_full_logsignature/rbf_svm | 35 | 22 |
| 561_plus_observable_energy_delayed_products/fourier_pascal_full_logsignature/random_forest | 59 | 32 |
| 561_plus_observable_energy_delayed_products/fourier_pascal_first_level_products/ridge | 23 | 7 |
| 561_plus_observable_energy_delayed_products/fourier_pascal_first_level_products/rbf_svm | 34 | 17 |
| 561_plus_observable_energy_delayed_products/fourier_pascal_first_level_products/random_forest | 66 | 30 |
