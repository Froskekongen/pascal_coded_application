# UCI HAR exploratory results

7,352 training / 2,947 test windows; official subject-disjoint split, fixed classifier settings, exploratory feature comparisons.

Accuracy and macro F1 are percentages. Times are seconds on this machine. Extraction includes train and test, with full calculations shared across readouts; do not sum extraction columns across heads or claim sparse quotient acceleration. The 561-feature extraction time is unmeasured (CSV placeholder 0); hybrid timings measure only the additional features.

## Best row per input/augmentation and head

These are descriptive test-set maxima over representations, not validation-selected models.

| Input / augmentation | Head | Representation | Features | Accuracy | Macro F1 | Extract | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|---:|
| engineered_561 | ridge | uci_features | 561 | 95.72 | 95.85 | 0.000 | 0.021 | 0.002 |
| pool_full234 | ridge | raw_tensor__spectral_tensor | 736 | 97.93 | 97.97 | 2.643 | 0.026 | 0.002 |
| no_pool | ridge | raw_tensor__spectral_full_compact | 892 | 95.35 | 95.32 | 2.643 | 0.033 | 0.002 |
| raw_only | ridge | tensor | 342 | 84.22 | 84.33 | 0.315 | 0.009 | 0.001 |
| spectral_only | ridge | cross_log | 370 | 87.04 | 87.19 | 2.327 | 0.009 | 0.002 |
| drop_rotation_energy | ridge | raw_log__spectral_log | 481 | 97.90 | 97.93 | 2.643 | 0.013 | 0.002 |
| drop_rotation_gram | ridge | raw_tensor__spectral_tensor | 712 | 97.69 | 97.72 | 2.643 | 0.023 | 0.002 |
| drop_rotation_lags | ridge | raw_tensor__spectral_tensor | 688 | 97.86 | 97.89 | 2.643 | 0.022 | 0.002 |
| drop_cross_cosines | ridge | raw_log__spectral_tensor | 559 | 96.78 | 96.85 | 2.643 | 0.017 | 0.001 |
| drop_lag_cosines | ridge | raw_tensor__spectral_tensor | 724 | 97.93 | 97.97 | 2.643 | 0.025 | 0.002 |
| drop_spectral_energy | ridge | raw_log__spectral_log | 485 | 97.86 | 97.89 | 2.643 | 0.013 | 0.002 |
| drop_spectral_log_energy | ridge | raw_tensor__spectral_tensor | 716 | 97.76 | 97.80 | 2.643 | 0.024 | 0.002 |
| drop_amplitude_mean | ridge | raw_tensor__spectral_log | 656 | 97.83 | 97.87 | 2.643 | 0.020 | 0.003 |
| drop_amplitude_std | ridge | raw_tensor__spectral_tensor | 716 | 97.79 | 97.83 | 2.643 | 0.024 | 0.002 |
| drop_amplitude_skew | ridge | raw_tensor__spectral_tensor | 716 | 97.76 | 97.80 | 2.643 | 0.024 | 0.002 |
| drop_amplitude_kurtosis | ridge | raw_tensor__spectral_tensor | 716 | 97.73 | 97.76 | 2.643 | 0.024 | 0.002 |
| keep_rotation | ridge | raw_tensor__spectral_tensor | 616 | 97.22 | 97.23 | 2.643 | 0.019 | 0.002 |
| keep_spectral_energy | ridge | raw_log__spectral_tensor | 371 | 95.62 | 95.66 | 2.643 | 0.010 | 0.001 |
| keep_amplitude_shape | ridge | raw_log__spectral_tensor | 411 | 96.23 | 96.29 | 2.643 | 0.012 | 0.001 |
| keep_rotation+spectral_energy | ridge | raw_tensor__spectral_tensor | 656 | 97.59 | 97.65 | 2.643 | 0.021 | 0.002 |
| keep_rotation+amplitude_shape | ridge | raw_tensor__spectral_log | 636 | 97.79 | 97.83 | 2.643 | 0.019 | 0.002 |
| keep_spectral_energy+amplitude_shape | ridge | raw_tensor__spectral_tensor | 622 | 96.40 | 96.47 | 2.643 | 0.020 | 0.002 |
| small_cosines6 | ridge | raw_tensor__spectral_cross_log | 718 | 96.37 | 96.31 | 2.643 | 0.024 | 0.003 |
| small_energy20 | ridge | raw_log__spectral_cross_log | 561 | 95.83 | 95.84 | 2.643 | 0.016 | 0.002 |
| small_log_energy20 | ridge | raw_log__spectral_cross_log | 561 | 96.10 | 96.11 | 2.643 | 0.017 | 0.002 |
| small_energy_cosines26 | ridge | raw_tensor__spectral_cross_log | 738 | 96.95 | 96.92 | 2.643 | 0.024 | 0.003 |
| small_log_energy_cosines26 | ridge | raw_log__spectral_cross_log | 567 | 97.15 | 97.12 | 2.643 | 0.017 | 0.002 |
| small_both_energy_cosines46 | ridge | raw_tensor__spectral_cross_log | 758 | 97.39 | 97.39 | 2.643 | 0.026 | 0.003 |
| small_energy_cosines_ampmean46 | ridge | raw_tensor__spectral_cross_log | 758 | 97.18 | 97.15 | 2.643 | 0.027 | 0.003 |
| small_log_energy_cosines_ampmean46 | ridge | raw_log__spectral_cross_log | 587 | 97.52 | 97.52 | 2.643 | 0.017 | 0.002 |
| small_energy_cosines_ampmeanstd66 | ridge | raw_tensor__spectral_cross_log | 778 | 97.59 | 97.61 | 2.643 | 0.027 | 0.003 |
| small_energy_cosines_amptails66 | ridge | raw_tensor__spectral_cross_log | 778 | 97.39 | 97.37 | 2.643 | 0.027 | 0.003 |
| small_energy_cosines_ampshape106 | ridge | raw_tensor__spectral_cross_log | 818 | 97.76 | 97.77 | 2.643 | 0.028 | 0.003 |
| small_both_energy_cosines_ampshape126 | ridge | raw_tensor__spectral_cross_log | 838 | 97.69 | 97.71 | 2.643 | 0.029 | 0.003 |
| moment_pool_energy_ampmeanstd_mean_std | ridge | raw_log__spectral_log | 361 | 97.62 | 97.65 | 2.643 | 0.009 | 0.001 |
| moment_pool_energy_ampmeanstd_mean_std_skew | ridge | raw_log__spectral_log | 373 | 97.73 | 97.76 | 2.643 | 0.009 | 0.001 |
| moment_pool_energy_ampmeanstd_mean_std_skew_kurt | ridge | raw_log__spectral_log | 385 | 97.76 | 97.79 | 2.643 | 0.010 | 0.002 |
| moment_pool_energy_ampmeanstd_mean_std_abs_rms | ridge | raw_log__spectral_log | 385 | 97.66 | 97.69 | 2.643 | 0.010 | 0.002 |
| moment_pool_energy_ampmeanstd_all_stats | ridge | raw_log__spectral_log | 433 | 97.66 | 97.68 | 2.643 | 0.011 | 0.002 |
| moment_pool_energy_ampmeanstd_energy_meanstd | ridge | raw_log__spectral_tensor | 403 | 97.59 | 97.61 | 2.643 | 0.011 | 0.001 |
| moment_pool_energy_ampmeanstd_gram_meanstd | ridge | raw_tensor__spectral_tensor | 574 | 97.52 | 97.54 | 2.643 | 0.018 | 0.002 |
| moment_pool_energy_ampmeanstd_lags_meanstd | ridge | raw_tensor__spectral_tensor | 580 | 97.73 | 97.76 | 2.643 | 0.018 | 0.002 |
| moment_pool_energy_ampmeanstd_gram_lags_meanstd | ridge | raw_tensor__spectral_tensor | 586 | 97.59 | 97.62 | 2.643 | 0.018 | 0.002 |
| moment_pool_logenergy_ampmeanstd_mean_std | ridge | raw_tensor__spectral_log | 532 | 97.62 | 97.64 | 2.643 | 0.015 | 0.002 |
| moment_pool_logenergy_ampmeanstd_mean_std_skew | ridge | raw_log__spectral_log | 373 | 97.79 | 97.81 | 2.643 | 0.009 | 0.001 |
| moment_pool_logenergy_ampmeanstd_mean_std_skew_kurt | ridge | raw_log__spectral_tensor | 445 | 97.76 | 97.78 | 2.643 | 0.013 | 0.001 |
| moment_pool_logenergy_ampmeanstd_mean_std_abs_rms | ridge | raw_tensor__spectral_tensor | 616 | 97.66 | 97.69 | 2.643 | 0.019 | 0.002 |
| moment_pool_logenergy_ampmeanstd_all_stats | ridge | raw_log__spectral_log | 433 | 97.73 | 97.75 | 2.643 | 0.011 | 0.002 |
| moment_pool_logenergy_ampmeanstd_energy_meanstd | ridge | raw_log__spectral_tensor | 403 | 97.52 | 97.53 | 2.643 | 0.011 | 0.001 |
| moment_pool_logenergy_ampmeanstd_gram_meanstd | ridge | raw_log__spectral_tensor | 403 | 97.46 | 97.45 | 2.643 | 0.011 | 0.001 |
| moment_pool_logenergy_ampmeanstd_lags_meanstd | ridge | raw_tensor__spectral_tensor | 580 | 97.76 | 97.79 | 2.643 | 0.018 | 0.002 |
| moment_pool_logenergy_ampmeanstd_gram_lags_meanstd | ridge | raw_tensor__spectral_tensor | 586 | 97.62 | 97.65 | 2.643 | 0.018 | 0.002 |
| moment_pool_energy_ampshape_mean_std | ridge | raw_log__spectral_tensor | 461 | 97.79 | 97.83 | 2.643 | 0.013 | 0.001 |
| moment_pool_energy_ampshape_mean_std_skew | ridge | raw_log__spectral_log | 413 | 97.90 | 97.93 | 2.643 | 0.010 | 0.002 |
| moment_pool_energy_ampshape_mean_std_skew_kurt | ridge | raw_log__spectral_tensor | 485 | 97.86 | 97.90 | 2.643 | 0.014 | 0.001 |
| moment_pool_energy_ampshape_mean_std_abs_rms | ridge | raw_log__spectral_tensor | 485 | 97.76 | 97.79 | 2.643 | 0.015 | 0.001 |
| moment_pool_energy_ampshape_all_stats | ridge | raw_tensor__spectral_tensor | 704 | 97.79 | 97.82 | 2.643 | 0.024 | 0.002 |
| moment_pool_energy_ampshape_energy_meanstd | ridge | raw_log__spectral_tensor | 443 | 97.66 | 97.68 | 2.643 | 0.013 | 0.001 |
| moment_pool_energy_ampshape_gram_meanstd | ridge | raw_tensor__spectral_tensor | 614 | 97.69 | 97.72 | 2.643 | 0.019 | 0.002 |
| moment_pool_energy_ampshape_lags_meanstd | ridge | raw_tensor__spectral_tensor | 620 | 97.79 | 97.82 | 2.643 | 0.020 | 0.002 |
| moment_pool_energy_ampshape_gram_lags_meanstd | ridge | raw_tensor__spectral_tensor | 626 | 97.76 | 97.79 | 2.643 | 0.020 | 0.002 |
| small_energy_axes_cosines21 | ridge | raw_tensor__spectral_cross_log | 733 | 96.98 | 96.96 | 2.643 | 0.023 | 0.003 |
| small_energy_axes_cosines_ampmean41 | ridge | raw_tensor__spectral_cross_log | 753 | 97.18 | 97.15 | 2.643 | 0.025 | 0.003 |
| small_energy_mean_cosines23 | ridge | raw_log__spectral_cross_log | 564 | 95.89 | 95.90 | 2.643 | 0.016 | 0.002 |
| lift_cosine_moments6 | ridge | raw_tensor__spectral_cross_log | 718 | 96.10 | 96.05 | 4.831 | 0.024 | 0.003 |
| lift_energy_cosine_moments12 | ridge | raw_tensor__spectral_cross_log | 724 | 96.30 | 96.26 | 4.831 | 0.024 | 0.003 |
| lift_energy_gram_cosine_moments18 | ridge | raw_tensor__spectral_cross_log | 730 | 96.67 | 96.65 | 4.831 | 0.024 | 0.003 |
| lift_energy_cosine_meanstd12 | ridge | raw_tensor__spectral_cross_log | 724 | 96.67 | 96.63 | 4.831 | 0.024 | 0.003 |
| lift_spectral_energy_cosine_moments26 | ridge | raw_tensor__spectral_cross_log | 738 | 96.64 | 96.62 | 4.831 | 0.025 | 0.003 |
| lift_spectral_energy_cosine_ampmoments86 | ridge | raw_tensor__spectral_cross_log | 798 | 97.25 | 97.25 | 4.831 | 0.028 | 0.003 |
| lift_spectral_ampmoments_cosine86 | ridge | raw_tensor__spectral_cross_log | 798 | 97.25 | 97.25 | 4.831 | 0.028 | 0.003 |
| lift_energy_cosine_concentration72 | ridge | raw_tensor__spectral_cross_log | 784 | 96.74 | 96.71 | 4.831 | 0.027 | 0.003 |
| lift_spectral_energy_cosine_concentration86 | ridge | raw_log__spectral_cross_log | 627 | 97.01 | 97.02 | 4.831 | 0.020 | 0.002 |
| lift_spectral_energy_cosine_std_concentration86 | ridge | raw_log__spectral_cross_log | 627 | 97.42 | 97.42 | 4.831 | 0.020 | 0.002 |
| lift_log_energy_cosine_std_concentration86 | ridge | raw_log__spectral_tensor | 417 | 97.39 | 97.38 | 4.831 | 0.012 | 0.001 |
| lift_energy_cosine_pascal_first18 | ridge | raw_tensor__spectral_cross_log | 730 | 95.59 | 95.58 | 4.831 | 0.024 | 0.003 |
| lift_energy_cosine_pascal_log36 | ridge | raw_tensor__spectral_cross_log | 748 | 95.52 | 95.50 | 4.831 | 0.026 | 0.003 |
| lift_spectral_energy_pascal_log56 | ridge | raw_tensor__spectral_cross_log | 768 | 95.96 | 95.97 | 4.831 | 0.027 | 0.003 |
| lift_spectral_energy_concentration_pascal_log116 | ridge | raw_tensor__spectral_cross_log | 828 | 96.23 | 96.26 | 4.831 | 0.029 | 0.003 |
| lift_profile142 | ridge | raw_tensor__spectral_cross_log | 854 | 98.00 | 98.03 | 4.831 | 0.031 | 0.003 |
| lift_profile102 | ridge | raw_log__spectral_cross_log | 643 | 97.96 | 97.99 | 4.831 | 0.022 | 0.002 |
| lift_profile66 | ridge | raw_tensor__spectral_cross_log | 778 | 97.59 | 97.61 | 4.831 | 0.026 | 0.003 |
| lift_energy_cosine_concentration_q05 | ridge | raw_log__spectral_cross_log | 587 | 97.32 | 97.32 | 4.831 | 0.017 | 0.002 |
| lift_energy_cosine_concentration_q15 | ridge | raw_log__spectral_cross_log | 587 | 97.39 | 97.38 | 4.831 | 0.017 | 0.002 |
| lift_energy_cosine_concentration_q2 | ridge | raw_log__spectral_cross_log | 587 | 97.29 | 97.27 | 4.831 | 0.017 | 0.002 |

## Every comparison

| Input / augmentation | Representation | Head | Features | Accuracy | Macro F1 | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|
| engineered_561 | uci_features | ridge | 561 | 95.72 | 95.85 | 0.021 | 0.002 |
| pool_full234 | raw_log__spectral_tensor | ridge | 565 | 97.86 | 97.90 | 0.018 | 0.002 |
| pool_full234 | raw_tensor__spectral_tensor | ridge | 736 | 97.93 | 97.97 | 0.026 | 0.002 |
| pool_full234 | raw_tensor__spectral_log | ridge | 676 | 97.83 | 97.86 | 0.021 | 0.003 |
| pool_full234 | raw_tensor__spectral_cross_log | ridge | 946 | 97.79 | 97.84 | 0.037 | 0.004 |
| pool_full234 | raw_log__spectral_log | ridge | 505 | 97.90 | 97.93 | 0.014 | 0.002 |
| pool_full234 | raw_log__spectral_cross_log | ridge | 775 | 97.79 | 97.83 | 0.026 | 0.003 |
| no_pool | raw_tensor__spectral_tensor | ridge | 502 | 94.16 | 94.14 | 0.015 | 0.001 |
| no_pool | raw_tensor__spectral_log | ridge | 442 | 93.59 | 93.56 | 0.012 | 0.002 |
| no_pool | raw_tensor__spectral_cross_log | ridge | 712 | 95.32 | 95.28 | 0.023 | 0.003 |
| no_pool | raw_log__spectral_tensor | ridge | 331 | 93.86 | 93.82 | 0.009 | 0.001 |
| no_pool | raw_log__spectral_log | ridge | 271 | 93.48 | 93.48 | 0.006 | 0.001 |
| no_pool | raw_log__spectral_cross_log | ridge | 541 | 94.88 | 94.85 | 0.016 | 0.002 |
| raw_only | tensor | ridge | 342 | 84.22 | 84.33 | 0.009 | 0.001 |
| raw_only | log | ridge | 171 | 81.98 | 82.19 | 0.004 | 0.001 |
| spectral_only | tensor | ridge | 160 | 83.85 | 83.93 | 0.003 | 0.001 |
| spectral_only | log | ridge | 100 | 82.90 | 82.91 | 0.002 | 0.000 |
| spectral_only | cross_log | ridge | 370 | 87.04 | 87.19 | 0.009 | 0.002 |
| no_pool | raw_tensor__spectral_full | ridge | 1082 | 95.22 | 95.19 | 0.045 | 0.004 |
| no_pool | raw_log__spectral_full | ridge | 911 | 94.94 | 94.93 | 0.033 | 0.003 |
| no_pool | raw_tensor__spectral_full_compact | ridge | 892 | 95.35 | 95.32 | 0.033 | 0.002 |
| no_pool | raw_log__spectral_full_compact | ridge | 721 | 94.98 | 94.96 | 0.025 | 0.002 |
| drop_rotation_energy | raw_tensor__spectral_tensor | ridge | 712 | 97.83 | 97.87 | 0.023 | 0.002 |
| drop_rotation_energy | raw_tensor__spectral_log | ridge | 652 | 97.83 | 97.86 | 0.020 | 0.003 |
| drop_rotation_energy | raw_log__spectral_tensor | ridge | 541 | 97.86 | 97.90 | 0.017 | 0.001 |
| drop_rotation_energy | raw_log__spectral_log | ridge | 481 | 97.90 | 97.93 | 0.013 | 0.002 |
| drop_rotation_gram | raw_tensor__spectral_tensor | ridge | 712 | 97.69 | 97.72 | 0.023 | 0.002 |
| drop_rotation_gram | raw_tensor__spectral_log | ridge | 652 | 97.59 | 97.62 | 0.020 | 0.003 |
| drop_rotation_gram | raw_log__spectral_tensor | ridge | 541 | 97.69 | 97.72 | 0.016 | 0.001 |
| drop_rotation_gram | raw_log__spectral_log | ridge | 481 | 97.62 | 97.65 | 0.013 | 0.002 |
| drop_rotation_lags | raw_tensor__spectral_tensor | ridge | 688 | 97.86 | 97.89 | 0.022 | 0.002 |
| drop_rotation_lags | raw_tensor__spectral_log | ridge | 628 | 97.83 | 97.86 | 0.019 | 0.002 |
| drop_rotation_lags | raw_log__spectral_tensor | ridge | 517 | 97.73 | 97.74 | 0.016 | 0.001 |
| drop_rotation_lags | raw_log__spectral_log | ridge | 457 | 97.62 | 97.64 | 0.012 | 0.002 |
| drop_cross_cosines | raw_tensor__spectral_tensor | ridge | 730 | 96.67 | 96.76 | 0.026 | 0.002 |
| drop_cross_cosines | raw_tensor__spectral_log | ridge | 670 | 96.50 | 96.59 | 0.021 | 0.003 |
| drop_cross_cosines | raw_log__spectral_tensor | ridge | 559 | 96.78 | 96.85 | 0.017 | 0.001 |
| drop_cross_cosines | raw_log__spectral_log | ridge | 499 | 96.61 | 96.69 | 0.014 | 0.002 |
| drop_lag_cosines | raw_tensor__spectral_tensor | ridge | 724 | 97.93 | 97.97 | 0.025 | 0.002 |
| drop_lag_cosines | raw_tensor__spectral_log | ridge | 664 | 97.73 | 97.75 | 0.021 | 0.003 |
| drop_lag_cosines | raw_log__spectral_tensor | ridge | 553 | 97.79 | 97.82 | 0.017 | 0.001 |
| drop_lag_cosines | raw_log__spectral_log | ridge | 493 | 97.73 | 97.76 | 0.014 | 0.002 |
| drop_spectral_energy | raw_tensor__spectral_tensor | ridge | 716 | 97.76 | 97.79 | 0.024 | 0.002 |
| drop_spectral_energy | raw_tensor__spectral_log | ridge | 656 | 97.73 | 97.74 | 0.020 | 0.003 |
| drop_spectral_energy | raw_log__spectral_tensor | ridge | 545 | 97.83 | 97.87 | 0.017 | 0.001 |
| drop_spectral_energy | raw_log__spectral_log | ridge | 485 | 97.86 | 97.89 | 0.013 | 0.002 |
| drop_spectral_log_energy | raw_tensor__spectral_tensor | ridge | 716 | 97.76 | 97.80 | 0.024 | 0.002 |
| drop_spectral_log_energy | raw_tensor__spectral_log | ridge | 656 | 97.73 | 97.76 | 0.020 | 0.003 |
| drop_spectral_log_energy | raw_log__spectral_tensor | ridge | 545 | 97.69 | 97.73 | 0.017 | 0.001 |
| drop_spectral_log_energy | raw_log__spectral_log | ridge | 485 | 97.73 | 97.77 | 0.013 | 0.002 |
| drop_amplitude_mean | raw_tensor__spectral_tensor | ridge | 716 | 97.79 | 97.85 | 0.024 | 0.002 |
| drop_amplitude_mean | raw_tensor__spectral_log | ridge | 656 | 97.83 | 97.87 | 0.020 | 0.003 |
| drop_amplitude_mean | raw_log__spectral_tensor | ridge | 545 | 97.76 | 97.80 | 0.017 | 0.001 |
| drop_amplitude_mean | raw_log__spectral_log | ridge | 485 | 97.76 | 97.80 | 0.013 | 0.002 |
| drop_amplitude_std | raw_tensor__spectral_tensor | ridge | 716 | 97.79 | 97.83 | 0.024 | 0.002 |
| drop_amplitude_std | raw_tensor__spectral_log | ridge | 656 | 97.76 | 97.80 | 0.020 | 0.002 |
| drop_amplitude_std | raw_log__spectral_tensor | ridge | 545 | 97.66 | 97.70 | 0.017 | 0.002 |
| drop_amplitude_std | raw_log__spectral_log | ridge | 485 | 97.66 | 97.69 | 0.013 | 0.002 |
| drop_amplitude_skew | raw_tensor__spectral_tensor | ridge | 716 | 97.76 | 97.80 | 0.024 | 0.002 |
| drop_amplitude_skew | raw_tensor__spectral_log | ridge | 656 | 97.59 | 97.63 | 0.020 | 0.003 |
| drop_amplitude_skew | raw_log__spectral_tensor | ridge | 545 | 97.66 | 97.70 | 0.017 | 0.002 |
| drop_amplitude_skew | raw_log__spectral_log | ridge | 485 | 97.66 | 97.69 | 0.013 | 0.002 |
| drop_amplitude_kurtosis | raw_tensor__spectral_tensor | ridge | 716 | 97.73 | 97.76 | 0.024 | 0.002 |
| drop_amplitude_kurtosis | raw_tensor__spectral_log | ridge | 656 | 97.73 | 97.76 | 0.020 | 0.003 |
| drop_amplitude_kurtosis | raw_log__spectral_tensor | ridge | 545 | 97.66 | 97.69 | 0.017 | 0.001 |
| drop_amplitude_kurtosis | raw_log__spectral_log | ridge | 485 | 97.69 | 97.73 | 0.014 | 0.002 |
| keep_rotation | raw_tensor__spectral_tensor | ridge | 616 | 97.22 | 97.23 | 0.019 | 0.002 |
| keep_rotation | raw_tensor__spectral_log | ridge | 556 | 97.01 | 97.02 | 0.017 | 0.002 |
| keep_rotation | raw_log__spectral_tensor | ridge | 445 | 97.05 | 97.05 | 0.013 | 0.001 |
| keep_rotation | raw_log__spectral_log | ridge | 385 | 97.01 | 97.01 | 0.010 | 0.002 |
| keep_spectral_energy | raw_tensor__spectral_tensor | ridge | 542 | 95.59 | 95.62 | 0.017 | 0.001 |
| keep_spectral_energy | raw_tensor__spectral_log | ridge | 482 | 95.18 | 95.22 | 0.013 | 0.002 |
| keep_spectral_energy | raw_log__spectral_tensor | ridge | 371 | 95.62 | 95.66 | 0.010 | 0.001 |
| keep_spectral_energy | raw_log__spectral_log | ridge | 311 | 95.25 | 95.30 | 0.008 | 0.001 |
| keep_amplitude_shape | raw_tensor__spectral_tensor | ridge | 582 | 95.86 | 95.90 | 0.018 | 0.002 |
| keep_amplitude_shape | raw_tensor__spectral_log | ridge | 522 | 95.35 | 95.39 | 0.015 | 0.002 |
| keep_amplitude_shape | raw_log__spectral_tensor | ridge | 411 | 96.23 | 96.29 | 0.012 | 0.001 |
| keep_amplitude_shape | raw_log__spectral_log | ridge | 351 | 95.89 | 95.94 | 0.008 | 0.001 |
| keep_rotation+spectral_energy | raw_tensor__spectral_tensor | ridge | 656 | 97.59 | 97.65 | 0.021 | 0.002 |
| keep_rotation+spectral_energy | raw_tensor__spectral_log | ridge | 596 | 97.59 | 97.63 | 0.017 | 0.002 |
| keep_rotation+spectral_energy | raw_log__spectral_tensor | ridge | 485 | 97.46 | 97.49 | 0.014 | 0.001 |
| keep_rotation+spectral_energy | raw_log__spectral_log | ridge | 425 | 97.25 | 97.29 | 0.012 | 0.002 |
| keep_rotation+amplitude_shape | raw_tensor__spectral_tensor | ridge | 696 | 97.69 | 97.73 | 0.023 | 0.002 |
| keep_rotation+amplitude_shape | raw_tensor__spectral_log | ridge | 636 | 97.79 | 97.83 | 0.019 | 0.002 |
| keep_rotation+amplitude_shape | raw_log__spectral_tensor | ridge | 525 | 97.69 | 97.73 | 0.016 | 0.001 |
| keep_rotation+amplitude_shape | raw_log__spectral_log | ridge | 465 | 97.69 | 97.72 | 0.013 | 0.002 |
| keep_spectral_energy+amplitude_shape | raw_tensor__spectral_tensor | ridge | 622 | 96.40 | 96.47 | 0.020 | 0.002 |
| keep_spectral_energy+amplitude_shape | raw_tensor__spectral_log | ridge | 562 | 96.10 | 96.14 | 0.016 | 0.003 |
| keep_spectral_energy+amplitude_shape | raw_log__spectral_tensor | ridge | 451 | 96.37 | 96.41 | 0.013 | 0.001 |
| keep_spectral_energy+amplitude_shape | raw_log__spectral_log | ridge | 391 | 96.20 | 96.25 | 0.010 | 0.002 |
| small_cosines6 | raw_tensor__spectral_tensor | ridge | 508 | 96.06 | 95.99 | 0.015 | 0.001 |
| small_cosines6 | raw_tensor__spectral_log | ridge | 448 | 95.93 | 95.83 | 0.012 | 0.002 |
| small_cosines6 | raw_tensor__spectral_cross_log | ridge | 718 | 96.37 | 96.31 | 0.024 | 0.003 |
| small_cosines6 | raw_log__spectral_tensor | ridge | 337 | 95.69 | 95.59 | 0.009 | 0.001 |
| small_cosines6 | raw_log__spectral_log | ridge | 277 | 95.79 | 95.69 | 0.006 | 0.001 |
| small_cosines6 | raw_log__spectral_cross_log | ridge | 547 | 95.93 | 95.87 | 0.016 | 0.002 |
| small_energy20 | raw_tensor__spectral_tensor | ridge | 522 | 95.22 | 95.26 | 0.016 | 0.001 |
| small_energy20 | raw_tensor__spectral_log | ridge | 462 | 94.71 | 94.74 | 0.012 | 0.002 |
| small_energy20 | raw_tensor__spectral_cross_log | ridge | 732 | 95.76 | 95.76 | 0.023 | 0.003 |
| small_energy20 | raw_log__spectral_tensor | ridge | 351 | 95.18 | 95.21 | 0.009 | 0.001 |
| small_energy20 | raw_log__spectral_log | ridge | 291 | 94.81 | 94.83 | 0.007 | 0.001 |
| small_energy20 | raw_log__spectral_cross_log | ridge | 561 | 95.83 | 95.84 | 0.016 | 0.002 |
| small_log_energy20 | raw_tensor__spectral_tensor | ridge | 522 | 95.22 | 95.21 | 0.015 | 0.001 |
| small_log_energy20 | raw_tensor__spectral_log | ridge | 462 | 94.77 | 94.79 | 0.012 | 0.002 |
| small_log_energy20 | raw_tensor__spectral_cross_log | ridge | 732 | 95.89 | 95.90 | 0.024 | 0.003 |
| small_log_energy20 | raw_log__spectral_tensor | ridge | 351 | 95.49 | 95.52 | 0.009 | 0.001 |
| small_log_energy20 | raw_log__spectral_log | ridge | 291 | 95.11 | 95.15 | 0.007 | 0.001 |
| small_log_energy20 | raw_log__spectral_cross_log | ridge | 561 | 96.10 | 96.11 | 0.017 | 0.002 |
| small_energy_cosines26 | raw_tensor__spectral_tensor | ridge | 528 | 96.61 | 96.57 | 0.016 | 0.001 |
| small_energy_cosines26 | raw_tensor__spectral_log | ridge | 468 | 96.67 | 96.64 | 0.013 | 0.002 |
| small_energy_cosines26 | raw_tensor__spectral_cross_log | ridge | 738 | 96.95 | 96.92 | 0.024 | 0.003 |
| small_energy_cosines26 | raw_log__spectral_tensor | ridge | 357 | 96.64 | 96.61 | 0.010 | 0.001 |
| small_energy_cosines26 | raw_log__spectral_log | ridge | 297 | 96.64 | 96.60 | 0.007 | 0.001 |
| small_energy_cosines26 | raw_log__spectral_cross_log | ridge | 567 | 96.78 | 96.76 | 0.016 | 0.002 |
| small_log_energy_cosines26 | raw_tensor__spectral_tensor | ridge | 528 | 96.64 | 96.59 | 0.015 | 0.002 |
| small_log_energy_cosines26 | raw_tensor__spectral_log | ridge | 468 | 96.71 | 96.65 | 0.012 | 0.002 |
| small_log_energy_cosines26 | raw_tensor__spectral_cross_log | ridge | 738 | 97.08 | 97.05 | 0.024 | 0.003 |
| small_log_energy_cosines26 | raw_log__spectral_tensor | ridge | 357 | 97.01 | 96.98 | 0.010 | 0.001 |
| small_log_energy_cosines26 | raw_log__spectral_log | ridge | 297 | 96.91 | 96.89 | 0.007 | 0.001 |
| small_log_energy_cosines26 | raw_log__spectral_cross_log | ridge | 567 | 97.15 | 97.12 | 0.017 | 0.002 |
| small_both_energy_cosines46 | raw_tensor__spectral_tensor | ridge | 548 | 97.08 | 97.07 | 0.017 | 0.002 |
| small_both_energy_cosines46 | raw_tensor__spectral_log | ridge | 488 | 97.01 | 96.99 | 0.013 | 0.002 |
| small_both_energy_cosines46 | raw_tensor__spectral_cross_log | ridge | 758 | 97.39 | 97.39 | 0.026 | 0.003 |
| small_both_energy_cosines46 | raw_log__spectral_tensor | ridge | 377 | 97.15 | 97.13 | 0.010 | 0.001 |
| small_both_energy_cosines46 | raw_log__spectral_log | ridge | 317 | 97.01 | 96.99 | 0.008 | 0.001 |
| small_both_energy_cosines46 | raw_log__spectral_cross_log | ridge | 587 | 97.15 | 97.14 | 0.018 | 0.002 |
| small_energy_cosines_ampmean46 | raw_tensor__spectral_tensor | ridge | 548 | 97.08 | 97.07 | 0.017 | 0.002 |
| small_energy_cosines_ampmean46 | raw_tensor__spectral_log | ridge | 488 | 96.98 | 96.95 | 0.014 | 0.002 |
| small_energy_cosines_ampmean46 | raw_tensor__spectral_cross_log | ridge | 758 | 97.18 | 97.15 | 0.027 | 0.003 |
| small_energy_cosines_ampmean46 | raw_log__spectral_tensor | ridge | 377 | 96.98 | 96.95 | 0.011 | 0.001 |
| small_energy_cosines_ampmean46 | raw_log__spectral_log | ridge | 317 | 97.08 | 97.05 | 0.008 | 0.001 |
| small_energy_cosines_ampmean46 | raw_log__spectral_cross_log | ridge | 587 | 97.08 | 97.06 | 0.018 | 0.002 |
| small_log_energy_cosines_ampmean46 | raw_tensor__spectral_tensor | ridge | 548 | 97.25 | 97.23 | 0.017 | 0.002 |
| small_log_energy_cosines_ampmean46 | raw_tensor__spectral_log | ridge | 488 | 97.18 | 97.14 | 0.014 | 0.002 |
| small_log_energy_cosines_ampmean46 | raw_tensor__spectral_cross_log | ridge | 758 | 97.22 | 97.20 | 0.025 | 0.003 |
| small_log_energy_cosines_ampmean46 | raw_log__spectral_tensor | ridge | 377 | 97.39 | 97.38 | 0.010 | 0.001 |
| small_log_energy_cosines_ampmean46 | raw_log__spectral_log | ridge | 317 | 97.32 | 97.30 | 0.008 | 0.001 |
| small_log_energy_cosines_ampmean46 | raw_log__spectral_cross_log | ridge | 587 | 97.52 | 97.52 | 0.017 | 0.002 |
| small_energy_cosines_ampmeanstd66 | raw_tensor__spectral_tensor | ridge | 568 | 97.42 | 97.43 | 0.017 | 0.002 |
| small_energy_cosines_ampmeanstd66 | raw_tensor__spectral_log | ridge | 508 | 97.35 | 97.34 | 0.014 | 0.002 |
| small_energy_cosines_ampmeanstd66 | raw_tensor__spectral_cross_log | ridge | 778 | 97.59 | 97.61 | 0.027 | 0.003 |
| small_energy_cosines_ampmeanstd66 | raw_log__spectral_tensor | ridge | 397 | 97.49 | 97.50 | 0.011 | 0.001 |
| small_energy_cosines_ampmeanstd66 | raw_log__spectral_log | ridge | 337 | 97.56 | 97.57 | 0.008 | 0.001 |
| small_energy_cosines_ampmeanstd66 | raw_log__spectral_cross_log | ridge | 607 | 97.56 | 97.57 | 0.018 | 0.002 |
| small_energy_cosines_amptails66 | raw_tensor__spectral_tensor | ridge | 568 | 96.84 | 96.83 | 0.017 | 0.002 |
| small_energy_cosines_amptails66 | raw_tensor__spectral_log | ridge | 508 | 96.84 | 96.81 | 0.014 | 0.002 |
| small_energy_cosines_amptails66 | raw_tensor__spectral_cross_log | ridge | 778 | 97.39 | 97.37 | 0.027 | 0.003 |
| small_energy_cosines_amptails66 | raw_log__spectral_tensor | ridge | 397 | 96.91 | 96.89 | 0.011 | 0.001 |
| small_energy_cosines_amptails66 | raw_log__spectral_log | ridge | 337 | 96.95 | 96.92 | 0.008 | 0.001 |
| small_energy_cosines_amptails66 | raw_log__spectral_cross_log | ridge | 607 | 97.35 | 97.35 | 0.018 | 0.002 |
| small_energy_cosines_ampshape106 | raw_tensor__spectral_tensor | ridge | 608 | 97.56 | 97.57 | 0.019 | 0.002 |
| small_energy_cosines_ampshape106 | raw_tensor__spectral_log | ridge | 548 | 97.35 | 97.35 | 0.015 | 0.002 |
| small_energy_cosines_ampshape106 | raw_tensor__spectral_cross_log | ridge | 818 | 97.76 | 97.77 | 0.028 | 0.003 |
| small_energy_cosines_ampshape106 | raw_log__spectral_tensor | ridge | 437 | 97.49 | 97.49 | 0.012 | 0.001 |
| small_energy_cosines_ampshape106 | raw_log__spectral_log | ridge | 377 | 97.46 | 97.46 | 0.010 | 0.002 |
| small_energy_cosines_ampshape106 | raw_log__spectral_cross_log | ridge | 647 | 97.66 | 97.66 | 0.020 | 0.002 |
| small_both_energy_cosines_ampshape126 | raw_tensor__spectral_tensor | ridge | 628 | 97.59 | 97.61 | 0.021 | 0.002 |
| small_both_energy_cosines_ampshape126 | raw_tensor__spectral_log | ridge | 568 | 97.59 | 97.60 | 0.016 | 0.002 |
| small_both_energy_cosines_ampshape126 | raw_tensor__spectral_cross_log | ridge | 838 | 97.69 | 97.71 | 0.029 | 0.003 |
| small_both_energy_cosines_ampshape126 | raw_log__spectral_tensor | ridge | 457 | 97.46 | 97.45 | 0.013 | 0.001 |
| small_both_energy_cosines_ampshape126 | raw_log__spectral_log | ridge | 397 | 97.46 | 97.45 | 0.010 | 0.002 |
| small_both_energy_cosines_ampshape126 | raw_log__spectral_cross_log | ridge | 667 | 97.62 | 97.61 | 0.020 | 0.002 |
| moment_pool_energy_ampmeanstd_mean_std | raw_tensor__spectral_tensor | ridge | 592 | 97.59 | 97.61 | 0.018 | 0.002 |
| moment_pool_energy_ampmeanstd_mean_std | raw_tensor__spectral_log | ridge | 532 | 97.62 | 97.65 | 0.015 | 0.002 |
| moment_pool_energy_ampmeanstd_mean_std | raw_log__spectral_tensor | ridge | 421 | 97.56 | 97.58 | 0.012 | 0.001 |
| moment_pool_energy_ampmeanstd_mean_std | raw_log__spectral_log | ridge | 361 | 97.62 | 97.65 | 0.009 | 0.001 |
| moment_pool_energy_ampmeanstd_mean_std_skew | raw_tensor__spectral_tensor | ridge | 604 | 97.62 | 97.65 | 0.019 | 0.002 |
| moment_pool_energy_ampmeanstd_mean_std_skew | raw_tensor__spectral_log | ridge | 544 | 97.66 | 97.68 | 0.015 | 0.002 |
| moment_pool_energy_ampmeanstd_mean_std_skew | raw_log__spectral_tensor | ridge | 433 | 97.59 | 97.62 | 0.012 | 0.001 |
| moment_pool_energy_ampmeanstd_mean_std_skew | raw_log__spectral_log | ridge | 373 | 97.73 | 97.76 | 0.009 | 0.001 |
| moment_pool_energy_ampmeanstd_mean_std_skew_kurt | raw_tensor__spectral_tensor | ridge | 616 | 97.62 | 97.66 | 0.019 | 0.002 |
| moment_pool_energy_ampmeanstd_mean_std_skew_kurt | raw_tensor__spectral_log | ridge | 556 | 97.76 | 97.78 | 0.016 | 0.002 |
| moment_pool_energy_ampmeanstd_mean_std_skew_kurt | raw_log__spectral_tensor | ridge | 445 | 97.59 | 97.62 | 0.012 | 0.001 |
| moment_pool_energy_ampmeanstd_mean_std_skew_kurt | raw_log__spectral_log | ridge | 385 | 97.76 | 97.79 | 0.010 | 0.002 |
| moment_pool_energy_ampmeanstd_mean_std_abs_rms | raw_tensor__spectral_tensor | ridge | 616 | 97.59 | 97.62 | 0.019 | 0.002 |
| moment_pool_energy_ampmeanstd_mean_std_abs_rms | raw_tensor__spectral_log | ridge | 556 | 97.56 | 97.58 | 0.016 | 0.002 |
| moment_pool_energy_ampmeanstd_mean_std_abs_rms | raw_log__spectral_tensor | ridge | 445 | 97.56 | 97.58 | 0.012 | 0.001 |
| moment_pool_energy_ampmeanstd_mean_std_abs_rms | raw_log__spectral_log | ridge | 385 | 97.66 | 97.69 | 0.010 | 0.002 |
| moment_pool_energy_ampmeanstd_all_stats | raw_tensor__spectral_tensor | ridge | 664 | 97.59 | 97.62 | 0.021 | 0.002 |
| moment_pool_energy_ampmeanstd_all_stats | raw_tensor__spectral_log | ridge | 604 | 97.59 | 97.61 | 0.018 | 0.002 |
| moment_pool_energy_ampmeanstd_all_stats | raw_log__spectral_tensor | ridge | 493 | 97.52 | 97.56 | 0.014 | 0.001 |
| moment_pool_energy_ampmeanstd_all_stats | raw_log__spectral_log | ridge | 433 | 97.66 | 97.68 | 0.011 | 0.002 |
| moment_pool_energy_ampmeanstd_energy_meanstd | raw_tensor__spectral_tensor | ridge | 574 | 97.59 | 97.61 | 0.018 | 0.002 |
| moment_pool_energy_ampmeanstd_energy_meanstd | raw_tensor__spectral_log | ridge | 514 | 97.52 | 97.53 | 0.015 | 0.002 |
| moment_pool_energy_ampmeanstd_energy_meanstd | raw_log__spectral_tensor | ridge | 403 | 97.59 | 97.61 | 0.011 | 0.001 |
| moment_pool_energy_ampmeanstd_energy_meanstd | raw_log__spectral_log | ridge | 343 | 97.59 | 97.60 | 0.008 | 0.001 |
| moment_pool_energy_ampmeanstd_gram_meanstd | raw_tensor__spectral_tensor | ridge | 574 | 97.52 | 97.54 | 0.018 | 0.002 |
| moment_pool_energy_ampmeanstd_gram_meanstd | raw_tensor__spectral_log | ridge | 514 | 97.49 | 97.49 | 0.014 | 0.002 |
| moment_pool_energy_ampmeanstd_gram_meanstd | raw_log__spectral_tensor | ridge | 403 | 97.25 | 97.26 | 0.011 | 0.001 |
| moment_pool_energy_ampmeanstd_gram_meanstd | raw_log__spectral_log | ridge | 343 | 97.32 | 97.32 | 0.008 | 0.001 |
| moment_pool_energy_ampmeanstd_lags_meanstd | raw_tensor__spectral_tensor | ridge | 580 | 97.73 | 97.76 | 0.018 | 0.002 |
| moment_pool_energy_ampmeanstd_lags_meanstd | raw_tensor__spectral_log | ridge | 520 | 97.62 | 97.64 | 0.014 | 0.002 |
| moment_pool_energy_ampmeanstd_lags_meanstd | raw_log__spectral_tensor | ridge | 409 | 97.56 | 97.58 | 0.011 | 0.001 |
| moment_pool_energy_ampmeanstd_lags_meanstd | raw_log__spectral_log | ridge | 349 | 97.59 | 97.60 | 0.008 | 0.001 |
| moment_pool_energy_ampmeanstd_gram_lags_meanstd | raw_tensor__spectral_tensor | ridge | 586 | 97.59 | 97.62 | 0.018 | 0.002 |
| moment_pool_energy_ampmeanstd_gram_lags_meanstd | raw_tensor__spectral_log | ridge | 526 | 97.52 | 97.54 | 0.015 | 0.002 |
| moment_pool_energy_ampmeanstd_gram_lags_meanstd | raw_log__spectral_tensor | ridge | 415 | 97.49 | 97.50 | 0.012 | 0.001 |
| moment_pool_energy_ampmeanstd_gram_lags_meanstd | raw_log__spectral_log | ridge | 355 | 97.59 | 97.61 | 0.009 | 0.001 |
| moment_pool_logenergy_ampmeanstd_mean_std | raw_tensor__spectral_tensor | ridge | 592 | 97.59 | 97.61 | 0.018 | 0.002 |
| moment_pool_logenergy_ampmeanstd_mean_std | raw_tensor__spectral_log | ridge | 532 | 97.62 | 97.64 | 0.015 | 0.002 |
| moment_pool_logenergy_ampmeanstd_mean_std | raw_log__spectral_tensor | ridge | 421 | 97.56 | 97.58 | 0.012 | 0.001 |
| moment_pool_logenergy_ampmeanstd_mean_std | raw_log__spectral_log | ridge | 361 | 97.56 | 97.57 | 0.009 | 0.001 |
| moment_pool_logenergy_ampmeanstd_mean_std_skew | raw_tensor__spectral_tensor | ridge | 604 | 97.62 | 97.65 | 0.019 | 0.002 |
| moment_pool_logenergy_ampmeanstd_mean_std_skew | raw_tensor__spectral_log | ridge | 544 | 97.79 | 97.81 | 0.015 | 0.002 |
| moment_pool_logenergy_ampmeanstd_mean_std_skew | raw_log__spectral_tensor | ridge | 433 | 97.69 | 97.72 | 0.012 | 0.001 |
| moment_pool_logenergy_ampmeanstd_mean_std_skew | raw_log__spectral_log | ridge | 373 | 97.79 | 97.81 | 0.009 | 0.001 |
| moment_pool_logenergy_ampmeanstd_mean_std_skew_kurt | raw_tensor__spectral_tensor | ridge | 616 | 97.66 | 97.68 | 0.019 | 0.002 |
| moment_pool_logenergy_ampmeanstd_mean_std_skew_kurt | raw_tensor__spectral_log | ridge | 556 | 97.66 | 97.68 | 0.016 | 0.002 |
| moment_pool_logenergy_ampmeanstd_mean_std_skew_kurt | raw_log__spectral_tensor | ridge | 445 | 97.76 | 97.78 | 0.013 | 0.001 |
| moment_pool_logenergy_ampmeanstd_mean_std_skew_kurt | raw_log__spectral_log | ridge | 385 | 97.73 | 97.74 | 0.010 | 0.001 |
| moment_pool_logenergy_ampmeanstd_mean_std_abs_rms | raw_tensor__spectral_tensor | ridge | 616 | 97.66 | 97.69 | 0.019 | 0.002 |
| moment_pool_logenergy_ampmeanstd_mean_std_abs_rms | raw_tensor__spectral_log | ridge | 556 | 97.56 | 97.57 | 0.016 | 0.002 |
| moment_pool_logenergy_ampmeanstd_mean_std_abs_rms | raw_log__spectral_tensor | ridge | 445 | 97.59 | 97.62 | 0.012 | 0.001 |
| moment_pool_logenergy_ampmeanstd_mean_std_abs_rms | raw_log__spectral_log | ridge | 385 | 97.49 | 97.51 | 0.010 | 0.002 |
| moment_pool_logenergy_ampmeanstd_all_stats | raw_tensor__spectral_tensor | ridge | 664 | 97.59 | 97.61 | 0.021 | 0.002 |
| moment_pool_logenergy_ampmeanstd_all_stats | raw_tensor__spectral_log | ridge | 604 | 97.62 | 97.64 | 0.018 | 0.002 |
| moment_pool_logenergy_ampmeanstd_all_stats | raw_log__spectral_tensor | ridge | 493 | 97.62 | 97.65 | 0.014 | 0.001 |
| moment_pool_logenergy_ampmeanstd_all_stats | raw_log__spectral_log | ridge | 433 | 97.73 | 97.75 | 0.011 | 0.002 |
| moment_pool_logenergy_ampmeanstd_energy_meanstd | raw_tensor__spectral_tensor | ridge | 574 | 97.46 | 97.45 | 0.018 | 0.001 |
| moment_pool_logenergy_ampmeanstd_energy_meanstd | raw_tensor__spectral_log | ridge | 514 | 97.29 | 97.28 | 0.015 | 0.002 |
| moment_pool_logenergy_ampmeanstd_energy_meanstd | raw_log__spectral_tensor | ridge | 403 | 97.52 | 97.53 | 0.011 | 0.001 |
| moment_pool_logenergy_ampmeanstd_energy_meanstd | raw_log__spectral_log | ridge | 343 | 97.46 | 97.45 | 0.008 | 0.001 |
| moment_pool_logenergy_ampmeanstd_gram_meanstd | raw_tensor__spectral_tensor | ridge | 574 | 97.29 | 97.27 | 0.018 | 0.002 |
| moment_pool_logenergy_ampmeanstd_gram_meanstd | raw_tensor__spectral_log | ridge | 514 | 97.22 | 97.20 | 0.014 | 0.002 |
| moment_pool_logenergy_ampmeanstd_gram_meanstd | raw_log__spectral_tensor | ridge | 403 | 97.46 | 97.45 | 0.011 | 0.001 |
| moment_pool_logenergy_ampmeanstd_gram_meanstd | raw_log__spectral_log | ridge | 343 | 97.35 | 97.35 | 0.009 | 0.001 |
| moment_pool_logenergy_ampmeanstd_lags_meanstd | raw_tensor__spectral_tensor | ridge | 580 | 97.76 | 97.79 | 0.018 | 0.002 |
| moment_pool_logenergy_ampmeanstd_lags_meanstd | raw_tensor__spectral_log | ridge | 520 | 97.49 | 97.50 | 0.014 | 0.002 |
| moment_pool_logenergy_ampmeanstd_lags_meanstd | raw_log__spectral_tensor | ridge | 409 | 97.56 | 97.56 | 0.011 | 0.001 |
| moment_pool_logenergy_ampmeanstd_lags_meanstd | raw_log__spectral_log | ridge | 349 | 97.52 | 97.52 | 0.009 | 0.001 |
| moment_pool_logenergy_ampmeanstd_gram_lags_meanstd | raw_tensor__spectral_tensor | ridge | 586 | 97.62 | 97.65 | 0.018 | 0.002 |
| moment_pool_logenergy_ampmeanstd_gram_lags_meanstd | raw_tensor__spectral_log | ridge | 526 | 97.56 | 97.57 | 0.015 | 0.002 |
| moment_pool_logenergy_ampmeanstd_gram_lags_meanstd | raw_log__spectral_tensor | ridge | 415 | 97.59 | 97.61 | 0.011 | 0.001 |
| moment_pool_logenergy_ampmeanstd_gram_lags_meanstd | raw_log__spectral_log | ridge | 355 | 97.42 | 97.43 | 0.009 | 0.001 |
| moment_pool_energy_ampshape_mean_std | raw_tensor__spectral_tensor | ridge | 632 | 97.76 | 97.79 | 0.019 | 0.002 |
| moment_pool_energy_ampshape_mean_std | raw_tensor__spectral_log | ridge | 572 | 97.52 | 97.54 | 0.016 | 0.002 |
| moment_pool_energy_ampshape_mean_std | raw_log__spectral_tensor | ridge | 461 | 97.79 | 97.83 | 0.013 | 0.001 |
| moment_pool_energy_ampshape_mean_std | raw_log__spectral_log | ridge | 401 | 97.76 | 97.80 | 0.010 | 0.002 |
| moment_pool_energy_ampshape_mean_std_skew | raw_tensor__spectral_tensor | ridge | 644 | 97.86 | 97.88 | 0.021 | 0.002 |
| moment_pool_energy_ampshape_mean_std_skew | raw_tensor__spectral_log | ridge | 584 | 97.66 | 97.68 | 0.017 | 0.002 |
| moment_pool_energy_ampshape_mean_std_skew | raw_log__spectral_tensor | ridge | 473 | 97.83 | 97.87 | 0.014 | 0.001 |
| moment_pool_energy_ampshape_mean_std_skew | raw_log__spectral_log | ridge | 413 | 97.90 | 97.93 | 0.010 | 0.002 |
| moment_pool_energy_ampshape_mean_std_skew_kurt | raw_tensor__spectral_tensor | ridge | 656 | 97.86 | 97.89 | 0.021 | 0.002 |
| moment_pool_energy_ampshape_mean_std_skew_kurt | raw_tensor__spectral_log | ridge | 596 | 97.79 | 97.82 | 0.032 | 0.003 |
| moment_pool_energy_ampshape_mean_std_skew_kurt | raw_log__spectral_tensor | ridge | 485 | 97.86 | 97.90 | 0.014 | 0.001 |
| moment_pool_energy_ampshape_mean_std_skew_kurt | raw_log__spectral_log | ridge | 425 | 97.86 | 97.90 | 0.012 | 0.002 |
| moment_pool_energy_ampshape_mean_std_abs_rms | raw_tensor__spectral_tensor | ridge | 656 | 97.73 | 97.76 | 0.021 | 0.002 |
| moment_pool_energy_ampshape_mean_std_abs_rms | raw_tensor__spectral_log | ridge | 596 | 97.59 | 97.62 | 0.018 | 0.002 |
| moment_pool_energy_ampshape_mean_std_abs_rms | raw_log__spectral_tensor | ridge | 485 | 97.76 | 97.79 | 0.015 | 0.001 |
| moment_pool_energy_ampshape_mean_std_abs_rms | raw_log__spectral_log | ridge | 425 | 97.66 | 97.69 | 0.012 | 0.002 |
| moment_pool_energy_ampshape_all_stats | raw_tensor__spectral_tensor | ridge | 704 | 97.79 | 97.82 | 0.024 | 0.002 |
| moment_pool_energy_ampshape_all_stats | raw_tensor__spectral_log | ridge | 644 | 97.79 | 97.82 | 0.020 | 0.002 |
| moment_pool_energy_ampshape_all_stats | raw_log__spectral_tensor | ridge | 533 | 97.76 | 97.80 | 0.016 | 0.001 |
| moment_pool_energy_ampshape_all_stats | raw_log__spectral_log | ridge | 473 | 97.76 | 97.79 | 0.013 | 0.002 |
| moment_pool_energy_ampshape_energy_meanstd | raw_tensor__spectral_tensor | ridge | 614 | 97.62 | 97.63 | 0.020 | 0.002 |
| moment_pool_energy_ampshape_energy_meanstd | raw_tensor__spectral_log | ridge | 554 | 97.42 | 97.43 | 0.016 | 0.002 |
| moment_pool_energy_ampshape_energy_meanstd | raw_log__spectral_tensor | ridge | 443 | 97.66 | 97.68 | 0.013 | 0.001 |
| moment_pool_energy_ampshape_energy_meanstd | raw_log__spectral_log | ridge | 383 | 97.59 | 97.61 | 0.010 | 0.002 |
| moment_pool_energy_ampshape_gram_meanstd | raw_tensor__spectral_tensor | ridge | 614 | 97.69 | 97.72 | 0.019 | 0.002 |
| moment_pool_energy_ampshape_gram_meanstd | raw_tensor__spectral_log | ridge | 554 | 97.49 | 97.50 | 0.016 | 0.002 |
| moment_pool_energy_ampshape_gram_meanstd | raw_log__spectral_tensor | ridge | 443 | 97.52 | 97.53 | 0.013 | 0.001 |
| moment_pool_energy_ampshape_gram_meanstd | raw_log__spectral_log | ridge | 383 | 97.52 | 97.54 | 0.010 | 0.001 |
| moment_pool_energy_ampshape_lags_meanstd | raw_tensor__spectral_tensor | ridge | 620 | 97.79 | 97.82 | 0.020 | 0.002 |
| moment_pool_energy_ampshape_lags_meanstd | raw_tensor__spectral_log | ridge | 560 | 97.56 | 97.57 | 0.016 | 0.002 |
| moment_pool_energy_ampshape_lags_meanstd | raw_log__spectral_tensor | ridge | 449 | 97.76 | 97.79 | 0.013 | 0.001 |
| moment_pool_energy_ampshape_lags_meanstd | raw_log__spectral_log | ridge | 389 | 97.69 | 97.72 | 0.010 | 0.002 |
| moment_pool_energy_ampshape_gram_lags_meanstd | raw_tensor__spectral_tensor | ridge | 626 | 97.76 | 97.79 | 0.020 | 0.002 |
| moment_pool_energy_ampshape_gram_lags_meanstd | raw_tensor__spectral_log | ridge | 566 | 97.56 | 97.58 | 0.016 | 0.002 |
| moment_pool_energy_ampshape_gram_lags_meanstd | raw_log__spectral_tensor | ridge | 455 | 97.69 | 97.72 | 0.013 | 0.001 |
| moment_pool_energy_ampshape_gram_lags_meanstd | raw_log__spectral_log | ridge | 395 | 97.66 | 97.69 | 0.010 | 0.002 |
| small_energy_axes_cosines21 | raw_tensor__spectral_tensor | ridge | 523 | 96.61 | 96.57 | 0.016 | 0.001 |
| small_energy_axes_cosines21 | raw_tensor__spectral_log | ridge | 463 | 96.67 | 96.64 | 0.012 | 0.002 |
| small_energy_axes_cosines21 | raw_tensor__spectral_cross_log | ridge | 733 | 96.98 | 96.96 | 0.023 | 0.003 |
| small_energy_axes_cosines21 | raw_log__spectral_tensor | ridge | 352 | 96.64 | 96.61 | 0.009 | 0.001 |
| small_energy_axes_cosines21 | raw_log__spectral_log | ridge | 292 | 96.64 | 96.60 | 0.007 | 0.001 |
| small_energy_axes_cosines21 | raw_log__spectral_cross_log | ridge | 562 | 96.78 | 96.76 | 0.016 | 0.002 |
| small_energy_axes_cosines_ampmean41 | raw_tensor__spectral_tensor | ridge | 543 | 97.05 | 97.03 | 0.016 | 0.001 |
| small_energy_axes_cosines_ampmean41 | raw_tensor__spectral_log | ridge | 483 | 96.98 | 96.95 | 0.013 | 0.002 |
| small_energy_axes_cosines_ampmean41 | raw_tensor__spectral_cross_log | ridge | 753 | 97.18 | 97.15 | 0.025 | 0.003 |
| small_energy_axes_cosines_ampmean41 | raw_log__spectral_tensor | ridge | 372 | 96.98 | 96.95 | 0.010 | 0.001 |
| small_energy_axes_cosines_ampmean41 | raw_log__spectral_log | ridge | 312 | 97.12 | 97.08 | 0.007 | 0.001 |
| small_energy_axes_cosines_ampmean41 | raw_log__spectral_cross_log | ridge | 582 | 97.08 | 97.06 | 0.017 | 0.002 |
| small_energy_mean_cosines23 | raw_tensor__spectral_tensor | ridge | 525 | 95.22 | 95.26 | 0.016 | 0.001 |
| small_energy_mean_cosines23 | raw_tensor__spectral_log | ridge | 465 | 94.81 | 94.84 | 0.012 | 0.002 |
| small_energy_mean_cosines23 | raw_tensor__spectral_cross_log | ridge | 735 | 95.89 | 95.90 | 0.024 | 0.003 |
| small_energy_mean_cosines23 | raw_log__spectral_tensor | ridge | 354 | 95.18 | 95.21 | 0.010 | 0.001 |
| small_energy_mean_cosines23 | raw_log__spectral_log | ridge | 294 | 94.81 | 94.83 | 0.007 | 0.001 |
| small_energy_mean_cosines23 | raw_log__spectral_cross_log | ridge | 564 | 95.89 | 95.90 | 0.016 | 0.002 |
| lift_cosine_moments6 | raw_tensor__spectral_tensor | ridge | 508 | 95.45 | 95.38 | 0.016 | 0.001 |
| lift_cosine_moments6 | raw_tensor__spectral_log | ridge | 448 | 95.39 | 95.31 | 0.012 | 0.002 |
| lift_cosine_moments6 | raw_tensor__spectral_cross_log | ridge | 718 | 96.10 | 96.05 | 0.024 | 0.003 |
| lift_cosine_moments6 | raw_log__spectral_tensor | ridge | 337 | 95.01 | 94.93 | 0.009 | 0.001 |
| lift_cosine_moments6 | raw_log__spectral_log | ridge | 277 | 95.11 | 95.03 | 0.007 | 0.001 |
| lift_cosine_moments6 | raw_log__spectral_cross_log | ridge | 547 | 95.79 | 95.74 | 0.016 | 0.002 |
| lift_energy_cosine_moments12 | raw_tensor__spectral_tensor | ridge | 514 | 96.00 | 95.97 | 0.016 | 0.001 |
| lift_energy_cosine_moments12 | raw_tensor__spectral_log | ridge | 454 | 95.89 | 95.86 | 0.013 | 0.002 |
| lift_energy_cosine_moments12 | raw_tensor__spectral_cross_log | ridge | 724 | 96.30 | 96.26 | 0.024 | 0.003 |
| lift_energy_cosine_moments12 | raw_log__spectral_tensor | ridge | 343 | 95.52 | 95.48 | 0.010 | 0.001 |
| lift_energy_cosine_moments12 | raw_log__spectral_log | ridge | 283 | 95.66 | 95.61 | 0.007 | 0.001 |
| lift_energy_cosine_moments12 | raw_log__spectral_cross_log | ridge | 553 | 96.03 | 96.00 | 0.016 | 0.002 |
| lift_energy_gram_cosine_moments18 | raw_tensor__spectral_tensor | ridge | 520 | 96.30 | 96.28 | 0.016 | 0.001 |
| lift_energy_gram_cosine_moments18 | raw_tensor__spectral_log | ridge | 460 | 96.13 | 96.10 | 0.013 | 0.002 |
| lift_energy_gram_cosine_moments18 | raw_tensor__spectral_cross_log | ridge | 730 | 96.67 | 96.65 | 0.024 | 0.003 |
| lift_energy_gram_cosine_moments18 | raw_log__spectral_tensor | ridge | 349 | 96.27 | 96.25 | 0.010 | 0.001 |
| lift_energy_gram_cosine_moments18 | raw_log__spectral_log | ridge | 289 | 96.30 | 96.27 | 0.007 | 0.001 |
| lift_energy_gram_cosine_moments18 | raw_log__spectral_cross_log | ridge | 559 | 96.61 | 96.59 | 0.017 | 0.002 |
| lift_energy_cosine_meanstd12 | raw_tensor__spectral_tensor | ridge | 514 | 96.47 | 96.43 | 0.016 | 0.001 |
| lift_energy_cosine_meanstd12 | raw_tensor__spectral_log | ridge | 454 | 96.47 | 96.41 | 0.013 | 0.002 |
| lift_energy_cosine_meanstd12 | raw_tensor__spectral_cross_log | ridge | 724 | 96.67 | 96.63 | 0.024 | 0.003 |
| lift_energy_cosine_meanstd12 | raw_log__spectral_tensor | ridge | 343 | 96.27 | 96.23 | 0.010 | 0.001 |
| lift_energy_cosine_meanstd12 | raw_log__spectral_log | ridge | 283 | 96.37 | 96.32 | 0.007 | 0.001 |
| lift_energy_cosine_meanstd12 | raw_log__spectral_cross_log | ridge | 553 | 96.34 | 96.31 | 0.016 | 0.002 |
| lift_spectral_energy_cosine_moments26 | raw_tensor__spectral_tensor | ridge | 528 | 96.34 | 96.32 | 0.016 | 0.001 |
| lift_spectral_energy_cosine_moments26 | raw_tensor__spectral_log | ridge | 468 | 96.13 | 96.11 | 0.013 | 0.002 |
| lift_spectral_energy_cosine_moments26 | raw_tensor__spectral_cross_log | ridge | 738 | 96.64 | 96.62 | 0.025 | 0.003 |
| lift_spectral_energy_cosine_moments26 | raw_log__spectral_tensor | ridge | 357 | 96.10 | 96.08 | 0.010 | 0.001 |
| lift_spectral_energy_cosine_moments26 | raw_log__spectral_log | ridge | 297 | 96.10 | 96.07 | 0.008 | 0.001 |
| lift_spectral_energy_cosine_moments26 | raw_log__spectral_cross_log | ridge | 567 | 96.57 | 96.56 | 0.017 | 0.002 |
| lift_spectral_energy_cosine_ampmoments86 | raw_tensor__spectral_tensor | ridge | 588 | 96.74 | 96.74 | 0.019 | 0.002 |
| lift_spectral_energy_cosine_ampmoments86 | raw_tensor__spectral_log | ridge | 528 | 96.64 | 96.64 | 0.015 | 0.002 |
| lift_spectral_energy_cosine_ampmoments86 | raw_tensor__spectral_cross_log | ridge | 798 | 97.25 | 97.25 | 0.028 | 0.003 |
| lift_spectral_energy_cosine_ampmoments86 | raw_log__spectral_tensor | ridge | 417 | 96.37 | 96.35 | 0.012 | 0.001 |
| lift_spectral_energy_cosine_ampmoments86 | raw_log__spectral_log | ridge | 357 | 96.13 | 96.11 | 0.009 | 0.002 |
| lift_spectral_energy_cosine_ampmoments86 | raw_log__spectral_cross_log | ridge | 627 | 96.91 | 96.89 | 0.020 | 0.002 |
| lift_spectral_ampmoments_cosine86 | raw_tensor__spectral_tensor | ridge | 588 | 96.74 | 96.74 | 0.019 | 0.002 |
| lift_spectral_ampmoments_cosine86 | raw_tensor__spectral_log | ridge | 528 | 96.64 | 96.64 | 0.016 | 0.002 |
| lift_spectral_ampmoments_cosine86 | raw_tensor__spectral_cross_log | ridge | 798 | 97.25 | 97.25 | 0.028 | 0.003 |
| lift_spectral_ampmoments_cosine86 | raw_log__spectral_tensor | ridge | 417 | 96.37 | 96.35 | 0.012 | 0.001 |
| lift_spectral_ampmoments_cosine86 | raw_log__spectral_log | ridge | 357 | 96.13 | 96.11 | 0.009 | 0.001 |
| lift_spectral_ampmoments_cosine86 | raw_log__spectral_cross_log | ridge | 627 | 96.91 | 96.89 | 0.020 | 0.002 |
| lift_energy_cosine_concentration72 | raw_tensor__spectral_tensor | ridge | 574 | 96.57 | 96.55 | 0.018 | 0.002 |
| lift_energy_cosine_concentration72 | raw_tensor__spectral_log | ridge | 514 | 96.47 | 96.44 | 0.015 | 0.002 |
| lift_energy_cosine_concentration72 | raw_tensor__spectral_cross_log | ridge | 784 | 96.74 | 96.71 | 0.027 | 0.003 |
| lift_energy_cosine_concentration72 | raw_log__spectral_tensor | ridge | 403 | 96.27 | 96.23 | 0.011 | 0.001 |
| lift_energy_cosine_concentration72 | raw_log__spectral_log | ridge | 343 | 96.17 | 96.13 | 0.009 | 0.002 |
| lift_energy_cosine_concentration72 | raw_log__spectral_cross_log | ridge | 613 | 96.47 | 96.45 | 0.019 | 0.002 |
| lift_spectral_energy_cosine_concentration86 | raw_tensor__spectral_tensor | ridge | 588 | 96.67 | 96.67 | 0.019 | 0.002 |
| lift_spectral_energy_cosine_concentration86 | raw_tensor__spectral_log | ridge | 528 | 96.71 | 96.70 | 0.015 | 0.002 |
| lift_spectral_energy_cosine_concentration86 | raw_tensor__spectral_cross_log | ridge | 798 | 97.01 | 97.01 | 0.028 | 0.003 |
| lift_spectral_energy_cosine_concentration86 | raw_log__spectral_tensor | ridge | 417 | 96.67 | 96.67 | 0.012 | 0.001 |
| lift_spectral_energy_cosine_concentration86 | raw_log__spectral_log | ridge | 357 | 96.64 | 96.63 | 0.010 | 0.002 |
| lift_spectral_energy_cosine_concentration86 | raw_log__spectral_cross_log | ridge | 627 | 97.01 | 97.02 | 0.020 | 0.002 |
| lift_spectral_energy_cosine_std_concentration86 | raw_tensor__spectral_tensor | ridge | 588 | 97.05 | 97.03 | 0.019 | 0.002 |
| lift_spectral_energy_cosine_std_concentration86 | raw_tensor__spectral_log | ridge | 528 | 96.98 | 96.94 | 0.015 | 0.002 |
| lift_spectral_energy_cosine_std_concentration86 | raw_tensor__spectral_cross_log | ridge | 798 | 97.32 | 97.31 | 0.028 | 0.003 |
| lift_spectral_energy_cosine_std_concentration86 | raw_log__spectral_tensor | ridge | 417 | 97.25 | 97.23 | 0.012 | 0.001 |
| lift_spectral_energy_cosine_std_concentration86 | raw_log__spectral_log | ridge | 357 | 97.15 | 97.13 | 0.009 | 0.001 |
| lift_spectral_energy_cosine_std_concentration86 | raw_log__spectral_cross_log | ridge | 627 | 97.42 | 97.42 | 0.020 | 0.002 |
| lift_log_energy_cosine_std_concentration86 | raw_tensor__spectral_tensor | ridge | 588 | 97.12 | 97.09 | 0.019 | 0.002 |
| lift_log_energy_cosine_std_concentration86 | raw_tensor__spectral_log | ridge | 528 | 97.05 | 97.01 | 0.015 | 0.002 |
| lift_log_energy_cosine_std_concentration86 | raw_tensor__spectral_cross_log | ridge | 798 | 97.25 | 97.23 | 0.028 | 0.003 |
| lift_log_energy_cosine_std_concentration86 | raw_log__spectral_tensor | ridge | 417 | 97.39 | 97.38 | 0.012 | 0.001 |
| lift_log_energy_cosine_std_concentration86 | raw_log__spectral_log | ridge | 357 | 97.29 | 97.27 | 0.009 | 0.001 |
| lift_log_energy_cosine_std_concentration86 | raw_log__spectral_cross_log | ridge | 627 | 97.32 | 97.30 | 0.019 | 0.002 |
| lift_energy_cosine_pascal_first18 | raw_tensor__spectral_tensor | ridge | 520 | 94.88 | 94.88 | 0.016 | 0.001 |
| lift_energy_cosine_pascal_first18 | raw_tensor__spectral_log | ridge | 460 | 94.60 | 94.62 | 0.013 | 0.002 |
| lift_energy_cosine_pascal_first18 | raw_tensor__spectral_cross_log | ridge | 730 | 95.59 | 95.58 | 0.024 | 0.003 |
| lift_energy_cosine_pascal_first18 | raw_log__spectral_tensor | ridge | 349 | 94.47 | 94.49 | 0.010 | 0.001 |
| lift_energy_cosine_pascal_first18 | raw_log__spectral_log | ridge | 289 | 94.23 | 94.26 | 0.007 | 0.001 |
| lift_energy_cosine_pascal_first18 | raw_log__spectral_cross_log | ridge | 559 | 95.25 | 95.26 | 0.017 | 0.002 |
| lift_energy_cosine_pascal_log36 | raw_tensor__spectral_tensor | ridge | 538 | 95.18 | 95.18 | 0.017 | 0.002 |
| lift_energy_cosine_pascal_log36 | raw_tensor__spectral_log | ridge | 478 | 95.25 | 95.25 | 0.013 | 0.002 |
| lift_energy_cosine_pascal_log36 | raw_tensor__spectral_cross_log | ridge | 748 | 95.52 | 95.50 | 0.026 | 0.003 |
| lift_energy_cosine_pascal_log36 | raw_log__spectral_tensor | ridge | 367 | 94.57 | 94.56 | 0.010 | 0.001 |
| lift_energy_cosine_pascal_log36 | raw_log__spectral_log | ridge | 307 | 94.64 | 94.61 | 0.008 | 0.001 |
| lift_energy_cosine_pascal_log36 | raw_log__spectral_cross_log | ridge | 577 | 95.28 | 95.27 | 0.018 | 0.003 |
| lift_spectral_energy_pascal_log56 | raw_tensor__spectral_tensor | ridge | 558 | 95.55 | 95.57 | 0.017 | 0.001 |
| lift_spectral_energy_pascal_log56 | raw_tensor__spectral_log | ridge | 498 | 95.32 | 95.33 | 0.014 | 0.002 |
| lift_spectral_energy_pascal_log56 | raw_tensor__spectral_cross_log | ridge | 768 | 95.96 | 95.97 | 0.027 | 0.003 |
| lift_spectral_energy_pascal_log56 | raw_log__spectral_tensor | ridge | 387 | 95.52 | 95.53 | 0.011 | 0.001 |
| lift_spectral_energy_pascal_log56 | raw_log__spectral_log | ridge | 327 | 95.35 | 95.36 | 0.008 | 0.001 |
| lift_spectral_energy_pascal_log56 | raw_log__spectral_cross_log | ridge | 597 | 95.86 | 95.86 | 0.018 | 0.003 |
| lift_spectral_energy_concentration_pascal_log116 | raw_tensor__spectral_tensor | ridge | 618 | 95.76 | 95.78 | 0.020 | 0.002 |
| lift_spectral_energy_concentration_pascal_log116 | raw_tensor__spectral_log | ridge | 558 | 95.69 | 95.71 | 0.016 | 0.002 |
| lift_spectral_energy_concentration_pascal_log116 | raw_tensor__spectral_cross_log | ridge | 828 | 96.23 | 96.26 | 0.029 | 0.003 |
| lift_spectral_energy_concentration_pascal_log116 | raw_log__spectral_tensor | ridge | 447 | 95.86 | 95.87 | 0.013 | 0.001 |
| lift_spectral_energy_concentration_pascal_log116 | raw_log__spectral_log | ridge | 387 | 95.72 | 95.74 | 0.010 | 0.002 |
| lift_spectral_energy_concentration_pascal_log116 | raw_log__spectral_cross_log | ridge | 657 | 96.20 | 96.21 | 0.021 | 0.003 |
| lift_profile142 | raw_tensor__spectral_tensor | ridge | 644 | 97.86 | 97.88 | 0.021 | 0.002 |
| lift_profile142 | raw_tensor__spectral_log | ridge | 584 | 97.66 | 97.68 | 0.017 | 0.002 |
| lift_profile142 | raw_tensor__spectral_cross_log | ridge | 854 | 98.00 | 98.03 | 0.031 | 0.003 |
| lift_profile142 | raw_log__spectral_tensor | ridge | 473 | 97.83 | 97.87 | 0.014 | 0.001 |
| lift_profile142 | raw_log__spectral_log | ridge | 413 | 97.90 | 97.93 | 0.011 | 0.002 |
| lift_profile142 | raw_log__spectral_cross_log | ridge | 683 | 98.00 | 98.02 | 0.023 | 0.003 |
| lift_profile102 | raw_tensor__spectral_tensor | ridge | 604 | 97.62 | 97.65 | 0.019 | 0.002 |
| lift_profile102 | raw_tensor__spectral_log | ridge | 544 | 97.79 | 97.81 | 0.016 | 0.002 |
| lift_profile102 | raw_tensor__spectral_cross_log | ridge | 814 | 97.76 | 97.79 | 0.028 | 0.003 |
| lift_profile102 | raw_log__spectral_tensor | ridge | 433 | 97.69 | 97.72 | 0.013 | 0.001 |
| lift_profile102 | raw_log__spectral_log | ridge | 373 | 97.79 | 97.81 | 0.010 | 0.002 |
| lift_profile102 | raw_log__spectral_cross_log | ridge | 643 | 97.96 | 97.99 | 0.022 | 0.002 |
| lift_profile66 | raw_tensor__spectral_tensor | ridge | 568 | 97.42 | 97.43 | 0.018 | 0.002 |
| lift_profile66 | raw_tensor__spectral_log | ridge | 508 | 97.35 | 97.34 | 0.015 | 0.002 |
| lift_profile66 | raw_tensor__spectral_cross_log | ridge | 778 | 97.59 | 97.61 | 0.026 | 0.003 |
| lift_profile66 | raw_log__spectral_tensor | ridge | 397 | 97.49 | 97.50 | 0.011 | 0.001 |
| lift_profile66 | raw_log__spectral_log | ridge | 337 | 97.56 | 97.57 | 0.008 | 0.001 |
| lift_profile66 | raw_log__spectral_cross_log | ridge | 607 | 97.56 | 97.57 | 0.018 | 0.003 |
| lift_energy_cosine_concentration_q05 | raw_tensor__spectral_tensor | ridge | 548 | 96.95 | 96.92 | 0.016 | 0.001 |
| lift_energy_cosine_concentration_q05 | raw_tensor__spectral_log | ridge | 488 | 96.91 | 96.88 | 0.013 | 0.002 |
| lift_energy_cosine_concentration_q05 | raw_tensor__spectral_cross_log | ridge | 758 | 97.12 | 97.10 | 0.025 | 0.003 |
| lift_energy_cosine_concentration_q05 | raw_log__spectral_tensor | ridge | 377 | 97.01 | 97.00 | 0.010 | 0.001 |
| lift_energy_cosine_concentration_q05 | raw_log__spectral_log | ridge | 317 | 96.91 | 96.89 | 0.008 | 0.001 |
| lift_energy_cosine_concentration_q05 | raw_log__spectral_cross_log | ridge | 587 | 97.32 | 97.32 | 0.017 | 0.002 |
| lift_energy_cosine_concentration_q15 | raw_tensor__spectral_tensor | ridge | 548 | 96.78 | 96.75 | 0.017 | 0.001 |
| lift_energy_cosine_concentration_q15 | raw_tensor__spectral_log | ridge | 488 | 96.78 | 96.73 | 0.013 | 0.002 |
| lift_energy_cosine_concentration_q15 | raw_tensor__spectral_cross_log | ridge | 758 | 97.32 | 97.30 | 0.025 | 0.003 |
| lift_energy_cosine_concentration_q15 | raw_log__spectral_tensor | ridge | 377 | 96.91 | 96.89 | 0.010 | 0.001 |
| lift_energy_cosine_concentration_q15 | raw_log__spectral_log | ridge | 317 | 96.91 | 96.89 | 0.007 | 0.001 |
| lift_energy_cosine_concentration_q15 | raw_log__spectral_cross_log | ridge | 587 | 97.39 | 97.38 | 0.017 | 0.002 |
| lift_energy_cosine_concentration_q2 | raw_tensor__spectral_tensor | ridge | 548 | 96.74 | 96.71 | 0.016 | 0.001 |
| lift_energy_cosine_concentration_q2 | raw_tensor__spectral_log | ridge | 488 | 96.78 | 96.73 | 0.013 | 0.002 |
| lift_energy_cosine_concentration_q2 | raw_tensor__spectral_cross_log | ridge | 758 | 97.29 | 97.27 | 0.025 | 0.003 |
| lift_energy_cosine_concentration_q2 | raw_log__spectral_tensor | ridge | 377 | 96.81 | 96.78 | 0.010 | 0.001 |
| lift_energy_cosine_concentration_q2 | raw_log__spectral_log | ridge | 317 | 96.81 | 96.77 | 0.008 | 0.001 |
| lift_energy_cosine_concentration_q2 | raw_log__spectral_cross_log | ridge | 587 | 97.29 | 97.27 | 0.017 | 0.002 |
