"""Small observable-integral readouts accompanying raw and spectral signatures.

Polynomial moments are level-one coordinates after lifting observations to
``(z, z**2, ...)`` and integrating. Standard deviation and standardized shape
also use window centering/normalization; they are not linear readouts of the
untransformed signature. All integral coordinates below are evaluated by
tensorsig, with the constant QR code's normalization explicitly removed.
"""

from time import perf_counter

import numpy as np
import torch
from families import _power, _with_norm
from generators import coded_integration, temporal_code


def _means(observations: torch.Tensor, batch_size: int) -> np.ndarray:
    """Recover observation means from QR P1, depth-one signature endpoints."""
    values, _ = coded_integration(observations, 1, 1, batch_size=batch_size)
    constant = float(temporal_code(observations.shape[1], 1).matrix[0, 0])
    return values.astype(np.float64) / constant


def _cosines(energy: torch.Tensor, dots: torch.Tensor) -> torch.Tensor:
    norms = energy.sqrt()
    denominator = torch.stack([norms[:, :, i] * norms[:, :, j]
                               for i, j in ((0, 1), (0, 2), (1, 2))], 2)
    return dots / denominator.clamp_min(1e-12)


@torch.inference_mode()
def build_lifts(signals, n_train: int, families: dict, batch_size: int = 256):
    """Return named small arrays and generation metadata for a prepared dataset.

    ``families`` must be the output of ``families.build_families(signals,
    n_train)``. Reusing its observations gives exactly the existing scaling:
    one uncentered training RMS per triad for rotation contractions, and
    training-global axis mean/std before computing spectra. Spectral channels
    retain the existing group-major, then xyz/norm order.

    ``metadata['blocks'][name]['extract_s']`` times its shared integral
    calculation, excluding prepared families and shared cosine construction.
    ``preparation_s`` includes this entire function. Block timings overlap.
    """
    if not 1 <= n_train <= len(signals):
        raise ValueError("Expected a nonempty training prefix")
    start = perf_counter()
    blocks, descriptions, timings = {}, {}, {}

    def add(name, values, description, elapsed):
        if len(values) != len(signals) or not np.isfinite(values).all():
            raise ValueError(f"Invalid observable-integral block: {name}")
        blocks[name] = values
        descriptions[name] = description
        timings[name] = elapsed

    energy, dots = families["rotation"]["observations"][:2]
    cosines = _cosines(energy, dots)
    for label, observations in (("energy", energy), ("gram", dots), ("cosine", cosines)):
        tick = perf_counter()
        centered = observations - observations.mean(1, keepdim=True)
        values = _means(torch.cat((observations, observations.square(), centered.square()), 2), batch_size)
        first, second, variance = np.split(values, 3, axis=1)
        elapsed = perf_counter() - tick
        add(label + "_mean", first, "Mean of " + label + " observations; constant-code endpoint", elapsed)
        add(label + "_second", second, "Raw second moment of " + label + "; squared-observable endpoint", elapsed)
        add(label + "_std", np.sqrt(np.maximum(variance, 0)),
            "Standard deviation of " + label + "; square root of centered-square endpoint", elapsed)

    tick = perf_counter()
    invariant_groups = []
    for observations in families["rotation"]["observations"]:
        centered = observations - observations.mean(1, keepdim=True)
        variance = centered.square().mean(1, keepdim=True)
        z = centered / variance.sqrt().clamp_min(1e-8)
        active = variance > 1e-12
        values = np.split(_means(torch.cat((observations, centered.square(),
                                           torch.where(active, z.pow(3), 0.),
                                           torch.where(active, z.pow(4), 0.)), 2), batch_size), 4, axis=1)
        values[1] = np.sqrt(np.maximum(values[1], 0))
        invariant_groups.append(values)
    elapsed = perf_counter() - tick
    for name, count in (("mean_std", 2), ("mean_std_skew", 3), ("mean_std_skew_kurt", 4)):
        add("invariant_" + name, np.concatenate([np.concatenate(values[:count], 1)
                                                 for values in invariant_groups], 1),
            "Energy, cross-triad Gram and lag-2/5 Gram streams: " + name.replace("_", "/") +
            "; P1 endpoints of centered/standardized observables, with square root for std", elapsed)

    tick = perf_counter()
    triads = families["moments"]["observations"]
    triad_values = [_means(observation, batch_size) for observation in triads]
    elapsed = perf_counter() - tick
    add("triad_mean", np.concatenate([value[:, :3] for value in triad_values], 1),
        "Body acceleration, gravity and gyro means after training axis scaling", elapsed)
    add("triad_second", np.concatenate([value[:, 3:] for value in triad_values], 1),
        "Body acceleration, gravity and gyro raw second moments after training axis scaling", elapsed)

    tick = perf_counter()
    # These are precisely the pre-FFT observations in build_families: the
    # first three groups are raw triads and the last two are first differences.
    spectral_vectors = [observation[:, :, :3] for observation in triads]
    spectral_vectors += [observation[:, :, :3]
                         for observation in families["filters_delays"]["observations"][:2]]
    spectral_values = {key: [] for key in ("mean", "second", "third", "fourth", "std", "skew", "kurtosis")}
    energies = []
    for vector in spectral_vectors:
        power = _power(_with_norm(vector))
        amplitude = power.sqrt()
        centered = amplitude - amplitude.mean(1, keepdim=True)
        variance = centered.square().mean(1, keepdim=True)
        z = centered / variance.sqrt().clamp_min(1e-8)
        active = variance > 1e-12
        lifted = torch.cat((amplitude, amplitude.square(), amplitude.pow(3), amplitude.pow(4),
                            centered.square(), torch.where(active, z.pow(3), 0.),
                            torch.where(active, z.pow(4), 0.)), 2)
        values = np.split(_means(lifted, batch_size), 7, axis=1)
        values[4] = np.sqrt(np.maximum(values[4], 0))
        for key, value in zip(spectral_values, values):
            spectral_values[key].append(value)
        # Mean amplitude-square times the number of bins is Parseval energy.
        energies.append(values[1] * power.shape[1])
    elapsed = perf_counter() - tick
    for name, values in spectral_values.items():
        detail = ("Raw amplitude moment" if name in ("mean", "second", "third", "fourth") else
                  "Window-centered amplitude " + name)
        add("spectral_amplitude_" + name, np.concatenate(values, 1),
            detail + ("; square root of centered-square endpoint" if name == "std" else
                      "; level-one signature after the stated observable transform"), elapsed)
    energy_values = np.concatenate(energies, 1)
    add("spectral_energy", energy_values, "Parseval energy from amplitude-square endpoints", elapsed)
    add("spectral_log_energy", np.log1p(energy_values),
        "log1p of Parseval energy; nonlinear endpoint readout, not a linear signature coordinate", elapsed)

    tick = perf_counter()
    concentrations = {"q05": [], "q15": [], "q2": []}
    for observation in families["spectral"]["observations"]:
        length = observation.shape[1]
        mass = observation / length
        values = np.split(_means(torch.cat([mass.pow(q) for q in (.5, 1.5, 2)], 2),
                                 batch_size) * length, 3, axis=1)
        for key, value in zip(concentrations, values):
            concentrations[key].append(value)
    elapsed = perf_counter() - tick
    for (name, values), q in zip(concentrations.items(), (.5, 1.5, 2)):
        add("concentration_" + name, np.concatenate(values, 1),
            f"Sum of normalized spectral bin masses raised to {q}" +
            "; power-observable integral, independent of the location of bins", elapsed)
    add("concentration", np.concatenate([blocks["concentration_" + key] for key in concentrations], 1),
        "Spectral concentration sums for q=0.5, 1.5, 2; q=1 is constant and omitted", elapsed)

    tick = perf_counter()
    observations = torch.cat((energy, cosines), 2)
    values, _ = coded_integration(observations, 3, 2, batch_size=batch_size)
    width = observations.shape[2] * 3
    first, second = values[:, :width], values[:, width:].reshape(-1, width, width)
    areas = []
    i, j = np.triu_indices(3, 1)
    for channel in range(observations.shape[2]):
        indices = slice(channel * 3, (channel + 1) * 3)
        tensor = second[:, indices, indices]
        areas.append((tensor[:, i, j] - tensor[:, j, i]) / np.sqrt(2))
    elapsed = perf_counter() - tick
    add("energy_cosine_pascal_P3_first", first,
        "Three QR polynomial time moments of three energy and three cross-cosine streams", elapsed)
    add("energy_cosine_pascal_P3_log", np.concatenate((first, *areas), 1),
        "Within-stream P3 depth-two logsignature: endpoints and orthonormal antisymmetric areas", elapsed)

    return blocks, {
        "preparation_s": perf_counter() - start,
        "blocks": {name: {"features": values.shape[1], "extract_s": timings[name],
                          "description": descriptions[name]} for name, values in blocks.items()},
        "normalization": "P1 endpoints divided by their actual constant QR code value to recover means",
        "timings": "Block times overlap; all pre-existing family construction is excluded",
    }


def self_check() -> None:
    """Verify integral identities, compatibility with pooling, and invariance."""
    from families import build_families

    generator = torch.Generator().manual_seed(928)
    observations = torch.randn(7, 19, 4, generator=generator, dtype=torch.float64)
    np.testing.assert_allclose(_means(observations, 3), observations.mean(1).numpy(),
                               atol=2e-7, rtol=2e-6)
    signals = torch.randn(7, 32, 9, generator=generator, dtype=torch.float64)
    families = build_families(signals, 4)
    blocks, _ = build_lifts(signals, 4, families, 3)
    expected = families["rotation"]["pooled"]
    np.testing.assert_allclose(blocks["cosine_mean"], expected[:, 96:99], atol=2e-7)
    np.testing.assert_allclose(blocks["cosine_std"], expected[:, 99:102], atol=2e-7)
    invariant_summary = expected[:, :96].reshape(7, 4, 8, 3)
    for name, indices in (("mean_std", [0, 1]), ("mean_std_skew", [0, 1, 4]),
                          ("mean_std_skew_kurt", [0, 1, 4, 5])):
        np.testing.assert_allclose(blocks["invariant_" + name],
                                   invariant_summary[:, :, indices].reshape(7, -1),
                                   atol=2e-6, rtol=2e-6)
    spectral = families["spectral"]["pooled"].reshape(7, 5, 18, 4)
    for name, index in (("mean", 0), ("std", 1), ("skew", 2), ("kurtosis", 3)):
        np.testing.assert_allclose(blocks["spectral_amplitude_" + name],
                                   spectral[:, :, index].reshape(7, -1), rtol=2e-6, atol=2e-6)
    np.testing.assert_allclose(blocks["spectral_energy"], spectral[:, :, 4].reshape(7, -1),
                               rtol=2e-6, atol=2e-6)
    for name, q in (("q05", .5), ("q15", 1.5), ("q2", 2)):
        expected = torch.cat([(observation / observation.shape[1]).pow(q).sum(1)
                              for observation in families["spectral"]["observations"]], 1).numpy()
        np.testing.assert_allclose(blocks["concentration_" + name], expected,
                                   rtol=2e-6, atol=2e-6)
    rotation, _ = torch.linalg.qr(torch.randn(3, 3, generator=generator, dtype=torch.float64))
    rotated = (signals.reshape(7, 32, 3, 3) @ rotation).reshape_as(signals)
    rotated_families = build_families(rotated, 4)
    invariant, _ = build_lifts(rotated, 4, rotated_families, 3)
    for name in blocks:
        if name.startswith(("energy_", "gram_", "cosine_", "invariant_")):
            np.testing.assert_allclose(blocks[name], invariant[name], rtol=2e-6, atol=2e-6)
    zero = torch.zeros_like(signals)
    zero_blocks, _ = build_lifts(zero, 4, build_families(zero, 4), 3)
    assert all(np.isfinite(value).all() for value in zero_blocks.values())


if __name__ == "__main__":
    torch.set_num_threads(1)
    self_check()
    print("Observable-integral lift checks passed.")
