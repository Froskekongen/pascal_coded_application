# UCI HAR exploratory results

7,352 training / 2,947 test windows; official subject-disjoint split, fixed classifier settings, exploratory feature comparisons.

Accuracy and macro F1 are percentages. Times are seconds on this machine. Extraction includes train and test, with full calculations shared across readouts; do not sum extraction columns across heads or claim sparse quotient acceleration. The 561-feature extraction time is unmeasured (CSV placeholder 0); hybrid timings measure only the additional features.

## Best row per input/augmentation and head

These are descriptive test-set maxima over representations, not validation-selected models.

| Input / augmentation | Head | Representation | Features | Accuracy | Macro F1 | Extract | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|---:|
| engineered_561 | ridge | uci_features | 561 | 95.72 | 95.85 | 0.000 | 0.046 | 0.004 |
| total_basepoint | ridge | ordinary_full_signature | 56 | 75.57 | 75.49 | 0.173 | 0.004 | 0.000 |
| 561_plus_total_basepoint | ridge | ordinary_full_signature | 617 | 97.05 | 97.07 | 0.173 | 0.031 | 0.003 |
| generator_identity | ridge | fourier_pascal_qr_P2_depth2 | 930 | 89.68 | 89.86 | 0.654 | 0.056 | 0.004 |
| 561_plus_generator_identity | ridge | pascal_qr_P3_depth2 | 903 | 97.12 | 97.16 | 3.698 | 0.053 | 0.003 |
| generator_difference | ridge | pascal_qr_P3_depth2 | 342 | 62.40 | 61.14 | 0.353 | 0.018 | 0.001 |
| 561_plus_generator_difference | ridge | pascal_qr_P1_depth2 | 603 | 96.10 | 96.22 | 0.162 | 0.029 | 0.003 |
| generator_energy | ridge | pascal_qr_P3_depth2 | 342 | 69.19 | 67.17 | 0.348 | 0.017 | 0.001 |
| 561_plus_generator_energy | ridge | pascal_qr_P3_depth1 | 579 | 95.79 | 95.92 | 0.348 | 0.039 | 0.002 |
| generator_lag_product | ridge | pascal_qr_P3_depth2 | 342 | 69.83 | 68.01 | 0.338 | 0.014 | 0.001 |
| 561_plus_generator_lag_product | ridge | pascal_qr_P3_depth1 | 579 | 95.83 | 95.96 | 0.338 | 0.026 | 0.003 |
| generator_spectral_power | ridge | pascal_qr_P3_depth2 | 342 | 78.01 | 75.67 | 0.220 | 0.015 | 0.002 |
| 561_plus_generator_spectral_power | ridge | pascal_qr_P3_depth1 | 579 | 96.10 | 96.23 | 0.220 | 0.030 | 0.003 |

## Every comparison

| Input / augmentation | Representation | Head | Features | Accuracy | Macro F1 | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|
| engineered_561 | uci_features | ridge | 561 | 95.72 | 95.85 | 0.046 | 0.004 |
| total_basepoint | ordinary_full_signature | ridge | 56 | 75.57 | 75.49 | 0.004 | 0.000 |
| 561_plus_total_basepoint | ordinary_full_signature | ridge | 617 | 97.05 | 97.07 | 0.031 | 0.003 |
| generator_identity | pascal_qr_P3_depth1 | ridge | 18 | 55.24 | 50.02 | 0.003 | 0.000 |
| 561_plus_generator_identity | pascal_qr_P3_depth1 | ridge | 579 | 96.00 | 96.13 | 0.028 | 0.002 |
| generator_identity | pascal_qr_P3_depth2 | ridge | 342 | 84.22 | 84.33 | 0.014 | 0.001 |
| 561_plus_generator_identity | pascal_qr_P3_depth2 | ridge | 903 | 97.12 | 97.16 | 0.053 | 0.003 |
| generator_identity | pascal_qr_P3_depth3 | ridge | 6174 | 85.82 | 86.01 | 1.704 | 0.044 |
| 561_plus_generator_identity | pascal_qr_P3_depth3 | ridge | 6735 | 94.23 | 94.29 | 2.347 | 0.030 |
| generator_identity | pascal_qr_P1_depth1 | ridge | 6 | 53.75 | 46.73 | 0.002 | 0.000 |
| 561_plus_generator_identity | pascal_qr_P1_depth1 | ridge | 567 | 95.76 | 95.88 | 0.029 | 0.002 |
| generator_identity | pascal_qr_P1_depth2 | ridge | 42 | 67.93 | 66.29 | 0.003 | 0.000 |
| 561_plus_generator_identity | pascal_qr_P1_depth2 | ridge | 603 | 96.67 | 96.71 | 0.030 | 0.002 |
| generator_identity | pascal_qr_P1_depth3 | ridge | 258 | 77.16 | 77.26 | 0.019 | 0.002 |
| 561_plus_generator_identity | pascal_qr_P1_depth3 | ridge | 819 | 95.11 | 95.18 | 0.062 | 0.005 |
| generator_identity | pascal_qr_P1_depth4 | ridge | 1554 | 81.81 | 82.13 | 0.198 | 0.008 |
| 561_plus_generator_identity | pascal_qr_P1_depth4 | ridge | 2115 | 95.15 | 95.20 | 0.268 | 0.009 |
| generator_identity | pascal_qr_P2_depth1 | ridge | 12 | 54.09 | 47.69 | 0.002 | 0.000 |
| 561_plus_generator_identity | pascal_qr_P2_depth1 | ridge | 573 | 95.79 | 95.92 | 0.025 | 0.002 |
| generator_identity | pascal_qr_P2_depth2 | ridge | 156 | 79.88 | 80.01 | 0.007 | 0.001 |
| 561_plus_generator_identity | pascal_qr_P2_depth2 | ridge | 717 | 97.01 | 97.07 | 0.034 | 0.002 |
| generator_identity | pascal_qr_P2_depth3 | ridge | 1884 | 84.46 | 84.69 | 0.169 | 0.006 |
| 561_plus_generator_identity | pascal_qr_P2_depth3 | ridge | 2445 | 95.28 | 95.36 | 0.295 | 0.011 |
| generator_identity | pascal_qr_P4_depth1 | ridge | 24 | 55.62 | 50.49 | 0.002 | 0.000 |
| 561_plus_generator_identity | pascal_qr_P4_depth1 | ridge | 585 | 95.89 | 96.03 | 0.029 | 0.002 |
| generator_identity | pascal_qr_P4_depth2 | ridge | 600 | 87.48 | 87.60 | 0.027 | 0.002 |
| 561_plus_generator_identity | pascal_qr_P4_depth2 | ridge | 1161 | 97.01 | 97.07 | 0.075 | 0.006 |
| generator_identity | pascal_qr_P6_depth1 | ridge | 36 | 56.36 | 52.00 | 0.003 | 0.000 |
| 561_plus_generator_identity | pascal_qr_P6_depth1 | ridge | 597 | 95.93 | 96.06 | 0.037 | 0.002 |
| generator_identity | pascal_qr_P6_depth2 | ridge | 1332 | 88.29 | 88.53 | 0.089 | 0.005 |
| 561_plus_generator_identity | pascal_qr_P6_depth2 | ridge | 1893 | 97.01 | 97.05 | 0.170 | 0.008 |
| generator_identity | fourier_pascal_qr_P3_depth1 | ridge | 42 | 54.70 | 49.27 | 0.003 | 0.000 |
| 561_plus_generator_identity | fourier_pascal_qr_P3_depth1 | ridge | 603 | 95.93 | 96.07 | 0.031 | 0.002 |
| generator_identity | fourier_pascal_qr_P3_depth2 | ridge | 1806 | 89.41 | 89.53 | 0.146 | 0.007 |
| 561_plus_generator_identity | fourier_pascal_qr_P3_depth2 | ridge | 2367 | 96.30 | 96.33 | 0.225 | 0.008 |
| generator_identity | fourier_pascal_qr_P1_depth1 | ridge | 18 | 54.09 | 47.90 | 0.003 | 0.000 |
| 561_plus_generator_identity | fourier_pascal_qr_P1_depth1 | ridge | 579 | 96.03 | 96.17 | 0.026 | 0.002 |
| generator_identity | fourier_pascal_qr_P1_depth2 | ridge | 342 | 85.34 | 85.81 | 0.016 | 0.001 |
| 561_plus_generator_identity | fourier_pascal_qr_P1_depth2 | ridge | 903 | 96.88 | 96.92 | 0.053 | 0.003 |
| generator_identity | fourier_pascal_qr_P1_depth3 | ridge | 6174 | 83.17 | 83.44 | 1.734 | 0.017 |
| 561_plus_generator_identity | fourier_pascal_qr_P1_depth3 | ridge | 6735 | 91.41 | 91.31 | 1.959 | 0.023 |
| generator_identity | fourier_pascal_qr_P2_depth1 | ridge | 30 | 53.68 | 47.89 | 0.003 | 0.000 |
| 561_plus_generator_identity | fourier_pascal_qr_P2_depth1 | ridge | 591 | 95.93 | 96.07 | 0.028 | 0.003 |
| generator_identity | fourier_pascal_qr_P2_depth2 | ridge | 930 | 89.68 | 89.86 | 0.056 | 0.004 |
| 561_plus_generator_identity | fourier_pascal_qr_P2_depth2 | ridge | 1491 | 96.71 | 96.76 | 0.147 | 0.005 |
| generator_identity | fourier_pascal_qr_P4_depth1 | ridge | 54 | 55.04 | 49.89 | 0.003 | 0.000 |
| 561_plus_generator_identity | fourier_pascal_qr_P4_depth1 | ridge | 615 | 96.03 | 96.17 | 0.035 | 0.002 |
| generator_identity | fourier_pascal_qr_P4_depth2 | ridge | 2970 | 88.50 | 88.56 | 0.409 | 0.008 |
| 561_plus_generator_identity | fourier_pascal_qr_P4_depth2 | ridge | 3531 | 95.55 | 95.54 | 0.551 | 0.014 |
| generator_identity | fourier_pascal_qr_P6_depth1 | ridge | 78 | 56.67 | 52.34 | 0.005 | 0.001 |
| 561_plus_generator_identity | fourier_pascal_qr_P6_depth1 | ridge | 639 | 95.89 | 96.03 | 0.031 | 0.002 |
| generator_identity | fourier_pascal_qr_P6_depth2 | ridge | 6162 | 84.26 | 84.31 | 1.705 | 0.021 |
| 561_plus_generator_identity | fourier_pascal_qr_P6_depth2 | ridge | 6723 | 92.50 | 92.35 | 1.930 | 0.016 |
| generator_difference | pascal_qr_P1_depth1 | ridge | 6 | 22.50 | 13.48 | 0.002 | 0.000 |
| 561_plus_generator_difference | pascal_qr_P1_depth1 | ridge | 567 | 95.72 | 95.86 | 0.025 | 0.002 |
| generator_difference | pascal_qr_P1_depth2 | ridge | 42 | 55.55 | 50.93 | 0.003 | 0.000 |
| 561_plus_generator_difference | pascal_qr_P1_depth2 | ridge | 603 | 96.10 | 96.22 | 0.029 | 0.003 |
| generator_difference | pascal_qr_P3_depth1 | ridge | 18 | 27.01 | 21.87 | 0.002 | 0.000 |
| 561_plus_generator_difference | pascal_qr_P3_depth1 | ridge | 579 | 95.79 | 95.92 | 0.029 | 0.003 |
| generator_difference | pascal_qr_P3_depth2 | ridge | 342 | 62.40 | 61.14 | 0.018 | 0.001 |
| 561_plus_generator_difference | pascal_qr_P3_depth2 | ridge | 903 | 95.83 | 95.93 | 0.057 | 0.004 |
| generator_energy | pascal_qr_P1_depth1 | ridge | 6 | 60.06 | 55.10 | 0.002 | 0.000 |
| 561_plus_generator_energy | pascal_qr_P1_depth1 | ridge | 567 | 95.79 | 95.92 | 0.027 | 0.003 |
| generator_energy | pascal_qr_P1_depth2 | ridge | 42 | 63.18 | 60.17 | 0.003 | 0.000 |
| 561_plus_generator_energy | pascal_qr_P1_depth2 | ridge | 603 | 95.55 | 95.57 | 0.028 | 0.003 |
| generator_energy | pascal_qr_P3_depth1 | ridge | 18 | 59.82 | 54.83 | 0.003 | 0.000 |
| 561_plus_generator_energy | pascal_qr_P3_depth1 | ridge | 579 | 95.79 | 95.92 | 0.039 | 0.002 |
| generator_energy | pascal_qr_P3_depth2 | ridge | 342 | 69.19 | 67.17 | 0.017 | 0.001 |
| 561_plus_generator_energy | pascal_qr_P3_depth2 | ridge | 903 | 95.32 | 95.33 | 0.052 | 0.003 |
| generator_lag_product | pascal_qr_P1_depth1 | ridge | 6 | 59.86 | 54.23 | 0.002 | 0.000 |
| 561_plus_generator_lag_product | pascal_qr_P1_depth1 | ridge | 567 | 95.79 | 95.92 | 0.032 | 0.002 |
| generator_lag_product | pascal_qr_P1_depth2 | ridge | 42 | 64.37 | 61.67 | 0.003 | 0.000 |
| 561_plus_generator_lag_product | pascal_qr_P1_depth2 | ridge | 603 | 95.39 | 95.40 | 0.029 | 0.003 |
| generator_lag_product | pascal_qr_P3_depth1 | ridge | 18 | 59.82 | 54.10 | 0.003 | 0.000 |
| 561_plus_generator_lag_product | pascal_qr_P3_depth1 | ridge | 579 | 95.83 | 95.96 | 0.026 | 0.003 |
| generator_lag_product | pascal_qr_P3_depth2 | ridge | 342 | 69.83 | 68.01 | 0.014 | 0.001 |
| 561_plus_generator_lag_product | pascal_qr_P3_depth2 | ridge | 903 | 95.15 | 95.17 | 0.052 | 0.003 |
| generator_spectral_power | pascal_qr_P1_depth1 | ridge | 6 | 60.06 | 55.10 | 0.002 | 0.000 |
| 561_plus_generator_spectral_power | pascal_qr_P1_depth1 | ridge | 567 | 95.79 | 95.92 | 0.030 | 0.002 |
| generator_spectral_power | pascal_qr_P1_depth2 | ridge | 42 | 67.05 | 64.30 | 0.003 | 0.000 |
| 561_plus_generator_spectral_power | pascal_qr_P1_depth2 | ridge | 603 | 95.93 | 95.95 | 0.031 | 0.002 |
| generator_spectral_power | pascal_qr_P3_depth1 | ridge | 18 | 72.18 | 68.33 | 0.002 | 0.000 |
| 561_plus_generator_spectral_power | pascal_qr_P3_depth1 | ridge | 579 | 96.10 | 96.23 | 0.030 | 0.003 |
| generator_spectral_power | pascal_qr_P3_depth2 | ridge | 342 | 78.01 | 75.67 | 0.015 | 0.002 |
| 561_plus_generator_spectral_power | pascal_qr_P3_depth2 | ridge | 903 | 95.79 | 95.79 | 0.049 | 0.003 |

## Adding features to the 561 features

Corrected and lost predictions compare the hybrid with the same head on the 561 features alone. They are descriptive counts on this test split, not significance tests.

| Hybrid / representation / head | Corrected errors | Introduced errors |
|---|---:|---:|
| 561_plus_total_basepoint/ordinary_full_signature/ridge | 59 | 20 |
| 561_plus_generator_identity/pascal_qr_P3_depth1/ridge | 9 | 1 |
| 561_plus_generator_identity/pascal_qr_P3_depth2/ridge | 59 | 18 |
| 561_plus_generator_identity/pascal_qr_P3_depth3/ridge | 40 | 84 |
| 561_plus_generator_identity/pascal_qr_P1_depth1/ridge | 1 | 0 |
| 561_plus_generator_identity/pascal_qr_P1_depth2/ridge | 43 | 15 |
| 561_plus_generator_identity/pascal_qr_P1_depth3/ridge | 31 | 49 |
| 561_plus_generator_identity/pascal_qr_P1_depth4/ridge | 59 | 76 |
| 561_plus_generator_identity/pascal_qr_P2_depth1/ridge | 2 | 0 |
| 561_plus_generator_identity/pascal_qr_P2_depth2/ridge | 55 | 17 |
| 561_plus_generator_identity/pascal_qr_P2_depth3/ridge | 43 | 56 |
| 561_plus_generator_identity/pascal_qr_P4_depth1/ridge | 7 | 2 |
| 561_plus_generator_identity/pascal_qr_P4_depth2/ridge | 63 | 25 |
| 561_plus_generator_identity/pascal_qr_P6_depth1/ridge | 8 | 2 |
| 561_plus_generator_identity/pascal_qr_P6_depth2/ridge | 69 | 31 |
| 561_plus_generator_identity/fourier_pascal_qr_P3_depth1/ridge | 10 | 4 |
| 561_plus_generator_identity/fourier_pascal_qr_P3_depth2/ridge | 69 | 52 |
| 561_plus_generator_identity/fourier_pascal_qr_P1_depth1/ridge | 9 | 0 |
| 561_plus_generator_identity/fourier_pascal_qr_P1_depth2/ridge | 68 | 34 |
| 561_plus_generator_identity/fourier_pascal_qr_P1_depth3/ridge | 46 | 173 |
| 561_plus_generator_identity/fourier_pascal_qr_P2_depth1/ridge | 9 | 3 |
| 561_plus_generator_identity/fourier_pascal_qr_P2_depth2/ridge | 66 | 37 |
| 561_plus_generator_identity/fourier_pascal_qr_P4_depth1/ridge | 12 | 3 |
| 561_plus_generator_identity/fourier_pascal_qr_P4_depth2/ridge | 71 | 76 |
| 561_plus_generator_identity/fourier_pascal_qr_P6_depth1/ridge | 10 | 5 |
| 561_plus_generator_identity/fourier_pascal_qr_P6_depth2/ridge | 61 | 156 |
| 561_plus_generator_difference/pascal_qr_P1_depth1/ridge | 1 | 1 |
| 561_plus_generator_difference/pascal_qr_P1_depth2/ridge | 23 | 12 |
| 561_plus_generator_difference/pascal_qr_P3_depth1/ridge | 4 | 2 |
| 561_plus_generator_difference/pascal_qr_P3_depth2/ridge | 31 | 28 |
| 561_plus_generator_energy/pascal_qr_P1_depth1/ridge | 2 | 0 |
| 561_plus_generator_energy/pascal_qr_P1_depth2/ridge | 35 | 40 |
| 561_plus_generator_energy/pascal_qr_P3_depth1/ridge | 4 | 2 |
| 561_plus_generator_energy/pascal_qr_P3_depth2/ridge | 44 | 56 |
| 561_plus_generator_lag_product/pascal_qr_P1_depth1/ridge | 2 | 0 |
| 561_plus_generator_lag_product/pascal_qr_P1_depth2/ridge | 35 | 45 |
| 561_plus_generator_lag_product/pascal_qr_P3_depth1/ridge | 4 | 1 |
| 561_plus_generator_lag_product/pascal_qr_P3_depth2/ridge | 41 | 58 |
| 561_plus_generator_spectral_power/pascal_qr_P1_depth1/ridge | 2 | 0 |
| 561_plus_generator_spectral_power/pascal_qr_P1_depth2/ridge | 41 | 35 |
| 561_plus_generator_spectral_power/pascal_qr_P3_depth1/ridge | 14 | 3 |
| 561_plus_generator_spectral_power/pascal_qr_P3_depth2/ridge | 43 | 41 |
