# UCI HAR: pooled and spectral ablations

**We can retain the previous accuracy with fewer features.** Spectral pooling,
rotation-aware pooling without its lag-cosine summaries, and raw Pascal P3 QR at
depth two give **98.10% with 803 features**, versus 98.07% with 1,066. The difference
is one test window; the useful finding is the 25% dimensional reduction.

The more uniform three-generator construction uses a **234-feature band-free
pool + 160 spectral Pascal features + 342 raw Pascal features**. It reaches
**97.93% with 736 features**, four extra errors compared with the old model.
Replacing the raw tensor by its first levels and areas gives **97.86% with 565
features**, six extra errors. These are worthwhile small candidates rather than
claims of a new accuracy ceiling.

## Run and main results

```sh
../tensorsig/.venv/bin/python examples/uci_har/benchmark.py --ablations
```

All **438 ridge fits finished in 31.75 seconds**, including data loading,
feature extraction and writing results. Same official 7,352/2,947 subject split,
fixed alpha 10, training-only scaling, one numerical thread. All signatures use
**tensorsig**; Pascal codes are QR conditioned. Ordinary integrated signatures
use the same observations with a constant QR code. Accuracy is on the test split;
errors are counts out of 2,947. **Every main model below excludes the supplied 561
columns.** The original 98.07% model also excluded them.

| Construction | Features | Accuracy | Errors | Fit / predict (s) |
|---|---:|---:|---:|---:|
| Supplied 561 reference | 561 | 95.72% | 126 | 0.022 / 0.002 |
| Previous complete pool + raw Pascal | 1,066 | 98.07% | 57 | 0.048 / 0.004 |
| Spectral + rotation pool + raw Pascal | 815 | 98.07% | 57 | 0.028 / 0.003 |
| Same, remove lag-cosine summaries | 803 | 98.10% | 56 | 0.029 / 0.003 |
| Band-free pool + compact spectral Pascal + raw Pascal | 736 | 97.93% | 61 | 0.027 / 0.002 |
| Same, raw Pascal logsignature | 565 | 97.86% | 63 | 0.018 / 0.002 |
| Band-free pool + full-span compact spectral Pascal + raw Pascal | 1,126 | 98.10% | 56 | 0.053 / 0.003 |

The small models extract all 10,299 windows in about 2.3–2.9 seconds, fit in
0.018–0.029 seconds and predict all test windows in 0.002–0.003 seconds. Extraction
includes shared preparation of every family and dense tensors before projection;
these are conservative comparison timings, not optimized standalone deployment
measurements. The largest fit in the whole sweep took 0.531 seconds.
The 561 extraction cost remains unmeasured.

## What drives 98.07%

Except for the explicitly marked no-signature row, these comparisons add the
same 342-coordinate raw Pascal P3/depth-two tensor.

| Construction | Features | Accuracy | Errors |
|---|---:|---:|---:|
| All four pools, no signature | 724 | 97.79% | 65 |
| Drop moment pool | 961 | 98.03% | 58 |
| Drop filter/delay pool | 920 | 98.07% | 57 |
| Drop spectral pool | 707 | 97.15% | 84 |
| Drop rotation pool | 952 | 97.08% | 86 |
| Keep spectral + rotation | 815 | 98.07% | 57 |
| Keep spectral + rotation, remove cross-cosines | 809 | 96.95% | 90 |
| Keep spectral + rotation, remove bands | 655 | 97.62% | 70 |

The separate moment and filter/delay pools can both be removed without losing
the old score. Spectral pooling already contains summaries of acceleration and
gyroscope differences, and rotation pooling includes lagged dot products: this
is **not** evidence that derivatives or delays are unnecessary.

The six cross-cosine features are the means and standard deviations of the
pointwise angles' cosines between body acceleration, estimated gravity and
gyroscope vectors. Removing them from the surviving pool loses 33 net correct
predictions. They describe relative orientation without choosing a spatial axis.
They remain useful alongside raw axis signatures. Spectral band masses also
help this head: removing them loses 13 net correct predictions. Energy, spectral
amplitude shape and the other rotation summaries contribute smaller, overlapping
improvements. These ablations measure conditional contributions, not additive
feature importance.

The 803-feature model consists of 359 nonconstant spectral pooled columns,
96 moment summaries of invariant energy/cross/lag-dot streams, six cross-cosine
summaries, and the raw 342-coordinate Pascal signature. Relative to the original
1,066-feature model, this model corrects 14 errors and introduces 13 errors.
Thus the one-window gain itself should not be overinterpreted.

## Ordinary versus Pascal on the same pool

| Construction | Features | Accuracy | Errors |
|---|---:|---:|---:|
| Spectral + rotation pooling | 473 | 97.29% | 80 |
| + ordinary integrated signature | 515 | 97.56% | 72 |
| + ordinary anchored signature and clock | 527 | 97.66% | 69 |
| + Pascal P3 QR signature | 815 | 98.07% | 57 |
| Pool with lag-cosines removed | 461 | 97.18% | 83 |
| + ordinary integrated signature | 503 | 97.42% | 76 |
| + Pascal P3 QR signature | 803 | 98.10% | 56 |

P3 adds polynomial time location and its ordered interactions to the same
integrated raw observations. Here it helps materially: on the 461-feature pool,
P3 improves over ordinary integrated signatures by 20 correctly classified
windows. The anchored ordinary path is an additional control with different
augmentation; it also falls short on the common 473-feature pool.

## A band-free raw-code + spectral-code + pooling construction

Use the existing five spectral groups: body acceleration, gravity, gyroscope,
and acceleration/gyroscope differences, each with xyz and norm channels.
Normalize each power spectrum to mass one; retain energy separately. The
234-feature pool has:

- 114 rotation-family summaries of energy, cross/lag products and cosines;
- 40 spectral energy and log-energy values;
- 80 mean/std/skewness/kurtosis values of spectral bin amplitudes.

It has **no frequency bands, peak-frequency selection, spectral entropy,
explicit centroid/spread or supplied 561 columns**. All rows below append the
same full raw Pascal P3/depth-two block. This isolates the spectral readout.

| Construction | Features | Accuracy | Errors |
|---|---:|---:|---:|
| No spectral signature | 576 | 97.08% | 86 |
| + ordinary spectral depth-two areas (30) | 606 | 96.91% | 91 |
| + P3 first levels (40 nonconstant) | 616 | 97.25% | 81 |
| + within-channel P3 moments/products, no areas (100) | 676 | 97.62% | 70 |
| + within-channel P3 first levels and areas (100) | 676 | 97.83% | 64 |
| + within-channel compact P3 signature (160) | 736 | 97.93% | 61 |
| + full P3 spectral tensor (740 nonconstant) | 1,316 | 97.90% | 62 |
| + full affine-span compact P3 tensor (550) | 1,126 | 98.10% | 56 |

The compact within-channel signature gives the requested three-part model.
Removing just its 60 area coordinates changes 97.93% to 97.62%: **nine net
correct predictions come from frequency-pair ordering**, conditional on this
pool and head. Keeping areas while omitting symmetric products loses three net
correct predictions. Cross-channel spectral interactions help when all 550
independent affine coordinates are retained, but cost 390 extra features.

The full 740-coordinate and compact 550-coordinate versions span the same
nonconstant linear predictors. Their score difference reflects the changed
standardized ridge penalty, not newly created information. The 160-coordinate
version intentionally drops interactions between different original channels.

A smaller raw readout yields another useful candidate: pool234 + spectral160 +
raw P3 logsignature171 = **565 features, 97.86%**. It retains raw ordered areas
but drops raw endpoint-product coordinates. It sacrifices two more windows than
the 736-feature tensor model.

## P and depth, spectral groups and raw quotients

This sweep uses one fixed alternative pool (300 columns: low-order time/Gram
summaries plus spectral energy/location and amplitude shape), together with
raw P3/depth two. It is separate from the 234-column pool above.

| Construction | Features | Accuracy | Errors |
|---|---:|---:|---:|
| Spectral P2/depth 1 | 662 | 97.59% | 71 |
| Spectral P3/depth 1 | 682 | 97.69% | 68 |
| Spectral P5/depth 1 | 722 | 97.73% | 67 |
| Spectral P2/depth 2, compact within-channel | 702 | 97.69% | 68 |
| Spectral P3/depth 2, compact within-channel | 802 | 97.83% | 64 |
| Spectral P4/depth 2, compact within-channel | 942 | 97.86% | 63 |
| Spectral P5/depth 2, compact within-channel | 1,122 | 97.93% | 61 |
| Ordinary spectral depth 3, full cross-channel | 1,002 | 97.96% | 60 |
| Spectral P2/depth 3, full cross-channel | 3,502 | 97.93% | 61 |
| Spectral P2/depth 3, within-channel | 862 | 97.66% | 69 |

Larger P and depth do not produce a monotone improvement. P3/depth two is a
reasonable small starting point with a mathematical coverage argument; these
experiments do not establish that it is accuracy-optimal. Ablations of the
**pooled spectral groups/channels** also tested base triads, dynamic triads,
their differences, and axes versus norms. With the fixed time-core pool and
raw P3, retaining all five pooled spectral groups gives 97.86%; base triads
give 97.66%, axes-only 97.73%, and
norms-only 97.08%. The spectral axis channels retain useful information here.
These spectral norms follow axiswise scaling and are not strictly rotation
invariant; the raw signatures also still retain axis information.

Raw-signature reductions on the 461-feature spectral/rotation pool give:

| Construction | Features | Accuracy | Errors |
|---|---:|---:|---:|
| Full raw P3 tensor | 803 | 98.10% | 56 |
| Raw P3 logsignature | 632 | 97.83% | 64 |
| Raw P3 modality quotient | 722 | 97.52% | 73 |
| Separate raw modality tensors | 641 | 97.73% | 67 |
| Raw P3 first levels + products | 650 | 97.66% | 69 |
| Raw P3 first levels only | 479 | 97.12% | 85 |

The modality quotient keeps symmetric cross-modality interactions while
removing their antisymmetric areas; separate modality tensors remove both.
Neither retains the full score here. The logsignature is the better compact
choice on this particular pool, but its 97.83% still falls short of 98.10%.

## Do the supplied 561 columns still help?

| Construction | Features | Accuracy | Errors |
|---|---:|---:|---:|
| Generic pool only | 724 | 97.79% | 65 |
| 561 + generic pool | 1,285 | 98.37% | 48 |
| Generic pool + raw Pascal | 1,066 | 98.07% | 57 |
| 561 + generic pool + raw Pascal | 1,627 | 98.17% | 54 |

Yes: the supplied table still adds information or useful nonlinear readouts for
this fixed ridge head. It is not necessary for the 98.10% generic model. These
hybrids are explicit controls, not hidden inputs to the replacement families.

## Why these parameters are generic

P3 spans the frequency polynomials 1, f, f². First levels recover mass, centroid
and second moment; the shuffle identity supplies centroid squared at depth two,
so variance is a linear tensor readout. Antisymmetric coordinates additionally
measure polynomially weighted pairwise frequency separation. They distinguish
some spectra with identical centroid, variance and eight band masses.

A normalized scalar spectrum needs only eight nonconstant affine coordinates
at P3/depth two: two moments, their three quadratic products, and three areas.
Twenty scalar spectra therefore need 160. P5 instead covers moments through
order four; it is a principled extension when higher-order spectral shape is
wanted. These are statements about represented functionals, not performance
guarantees. FFT power discards phase, so raw temporal signatures remain a
complementary family.

See [the derivation and checked example](feature_families.md#compact-spectral-signatures-moments-and-pairwise-dispersion)
and [tensorsig suggestions](tensorsig_suggestions.md). The pooled statistics and
particular delays are reusable choices, but their optimality is not derived by
this argument. In particular, the 803-feature model still uses eight heuristic
frequency bands; the 736/565-feature models remove those boundaries.

## Scope and checks

All nonempty family subsets, named leave-one-block-out ablations, compact pools,
spectral group/channel/readout ablations, and small P/depth sweeps are recorded
in [results.csv](ablation_results/results.csv), [RESULTS.md](ablation_results/RESULTS.md)
and [run.json](ablation_results/run.json). The later focused reductions were
prompted by the initial results on this same test split. Scores are descriptive
research evidence, not independent validation of selected winners. The highest
observed score without 561 is 98.20%, but it uses 1,057 features and does not serve
the dimensionality goal as well.

Mathematical self-checks and Ruff pass. Fresh-process fits of the 803-, 736-,
565- and 1,126-feature models agree **on every test prediction** between the
closed-form LU ridge implementation and sklearn's iterative LSQR ridge, and
reproduce the recorded confusion matrices. No model hyperparameters were tuned.
