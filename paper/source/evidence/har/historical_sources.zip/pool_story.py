"""Small-pool and spectral logsignature comparisons, with fixed ridge heads."""

from itertools import combinations
from time import perf_counter

import numpy as np
import torch
from families import build_families
from features import _coordinates, _standardize
from generators import coded_integration
from moment_lifts import build_lifts
from pooled_blocks import pooled_blocks, spectral_pool
from spectral_readouts import signature_readouts


def run(evaluate, signals, n_train, engineered, args, metadata):
    start = perf_counter()
    raw = _standardize(torch.as_tensor(signals[..., [6, 7, 8, 3, 4, 5]],
                                      dtype=torch.float64), n_train)
    values, _ = coded_integration(raw, 3, 2, batch_size=args.batch_size)
    raw_features = {"tensor": values, "log": _coordinates(
        torch.as_tensor(values), ("accel",)*9 + ("gyro",)*9)["full_logsignature"].numpy()}
    raw_seconds = perf_counter() - start
    start = perf_counter()
    families = build_families(signals, n_train)
    blocks = pooled_blocks(families)
    preparation = perf_counter() - start
    spectral, spectral_seconds = signature_readouts(families["spectral"]["observations"],
                                                   3, 2, args.batch_size)
    spectral_features = {
        "tensor": spectral["within_channel_compact"],
        "log": spectral["within_channel_first_areas"],
        "cross_log": spectral["first_areas"],
    }
    bases = {f"raw_{r}__spectral_{s}": np.concatenate((rv, sv), axis=1)
             for r, rv in raw_features.items() for s, sv in spectral_features.items()}
    seconds = preparation + spectral_seconds + raw_seconds
    rotation = families["rotation"]["pooled"]
    parts = {
        "rotation_energy": rotation[:, :24], "rotation_gram": rotation[:, 24:48],
        "rotation_lags": rotation[:, 48:96],
        "cross_cosines": rotation[:, 96:102], "lag_cosines": rotation[:, 102:114],
        "spectral_energy": spectral_pool(families, statistics=["raw_energy"]),
        "spectral_log_energy": spectral_pool(families, statistics=["log_energy"]),
        **{f"amplitude_{stat}": spectral_pool(families, statistics=["amplitude_" + stat])
           for stat in ("mean", "std", "skew", "kurtosis")},
    }
    # Keep the old group-major ordering for exact reproduction of 565/736.
    full_pool = np.concatenate((rotation, spectral_pool(
        families, statistics=("energy", "amplitude_shape"))), axis=1)
    empty = np.empty((len(signals), 0), dtype=np.float32)

    def cat(names, source=parts):
        return np.concatenate([source[name] for name in names], axis=1)

    def compare(name, pool, labels=None, elapsed=seconds):
        for label in bases if labels is None else labels:
            if name == "pool_full234" and label == "raw_log__spectral_tensor":
                continue  # Recorded first below to establish paired errors.
            evaluate(name, label, np.concatenate((pool, bases[label]), axis=1), elapsed)

    metadata["pool_story_settings"] = {
        "P": 3, "depth": 2, "codes": "QR Pascal throughout; P1 for observable integral endpoints",
        "raw": "total acceleration + body gyro, training-global axis scaling; tensor342 or log171",
        "spectral": "Five groups, xyz/norm; normalized power; within-channel tensor160/log100 or cross-channel log370",
        "log_convention": "First levels and antisymmetric level two; constants removed with training mask",
        "supplied561": "Only the separately evaluated baseline, never appended to any construction here",
        "pool_parts": {key: value.shape[1] for key, value in parts.items()},
        "protocol": "Existing official subject split, fixed ridge alpha10; exploratory comparisons on the same test set",
        "timings": "Shared all-family preparation and dense signatures before readout; added integral timings include all lifts",
    }
    evaluate("pool_full234", "raw_log__spectral_tensor",
             np.concatenate((full_pool, bases["raw_log__spectral_tensor"]), axis=1), seconds)
    compare("pool_full234", full_pool)
    compare("no_pool", empty)
    for label, value in raw_features.items():
        evaluate("raw_only", label, value, raw_seconds)
    for label, value in spectral_features.items():
        evaluate("spectral_only", label, value, preparation + spectral_seconds)
    for label in ("full", "full_compact"):
        for r, value in raw_features.items():
            evaluate("no_pool", f"raw_{r}__spectral_{label}",
                     np.concatenate((value, spectral[label]), axis=1), seconds)

    matched = [name for name in bases if not name.endswith("cross_log")]
    for removed in parts:
        compare("drop_" + removed, cat([key for key in parts if key != removed]), matched)
    coarse = {"rotation": rotation, "spectral_energy": blocks["spectral"]["energy"],
              "amplitude_shape": blocks["spectral"]["amplitude_shape"]}
    for size in (1, 2):
        for names in combinations(coarse, size):
            compare("keep_" + "+".join(names), cat(names, coarse), matched)

    presets = {
        "cosines6": ["cross_cosines"],
        "energy20": ["spectral_energy"],
        "log_energy20": ["spectral_log_energy"],
        "energy_cosines26": ["spectral_energy", "cross_cosines"],
        "log_energy_cosines26": ["spectral_log_energy", "cross_cosines"],
        "both_energy_cosines46": ["spectral_energy", "spectral_log_energy", "cross_cosines"],
        "energy_cosines_ampmean46": ["spectral_energy", "cross_cosines", "amplitude_mean"],
        "log_energy_cosines_ampmean46": ["spectral_log_energy", "cross_cosines", "amplitude_mean"],
        "energy_cosines_ampmeanstd66": ["spectral_energy", "cross_cosines", "amplitude_mean", "amplitude_std"],
        "energy_cosines_amptails66": ["spectral_energy", "cross_cosines", "amplitude_skew", "amplitude_kurtosis"],
        "energy_cosines_ampshape106": ["spectral_energy", "cross_cosines", "amplitude_mean", "amplitude_std",
                                      "amplitude_skew", "amplitude_kurtosis"],
        "both_energy_cosines_ampshape126": ["spectral_energy", "spectral_log_energy", "cross_cosines",
                                           "amplitude_mean", "amplitude_std", "amplitude_skew", "amplitude_kurtosis"],
    }
    for name, names in presets.items():
        compare("small_" + name, cat(names))
    # A fixed degree/readout grid tests whether uniform low-order moments of
    # the invariant streams replace the larger 8-statistic rotation pool.
    rotation_stats = rotation[:, :96].reshape(len(signals), 4, 8, 3)
    moment_choices = {
        "mean_std": (0, 1), "mean_std_skew": (0, 1, 4),
        "mean_std_skew_kurt": (0, 1, 4, 5),
        "mean_std_abs_rms": (0, 1, 2, 3), "all_stats": tuple(range(8)),
    }
    for core_name, core_parts in {
        "energy_ampmeanstd": ["spectral_energy", "cross_cosines", "amplitude_mean", "amplitude_std"],
        "logenergy_ampmeanstd": ["spectral_log_energy", "cross_cosines", "amplitude_mean", "amplitude_std"],
        "energy_ampshape": presets["energy_cosines_ampshape106"],
    }.items():
        for moment_name, stats in moment_choices.items():
            pool = np.concatenate((cat(core_parts), rotation_stats[:, :, stats].reshape(len(signals), -1)), axis=1)
            compare(f"moment_pool_{core_name}_{moment_name}", pool, matched)
        for group_name, groups in {"energy": [0], "gram": [1], "lags": [2, 3],
                                   "gram_lags": [1, 2, 3]}.items():
            pool = np.concatenate((cat(core_parts), rotation_stats[:, groups, :2].reshape(len(signals), -1)), axis=1)
            compare(f"moment_pool_{core_name}_{group_name}_meanstd", pool, matched)
    energy_axes = parts["spectral_energy"].reshape(len(signals), 5, 4)[:, :, :3].reshape(len(signals), -1)
    for name, pool in {
        "energy_axes_cosines21": np.concatenate((energy_axes, parts["cross_cosines"]), axis=1),
        "energy_axes_cosines_ampmean41": np.concatenate((energy_axes, parts["cross_cosines"], parts["amplitude_mean"]), axis=1),
        "energy_mean_cosines23": np.concatenate((parts["spectral_energy"], parts["cross_cosines"][:, :3]), axis=1),
    }.items():
        compare("small_" + name, pool)

    lifts, lift_metadata = build_lifts(signals, n_train, families, args.batch_size)
    metadata["pool_story_settings"]["observable_integrals"] = lift_metadata
    lift_sets = {
        "cosine_moments6": ["cosine_mean", "cosine_second"],
        "energy_cosine_moments12": ["energy_mean", "energy_second", "cosine_mean", "cosine_second"],
        "energy_gram_cosine_moments18": ["energy_mean", "energy_second", "gram_mean", "gram_second",
                                       "cosine_mean", "cosine_second"],
        "energy_cosine_meanstd12": ["energy_mean", "energy_std", "cosine_mean", "cosine_std"],
        "spectral_energy_cosine_moments26": ["spectral_energy", "cosine_mean", "cosine_second"],
        "spectral_energy_cosine_ampmoments86": ["spectral_energy", "cosine_mean", "cosine_second",
                                               "spectral_amplitude_mean", "spectral_amplitude_third", "spectral_amplitude_fourth"],
        "spectral_ampmoments_cosine86": ["spectral_amplitude_mean", "spectral_amplitude_second", "spectral_amplitude_third",
                                         "spectral_amplitude_fourth", "cosine_mean", "cosine_second"],
        "energy_cosine_concentration72": ["energy_mean", "energy_second", "cosine_mean", "cosine_second", "concentration"],
        "spectral_energy_cosine_concentration86": ["spectral_energy", "cosine_mean", "cosine_second", "concentration"],
        "spectral_energy_cosine_std_concentration86": ["spectral_energy", "cosine_mean", "cosine_std", "concentration"],
        "log_energy_cosine_std_concentration86": ["spectral_log_energy", "cosine_mean", "cosine_std", "concentration"],
        "energy_cosine_pascal_first18": ["energy_cosine_pascal_P3_first"],
        "energy_cosine_pascal_log36": ["energy_cosine_pascal_P3_log"],
        "spectral_energy_pascal_log56": ["spectral_energy", "energy_cosine_pascal_P3_log"],
        "spectral_energy_concentration_pascal_log116": ["spectral_energy", "concentration", "energy_cosine_pascal_P3_log"],
        "profile142": ["spectral_energy", "cosine_mean", "cosine_std", "spectral_amplitude_mean",
                       "spectral_amplitude_std", "spectral_amplitude_skew", "spectral_amplitude_kurtosis",
                       "invariant_mean_std_skew"],
        "profile102": ["spectral_log_energy", "cosine_mean", "cosine_std", "spectral_amplitude_mean",
                       "spectral_amplitude_std", "invariant_mean_std_skew"],
        "profile66": ["spectral_energy", "cosine_mean", "cosine_std", "spectral_amplitude_mean", "spectral_amplitude_std"],
    }
    for q in ("q05", "q15", "q2"):
        lift_sets["energy_cosine_concentration_" + q] = ["spectral_energy", "cosine_mean", "cosine_std", "concentration_" + q]
    for name, names in lift_sets.items():
        compare("lift_" + name, cat(names, lifts), elapsed=seconds + lift_metadata["preparation_s"])
    metadata["pool_story_settings"]["small_pools"] = presets
    metadata["pool_story_settings"]["lift_sets"] = lift_sets
    metadata["pool_story_settings"]["rotation_moment_grid"] = {
        "statistics": moment_choices,
        "groups": "all streams; or energy / instantaneous Gram / lag-2,5 Gram / instantaneous+lagged Gram",
        "reason": "Initial run:66-column energy+cosine+amplitude mean/std pool retained97.56% with log/log; test invariant moment additions",
    }
