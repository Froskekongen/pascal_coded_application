# From the 561 HAR features to generic signature feature families

The useful generalization is to make the **signal representation, observable,
ordering variable and readout** explicit. Many of the 561 columns are pooled
observables of a transformed signal. Integration makes those pools first-level
signature coordinates. Coding adds a position dependence to the pools; deeper
signatures add ordered interactions between them. These choices give a family
that can be reused outside HAR.

The practical reference is ridge on **561 + Pascal P3 QR full tensor**, measured
at 97.12% in the temporal experiment. The new ridge sweep varies code width and
depth around this reference and tests a few generic pretransforms. This note
also identifies families that have not yet been run. Library proposals remain
in [tensorsig_suggestions.md](tensorsig_suggestions.md).

## What the 561 columns contain

This inventory was counted from features.txt, and checked against
features_info.txt and README.txt inside the cached data/uci_har.zip →
UCI HAR Dataset.zip. These are the files distributed with the
[official UCI dataset](https://archive.ics.uci.edu/dataset/240/human+activity+recognition+using+smartphones).

The documented preprocessing uses a median filter and a third-order Butterworth
low-pass filter at 20 Hz. Another Butterworth filter at 0.3 Hz separates gravity
from body acceleration. Derivatives produce acceleration jerk and angular
acceleration, the latter named BodyGyroJerk. Euclidean norms produce scalar
magnitudes. FFTs are then applied to selected signals. The
[dataset paper, Tables 2–3](https://www.esann.org/sites/default/files/proceedings/legacy/es2013-84.pdf)
also describes this construction.

| Source signals | Column ranges | Number |
|---|---|---:|
| Time-domain xyz: body acceleration, gravity, acceleration jerk, gyro, gyro derivative | 1–200: five blocks of 40 | 200 |
| Norm of each of those five xyz signals | 201–265: five blocks of 13 | 65 |
| FFT xyz: body acceleration, acceleration jerk, gyro | 266–502: three blocks of 79 | 237 |
| FFT of scalar body-acceleration, acceleration-jerk, gyro and gyro-derivative magnitudes | 503–554: four blocks of 13 | 52 |
| Angles involving mean vectors | 555–561 | 7 |
| **Total** | **265 time + 289 frequency + 7 angles** | **561** |

Eight statistics occur on every scalar signal: mean, standard deviation,
median absolute deviation, maximum, minimum, energy, interquartile range and
entropy. There are 20 scalar time signals and 13 scalar FFT signals, so each
of these statistics has 33 columns. The remaining counts explain the whole table:

| Statistic | Number | Where it occurs |
|---|---:|---|
| The eight common statistics | 264 | 33 of each |
| Signal magnitude area | 17 | One per xyz or scalar source family |
| Burg autoregression coefficients, order four | 80 | Four per scalar time signal |
| Pairwise correlation | 15 | xy, xz, yz within each of five time-domain triads |
| Peak-frequency index, mean frequency, skewness, kurtosis | 52 | 13 of each, on FFT signals |
| Frequency-band energy | 126 | 14 intervals × three axes × three FFT triads |
| Angles | 7 | Four mean-signal/gravity angles and three gravity/device-axis angles |

The 14 frequency intervals are the eight consecutive eight-bin intervals from
1–8 through 57–64; the four 16-bin intervals; and 1–24 and 25–48. The names
repeat the same band labels three times without an axis suffix. They are
different columns, not an instruction to deduplicate. Three scalar FFT families
also contain a repeated Body in their names, e.g. fBodyBodyGyroMag.

This documentation specifies a recipe, not an executable reference. It does
not fully specify the entropy estimator, FFT endpoints and normalization,
derivative boundaries or every moment convention. It describes 64 FFT bins,
whereas a standard real FFT of 128 samples returns 65 including both endpoints.
The supplied columns are further normalized to [-1,1]. We should distinguish
recovering the underlying statistic from reproducing its exact supplied column.
The formulas below do the former under explicit conventions.

## One construction, with independent choices

Choose a pretransform \(T\): identity, finite differences, delays, filters or
FFT. Let its output be a sequence \(u_r\), ordered by a variable \(a_r\).
Usually \(a_r\) is time; after FFT it can be frequency. Choose observables
\(\phi(u_r)\in\mathbb R^d\), and form a path starting at zero with increments

\[
\Delta Y_r=\phi(u_r)/M,
\]

where \(M\) is the output sequence length. First level is exactly the average
observable. For code columns \(c_0,\ldots,c_{P-1}\), replace the increments by

\[
\Delta Z_r^{i,p}=c_p(a_r)\phi_i(u_r)/M.
\]

Compute its signature through depth \(m\), then optionally apply a fixed
readout: centering, a correlation ratio, an invariant contraction or a selected
coordinate projection. For ridge these readouts matter: supplying a variance
or ratio explicitly is different from supplying its ingredients to a linear
classifier. This separation agrees with the
[generalised signature method](https://arxiv.org/abs/2006.00873), which treats
representation choices as part of the method.

The complexity choices have distinct meanings:

- **Observable degree** determines what happens at one sample: a value,
  square, product, norm, threshold or kernel response.
- **Code width P** determines position resolution. Pascal P spans polynomials
  of degree at most \(P-1\); Fourier columns target oscillations; interval
  indicators select locations.
- **Depth m** determines the number of ordered factors. Increasing Pascal P
  does not increase polynomial degree in signal values. If the composed
  observables \(\phi_i(Tx)\) are polynomial of degree at most \(q\) in the
  original samples, level \(m\) has degree at most \(qm\). FFT power, for
  example, already has degree two before taking a signature. Nonpolynomial
  observables such as norms and thresholds do not have this degree count.

QR changes the basis and conditioning of the Pascal space, not its information
at fixed P and depth. Full tensors have
\(\sum_{k=1}^m(dP)^k\) coordinates. For six channels, P3 gives 342 at depth two,
6,174 at depth three and 111,150 at depth four. Modest grids and selected
readouts therefore matter for a fast experiment. P here is the number of
Pascal columns; the Fourier–Pascal sweep has \(1+2P\) actual code columns.

## Family 1: moments and ordered observables

Use identity preprocessing and selected members of

\[
\phi(x)=\bigl(x_i,\ x_i^2,\ x_ix_j,\ |x_i|,\ \|x_G\|,\ x_i^3,\ x_i^4\bigr).
\]

Here \(G\) is any declared channel group, not necessarily a triad. Keep axiswise
observables unless discarding direction is intended. Averaging only two triad
energies is a much coarser specialization.

First levels give mean, energy, simultaneous cross-moment, absolute magnitude
and higher raw moments. With
\(\mu_i=\operatorname{mean}(x_i)\) and \(M_{ij}=\operatorname{mean}(x_ix_j)\),

\[
\operatorname{var}(x_i)=M_{ii}-\mu_i^2,\qquad
\operatorname{corr}(x_i,x_j)=
\frac{M_{ij}-\mu_i\mu_j}
{\sqrt{(M_{ii}-\mu_i^2)(M_{jj}-\mu_j^2)}}.
\]

These are exact population-statistic identities for nonzero denominators.
Central third/fourth moments similarly follow from the first four raw moments.
Standard deviation and normalized skewness/kurtosis need a nonlinear readout
and a declared zero-variance convention. Pooling absolute values generalizes
magnitude area; matching the source's normalization requires its convention.

A **moment of values** differs from a **product of moments**. An ordinary scalar
integrated path has \(S^{11}=\tfrac12\operatorname{mean}(x)^2\), not
\(\tfrac12\operatorname{mean}(x^2)\). Increasing its depth never recovers sample
energy: its entire signature depends on its endpoint. Including \(x^2\) as an
observable, or retaining discrete covariation through lead–lag, addresses this.

For two observables the geometric second level is

\[
S^{ij}=\frac1{M^2}\sum_{r<s}\phi_i(u_r)\phi_j(u_s)
+\frac1{2M^2}\sum_r\phi_i(u_r)\phi_j(u_r).
\]

Its antisymmetric part measures which observable tends to come first.
Acceleration energy before angular speed differs from the reverse order.
Pascal coding additionally weights early/late occurrences or, after a
contraction, moments of their time gap. Depth three adds three-factor ordering.
Symmetric tensor coordinates also contain products of lower-order statistics,
so a ridge gain from full tensors need not come entirely from order information.

## Family 2: filters, derivatives and lag responses

Choose a small bank of fixed linear filters or delays, for example

\[
u_r=\bigl(x_r,\ x_{r-\ell},\ (x_r-x_{r-1})/\delta t,\ (h_b*x)_r\bigr),
\]

then apply the same observable/signature construction. The filter index \(b\)
can range over smoothing or band-pass scales. Derivative-energy features become
second moments of transformed channels. Integrating a derivative alone mostly
telescopes to an endpoint difference; integrate its square or absolute value
when the target is roughness.

The observable \(\phi_{ij,\ell}(u_r)=x_r^ix_{r-\ell}^j\) gives lagged
cross-products at first level. Valid-window averages give exact empirical lag
statistics for that convention. Padding and normalization must remain explicit.
This generalizes to arbitrary sensor pairs and lags without defining a new
activity-specific statistic for each combination.

Autoregression shows why readouts should stay separate. For order \(L\), let
\(v_r=(x_{r-1},\ldots,x_{r-L})\). A zero-intercept ridge autoregression with
\(\lambda>0\) is determined by

\[
A=\sum_rv_rv_r^\top,\qquad b=\sum_rv_rx_r,\qquad
\widehat a=(A+\lambda I)^{-1}b.
\]

Entries of \(A,b\) are pooled product observables, hence integrated first levels
provide their ingredients; a constant coordinate in \(v_r\) adds an intercept.
The solve is nonlinear. **This is not Burg's
algorithm**, which uses a different forward/backward prediction recursion.
It is a generic prediction-statistic alternative to the 80 Burg columns.
Signatures of the product sequence record how these relationships change
within a window.

Lag can also be the ordering variable: first compute a correlation-matrix
sequence \(R(\ell)\), then integrate selected entries in increasing lag order.
Pascal first levels give smooth lag summaries; higher levels describe the
correlation curve across scales. This loses original event locations, so it
differs from taking the time-ordered signature of delayed products.

## Family 3: spectral moments and signatures over frequency

Two constructions that both involve Fourier analysis retain different order.

**Fourier codes on time samples.** For integrated samples, a complex code
\(e^{-2\pi i kr/M}\) gives exactly the normalized DFT coefficient at first level:

\[
F_i(k)=\frac1M\sum_rx_r^ie^{-2\pi i kr/M}.
\]

Cosine and negative-sine columns store its real and imaginary parts. Products of first
levels give power and cross-spectra; the geometric shuffle identity
\(S^aS^b=S^{ab}+S^{ba}\) expresses those products as linear depth-two readouts.
Summing the appropriate powers gives band energies, with the chosen endpoint
weights and normalization. A few selected frequencies do not recover arbitrary
bands exactly. Higher levels here still order **time samples**.

**FFT first, signature indexed by frequency.** Compute amplitude
\(A_i(k)=|F_i(k)|\), power \(E_i(k)=|F_i(k)|^2\), or real/imaginary cross-spectral
entries. Treat these as values ordered by frequency \(\nu_k\), integrate them
and code by frequency. For example,

\[
m_i^{(q)}=\sum_k\nu_k^qE_i(k),\qquad
b_{i,B}=\sum_{k\in B}E_i(k)
\]

are first-level readouts using polynomial and band-indicator codes, with an
overall factor if increments are divided by the number of bins. Pascal QR spans
the polynomial weights on a uniform frequency grid, giving smooth
spectral-location summaries. A normalized centroid \(m^{(1)}/m^{(0)}\), spread
and higher moments follow by explicit readouts. Amplitude-weighted and
power-weighted centroids differ; the choice should be named.

Another kind of spectral moment describes the **amplitude distribution across
bins**. Mean/std/skewness/kurtosis of an FFT magnitude array follow from pooled
\(A,A^2,A^3,A^4\) and normalization. They are not moments of frequency locations
weighted by spectral mass. Both constructions fit this family, but use
different observables and codes.

Second levels of a multichannel spectral-energy path describe cross-band
relationships: low-frequency power in one channel followed, along the
frequency axis, by high-frequency power in another. A scalar spectral path
again needs a frequency clock, nonconstant codes or more observables to retain
more than total energy. Taking powers erases phase, so their signature cannot
recover the time ordering lost by that pretransform.

Fourier–Pascal **time codes** multiply Fourier carriers by polynomial factors.
Their first levels measure spectral coefficients and frequency derivatives;
later levels describe modulated temporal interactions. This remains distinct
from Pascal coding of an FFT power sequence. Derivations are in
[pascal_investigation.md](pascal_investigation.md).

## Family 4: distributions, thresholds and soft states

Use fixed bin indicators, smooth thresholds or a small kernel dictionary as
observables. For a partition \(B_j\), take
\(\phi_j(x_r)=\mathbf1\{x_r\in B_j\}\). Integrated first levels are empirical
bin probabilities. A soft partition gives a smooth analogue. Thresholds,
centers and widths can be fixed or estimated from training values.

The readout \(-\sum_jp_j\log p_j\), with \(0\log0=0\), gives histogram entropy.
Cumulative masses give an approximate CDF and quantiles. Finite bins generally
only approximate IQR and median absolute deviation; exact sample quantiles need
the underlying order statistics. This does not identify the source's
unspecified entropy estimator.

Coding state indicators gives time-weighted occupation measures. Their second
levels describe whether one state tends to precede another. The generator
extends a histogram into an order description without manually defining each
event pattern. Products or multivariate kernels supply joint states.

Extrema are naturally nonlinear readouts too. For \(\beta>0\),

\[
\max_rx_r-\frac{\log M}{\beta}
\leq\frac1\beta\log\!\left(\frac1M\sum_re^{\beta x_r}\right)
\leq\max_rx_r.
\]

The middle quantity integrates an exponential observable and applies a
logarithm. It approximates the maximum with a visible bound; it is not an exact
finite raw-signature coordinate. A stable log-sum-exp evaluates it numerically.

An alternative pretransform is the empirical quantile curve: sort values and
form a path in quantile position. Coding/signatures then describe distribution
shape, deliberately discarding chronology. Alternatively replace values by
ranks **while preserving time order**, and take the coded signature of that
sequence. This keeps order patterns while reducing amplitude dependence.

## Family 5: geometric contractions and reference directions

For vector-valued channel groups, integrated first levels recover mean vectors.
Their dot products and norms give cosine similarities; arccos gives angles for
nonzero norms. This recovers the underlying mean-vector construction of the
seven angle columns when source vectors and conventions match.

Contracting spatial indices of higher signature tensors with dot products gives
quantities unchanged by a common orthogonal rotation of the vector groups.
Pascal/Fourier codes act on position indices and can coexist with these spatial
contractions. A fixed gravity or device-axis reference instead measures
orientation relative to that reference. Full rotation invariance would remove
some posture information used by the 561 table. Axiswise unequal scaling also
breaks simple Euclidean rotation invariance; make contractions before it, or
use a common scale for each vector group.

A modality quotient removes selected order interactions. It does not by itself
produce rotation invariance or normalized statistical correlations.

## A discrete algebra particularly close to the handcrafted features

A signature-like object can have letters that mean same-sample products.
For unnormalized increments \(z_r\), define

\[
I^i=\sum_rz_r^i,\qquad I^{ij}=\sum_{r<s}z_r^iz_s^j,\qquad
I^{[ij]}=\sum_rz_r^iz_r^j.
\]

Splitting the product of sums into the three index relations gives

\[
I^iI^j=I^{ij}+I^{ji}+I^{[ij]}.
\]

The bracketed letter means “multiply at the same sample”; the two-letter words
mean “multiply at strictly ordered samples.” This is the quasi-shuffle identity
underlying [iterated-sums signatures](https://arxiv.org/abs/1906.05823).
It organizes covariance, moments and temporal ordering in one algebra.
Normalization matters: with \(z=x/M\),
\(I^{[ij]}=\operatorname{mean}(x_ix_j)/M\).

The geometric transform gives \(S^{ij}=I^{ij}+I^{[ij]}/2\). Thus direct
diagonal-product features plus a geometric depth-two signature already recover
these discrete second-order features. Higher orders need the corresponding
merged-product corrections; merely renaming a geometric signature is
incorrect. This algebraic connection does not require a new engine for HAR:
observable integration and direct readouts can test the low-order cases with
existing tensorsig.

## What the new prototype implements

The ridge-only sweep in [benchmark.py](benchmark.py) uses the reusable
[generators.py](generators.py) pretransform followed by sample integration and
Pascal QR coding. It keeps train-global channel scaling, with no per-window
centering or extra posture block.

| Pretransform | Sequence before integration | Interpretation |
|---|---|---|
| Identity | Six total-acceleration/gyro axes | Current Pascal reference; P/depth sweep |
| Difference | Consecutive differences, length 127 | Change sequence; no physical time-unit factor |
| Energy | Axiswise squares, length 128 | First level supplies six second moments; later levels retain their order |
| Lag product | Axiswise products at valid lag two, length 126 | First level supplies short-lag product means; later levels retain their order |
| Spectral power | One-sided FFT power with Parseval weights, multiplied by the bin count | Integrated first level recovers each channel's mean square; the ordering axis is frequency |

The four extra pretransforms compare P1/P3 and depths one/two, alone and
appended to 561. Identity additionally gets the larger P/depth sweep and
Fourier–Pascal time codes. P1 is an ordinary integrated signature up to a
constant code scaling. This experiment covers small members of the moment,
lag and spectral families. It does **not** implement the whole filter bank,
cross-channel observable dictionary, histogram/quantile, AR-solve or rotation
families described above.

A useful next control for any linear head is products of pooled/coded first
levels: it separates polynomial feature expansion from genuinely ordered
information. The earlier observable experiment already used this control.
There is no need to run every cross-product of transforms, dictionaries, P and
depth; expand a family when a compact member is useful.

The intended alternative to a list of 561 named statistics is a few composable
generators. Some original statistics become exact low-order readouts, others
need a spectral/distributional pretransform, and some remain nonlinear or
approximate. Preserving these distinctions makes the family both generic and
mathematically clear.

## Richer families: the implemented comparison

[families.py](families.py) now supplies four families to the ridge-only
[family_sweep.py](family_sweep.py). Gravity is supplied total acceleration minus
supplied body acceleration. Unless stated otherwise, each axis is centered and
scaled using training windows and time points, without per-window centering.
Each declared group is integrated and signed independently; the resulting
coordinates are concatenated. This retains within-group ordering but omits
signature words spanning different groups. It is a selected collection of
signatures, not the full joint signature of all observations.

| Family | Sequences supplied to the signature | Pooled features before removing constants |
|---|---|---:|
| Moments | Three six-channel groups: axes and their squares for body acceleration, gravity and gyro | 105 |
| Filters and delays | Four six-channel groups: axes and squares after one-step differences or trailing-five-mean subtraction, for body acceleration and gyro; four three-channel groups: their valid lag-two/five axiswise products | 146 |
| Spectral | Five four-channel groups: normalized one-sided power of xyz and norm for body acceleration, gravity, gyro and the two dynamic differences, ordered by frequency | 360 |
| Rotation | Four three-channel groups: triad energies, three cross-triad dot products, and within-triad lag-two/five dot products | 114 |

The common pooled summary contains mean, population standard deviation, mean
absolute value, RMS, standardized third/fourth central moments, minimum and
maximum. Moments apply it to xyz and norm and add within-triad correlations.
Filters apply it to the four filtered xyz-plus-norm groups and add centered
lag-one/two/five correlations. The trailing filter repeats the first sample for
missing history; delayed products use only valid pairs and receive their own
training scaling. Differences omit the constant 50 Hz derivative factor.

Spectral pooling retains total energy, log(1 + energy), frequency centroid,
spread, entropy, peak location and eight equal-width band masses, plus
mean/std/skew/kurtosis of the square roots of the Parseval-weighted bin energies.
The FFT includes DC and, for even sequence lengths, Nyquist; paired interior
bins receive factor two. The norm is computed before its FFT, so this is not
the sum of three axis spectra. Frequency is expressed relative to 25 Hz.
These are explicit generic conventions, not a reconstruction of the 561 table.

For one spectral channel, write its bin energies as \(E_k\) and normalized mass
as \(p_k=E_k/\sum_j E_j\). The implementation floors the denominator at
\(10^{-20}\), giving zero mass to an identically zero signal. It supplies
\(M p_k\) as observations for \(M\) bins, so integration gives increments
\(p_k\). Absolute energy is retained separately in the pooled features.
For a spectrum above the denominator floor, let \(Q\) be its three-column QR
Pascal code, \(f_k\) the frequency grid, and
\(b_1=Q^\top f\), \(b_2=Q^\top(f^2)\). Because the columns span quadratic
polynomials on the grid, the coded first level \(L\) and second level \(S\)
of this channel give

\[
\mu_f=b_1^\top L,\qquad
\operatorname{Var}_p(f)=b_2^\top L
 -2\sum_{a,b}(b_1)_a(b_1)_b S^{ab}.
\]

The second identity uses the shuffle relation to recover \(\mu_f^2\).
Thus centroid and variance are linear readouts of P3, depth two; standard
deviation still requires a square root. Additional depth-two coordinates
describe ordered relationships between frequency masses, including across axes
within each group. Power has already discarded phase. At P1, spectral first
levels carry only fixed mass, so their variation cannot describe spectral shape.

The rotation family divides each raw triad by one training RMS scalar, without
axiswise centering, before taking its dot products. Its pooled summaries also
include mean/std of normalized simultaneous and lagged dot products. One common
orthogonal transformation applied to every sample and triad in a window leaves
all these streams, their pooled readouts and all coded signatures unchanged.
Appending the raw total-acceleration/gyro reference destroys this invariance;
that hybrid tests complementary posture information. These contracted streams
also differ from spatial contractions of a raw vector signature: the latter can
retain cross-time dot products beyond the selected lags used here.

The grid is \(P\in\{1,2,3,4\}\), depth \(\in\{1,2,3\}\), retaining at most
7,000 signature coordinates before appending pooled or reference features.
All P values retain depths one/two. At depth three, moments retain P1/P2,
filters P1, spectra P1/P2, rotation P1/P2/P3, and the combined family P1.
Every code uses QR; P1 is the ordinary integrated signature up to fixed scales
per level. QR conditions the position basis, not the whole feature matrix.

Controls compare pooled features with pooled-plus-signature features, each with
and without the 342-coordinate raw Pascal P3 QR depth-two reference. P3 depth
two additionally has signature-only and pooled-plus-first-level-product controls.
The latter supplies symmetric polynomial information without the antisymmetric
ordering coordinates. The combined families concatenate all their blocks; two
fixed pooled hybrids also append the 561 columns. All fits use standardized
ridge with alpha 10, and remove numerically constant columns using training
values only. Scores and timings are recorded separately in the README/results.

## Compact spectral signatures: moments and pairwise dispersion

[spectral_readouts.py](spectral_readouts.py) makes the extra spectral information
and its dimension explicit. Consider one nonzero spectrum with normalized bin
masses \(p_r\), \(\sum_r p_r=1\), at increasing frequencies \(f_r\in[0,1]\).
In the polynomial basis, P3 integrates the increments
\(\Delta Z_r=p_r(1,f_r,f_r^2)\). QR gives an invertible change of this basis;
the following identities become fixed linear readouts of the QR coordinates.
The first level contains \(1,m_1,m_2\), where
\(m_j=\sum_r p_r f_r^j\). Thus P3 is the smallest Pascal width spanning the
quadratic frequency weights needed for centroid and variance. Depth two makes
\(m_1^2\), and hence variance, a linear readout by shuffle. This justifies
moment coverage, not optimal classification accuracy.

To see what the remaining coordinates describe, define
\(D_{ab}=S^{ab}-S^{ba}\) for polynomial degrees \(a,b\in\{0,1,2\}\).
The same-bin terms cancel, leaving

\[
D_{ab}=\sum_{r<s}p_rp_s
\bigl(f_r^a f_s^b-f_r^b f_s^a\bigr).
\]

If \(F,G\) are independent frequencies drawn from the bin masses, this gives

\[
D_{01}=\tfrac12\mathbb E|F-G|,\qquad
D_{02}=\tfrac12\mathbb E|F^2-G^2|,\qquad
D_{12}=\tfrac12\mathbb E[FG|F-G|].
\]

These measure pairwise separation, optionally giving higher frequencies more
weight. The conventional signed area is \(A_{ab}=D_{ab}/2\), so its expectation
coefficients are \(1/4\). The module instead retains the orthonormal coordinate
\(D_{ab}/\sqrt2\); none of these conventions changes the available information.

For a concrete distinction from moments and bands, put masses
\((1/4,1/4,1/4,1/4)\) or \((1/5,2/5,1/10,3/10)\) on frequencies
\((0,1/64,2/64,3/64)\), and zero elsewhere. Both spectra have centroid
\(3/128\), variance \(5/16384\), and identical masses in the eight equal-width
bands: everything lies in the first band. Nevertheless, \(A_{01}\) is
\(5/1024\) for the first and \(61/12800\) for the second. The area distinguishes
shapes those summaries cannot; other pooled summaries, such as entropy, may
also distinguish them.

For one normalized channel, all nonconstant linear depth-two readouts are
spanned by eight quantities:

\[
m_1,\ m_2,\ m_1^2,\ m_1m_2,\ m_2^2,\ D_{01},\ D_{02},\ D_{12}.
\]

The mass coordinate is fixed, and shuffle expresses the symmetric second level
through endpoint products. Applying this reduction independently to the twenty
spectral channels gives **160 coordinates**. It deliberately omits interactions
between different channels. To retain those interactions in a group of \(C\)
channels, keep its \(2C\) varying endpoints, their
\(2C(2C+1)/2\) symmetric products, and all \(3C(3C-1)/2\) antisymmetric
coordinates. For each four-channel group this gives 110 coordinates, hence
**550 across five groups**, retaining every full P3/depth-two linear readout
up to an intercept. The module constructs an orthonormal reduction of this
affine space and checks that differences between signatures retain their norms.
Unit mass is required; zero-mass channels are rejected by this compact readout.

Ordinary P1 signatures are a useful control: their first levels are constant,
and each scalar channel's entire signature is constant, but cross-channel
areas still compare which channel places mass at lower frequencies. Power
spectra discard phase before any of these signatures are taken; frequency-pair
dispersion cannot restore it. Finally, standardizing compact coordinates changes
ridge's penalty geometry even when the linear span is preserved. Differences
between full and compact fits therefore need not reflect lost information.

## A generic explanation for the remaining small readouts

The remaining features describe **amplitude concentration, absolute energy and
relative geometry**, alongside the raw path's temporal order and the normalized
spectrum's frequency locations. [moment_lifts.py](moment_lifts.py) implements
these as observable integrals using tensorsig. The observable is chosen at each
sample or frequency bin, before pooling; this gives reusable families rather
than encoding an already computed window statistic as a constant path.

For a scalar observation sequence \(z_k\), integrate the polynomial lift
\((z_k,z_k^2,\ldots,z_k^r)/N\). Its first signature level, which also equals its
first logsignature level, contains the raw moments
\(M_j=N^{-1}\sum_k z_k^j\). A constant QR code only rescales these endpoints;
the implementation removes that known scale. Mean and variance follow from
\(M_1\) and \(M_2-M_1^2\). Standard deviation needs a square root, and skewness
and kurtosis need centralization and division by powers of the standard
deviation. These are explicit nonlinear readouts, not linear coordinates of the
untransformed logsignature. Degrees two and four have clear coverage meanings:
mean/variance and standardized third/fourth moments, respectively.

There is also a direct ordinary-signature interpretation. Anchor a graph path
at value zero, change its value to \(z_k\) while keeping its clock fixed, then
hold that value while advancing the clock by \(1/N\). For this staircase path,

\[
S^{\underbrace{z\cdots z}_{j}\,t}
=\frac{1}{j!}\int z(t)^j\,dt=\frac{M_j}{j!}.
\]

The scalar prefix signature contributes \(z(t)^j/j!\); the final clock letter
integrates it. Thus the polynomial lift moves selected depth-\((j+1)\) graph
signature readouts into level one. The staircase convention makes this identity
exact for sample moments; straight interpolation would integrate different
values between samples. The identity has been checked with tensorsig through
degree four. Higher codes and depths can subsequently describe where these
observations occur and how they are ordered, but are unnecessary for the means.

For spectral bin energies \(e_k\), write
\(E=\sum_k e_k\), \(p_k=e_k/E\), \(a_k=\sqrt{e_k}\), and let \(K\) be the
number of bins. When \(E>0\), define the concentration sums
\(\tau_q=\sum_k p_k^q\). Then

\[
\frac1K\sum_k a_k^r=\frac{E^{r/2}}K\tau_{r/2},\qquad r=1,2,3,4.
\]

Since \(\tau_1=1\), energy and just three concentration coordinates,
\(\tau_{1/2},\tau_{3/2},\tau_2\), determine the four amplitude moments.
Twenty scalar spectra give 60 concentration columns plus 20 energy columns.
Each concentration is a level-one integral of a fixed power observable of the
bin mass. These describe how mass is distributed across bins, independently of
their locations: if mass is uniform on \(L\) bins, \(\tau_q=L^{1-q}\).
They complement frequency moments, which also depend on where those bins lie.
The bin grid still matters; these quantities are not resolution invariant.
Energy is necessary because multiplying every \(e_k\) by the same positive
factor leaves both the normalized spectral signature and concentrations
unchanged. Log-energy and standardized amplitude shape are optional nonlinear
readouts of this small generator, with the implementation's zero-variance
conventions. This reconstruction does not make their linear ridge fits equal.

For relative geometry, use the three pairwise cosine streams
\(c_{gh}(t)=\langle v_g(t),v_h(t)\rangle/(\|v_g(t)\|\|v_h(t)\|)\), with
the fixed small-denominator convention used in the code. Integrating
\((c_{gh},c_{gh}^2)\) gives six moment coordinates; mean/std is another readout
of them. Norm squares and unnormalized Gram entries supply parallel energy and
cross-product families. All are invariant under one common orthogonal
transformation of the triads, using their common-per-triad scaling. These
same-time contractions differ from contracting a raw signature tensor, which
integrates products at different times. Their useful information therefore has
a geometric explanation beyond adding another raw temporal signature.

Finally, a normalized scalar P3/depth-two spectral **logsignature** needs just
two varying endpoints and three areas: 100 columns for twenty spectra. It
retains the full truncated signature under nonlinear reconstruction,
\(S_2=(\log S)_2+\tfrac12 S_1\otimes S_1\). A linear ridge head on logsignature
coordinates cannot automatically form those endpoint products; adding them
recovers the 160-coordinate within-channel tensor readout's linear span.
P3/depth two is justified by quadratic location moments and pairwise dispersion;
low-degree observable lifts supply amplitude concentration and geometry. These
coverage statements motivate small, composable families without claiming that
the particular degree choices guarantee classification performance.
