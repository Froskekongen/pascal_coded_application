# Observable graph logsignatures for UCI HAR

**All four remaining feature families have a common signature construction.**
A log cumulative-energy path recovers the 20 log-energy coordinates. A small
value–clock graph captures the moments of amplitudes, cosines and invariant
observables. Applying explicit mean/std/skew readouts recovers the previous
**97.79% with 373 features**, with identical test predictions. Adding selected
logsignature coordinates of standardized observable graphs gives **97.93%
with 393 features**, or **98.00% with 429 features**.

This is the same exploratory UCI subject split, 7,352 training and 2,947 test
windows, fixed ridge alpha 10, and training-only feature scaling. The fixed
base is **raw Pascal P3 QR depth-two log171 + spectral Pascal P3 QR depth-two
log100**. No construction appends supplied 561 features; their separate ridge
baseline remains 95.72%. These are descriptive comparisons on the repeatedly
used test split, not validation-selected accuracy estimates.

## One path construction for three of the families

For a scalar sequence, alternate a jump to the observed value and a clock
advance of 1/N. Start the value at zero and return it to zero after the last
observation. This is a staircase with horizontal holds, not linear
interpolation between observations. For value letter x and clock letter t,

\[
(\log S)^{x^r t}=\frac{1}{r!N}\sum_k z_k^r.
\]

The mean is therefore a depth-two logsignature coordinate. The second raw
moment appears at depth three and the third at depth four. Each graph has just
two channels: a full logsignature through depth four has eight Lie coordinates,
of which the two endpoints are fixed. Graphs are computed independently per
observable, so dimension grows linearly with the number of scalar streams.

| Family | Pre-transform / observations | Sufficient signature construction |
|---|---|---|
| Spectral log-energy, 20 | One-sided spectral bin powers p | First level of the path log(1 + cumulative sum of p) |
| Amplitude mean/std, 40 | Square roots of those powers | Value–clock graph depth 3; mean and sqrt(second moment − mean²) |
| Cross-triad cosine mean/std, 6 | Three normalized simultaneous dot products | Same graph depth 3 and moment readout |
| Invariant mean/std/skew, 36 | Three energies, three cross-triad dots, and three self-dots at each of lags 2 and 5 | Same graph depth 4; mean, std and normalized third central moment |

The full definitions and proof are in [occupation_theory.md](occupation_theory.md).
Spectral power uses the existing train-scaled body, gravity, gyro and two
difference groups, with xyz and norm in each group. Rotation contractions use
one uncentered training RMS per triad. The invariance belongs to these
observable branches; the complete model still includes raw device axes.

**Std and skew remain nonlinear readouts.** The logsignature exposes enough
information, but ridge does not automatically take square roots or divide by
variance. We expose these generic readouts explicitly. For numerical stability,
the code obtains mean from one graph, then central moments from a graph of the
centered sequence. Every signature is computed by tensorsig. This replaces
fragile subtraction of nearly equal raw moments, especially for gravity energy.

## What the comparisons show

Every row below includes the fixed 271-feature raw/spectral base. “Calibrated”
means the 102 mean/std/skew/log-energy readouts recovered through the paths.

| Additional representation | Total features | Accuracy | Errors |
|---|---:|---:|---:|
| None | 271 | 93.48% | 192 |
| Previous direct pool102 | 373 | 97.79% | 65 |
| Selected raw moment coordinates + log-energy | 373 | 97.01% | 88 |
| Full observable graphs, depth 3 + log-energy | 396 | 96.98% | 89 |
| Full observable graphs, depth 4 + log-energy | 501 | 97.22% | 82 |
| Calibrated graph readouts | 373 | 97.79% | 65 |
| Calibrated + 20 normalized amplitude-order coordinates | 393 | 97.93% | 61 |
| Calibrated + 20 amplitude and 3 cosine order coordinates | 396 | 97.96% | 60 |
| Calibrated + 36 normalized invariant-order coordinates | 409 | 97.96% | 60 |
| Calibrated + amplitude20 + invariant36 ordering | 429 | **98.00%** | **59** |
| Calibrated + all 105 depth-four ordering coordinates | 478 | 97.86% | 63 |

The 393-feature model corrects seven errors and introduces three relative to
the direct pool102. The 429-feature model corrects ten and introduces four.
Those small differences are useful exploratory evidence, not a claim that one
construction is statistically superior.

The additional ordering coordinates are genuine logsignature coordinates of
the standardized observable sequence (z − mean)/std. For amplitudes and
cosines, the first added word is xtt, one coordinate per stream:

\[
(\log S)^{xtt}=\int_0^1 (1/2-t)\,x(t)\,dt.
\]

It distinguishes large early values from large late values, independently of
scale. For the twelve invariant streams, we retain xtt, xxtt and xttt, adding
36 coordinates. Their interpretation and normalization follow from the number
of value letters, not from a search over arbitrary statistics. Constant streams
receive zero normalized ordering coordinates.

These supplement the baseline for concrete reasons. Normalized spectral power
discards absolute energy, while log-energy restores it. Amplitude graphs weight
bins by the square root of power and describe the distribution and ordering of
those amplitudes, rather than power-weighted spectral location alone. Cosine
and Gram streams expose simultaneous or fixed-delay sensor geometry before
integration; these are different observables from cross-time interactions in
the raw coded path.

Unnormalized ordering helps much less: the 20 amplitude-order coordinates leave
accuracy at 97.79%, and the 36 invariant-order coordinates reach 97.83%.
Normalization is doing useful work for the fixed linear head. Adding every
available coordinate is unnecessary.

## Separating representation from readout

Replacing just one original block, while retaining the other three direct
blocks, isolates the effect of feeding raw moments instead of mean/std/skew:

| Replaced block | Raw moments | Full graph at sufficient depth | Calibrated graph |
|---|---:|---:|---:|
| Amplitude40 | 97.59% | 97.73% (depth 3) | 97.79% |
| Cosine6 | 97.05% | 97.18% (depth 3) | 97.79% |
| Invariant36 | 97.49% | 97.52% (depth 4) | 97.79% |

The cosine block is particularly sensitive to making std explicitly available.
This is why “the signature contains the information” is insufficient to explain
classification performance. A useful generic family should include its
normalization and readout conventions.

## Does extra coding help the log-energy path?

P1 gives exactly the 20 original log-energy values. QR Pascal P2/P3 code its
increments along frequency, retaining location and area information. With the
other calibrated families fixed:

| Log-energy representation | Total features | Accuracy |
|---|---:|---:|
| P1 endpoint | 373 | 97.79% |
| P2 first level | 393 | 97.69% |
| P2 depth-two log | 413 | 97.83% |
| P3 first level | 413 | 97.56% |
| P3 depth-two log | 473 | 97.76% |

The extra energy coding offers little here. The compact P1 endpoint is a good
default alongside the existing spectral Pascal logsignature. Ordinary
value–clock graphs have no polynomial code basis to condition; every Pascal
code in the run uses QR.

## Reproduce and inspect

```sh
../tensorsig/.venv/bin/python examples/uci_har/benchmark.py --occupations
../tensorsig/.venv/bin/python examples/uci_har/benchmark.py --self-check
```

All 57 comparisons complete in about 20 seconds on this machine, single-threaded
for numerical work. Individual ridge fits take hundredths of a second. Reported
graph extraction times conservatively include both raw and centered passes,
and extraction shared by multiple readouts; they should not be added across
rows. Depth-three variants reuse the computed depth-four tensors. Exact run
timings, confusion matrices, numerical checks and paired prediction counts are
saved in [run.json](occupation_results/run.json).

- [Complete results](occupation_results/RESULTS.md) and [CSV](occupation_results/results.csv)
- [Generic staircase implementation](occupation_graph.py)
- [Experiment and log-energy implementation](occupation_experiment.py)
- [Theory, including coded occupation moments and expected-signature cumulants](occupation_theory.md)
- [Separate tensorsig suggestions](tensorsig_suggestions.md)

The working family is therefore **observable transform → small graph
logsignature → explicit scale/shape readout**, supplemented by a few normalized
ordering coordinates. Its depths are justified by the required moment order,
and the same construction applies across time, frequency and invariant streams.
