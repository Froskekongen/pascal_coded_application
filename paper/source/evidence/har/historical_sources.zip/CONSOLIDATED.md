# Consolidated HAR comparison

We retain the **368-feature compact model**, the **803-feature reduced
spectral/rotation pool + raw Pascal**, and **561 + raw Pascal P3/depth 2**
(903 features). The new run reproduces their previous confusion matrices
exactly. It compares ordinary-signature replacements while keeping the other
blocks and the ridge head fixed.

The result supports raw coding in the two generic models and spectral coding
as a compact representation. It does **not** establish that Pascal signatures
are more expressive than ordinary signatures of suitably transformed paths.
Several exact ordinary constructions reproduce the coded features and every
test prediction. With the supplied 561 features, the best conventional ordinary
replacement is only two errors behind Pascal and uses fewer coordinates.

## Fixed models and experiment

| Model | Recipe after constant removal | Features | Accuracy | Macro F1 | Errors |
|---|---|---:|---:|---:|---:|
| Compact | Raw log171 + spectral log100 + calibrated moments82 + graph trends15 | 368 | 98.03% | 98.06% | 58 |
| Reduced pool | Spectral pool359 + rotation pool102 + raw tensor342 | 803 | 98.10% | 98.14% | 56 |
| Supplied-feature hybrid | UCI561 + raw tensor342 | 903 | 97.12% | 97.16% | 85 |
| Supplied-feature reference | UCI561 alone | 561 | 95.72% | 95.85% | 126 |

Both raw branches integrate total acceleration and gyroscope samples, using
Pascal QR P3 codes and signature depth 2. The tensor has 18 + 18² = 342
coordinates; the logsignature has 18 + 153 = 171. The compact spectral branch
has 20 independent scalar spectra, each contributing five nonconstant P3/depth-2
logsignature coordinates. There are no supplied 561 features in either generic
model. The reduced pool retains richer amplitude statistics, energy, entropy,
peaks and bands; it is a performance comparator, not the compact construction.

The official UCI split has 7,352 training and 2,947 test windows from disjoint
subjects. Each window contains 128 samples at 50 Hz. We use a single fixed
ridge head with alpha 10, training-only feature scaling and the existing
float64 general-LU solver. Raw axis scaling also uses training data only.
The representations were explored over many previous runs on this test split;
these are descriptive research comparisons, not held-out model-selection
claims. We do not tune a separate alpha for every embedding.

Run:

```sh
../tensorsig/.venv/bin/python examples/uci_har/benchmark.py --consolidated
```

The run contains **187 fits**. Complete rows, settings, confusion matrices and
paired errors are in [consolidated_results](consolidated_results/RESULTS.md),
[results.csv](consolidated_results/results.csv) and
[run.json](consolidated_results/run.json). The 52 ordinary raw representations
are each tested in all three fixed contexts.

## Replace only the raw signature branch

The matched controls use the same total-acceleration/gyroscope inputs and raw
training scaling as Pascal. We test sample paths with a clock; an origin
basepoint; integrated samples with and without a clock; lags 1, 2 and 5;
staircase lead–lag; integrated lead–lag; and the two interpretations of the
reference paper's embedding described below. Tensor and logsignature readouts
are both included where they fit the fixed budget. Time, anchored and integrated
paths use depths 2–4; delay and lead–lag paths use depths 2–3.

| Fixed context | Pascal result | Best conventional ordinary replacement | Total features | Accuracy | Additional errors |
|---|---:|---|---:|---:|---:|
| Compact | 368 / 98.03% | Lead–lag tensor, depth 2 | 377 | 97.46% | 17 |
| Reduced pool | 803 / 98.10% | Lag-1 tensor, depth 2 | 641 | 97.83% | 8 |
| Supplied 561 | 903 / 97.12% | Anchored tensor, depth 2 | 615 | 97.05% | 2 |

“Best” here is the descriptive test-accuracy maximum over this fixed
control set. It excludes the deliberately equivalent polynomial lift below.
All three maxima use the matched total-acceleration source. With a total
feature budget at most 368, the best matched raw replacement is time-augmented
depth-2 logsignature: 224 features and 97.22%. A body-acceleration paper variant
gives 299 features and 97.25%, but also changes the sensor input.

The paired comparisons are more informative than the rounded percentages.
Relative to the compact model, the lead–lag replacement corrects 15 errors but
introduces 32. The reduced-pool lag replacement corrects 16 and introduces 24.
The supplied-feature anchored replacement corrects 26 and introduces 28. Thus
the 561 comparison is a close tradeoff, not persuasive evidence of a general
Pascal advantage; the smaller ordinary representation is competitive.

Dropping the raw branch entirely gives 96.17% for the 197-feature compact
remainder, 97.18% for the 461-feature reduced pool, and 95.72% for UCI561.
Raw coding contributes useful information in each fixed context. Increasing
ordinary depth within this budget does not close the gap in the generic models.
That observation concerns these embeddings, coordinates and regularization;
it is not a claim about every ordinary-signature method.

### What comes from the reference paper

There is one PDF in [reference_papers](../../reference_papers):
[signature_human_activity.pdf](../../reference_papers/signature_human_activity.pdf).
It uses body acceleration plus gyroscope, with normalized time augmentation.
Section 2.2 describes a simultaneous one-step shift `(x_i, x_{i+1})`; Appendix
A.2 instead describes doubling the time-augmented path length and channel count.
We therefore test both a simultaneous shift and a conventional staircase
lead–lag path, labelled `paper_shift1` and `paper_staircase_leadlag`. A repeated
final point reconciles the staircase's 255 distinct vertices with 256 points
without changing its signature.

The body-source adaptations attain at most 97.35%, 97.69% and 96.17% in the three
contexts. They are supplementary: replacing total acceleration by body
acceleration also removes gravity information from the raw branch. The matched
total-source versions isolate the embedding comparison more closely.

The paper does not prescribe integration, a basepoint, FFT or the other
embeddings we add. It uses a subject-disjoint validation subset, RF/MLP heads
and validation-based selection. We retain our fixed ridge setup and training
input scaling, so this is a comparison of paper-inspired embeddings, **not a
replication of its reported score**. The paper's deepest time signature has
137,256 tensor coordinates; such runs are outside this fast experiment.
Here each raw output is capped at 1,600 coordinates and each dense intermediate
at 3,000; these are branch budgets, before concatenating the fixed context.

## Replace only the spectral signature branch

Hold raw log171 and the 97 graph readouts fixed. For each of the same 20
normalized spectra, construct an ordinary two-dimensional staircase: advance
the frequency clock to the bin, then accumulate that bin's probability mass.
This gives ordinary signatures access to frequency location; an uncoded
one-dimensional unit-mass path would be constant and would be an inadequate
control. Pure clock and pure mass words are deterministic and removed.

| Spectral branch | Spectral features | Total features | Accuracy | Errors |
|---|---:|---:|---:|---:|
| None | 0 | 268 | 96.78% | 95 |
| Ordinary log, depth 2 | 20 | 288 | 97.49% | 74 |
| Ordinary log, depth 3 | 60 | 328 | 97.79% | 65 |
| Ordinary tensor, depth 3 | 160 | 428 | 97.83% | 64 |
| Ordinary log, depth 4 | 120 | 388 | 97.83% | 64 |
| Ordinary tensor, depth 4 | 440 | 708 | 98.00% | 59 |
| Ordinary log, depth 5 | 240 | 508 | 97.93% | 61 |
| Ordinary tensor, depth 5 | 1,040 | 1,308 | 97.83% | 64 |
| **Pascal QR P3/depth-2 log** | **100** | **368** | **98.03%** | **58** |
| Ordinary depth-5 tensor projected onto Pascal readouts | 100 | 368 | 98.03% | 58 |

The strong result is **100 versus 440 spectral coordinates at essentially
equal accuracy**, not a meaningful accuracy win of one window. The ordinary
depth-4 tensor corrects eight Pascal errors and introduces nine. Depth-3 ordinary
logs offer a smaller, slightly less accurate alternative.

Six additional joint replacements use integrated depth-3 or lag-2 depth-2
ordinary raw logsignatures together with spectral depth-4/5 logs or the exact
spectral projection. Their best result is 96.44% with 427 features. They use
the ordinary graph form of the trends too. These are two predetermined joint
raw choices, not an exhaustive search over pairs of embeddings; the
single-branch replacements above are the cleaner attribution experiment.

## Why the remaining 97 coordinates stay

Each calibration block is generated by the same closed value–clock graph,
using selected moment words followed by explicit nonlinear calibration. The
mean/std pair uses depth 3; skewness requires depth 4. The 15 trends use only a
linear Pascal clock and depth 2 on standardized streams. See
[MOTIVATION.md](MOTIVATION.md) for formulas and application reasoning.

| Removed from the compact model | Coordinates removed | Remaining features | Accuracy | Errors |
|---|---:|---:|---:|---:|
| Nothing | 0 | 368 | 98.03% | 58 |
| Spectral-amplitude mean/std | 40 | 328 | 97.15% | 84 |
| Cross-triad cosine mean/std | 6 | 362 | 96.34% | 108 |
| Energy / simultaneous-dot / lagged-dot mean/std/skew | 36 | 332 | 97.42% | 76 |
| Standardized invariant/cosine trends | 15 | 353 | 97.86% | 63 |

These are **calibration-block removals**, not removal of every occurrence of
the underlying phenomenon: energy, alignment or temporal trends can remain
in other branches. They establish conditional usefulness in this frozen
model, not independent causal contributions. The six cosine coordinates are
particularly valuable. Amplitude restores scale lost by spectral normalization;
geometric moments describe vector coordination and persistence; trends locate
those observations within the window. No separate log-energy or band-pooling
block is needed for the retained 368-feature result.

## Exact ordinary equivalences and the claim we can defend

For raw data, explicitly form the 18-dimensional cumulative path with
increments `x_k[i] q_a(k) / N` and apply tensorsig's ordinary signature. Its
depth-2 tensor agrees with the coded extractor to maximum absolute error
3.55e-15 in this run. Replacing the raw branch by this independently computed
ordinary lift changes **zero predictions** in all three models.

For the spectral staircase let `t` denote frequency and `x` cumulative mass.
Before the QR basis change, the P3 endpoints and antisymmetric areas are the
following ordinary tensor-signature readouts:

\[
M=(1,S^{tx},2S^{ttx}),\qquad
D_{01}=S^{xtx},\qquad
D_{02}=2(S^{txtx}+S^{xttx}),\qquad
D_{12}=2(S^{ttxtx}+S^{txttx}).
\]

The highest word length is five. The implementation applies the same QR basis
change and area normalization as the retained coded branch. This projection
changes **zero predictions**, as does replacing the 15 P2 graph trends by the
ordinary depth-3 graph word `xtt` (up to scale).

The interpretation is therefore precise: polynomial coding selects useful
location moments and ordered interactions at low signature depth. QR conditions
that coordinate system. It does not provide an information-theoretic separation
from ordinary signatures, nor is this an advantage unique to Pascal over all
bases of the same polynomial space. Full signatures, logsignatures and projected
coordinates also induce different linear hypothesis classes or penalties after
feature standardization. Our controls evaluate those practical choices together.

## Speed, checks and retained artifacts

The complete run took **148.4 seconds** on this Apple Silicon machine, including
all ordinary embeddings and 187 ridge fits. Fits took at most 0.259 seconds;
test prediction took at most 0.010 seconds. The retained 368/803/903 fits took
0.010/0.033/0.041 seconds and their predictions about 0.002/0.004/0.003 seconds.

Shared preparation of all retained blocks and the ordinary trend control took
8.75 seconds; within it, raw Pascal extraction took 0.31 seconds and spectral
Pascal extraction 0.57 seconds. Ordinary spectral depth 5 and all its readouts
took a shared 5.81 seconds. These are batch measurements over train and test,
not per-window deployment latency. The CSV's extraction column includes shared
preparation, even for deletion ablations; it must not be summed across rows or
interpreted as optimized cost for an individual retained model. The supplied
561-feature extraction cost remains unmeasured.

The feature self-checks and full smoke run pass. All 187 rows agree with their
saved 6-by-6 confusion matrices and macro F1 values; all matrices contain 2,947
windows. Paired error changes are consistent, train/test subjects are disjoint,
and all three retained confusion matrices match their earlier runs. The raw
lift, spectral projection and ordinary graph-trend identities are checked
independently. No tensorsig core changes or new dependencies were needed.

The current recipes and comparisons live in [consolidated.py](consolidated.py),
[ordinary_controls.py](ordinary_controls.py) and
[ordinary_spectral.py](ordinary_spectral.py). Earlier experiments are preserved
in [EXPERIMENT_HISTORY.md](EXPERIMENT_HISTORY.md). Library suggestions stay in
their separate [tensorsig_suggestions.md](tensorsig_suggestions.md).
