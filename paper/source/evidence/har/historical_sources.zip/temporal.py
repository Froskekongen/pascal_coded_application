"""Small temporal-code experiments; see pascal_investigation.md."""

from time import perf_counter

import numpy as np
import torch
from features import _standardize, extract_coded_features
from tensorsig.offset_coded_signatures.codes import OffsetCode


def _readouts(tensor: np.ndarray, width: int) -> dict[str, np.ndarray]:
    first, second = tensor[:, :width], tensor[:, width:].reshape(-1, width, width)
    i, j = np.triu_indices(width, 1)
    return {
        "full_signature": tensor.astype(np.float32),
        "full_logsignature": np.concatenate(
            (first, (second[:, i, j] - second[:, j, i]) / 2), axis=1
        ).astype(np.float32),
    }


def _gap_readout(tensor: np.ndarray, channels: int, demodulated: bool) -> np.ndarray:
    """Linear tensor contractions; same-step half products cancel exactly."""
    copies = 5 if demodulated else 3
    width = channels * copies
    first = tensor[:, :width].reshape(-1, channels, copies)
    second = tensor[:, width:].reshape(-1, channels, copies, channels, copies)

    def word(a, b):
        return second[:, :, a, :, b]

    if demodulated:  # [1, cos, sin, t*cos, t*sin]
        real = word(1, 3) + word(2, 4) - word(3, 1) - word(4, 2)
        imag = word(1, 4) - word(2, 3) - word(3, 2) + word(4, 1)
        blocks = (real, imag)
    else:  # [1,t,t²]
        blocks = (word(0, 1) - word(1, 0),
                  word(0, 2) - 2 * word(1, 1) + word(2, 0))
    return np.concatenate((first[:, :, 0], *(b.reshape(len(tensor), -1) for b in blocks)),
                          axis=1).astype(np.float32)


def extract_pascal_features(signals: np.ndarray, train_size: int, batch_size: int = 256):
    """Certified P3 plus a Fourier×P2 carrier, all on integrated samples.

    P3 QR and normalized Newton tensors contain exactly the same information.
    Gap readouts expose relative lags to the head. They do not make a finite
    window invariant to changing its crop. The fixed carrier is four cycles
    per 128-sample window (1.5625 Hz); no labels choose its frequency.
    """
    begin = perf_counter()
    x = _standardize(torch.as_tensor(signals, dtype=torch.float64), train_size)
    n, channels = x.shape[1:]
    t = torch.arange(n, dtype=torch.float64) / n
    increments = x / n
    preprocessing = perf_counter() - begin
    result, timings = {}, {}
    ordinary, seconds = extract_coded_features(increments, OffsetCode.constant(n), batch_size)
    for name, values in _readouts(ordinary, channels).items():
        result["ordinary_integrated_" + name] = values
        timings["ordinary_integrated_" + name] = seconds + preprocessing
    code = OffsetCode.pascal(n, 3, orthonormal=True, dtype=torch.float64)
    tensor, seconds = extract_coded_features(increments, code, batch_size)
    begin = perf_counter()
    # Transform BOTH tensor factors. Transforming level one alone is incorrect.
    first = tensor[:, :channels * 3].reshape(-1, channels, 3).astype(np.float64)
    second = tensor[:, channels * 3:].reshape(-1, channels, 3, channels, 3).astype(np.float64)

    def change_basis(matrix):
        transform = (code.matrix.T @ matrix).numpy()
        transformed_first = np.einsum("bia,ap->bip", first, transform)
        transformed_second = np.einsum("biajc,ap,cq->bipjq", second, transform, transform)
        return np.concatenate((transformed_first.reshape(len(x), -1),
                               transformed_second.reshape(len(x), -1)), axis=1)

    newton = torch.stack((torch.ones_like(t), t, t * (t - 1 / n)), dim=1)
    monomials = torch.stack((torch.ones_like(t), t, t.square()), dim=1)
    for name, values in _readouts(tensor, channels * 3).items():
        result["pascal_qr_" + name] = values
    result["pascal_qr_first_level"] = tensor[:, :channels * 3].copy()
    newton_tensor = change_basis(newton)
    for name, values in _readouts(newton_tensor, channels * 3).items():
        result["pascal_newton_" + name] = values
    result["pascal_newton_first_level"] = newton_tensor[:, :channels * 3].astype(np.float32)
    result["pascal_gap_moments"] = _gap_readout(change_basis(monomials), channels, False)
    seconds += preprocessing + perf_counter() - begin
    timings.update({name: seconds for name in result if name.startswith("pascal_")})

    phase = 2 * torch.pi * 4 * t
    matrix = torch.stack((torch.ones_like(t), phase.cos(), phase.sin(),
                          t * phase.cos(), t * phase.sin()), dim=1)
    tensor, seconds = extract_coded_features(increments, OffsetCode(matrix), batch_size)
    begin = perf_counter()
    demodulated = {"fourier_pascal_" + k: v for k, v in _readouts(tensor, channels * 5).items()}
    demodulated["fourier_pascal_first_level"] = tensor[:, :channels * 5].copy()
    demodulated["fourier_pascal_gap"] = _gap_readout(tensor, channels, True)
    seconds += preprocessing + perf_counter() - begin
    result.update(demodulated)
    timings.update(dict.fromkeys(demodulated, seconds))
    return result, timings


def _observable_sequences(x: torch.Tensor) -> dict[str, torch.Tensor]:
    """Energy envelopes and delayed dot products of two standardized triads."""
    dynamics = x[:, :, :6].reshape(len(x), x.shape[1], 2, 3)
    energy = dynamics.square().sum(-1)
    # A causal five-sample mean; missing history repeats the first energy.
    padded = torch.cat((energy[:, :1].expand(-1, 4, -1), energy), 1)
    cumulative = torch.cat((torch.zeros_like(padded[:, :1]), padded.cumsum(1)), 1)
    envelopes = (cumulative[:, 5:] - cumulative[:, :-5]) / 5
    products = torch.cat([
        (dynamics * dynamics[:, (torch.arange(x.shape[1]) - lag).clamp_min(0)]).sum(-1)
        for lag in (2, 5)
    ], 2)
    return {
        "energy_envelopes": envelopes,
        "delayed_products": products,
        "energy_delayed_products": torch.cat((envelopes, products), 2),
    }


def extract_observable_features(
    signals: np.ndarray, train_size: int, batch_size: int = 256,
) -> tuple[dict[str, dict[str, np.ndarray]], dict[str, dict[str, float]]]:
    """Integrate a few nonlinear observables before applying temporal codes.

    Input channels are body_acc xyz, body_gyro xyz, total_acc xyz. Fit raw
    channel means/std over training windows only, without window centering.
    For each dynamic triad, energy is its squared norm, causally averaged over
    five samples. Delayed products are dot(x[r], x[max(r-lag, 0)]) at lags 2
    and 5 (40/100 ms at 50 Hz), in lag-major then accel/gyro order. The global
    axiswise standardization means these are not rotation-invariant features.

    Integrating means increments = observable/N: ordinary level one is exactly
    the pooled observable mean. Compare ordinary, QR-Pascal [degree <=2], and
    Fourier-Pascal [1, cos, sin, t*cos, t*sin] at the existing four-cycle
    carrier. Append the same six total_acc/gyro means to every readout, giving
    static posture information even though the dynamics use body acceleration.
    Also return pooled observable means with those posture coordinates as a
    direct control, and each code's first level with its upper-triangle pair
    products. The latter separates products of coded moments from ordered
    level-two information. No observable is rescaled or centered before integration.

    Each returned group has the same ten readouts and a matching timing map.
    Timings include shared preprocessing; they must not be summed across rows.
    """
    begin = perf_counter()
    x = torch.as_tensor(signals, dtype=torch.float64)
    if x.ndim != 3 or x.shape[1] < 6 or x.shape[2] != 9 or not torch.isfinite(x).all():
        raise ValueError("signals must be finite with shape (samples, >=6 points, 9)")
    x = _standardize(x, train_size)
    observables = _observable_sequences(x)
    posture = x[:, :, [6, 7, 8, 3, 4, 5]].mean(1).numpy().astype(np.float32)
    n = x.shape[1]
    t = torch.arange(n, dtype=torch.float64) / n
    phase = 2 * torch.pi * 4 * t
    codes = {
        "ordinary": OffsetCode.constant(n),
        "pascal_qr": OffsetCode.pascal(n, 3, orthonormal=True, dtype=torch.float64),
        "fourier_pascal": OffsetCode(torch.stack((
            torch.ones_like(t), phase.cos(), phase.sin(), t * phase.cos(), t * phase.sin(),
        ), 1)),
    }
    preprocessing = perf_counter() - begin
    result, timings = {}, {}
    for group, values in observables.items():
        begin = perf_counter()
        result[group] = {
            "pooled_means": np.concatenate((values.mean(1).numpy(), posture), 1).astype(np.float32),
        }
        timings[group] = {"pooled_means": preprocessing + perf_counter() - begin}
        for name, code in codes.items():
            tensor, seconds = extract_coded_features(values / n, code, batch_size)
            begin = perf_counter()
            width = values.shape[2] * code.matrix.shape[1]
            first = tensor[:, :width]
            left, right = np.triu_indices(width)
            readouts = _readouts(tensor, width)
            readouts["first_level_products"] = np.concatenate(
                (first, first[:, left] * first[:, right]), 1,
            )
            for readout, matrix in readouts.items():
                result[group][name + "_" + readout] = np.concatenate((matrix, posture), 1)
            seconds += preprocessing + perf_counter() - begin
            timings[group].update({name + "_" + readout: seconds for readout in readouts})
    return result, timings


def self_check() -> None:
    from math import factorial

    from tensorsig.classical.signatures import signature

    rng = np.random.default_rng(11)
    x = rng.normal(size=(3, 12, 6))
    features, _ = extract_pascal_features(x, train_size=2, batch_size=2)
    scaled = (x - x[:2].mean((0, 1))) / x[:2].std((0, 1))
    n = x.shape[1]
    t = np.arange(n) / n
    gap = t[None, :] - t[:, None]
    for name, kernels in (
        ("pascal_gap_moments", (np.triu(gap, 1), np.triu(gap**2, 1))),
        ("fourier_pascal_gap", (np.triu(gap * np.cos(8 * np.pi * gap), 1),
                               np.triu(gap * np.sin(8 * np.pi * gap), 1))),
    ):
        expected = np.concatenate((scaled.mean(1), *(
            np.einsum("bri,rs,bsj->bij", scaled, kernel, scaled).reshape(len(x), -1) / n**2
            for kernel in kernels)), axis=1)
        np.testing.assert_allclose(features[name], expected, atol=1e-6)
    # The basis-transformed output must agree with a fresh tensorsig evaluation.
    t = torch.arange(n, dtype=torch.float64) / n
    code = OffsetCode(torch.stack((torch.ones_like(t), t, t * (t - 1 / n)), dim=1))
    direct, _ = extract_coded_features(torch.from_numpy(scaled / n), code)
    np.testing.assert_allclose(features["pascal_newton_full_signature"], direct, atol=1e-6)
    changed = x.copy()
    changed[2] += 50
    changed_features, _ = extract_pascal_features(changed, 2)
    for name in features:
        np.testing.assert_allclose(features[name][:2], changed_features[name][:2])
    # On a staircase, word i time^k j equals the gap-k moment divided by k!.
    events = torch.tensor([[1., -2.], [3., 1.], [-2., 4.], [.5, -1.]], dtype=torch.float64)
    times = torch.tensor([0., .2, .6, 1.], dtype=torch.float64)
    points = [torch.zeros(3, dtype=torch.float64)]
    for event, time in zip(events, times):
        before = torch.cat((points[-1][:2], time[None]))
        points.extend((before, torch.cat((before[:2] + event, time[None]))))
    ordinary = signature(torch.stack(points)[None], depth=4)[0]
    for k, index in ((1, 19), (2, 64)):  # Flattened words (0,2,1) and (0,2,2,1).
        expected = sum((times[s] - times[r])**k * events[r, 0] * events[s, 1]
                       for r in range(4) for s in range(r + 1, 4)) / factorial(k)
        torch.testing.assert_close(ordinary[index], expected, rtol=1e-12, atol=1e-12)

    raw = rng.normal(size=(3, 12, 9))
    scaled = _standardize(torch.from_numpy(raw), 2)
    sequences = _observable_sequences(scaled)
    dynamics = scaled.numpy()[:, :, :6].reshape(3, 12, 2, 3)
    energy = (dynamics**2).sum(-1)
    expected_energy = np.stack([
        energy[:, np.maximum(np.arange(r - 4, r + 1), 0)].mean(1)
        for r in range(12)
    ], 1)
    expected_products = np.concatenate([
        (dynamics * dynamics[:, np.maximum(np.arange(12) - lag, 0)]).sum(-1)
        for lag in (2, 5)
    ], 2)
    np.testing.assert_allclose(sequences["energy_envelopes"], expected_energy, atol=1e-12)
    np.testing.assert_allclose(sequences["delayed_products"], expected_products, atol=1e-12)
    features, _ = extract_observable_features(raw, 2, batch_size=2)
    changed = raw.copy()
    changed[2] += 50
    changed_features, _ = extract_observable_features(changed, 2)
    for group, matrices in features.items():
        width = sequences[group].shape[2]
        pooled = matrices["pooled_means"]
        np.testing.assert_allclose(pooled[:, :width], sequences[group].mean(1), atol=1e-6)
        np.testing.assert_allclose(pooled[:, width:], scaled[:, :, [6, 7, 8, 3, 4, 5]].mean(1),
                                   atol=1e-6)
        np.testing.assert_allclose(matrices["ordinary_full_signature"][:, :width],
                                   pooled[:, :width], atol=1e-6)
        for code_name, copies in (("ordinary", 1), ("pascal_qr", 3), ("fourier_pascal", 5)):
            coded_width = width * copies
            tensor = matrices[code_name + "_full_signature"][:, :-6]
            first = tensor[:, :coded_width]
            second = tensor[:, coded_width:].reshape(-1, coded_width, coded_width)
            left, right = np.triu_indices(coded_width)
            products = matrices[code_name + "_first_level_products"]
            assert products.shape == (len(raw), coded_width + len(left) + 6)
            np.testing.assert_allclose(products[:, :coded_width], first, atol=1e-6)
            np.testing.assert_allclose(products[:, coded_width:-6],
                                       first[:, left] * first[:, right], atol=1e-6)
            np.testing.assert_allclose(products[:, coded_width:-6],
                                       second[:, left, right] + second[:, right, left], atol=1e-5)
        for name, values in matrices.items():
            np.testing.assert_allclose(values[:, -6:], pooled[:, -6:], atol=1e-6)
            np.testing.assert_allclose(values[:2], changed_features[group][name][:2])
    constant_features, _ = extract_observable_features(np.ones((3, 12, 9)), 2)
    for matrices in constant_features.values():
        for values in matrices.values():
            assert np.isfinite(values).all()
            np.testing.assert_allclose(values, 0, atol=1e-12)


if __name__ == "__main__":
    self_check()
    print("Pascal feature checks passed.")
