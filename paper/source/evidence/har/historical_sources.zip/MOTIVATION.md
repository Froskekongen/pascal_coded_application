# Why these signature families for human activity?

The proposed representation separates three questions: **what changes in time,
where oscillatory energy lies in frequency, and how sensor vectors relate to
one another**. Each question suggests an observation transform followed by a
small signature. This gives a reusable design with interpretable parameters,
rather than requiring a new list of statistics for every dataset.

The retained compact model has 368 coordinates:

| Construction | Coordinates | Role |
|---|---:|---|
| Raw Pascal QR P3/depth-2 logsignature | 171 | Sample levels, temporal location, ordered interactions |
| Spectral Pascal QR P3/depth-2 logsignatures | 100 | Frequency location and pairwise separation |
| Spectral-amplitude mean/std | 40 | Absolute scale and amplitude concentration |
| Cross-triad cosine mean/std | 6 | Relative vector alignment |
| Energy and dot-product mean/std/skew | 36 | Magnitude, coordination and short-lag persistence |
| Standardized Pascal P2/depth-2 graph trends | 15 | When larger invariant/cosine values occur |

The separate retained comparators are the **803-coordinate reduced
spectral/rotation pool + raw Pascal** and **903-coordinate supplied 561 + raw
Pascal P3/depth 2**. Both use the 342-coordinate raw *tensor* signature. The
compact model instead uses its 171-coordinate *logsignature*. These choices
give different linear predictors even though tensor signatures and
logsignatures determine one another by nonlinear maps.

## Raw coding preserves levels and locates interactions

Let \(x_k\in\mathbb R^6\) contain total-acceleration and gyroscope samples,
scaled using training means and standard deviations. For a window of \(N\)
samples, integrate the observations and attach position codes:

\[
\Delta Z_k^{i,a}=\frac{x_k^i}{N}q_a(k),\qquad a=0,1,2.
\]

The QR Pascal columns \(q_0,q_1,q_2\) span constant, linear and quadratic
functions of sample position. The first signature level therefore contains
the window mean and its linear and quadratic position-weighted counterparts.
Integration is deliberate: an unanchored signature of the sample path depends
on changes \(dx\) and loses constant offsets. Integrating samples preserves
posture-related levels. Anchoring an ordinary path is another way to retain
levels and belongs among the controls.

For two lifted coordinates \(A,B\), the antisymmetric second level is

\[
D_{AB}=S^{AB}-S^{BA}
=\sum_{k<l}\left(\Delta Z_k^A\Delta Z_l^B
                 -\Delta Z_k^B\Delta Z_l^A\right).
\]

This compares an interaction in one temporal order with its reversal. Codes
also say where the interacting observations occurred. Thus P controls
polynomial position resolution, while signature depth controls the number of
ordered factors. P3/depth 2 provides quadratic location information and
pairwise interactions without constructing a deep tensor over many channels.
With 18 lifted channels, the logsignature has \(18+\binom{18}{2}=171\)
coordinates. This is a dimension and coverage argument, not a theorem that
P3 is optimal for activity recognition.

## Spectral coding turns frequency into geometry

The spectral branch forms xyz and norms after training channel scaling;
energy here means energy of those transformed signals. For each scalar signal,
take its one-sided FFT bin energies \(e_k\), including
the appropriate doubling of interior bins, so that
\(E=\sum_k e_k\) equals the time-domain mean square. Normalize to
\(p_k=e_k/E\) for a nonzero spectrum. In increasing frequency order, integrate

\[
\Delta Z_k=p_k(1,f_k,f_k^2).
\]

QR is an invertible basis change of these polynomial weights. The endpoints
give the first two frequency moments; the mass endpoint is fixed at one.
The three antisymmetric second-level coordinates measure more than those
moments. If independent \(F,G\) are sampled from the spectral masses, then

\[
D_{01}=\tfrac12\mathbb E|F-G|,\quad
D_{02}=\tfrac12\mathbb E|F^2-G^2|,\quad
D_{12}=\tfrac12\mathbb E[FG|F-G|].
\]

They measure frequency-pair separation with different emphasis on high
frequencies. No frequency bands or peak detector are required. A compact
logsignature retains two varying endpoints and three areas per scalar
spectrum: five coordinates. The 20 spectra are xyz and norm for body
acceleration, gravity, gyroscope, and first differences of body acceleration
and gyroscope, giving 100 coordinates. Cross-spectrum areas are deliberately
omitted.

The role of coding is especially clear here. Without a frequency coordinate
or nonconstant code, the scalar cumulative normalized spectrum has endpoint
one and the same entire signature for every spectrum. Frequency coding makes
its shape visible. For example, spectra with masses
\((1/4,1/4,1/4,1/4)\) and \((1/5,2/5,1/10,3/10)\) on the first four
frequency bins have identical first two moments, but different \(D_{01}\).
The calculation is given in [feature_families.md](feature_families.md).

The FFT power transform discards phase and normalized power discards energy;
signatures cannot recover either loss. This explains the complementary raw
and amplitude branches. Spectral variance is a nonlinear endpoint readout of
the logsignature; the tensor signature would additionally make endpoint
products linear through the shuffle identity.

## The remaining 97 coordinates have one graph construction

For any scalar observation stream \(z_k\), construct a staircase graph with
value coordinate \(x\) and clock \(t\). Start at value zero, jump to each
\(z_k\), hold it while the clock advances by \(1/N\), and finally return
the value to zero. Then

\[
(\log S)^{x^r t}=S^{x^r t}
=\frac{1}{r!N}\sum_k z_k^r.
\]

These superscripts denote tensor-log word coefficients; the implementation
selects the corresponding Lyndon words, rather than arbitrary Hall-basis
coordinates. The last clock integral averages the pure-value prefix \(x^r/r!\). In the
tensor logarithm, all correction terms contain a pure-value prefix of the
complete path, which vanishes because that value coordinate closes.
Consequently depth 3 supplies mean and second moment; depth 4 adds the third
moment. Std and standardized skew are **explicit nonlinear readouts** of
these coordinates. The implementation uses centered graphs to avoid unstable
subtraction of nearly equal raw moments.

For spectral amplitudes \(a_k=\sqrt{e_k}\), this yields 40 mean/std readouts.
They have a useful scale–shape interpretation:

\[
\operatorname{mean}(a)=\frac{\sqrt E}{K}\sum_k\sqrt{p_k},\qquad
\operatorname{std}(a)^2=E/K-\operatorname{mean}(a)^2.
\]

Together they determine energy and describe how concentrated the mass is,
complementing frequency location. A separate log-energy column is therefore
not needed for information sufficiency, although changing readouts can still
change a linear ridge fit.

For geometry, let \(v_g(k)\) be body acceleration, gravity or gyroscope,
each divided by one training RMS scalar without axiswise centering. Use

\[
\|v_g(k)\|^2,\qquad
\langle v_g(k),v_h(k)\rangle,\qquad
\langle v_g(k),v_g(k-\tau)\rangle.
\]

Three energies, three simultaneous products, and three products at each of
lags 2 and 5 give twelve streams and 36 mean/std/skew readouts. Three
normalized simultaneous products supply the six cosine readouts. The short
lags correspond to 40 and 100 ms at 50 Hz; these are simple tested choices,
not theoretically optimal timescales. All averages use valid pairs.

Finally replace the graph clock by Pascal-coded clocks with increments
\(q_a(k)/N\). The same identity gives

\[
(\log S)^{x^r t_a}=\frac1{r!N}\sum_k q_a(k)z_k^r.
\]

The retained model adds only \(r=1,a=1\), applied to each standardized
invariant and cosine stream: 15 trends. They distinguish early from late
large values independently of scale. Constant streams receive zero trends;
mean/std remain in the other branch. Selected graph words can be computed
directly without constructing the full graph tensor.

## What the comparison can establish

These constructions are ordinary signatures of explicitly lifted paths.
Pascal coding is not more expressive than *all* ordinary-signature embeddings.
For a staircase integrated path whose clock is fixed during each observation
increment, \(S^{t^aY}=\sum_k t_k^a\Delta Y_k/a!\). Thus polynomial weighting
moves information from longer ordinary time words to shorter words in a
larger alphabet. The graph's P2 trend likewise reproduces an ordinary
depth-3 graph word up to scale. The question is which representation provides
useful coordinates at modest dimension and cost for the same ridge head.

QR improves conditioning of the polynomial position basis; it does not add
information or establish an advantage specific to the Pascal basis. Even an
invertible basis change can alter the penalty after coordinatewise scaling.
The consolidated controls therefore compare uncoded, time-augmented, anchored,
lagged and lead–lag embeddings under explicit dimension limits, retaining the
same observation transforms and non-signature blocks where applicable.

The geometric branch is invariant under a common fixed orthogonal transform
of all triads in a window. Delayed products require the same transform at
both times. Raw axes and the spectrally transformed, axis-standardized
channels make the complete model rotation-sensitive. FFT power is invariant
to circular shifts of the particular input sequence; the complete model is
not time-shift invariant. These distinctions are useful: posture, timing and
relative geometry need not share the same invariances.

The structural motivation is the controlled combination of polynomial
location, ordered interaction, occupation moments and geometric contraction.
The observed 98.03% compact-model accuracy is exploratory evidence from the
repeatedly used UCI test split; it does not prove a universal Pascal advantage.
The retained 803-feature comparator still includes bands and richer pooled
statistics, and the 903-feature comparator tests complementarity with the
supplied engineering. Their role is to measure what the smaller generic
construction recovers, rather than to redefine all hand-crafted statistics
as signature discoveries. Implementation proposals belong separately in
[tensorsig_suggestions.md](tensorsig_suggestions.md).

## What the consolidated controls show

The [187-comparison consolidation](CONSOLIDATED.md) strengthens the case for
raw coding in the generic models. With all other branches fixed, the compact
model reaches 98.03% with 368 features versus the best tested conventional raw
replacement's 97.46% with 377 features, a difference of 17 errors. For the
larger pool the corresponding results are 98.10%/803 versus 97.83%/641,
eight errors apart. These comparisons support usefulness at the tested
budgets; they do not establish dominance over untested embeddings or heads.

With the supplied 561 features, the difference is only **two errors**:
97.12%/903 for Pascal versus 97.05%/615 for an anchored, time-augmented
ordinary signature. That is effectively a close empirical comparison,
especially after repeated test-set exploration.

The spectral result is chiefly about compactness. Replacing its 100-coordinate
Pascal branch with a 440-coordinate ordinary frequency-clock tensor gives
98.00% at 708 total features, just one extra error. Moreover, projecting the
ordinary depth-5 frequency-clock signature onto the Pascal readouts reproduces
every prediction at 368 features. Ordinary signatures of the explicit raw
polynomial lift also reproduce all three retained models, and ordinary graph
depth-3 words reproduce all 15 trends. These exact controls reinforce the
intended claim: coding packages useful ordinary-signature information into
small, interpretable coordinate families; it does not create information
unavailable to ordinary signatures of suitable embeddings.
