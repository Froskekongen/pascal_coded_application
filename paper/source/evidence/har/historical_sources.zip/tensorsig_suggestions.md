# UCI HAR: feature connections and small tensorsig additions

The reusable direction is **pre-transform → observable values → weighted
integration → code → signature/readout**. Time, frequency and lag can each be the
ordered axis. Most of this already composes from PyTorch and tensorsig; the useful
library additions are small helpers that make normalization and selected
statistical readouts explicit. No new framework or tensorsig implementation is a
prerequisite for the HAR example.

The executable comparisons and measurements live in [README.md](README.md) and
[the current family sweep](family_results/RESULTS.md). The complete 561-column
inventory and generic family designs are in [feature_families.md](feature_families.md).
This document separates mathematical
identities, interpretations of the current experiment, and future possibilities.

## What the 561 features actually contain

The dataset's `features_info.txt` and all 561 names in `features.txt` were checked
inside the cached `data/uci_har.zip` / `UCI HAR Dataset.zip`. Its pipeline computes
body and gravity acceleration separately, angular velocity, derivatives called
jerk, vector magnitudes, and FFT transforms. Statistics include moments, extrema,
quantiles, entropy, correlations within each xyz family, order-four Burg
autoregression coefficients, frequency-band energy, and angles involving window
means and gravity. See the [official UCI dataset and download](https://archive.ics.uci.edu/dataset/240/human+activity+recognition+using+smartphones).

Thus the baseline benefits from considerably more preprocessing than six input
channels and a generic shallow signature. In particular, replacing body with
total acceleration does not explicitly supply both the body and gravity
components. The supplied 561 coordinates are also normalized; reproducing their
exact numbers requires their filtering, boundary and normalization conventions.
The connections below concern the underlying statistics, not exact reproduction
of that supplied table.

| Handcrafted family | Signature-like construction | Mathematical status and useful extension |
|---|---|---|
| Mean | Use samples divided by window length as path increments | First level is exactly the sample mean. Coded first levels give position-weighted means. |
| Energy, variance, correlation | Retain same-sample products, or use integrated lead–lag | Exact second moments; centering gives covariance, and division by standard deviations gives correlation. Cross-modality products extend the within-triad correlations in the feature list. |
| Signal magnitude area, vector magnitudes | Apply absolute value or norm, then sample integration | The first level pools the chosen nonlinear observable. Higher levels retain its ordering relative to other observables. Norms discard direction, so supplementing axes and replacing axes answer different questions. |
| Jerk statistics | Difference channels with an explicit sample interval, then integrate or take signatures | Difference energy is exactly a rescaled increment-covariation diagonal. This does not reproduce all jerk distribution or spectral features. |
| FFT coefficients and band energy | Sine/cosine offset codes on the sample-integrated path | Coded first levels are normalized discrete Fourier coefficients, with the matching sign/grid. Squared sine/cosine pairs give spectral power; summing selected frequencies gives band power. Higher levels order time samples with frequency weights. An FFT pre-transform followed by a signature over frequency bins is a different construction. |
| Frequency skewness/kurtosis | Polynomial moments of the spectral observable, followed by centering and normalization | The required powers can be integrated exactly once the same spectral observable is supplied. These are not automatically moments of the time-domain samples. |
| Autoregression | Delay channels, same-sample products and pooled lagged cross-products | Provides correlation statistics for regression and their ordered extensions. Burg's fitted coefficients are not signature coordinates, and merely matching a few lag moments is not an exact Burg implementation. |
| Mean-vector angles | Integrated first levels, dot products, norms and an angle readout | Exact for the same mean vectors and nonzero denominators. Joint-rotation contractions of higher signature tensors could extend this beyond averages. |
| Median deviation, quantiles, max/min, entropy, peak-frequency index | Nonlinear preprocessing/readout, or deliberate approximation | There is no generic finite linear-coordinate identity for these on the raw geometric lift. A richer signature may support approximation, but calling them exact shallow signature features would be misleading. The feature description does not fully specify the entropy estimator. |

This is an instance of selecting the path representation before taking its
signature, rather than expecting one lift to supply every useful statistic.
The [generalised signature method](https://arxiv.org/abs/2006.00873) systematically
studies that separation.

## The exact bridge: integrated lead–lag and direct covariation

Let a window have samples \(x_0,\ldots,x_{N-1}\in\mathbb R^d\), after whatever
fixed channel scaling is chosen. Form the sample-integrated path

\[
Y_0=0,\qquad Y_{r+1}-Y_r=x_r/N.
\]

Its first level is \(\mu=N^{-1}\sum_r x_r\). Define the **discrete** covariation
of any increment sequence \(z_r\) as

\[
Q_{ij}(z)=\sum_r z_r^i z_r^j.
\]

For the integrated path, the empirical second-moment matrix and population
covariance are therefore

\[
M=NQ(\Delta Y)=\frac1N\sum_r x_rx_r^\top,
\qquad C=M-\mu\mu^\top.
\]

The diagonal of \(M\) is sample energy, and \(\sqrt{C_{ii}}\) is population
standard deviation. The off-diagonal entries retain simultaneous cross-channel
information. These are exact finite-sample identities; an unbiased sample
covariance would use the additional factor \(N/(N-1)\).

For the staircase that moves the lead copy before the lag copy, write signed
area as \(A_{ab}=(S_{ab}-S_{ba})/2\). Then

\[
A_{L_i,G_j}=A_{ij}(Y)+\tfrac12Q_{ij}(\Delta Y),
\qquad
Q_{ij}(\Delta Y)=A_{L_i,G_j}+A_{L_j,G_i}.
\]

In particular, \(Q_{ii}=2A_{L_i,G_i}\), so
\(M_{ii}=2N A_{L_i,G_i}\). To see the formula, each lead step precedes its
matching lag step, contributing \(z_r^iz_r^j/2\) to area. Contributions from
different samples give the ordinary area. **One cross-channel lead–lag area is
not by itself a covariance:** it also includes ordinary signed area. Symmetrizing
the channel pair removes that part. This is the finite-sample mechanism behind
the lead–lag/covariation connection studied in the
[rough Hoff process](https://arxiv.org/abs/1310.4054).

For the original signal path, \(Q(\Delta x)\) instead measures change activity.
At interval \(\delta t\), the mean product of finite-difference derivatives is
\(Q(\Delta x)/((N-1)\delta t^2)\). An origin anchor must not be included as an
extra observed increment when computing this statistic. Neither version is an
estimate of a sampling-independent stochastic quadratic variation merely
because of its name: these are filtered signals at a fixed mesh.

Direct \(\mu,M,Q(\Delta x)\) costs \(O(Nd^2)\) work and needs only the upper
triangles of the symmetric matrices. A modality restriction can omit unwanted
cross-block entries. Concatenating this readout with a geometric signature gives
a useful feature vector; it does not silently change the signature's algebra.

In this example the direct increment block is normalized as
\(\overline Q=Q(\Delta x)/(N-1)\). For six channels, the controls are
\(\mu+\operatorname{upper}(M)\) (27 features), that block plus
\(\operatorname{upper}(\overline Q)\) (48), and
\(\mu+\mathrm{std}+\operatorname{upper}(C)+\operatorname{upper}(\overline Q)\)
(54). The last exposes standard deviation and covariance directly to the linear
head. The 42-coordinate \(M,\overline Q\) block is also appended to integrated
signature constructions. These definitions refer to training-globally
standardized channels, not per-window centered signals.

## What offset coding can add

Offset coding makes **position-weighted ordered interactions** available at
shallow depth. For increments \(z_r\) and code columns \(c_a(r)\), the coded
coordinate has increments \(v_r^{i,a}=c_a(r)z_r^i\), and its area is

\[
A_{(i,a),(j,b)}=
\frac12\sum_{r<s}
\left[c_a(r)c_b(s)z_r^iz_s^j
-c_b(r)c_a(s)z_r^jz_s^i\right].
\]

It measures a directed interaction across different times, weighted by where
those events occur. On the integrated sample path this is a weighted bilinear
summary of earlier and later sensor values. Mean, energy and simultaneous
correlation pool different information. For example, the two sample sequences
\(((1,0),(0,1))\) and \(((0,1),(1,0))\) have identical means and second moments,
but their integrated areas are \(+1/8\) and \(-1/8\). This example demonstrates
separation from those pooled statistics, **not** a collision of all 561 features.

Ordinary area already detects this simple order difference. Offset codes extend
the question to *when* the interaction occurs and to richer temporal weightings.
Linear time codes provide broad position trends, not a recovered delay spectrum.
Sine/cosine codes offer a more direct connection to periodic motion. Those
weightings may expose information to a linear head that an ordinary shallow
representation would need higher depth or a nonlinear head to exploit.

There is a stronger overlap with familiar statistics in the **origin-anchored
signal path used by `total_basepoint`**. For its \(N\) increments, including the
initial jump, let \(u_r=r/(N-1)\), \(P_i\) be the unweighted first level, and
\(B_i\) the weighted first level. Then \(P_i=x_{N-1}^i\), and exactly

\[
\mu_i=P_i-\frac{N-1}{N}B_i.
\]

Writing \(A_{ij}=A_{(i,0),(j,1)}\), the second moment is also recoverable:

\[
M_{ij}=P_iP_j-\frac{N-1}{N}
\left[\frac{P_iB_j+P_jB_i}{2}+A_{ij}+A_{ji}\right].
\]

The shuffle identity converts products of first levels to sums of second-level
tensor coordinates; combining the products with the areas cancels the reverse
words. Hence the particularly simple **linear tensor readout**

\[
M_{ij}=S_{(i,0),(j,0)}+S_{(j,0),(i,0)}
-\frac{N-1}{N}\left[S_{(i,0),(j,1)}+S_{(j,0),(i,1)}\right].
\]

One way to derive these formulas is to write each sample as a cumulative sum of
the anchored increments and count how many samples each increment contributes
to. For the area sum, split the path at every sample: the left cumulative
increment is \(x_k\), and the right one is \(P-x_k\). Their symmetric products
give the stated identity for \(M\).

Thus **means and raw second moments are already linear features of the full
anchored offset depth-two tensor signature**. The moment formula requires
products when using log coordinates, and covariance further subtracts
\(\mu_i\mu_j\). Large gains for a linear offset head can therefore be recovery
of familiar statistics, not evidence of unique timing information. Within a
modality the formulas survive the quotient; across modalities their required
areas are discarded. The direct full-moment appendage intentionally supplies
cross-modality simultaneous products again. The formulas are tied to this
origin/offset convention and are not identities for an arbitrary augmentation.

The actual 561-name list has within-family correlations and several mean-vector
angles, but no explicitly listed directed acceleration–gyroscope area. Such
interactions are a plausible source of complementary information. A modality
quotient removes these cross-modality areas, including their coded versions, so
it can remove exactly the candidate contribution. Conversely, absolute code
position can be a nuisance when otherwise similar gait cycles enter the crop at
different phases. Neither an offset advantage nor quotient harmlessness follows
from the mathematics alone.

There is also an important redundancy. For a scalar path with \(R\) increments,
\(u_r=r/(R-1)\), and \(R>1\), the area between its ordinary and linearly weighted
copies is

\[
J=\frac1{2(R-1)}\sum_{r<s}(s-r)z_rz_s.
\]

If \(x_R=x_0\), then exactly

\[
J=-\frac1{2(R-1)}\sum_{k=1}^{R-1}(x_k-x_0)^2.
\]

Each increment pair crosses \(s-r\) cuts; at each cut the left cumulative
increment is the negative of the right one. Summing those products proves the
identity. Thus this particular coded area becomes a pooled squared-amplitude
statistic on closed scalar paths. It does not establish extra frequency or
ordering information there. The closed-path condition need not hold for a HAR
window, or for its sample-integrated path.

The practical test of added value is an equal-head comparison of **561 alone,
561 plus ordinary features, and 561 plus offset features**, alongside the smaller
feature-only models. A gain only over mean/std or only over an ordinary linear
head does not establish a gain over handcrafted features. Include 561 plus the
direct-statistics control to test whether simpler additions explain the gain.
Even an improved hybrid measures usefulness for the fixed head: alternate
parameterizations and duplicated information can change regularization. It does
not prove information unavailable in the original 561 features. On this single
split, small differences are descriptive; no significance or general superiority
is claimed.

The recorded extension gives the following test accuracies (%), with unchanged
heads and no tuning:

| Features | Ridge | RBF SVM | Random forest |
|---|---:|---:|---:|
| Supplied 561 | 95.72 | 95.49 | 92.43 |
| 561 + direct 54-statistic block | 95.86 | 96.17 | 92.47 |
| 561 + ordinary anchored tensor | **97.05** | **96.91** | **92.94** |
| 561 + offset anchored tensor | 97.01 | 96.64 | 92.57 |

The 54 direct statistics alone reach 88.53/89.85/92.77. Thus their random forest
matches the supplied-feature forest closely, with far fewer features, while
their linear/SVM heads still trail it. Integrated lead–lag reaches at most
88.39% with an SVM in this sweep and does not close the gap.

The strongest evidence of complementary predictive value here is the signature
appendage to 561, but **it is not specific to offset coding**. Ordinary anchored
tensor features beat their offset counterpart for each of the three heads;
ordinary lead–lag log features also beat the corresponding offset hybrid with
every head. The direct-statistics hybrid gives a smaller gain. This motivates
studying cross-channel order beyond simple moments, but does not establish that
those interactions caused the gain, nor that offset coding adds information
unavailable to the handcrafted baseline. See the full timings and 234 comparisons
in [results/RESULTS.md](results/RESULTS.md).

The later [252-comparison temporal extension](temporal_results/RESULTS.md) gives
a more specific practical direction: the compact 78-feature Fourier cross-spectrum
block raises the 561-feature SVM/RF to 97.05/94.10 and beats its much larger full
Fourier tensor hybrid. QR-Pascal plus 561 gives 97.12 with ridge and is the
reference for the subsequent ridge-only width/depth sweep. Fourier–Pascal improves
standalone ridge over its matched Fourier carrier, but its hybrids do not improve. These observations
favor small, interpretable readouts before adding broader code families or kernels.

## One generator pattern, several ordered axes

Suppose preprocessing produces vectors \(u_r\), indexed by an ordered coordinate
\(s_r\). Choose observable functions \(\phi_j\), integration weights \(w_r\), and
code columns \(c_a(s_r)\). Feed the increments

\[
z_r^j=w_r\phi_j(u_r),\qquad
v_r^{j,a}=c_a(s_r)z_r^j
\]

to the existing signature plan. Its first level is exactly
\(\sum_r w_r c_a(s_r)\phi_j(u_r)\). Later levels describe ordered interactions
between these observables on the chosen axis. A scalar observable with constant
code has a one-dimensional signature determined entirely by its total; useful
ordering therefore needs multiple observables, multiple code columns, or an
extra axis channel.

| Ordered axis and pre-transform | Observable and weights | Generic feature family |
|---|---|---|
| Time; raw, filtered or differenced signals | Powers, absolute values, selected products, vector norms; \(w_r=1/N\) for an empirical mean | Moments and their temporal ordering; polynomial codes add position-weighted moments. |
| Time; fixed delays or filtered envelopes | Selected cross-products or squared filter outputs | Lagged dependence and energy modulation, including which type of energy precedes another. |
| Frequency; FFT followed by magnitude, power or cross-spectrum | Spectral values on the frequency grid; choose bin-mass or quadrature weights explicitly | Spectral moments, band masses and ordered cross-channel spectral structure. A frequency code weights frequency bins. |
| Lag; form empirical auto/cross-correlation curves | Correlation values at selected lags with declared overlap normalization | Polynomial or Fourier moments of lag dependence and signatures of the lag curves. |
| Time; fixed amplitude-bin indicators or smooth bin functions | \(\phi_j(x)=1\{x\in B_j\}\), with \(w_r=1/N\) | Bin occupancy at level one and ordered visits to amplitude regions at later levels; entropy is a nonlinear readout of occupancies. |

These are families controlled by a small set of choices, rather than a special
HAR function for each statistic. FFT-on-input followed by a frequency-axis
signature is different from Fourier coding a time-axis signal: the former orders
spectral bins, while the latter weights events in time. Neither operation should
be hidden behind a generic “Fourier signature” name.
The application-level prototype is in [generators.py](generators.py); the table
also includes possible extensions beyond that implementation.

The weights specify the measure being summarized. Uniform \(1/N\) weights give
an empirical average; interval lengths give a time or frequency integral;
normalized spectral mass gives moments of a spectral distribution. The last
normalization deliberately removes total power, so retain it separately when
amplitude matters. For irregular grids, multiplying increments by the weights
before applying a code keeps this distinction visible. A rectangular sample sum
and a trapezoidal integral are different conventions, even if both use
`cumsum` to construct path points.

This requires no new signature engine. Once `observables` has shape
`(batch, samples, channels)` and `weights` has shape `(samples,)`, the current
public API already accepts the construction:

```python
from tensorsig.offset_coded_signatures.codes import OffsetCode
from tensorsig.offset_coded_signatures.plans import LocalRealization

increments = observables * weights[None, :, None]
code = OffsetCode.pascal(increments.shape[1], P, orthonormal=True,
                         dtype=increments.dtype)
plan = LocalRealization(code, channels=increments.shape[-1],
                        max_depth=depth).signature(coordinates="dense")
features = plan.evaluate(increments[:, None])[:, 0]
```

Normalization of the code is separate from normalization of the measure. A
QR-normalized constant column has magnitude \(1/\sqrt N\); its first coordinate
is therefore a known rescaling of the mean, not literally the mean. Preserve
labels and scaling when interpreting a coded coordinate as a named statistic.

## Prioritized library suggestions

1. **Named covariation and moment readouts.** Offer explicit `sum`/`mean`
   normalization, samples versus increments, and optional selected channel pairs.
   Include diagonal terms and expose their labels. Keep the direct implementation
   until a measured need justifies a specialized kernel. This is the clearest
   convenience missing from the checked public API.
2. **A documented weighted-integration recipe.** Accept already computed
   observables and explicit weights; return increments, or origin-prefixed path
   points if the classical API is used. Keep FFT, filters, norms and histogram
   bins as ordinary preprocessing. Document the ordered axis, endpoint, clock
   and normalization conventions. The short helpers in [features.py](features.py)
   suffice until another example needs them. No public named weighted observable
   integrator was found in the checked source, but multiplication and `cumsum`
   already implement it.
3. **Selected products including squares.** `PairwiseProductAugmentation`
   supplies all distinct-channel products on path points and omits squares.
   A small extension allowing selected channel pairs and diagonal terms would
   support both moment observables and lag products without creating every pair.
   Integrate those outputs when the intended first level is their sample average.
   A norm or amplitude-bin observable is just a tensor operation; it needs no
   separate class. Existing polynomial dictionaries already represent selected
   families of same-offset and cross-offset monomials, so this is a convenience
   at the sample-observable stage, not a missing ability to express products.
   The `--observables` example now implements smoothed triad energies and short-lag
   dot products. Coding improves their standalone models, but their hybrids do
   not beat the earlier stronger alternatives. Products of coded first levels
   retain much of the gain. Keep this as an example recipe rather than promoting
   a new library abstraction on the basis of these results.
4. **Time, frequency and lag examples using existing APIs.** The `--temporal` extension
   now tests short delays, Fourier codes and spectral readouts; see
   [README.md](README.md) and [the recorded rows](temporal_results/RESULTS.md).
   `causal_fir` and
   `CausalFIRAugmentation` already support delays/differences. `OffsetCode.structured`
   already supports sinusoidal, DCT and polynomial codes, and explicit matrices
   allow a chosen frequency grid. Show the integrated-sample Fourier identity
   and a sine/cosine power readout, including normalization and phase choices.
   Contrast that with an FFT pre-transform and a signature over ascending
   frequency bins, and with signatures over lag-correlation curves. For the FFT
   recipe declare one/two-sided scaling, DC/Nyquist treatment, magnitude versus
   power, and whether total power is retained. These capabilities do not require
   new code families. Pooling several short
   windows is another small ablation, with an explicit tradeoff in retained order.
5. **Defer a full discrete iterated-sums interface.** For
   \(I^{ij}=\sum_{r<s}z_r^iz_s^j\), the product identity is
   \((\sum_rz_r^i)(\sum_rz_r^j)=I^{ij}+I^{ji}+Q_{ij}\).
   The equal-time term suggests an enlarged alphabet of same-sample products;
   higher words retain their order. This is the natural algebraic generalization
   of moments and ordered summaries, formalized by the
   [iterated-sums/quasi-shuffle signature](https://www.wias-berlin.de/preprint/2736/wias_preprints_2736.pdf).
   No public interface with that product law was found. Existing polynomial
   dictionaries can express equal-time products and strict ordered-offset
   monomials, but are not by themselves an aggregated iterated-sums interface
   with an observable alphabet and its product law. Start with the direct
   readout, not a new algebra for one dataset.

### What the Pascal investigation suggests for the API

The deeper investigation is in [pascal_investigation.md](pascal_investigation.md).
The library already has certified orthonormal Pascal codes, so **conditioning
the code matrix is not a missing feature**. The example computes through that
basis, then transforms both factors of level two into bounded Newton coordinates.
A documented basis-transport recipe would prevent users from transforming only
the first level or evaluating a poorly conditioned raw Pascal matrix.
`tensor_ops.linear.apply_linear_map_to_tensor_level` and
`apply_linear_map_to_signature_levels` already implement the required map on
every tensor axis. Reuse them; a second basis-conversion API is unnecessary.

Two small readout recipes are more actionable than a new signature family:

- **Polynomial lag contractions:** expand `(t_s-t_r)^q` into products of code
  columns and contract the coded tensor. This selects directed lag moments and
  cancels the equal-time diagonal contribution. It can expose selected deep
  time-augmented ordinary signature words at coded depth two.
- **Fourier–Pascal products:** multiply Fourier columns by low-degree polynomial
  columns. Explicit `OffsetCode(matrix)` already supports this. A recipe should
  include the compact complex lag readout, its frequency-derivative identity,
  and the distinction between time-origin rebasing and changing a window crop.

These are selective projections of existing tensors, not extra information added
after extraction. They should remain example code until repeat use justifies a
named API. The first-level Fourier and cross-spectrum controls likewise could be
computed by a small matrix product rather than paying for a full signature.

### Existing selection and contraction support, and the remaining gap

The public API already does more than dense extraction. The scope matters when
proposing a speed improvement:

| Current capability | What it already supplies | Narrow remaining opportunity |
|---|---|---|
| `LocalRealization.signature(depths=...)` | Only requested homogeneous levels in the returned representation | No new depth-selection API is needed. |
| `WordSelection` on a certified Pascal chronological plan | Bounds on temporal degree, channel descents and combined complexity | Arbitrary user-listed words or a named statistical functional are not public selection options. |
| `SignaturePlan.reconstruct_words(features, words)` | Decodes requested ambient words from an already evaluated sufficient chart; retained words can also be gathered from a lossy chart | It does not directly evaluate an arbitrary word list from the original increments. |
| `SignaturePlan.contract(windows, weight)` | Applies a linear readout to the plan's features | The checked implementation calls `evaluate` first. A sparse readout does not itself reduce that evaluation to its necessary word states. |
| `compile_polynomial` and `PolynomialPlan.contract(..., chunk_size=...)` | Physical-offset monomials, restrictions on span/support/multiplicity, and chunked contraction without one concatenated feature tensor | It enumerates the chosen polynomial dictionary; it is not a named pooled-moment or arbitrary signature-word compiler. |
| `GapFactorizedVolterra` | A public learned readout with factored positive-gap and terminal-lag weights; complete strict plans have a dynamic backend | Do not propose a new generic Volterra/gap-factorized layer. Fixed lag-moment recipes for ridge are a smaller, distinct need. |

A useful future execution feature would compile a **small list of weighted word
sums** directly from increments, sharing their necessary prefix states. Examples
are selected signed areas, polynomial gap moments and cross-modality
interactions. The internal word-program machinery already shares prefixes for
the existing chronological charts. A public explicit-word or sparse-functional
entry point could reuse it; it would need a defined convention for coefficients,
word labels and omitted dependencies. This is a proposed extension, not an API
implemented or timed by the HAR example.

This matters as code width and depth grow. With \(d\) observables and \(P\)
code columns, dense extraction returns \(\sum_{m=1}^M(dP)^m\) coordinates.
Taking a larger \(P\) to obtain a few specific lag contractions need not justify
paying for all of those coordinates. First benchmark the existing
`WordSelection` against the ridge reference; its coordinate restriction changes
the model and should not be described as a lossless speedup by default.

The current family experiment already tests **signatures of invariant streams**:
triad energies, cross-triad dot products and lagged dot products, all formed
before axiswise normalization. QR Pascal coding of these streams preserves
their invariance. No new tensorsig API is needed for that construction.

A distinct next readout is a **spatial contraction of a vector signature**.
For vector group \(g\), spatial coordinate \(a\) and code column \(p\), set

\[
T_{(g,p),(h,q)}=\sum_{a=1}^3 S^{(g,a,p),(h,a,q)}.
\]

This retains code-weighted cross-time dot products. A common orthogonal matrix
cancels when the spatial index is summed, while code indices remain available
to the classifier. For three vector groups and P3 this gives 81 depth-two
coordinates. Its symmetric part contains dot products of coded first-level
vectors; its antisymmetric part retains directed interactions between vector
groups/code columns. It differs from signing pointwise norms or Gram streams,
which have already compressed the vector history. An explicit spatial-index
contraction helper would make this readout easier to express and potentially
avoid materializing irrelevant coordinates. It has **not** been run here.

No public named SO(3)-contraction or cyclic-signature readout was found in the
checked source. Gravity orientation can be predictive of posture, so appending
raw axis features intentionally gives up full rotation invariance. Likewise,
[loop and closure invariants](https://arxiv.org/abs/2412.19670) concern specified
path operations; arbitrary HAR crops need not be closed or contain complete
cycles. Choose the nuisance transformation before adding an invariant API.

Rolling computation is partly implemented already: classical windows, eligible
offset rolling and experimental `RollingLogSignature` with Pascal rebasing and
selected quotient rules exist. A stable public online state is a possible
extension. Pre-cut HAR rows cannot be concatenated indiscriminately to claim a
streaming speedup across people or activities.

Checked local API sources (relative to the sibling checkout):

- [Path augmentations](../../../tensorsig/src/tensorsig/offset_coded_signatures/path_augmentations.py)
- [Offset codes](../../../tensorsig/src/tensorsig/offset_coded_signatures/alphabet.py)
- [Polynomial and signature plans](../../../tensorsig/src/tensorsig/offset_coded_signatures/plan.py)
- [Public coordinate selections](../../../tensorsig/src/tensorsig/offset_coded_signatures/coordinates.py)
- [Existing tensor basis maps and contractions](../../../tensorsig/src/tensorsig/tensor_ops/linear.py)
- [Gap-factorized Volterra implementation](../../../tensorsig/src/tensorsig/offset_coded_signatures/gap_factorized_volterra.py)
- [Shared internal word program](../../../tensorsig/src/tensorsig/offset_coded_signatures/word_program.py)
- [Experimental rolling interface and limits](../../../tensorsig/src/tensorsig/offset_coded_signatures/experimental/rolling_logsignature/README.md)

## Spectral ablations: small readouts with declared endpoint constraints

The new [spectral readouts](spectral_readouts.py) make one narrow addition worth
considering: a convenient chart for **coded probability measures**. After an
FFT, normalize each channel's power to mass one and integrate along frequency.
The constant-code first endpoint is then fixed. Shuffle identities remove
additional affine redundancy from the depth-two tensor. For five groups of
four channels with P3, the full tensor has 780 columns, its nonconstant affine
span has 550 coordinates, and independent within-channel spans have only 160.
These sizes follow from the endpoint constraint, rather than a learned PCA
cutoff. The example verifies the projection and its distance preservation
before feature standardization. Column standardization changes ridge's penalty,
so this is not a claim of identical regularized predictions.

A small convenience layer could accept declared fixed endpoints and expose
endpoint, symmetric-product and antisymmetric-area readouts. Existing tensor
linear maps provide the underlying operation; this would supply the constraints
and coordinate bookkeeping. Unit mass must be checked: a zero-energy spectrum
cannot silently be treated as a probability measure. The experiment rejects
that case; a reusable application API should specify its convention explicitly.

The more consequential optimization would evaluate only requested channels,
words or weighted areas. The current example extracts dense tensors and then
projects, so its smaller feature counts primarily reduce the ridge problem.
For a normalized scalar spectrum, P3/depth2 needs eight nonconstant coordinates:
two spectral moments, three products of those moments, and three frequency-pair
areas. The areas are polynomially weighted versions of pairwise absolute
frequency differences. A named spectral-measure recipe plus direct evaluation
of these readouts would make this generic family easy to use without constructing
arbitrary FFT band tables. P3 guarantees coverage of quadratic location moments;
it does not guarantee optimal classification accuracy.

## Small-pool follow-up: observable moments and nonlinear readouts

The [small-pool experiment](POOL_STORY.md) implements moment readouts through
the existing tensorsig API in [moment_lifts.py](moment_lifts.py). No new
signature algebra is needed. Integrating a fixed pointwise polynomial lift
`(z, z**2, ..., z**r)` makes the corresponding sample moments first-level
signature and logsignature coordinates. Suitable inputs include spectral bin
amplitudes, triad energies, Gram entries and normalized Gram entries (cosines).
These are local observation transforms, rather than encodings of a completed
window statistic as a constant path.

A useful application-facing helper would distinguish the **moment generator**
from its **readout**. Raw moments, centered moments, variance, standard
deviation, skewness and kurtosis belong to one small family, with explicit
zero-variance conventions. Standardized shape and log-energy are nonlinear
readouts; calling every output a linear logsignature coordinate would be
incorrect. A numerically stable centered implementation is preferable to
subtracting large nearly equal raw moments. The current experiment verifies
the observable-integral calculation against the direct pooled implementation.

Energy plus the spectral concentration sums `sum(p**q)` for q = 1/2, 3/2, 2
determine the amplitude moments through degree four. This gives a compact,
reusable generator for the old amplitude summary block, although an unchanged
linear ridge head performs differently on raw generators and their normalized
readouts. The q=2 sum also describes the sampled quadratic variation of the
cumulative spectral mass, linking this family to lead–lag constructions.

Depth-two spectral logsignatures are already available from the first levels
and antisymmetric tensor readouts. The small example uses 100 nonconstant
within-channel coordinates. Converting between tensor and log coordinates
preserves the underlying truncated object, but a linear head on log coordinates
needs explicit endpoint products to recover tensor-linear predictors. Clear
documentation and composable readouts are the immediate opportunity here;
the lower-level evaluation and basis-map capabilities already exist.

## Closed-value graphs: a small reusable recipe

[occupation_graph.py](occupation_graph.py) provides a different moment generator:
a two-coordinate staircase holds each observation while its clock advances,
then returns the value coordinate to zero. Its genuine path logsignature has
`logS[x**r, t] = mean(z**r) / r!`. Depth 3 therefore supplies first and second
moments; depth 4 supplies third moments, together with additional ordering
coordinates. The finite-sample construction and proof are in
[occupation_theory.md](occupation_theory.md).

The existing classical `log_signature(path, depth=..., mode="words")` already
returns tensor-log coefficients at Lyndon words. It exposes `xt`, `xxt` and
`xxxt` directly in this two-letter example, along with the other coordinates.
This is distinct from requesting an arbitrary sparse word program in an offset
plan: the current experiment needs neither a new coordinate extractor nor any
library implementation. The known endpoints can simply be omitted. A reusable
application recipe could later package the staircase, channel batching, clock
weights and selected moment/ordering words, if other applications need it.

The related readout helper should state whether it returns raw moments or
nonlinear mean/std/skewness features. For near-constant streams, compute a first
graph to obtain the mean, center the observations, and compute a second graph
for central second/third moments. Subtracting large raw moments can make
skewness inaccurate even in float64; a variance threshold alone does not prevent
that cancellation. Keep the zero-variance convention and threshold explicit.
Centering is an observable pretransform, not a replacement of the algebra.

Log cumulative-energy paths are another small recipe: apply `log1p` to the
cumulative nonnegative energy before taking increments. Their endpoint is
exactly log-energy; existing QR Pascal coding adds frequency/time location
information. Both recipes can stay in the example until reuse justifies an
application-facing helper. If expected-signature cumulants are exposed later,
label their tensor logarithm separately: it is generally not a Lie
logsignature, unlike the graph construction used here.

The [Pascal clock-code follow-up](CODED_OCCUPATIONS.md) supplies a useful
optimization contract: selected graph words `x**r t_a` equal
`mean(z**r * q_a) / r!`. [coded_occupation.py](coded_occupation.py) evaluates
them with a polynomial observation lift and an existing **first-level** coded
signature, and checks the result against full graph logsignatures. A future
recipe should distinguish the graph word depth `r+1` from the depth-one
evaluation program and distinguish clock-only coding from coding every graph
increment. This shortcut computes exact selected words; it is not a new
approximation or a full graph-logsignature evaluator.

The useful compact readout parameter is the retained pair of **observable
power and code degree**. Rectangles and total-degree triangles give systematic
families without selecting arbitrary columns. Standardized scalar observations
and explicit calibration readouts remain part of their contract. These
helpers already work in the example, so no tensorsig core change is needed.
