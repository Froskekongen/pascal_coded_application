# Compact Pascal QR value–clock graphs

**365 features recover the previous 429-feature model's 98.00% accuracy;
368 features reach 98.03%.** The raw171 + spectral100 Pascal P3 QR,
depth-2 logsignature baseline stays fixed. These models use only ridge,
with no supplied 561 features.

The compact recipe is:

| Component | Features |
|---|---:|
| Fixed raw + spectral Pascal logsignatures | 271 |
| Spectral-amplitude mean/std | 40 |
| Cross-triad cosine mean/std | 6 |
| Energy, simultaneous-dot and lagged-dot mean/std/skew | 36 |
| P2/depth2 standardized invariant trends | 12 |
| **Total** | **365** |
| Optional P2/depth2 standardized cosine trends | **+3** |

It removes the 20 log-energy endpoints and all amplitude-order coordinates.
The 12 invariant streams are three triad energies, three simultaneous
cross-triad products, and three self-products at each of lags 2 and 5.
Each added trend is a signed measure of whether the standardized stream's
larger values occur earlier or later in the window.

**P2/depth2 describes the added trend branch.** The retained mean/std/skew
calibration still uses graph moments through depth 3 for mean/std and depth 4
for skew, followed by the explicit nonlinear readouts. This is not a claim
that the entire extra representation comes from a depth-2 graph.

| Model, including the fixed 271-feature baseline | Features | Accuracy | Errors |
|---|---:|---:|---:|
| Previous ordinary-graph reference | 429 | 98.00% | 59 |
| Exact coded-clock reconstruction of reference | 429 | 98.00% | 59 |
| Original 102-readout pool + amplitude/invariant P2/depth2 trends | 405 | 98.00% | 59 |
| Same pool + amplitude P2/depth2, invariant P2/depth3 | 417 | 98.03% | 58 |
| Same pool + amplitude P2/depth2, invariant P3/depth2 | 417 | 98.03% | 58 |
| Reduced 82-readout pool alone | 353 | 97.86% | 63 |
| Reduced pool + 12 invariant trends | **365** | **98.00%** | **59** |
| Reduced pool + invariant and cosine trends | **368** | **98.03%** | **58** |
| Best wider construction: original pool + cosine/invariant P3/depth4 | 463 | 98.07% | 57 |

The 365-feature model corrects seven reference errors and introduces seven;
the 368-feature model corrects seven and introduces six. Equal accuracy does
not mean identical predictions. In contrast, the coded reconstruction of the
429-feature reference reproduces **every prediction**. The wider sweep's
98.07% is only two fewer errors than the reference and misses the compactness
target. These are exploratory comparisons after repeated use of the same
2,947-window official test split, not evidence of a reliable one-window gain.

The construction keeps the closed value coordinate \(x\), but replaces its
clock holds by \(P\) clock increments \(q_a(k)/N\). Here \(q_a\) is QR
Pascal column \(a\), indexed from zero. For any scalar observations \(z_k\),

\[
(\log S)^{x^r t_a}
=\frac{1}{r!N}\sum_k q_a(k)z_k^r.
\]

The signature integral gives the right side directly. All tensor-log
corrections have a pure-value prefix, which vanishes because the value
coordinate returns to zero. Thus these are selected coordinates of a genuine
graph logsignature. The implementation evaluates them exactly using a fused
polynomial observation lift and a level-one `tensorsig` coded signature;
small explicit graph computations check this equivalence.

For added order features, observations are centered and divided by their
window std, with the existing zero-variance convention. Constant-code P1
moments provide the calibration and are not counted again as new features.
Positive code degree \(a\) describes location; value power \(r\) describes
the moment. Rectangles retain \(1\le a<P,\ 1\le r<d\); triangles also impose
\(a+r\le K\). P2/depth3 retains value and squared-value trends, while
P3/depth2 retains value trend and curvature.

The relation to the old ordinary-graph words is exact, including finite
clock holds. With midpoint \(c_k=(k+1/2)/N\) and \(\langle\cdot\rangle\)
denoting the sample mean,

\[
L^{xtt}=\langle(1/2-c)z\rangle,\qquad
L^{xxtt}=\tfrac12\langle(1/2-c)z^2\rangle,
\]
\[
L^{xttt}=\tfrac12\left\langle
\left(c^2-c+\tfrac16+\tfrac1{12N^2}\right)z\right\rangle.
\]

The two displayed polynomial weights are proportional to QR columns
\(q_1\) and \(q_2\), respectively. The final term corrects for each hold's
finite width. Consequently the reference's ordering coordinates are merely
rescaled versions of \(\langle q_1z\rangle\),
\(\langle q_1z^2\rangle\), and \(\langle q_2z\rangle\).
Training StandardScaler removes these separate scale changes, preserving
ridge predictions. This argument concerns diagonal rescaling; an arbitrary
change of basis spanning the same features need not preserve ridge geometry.
Coding reduces the required word depth here; the observed feature-count
reduction comes from dropping unneeded coordinates and readouts.

The sweep used P = 1, 2, 3, 4, 6 and graph depths 2–4, with rectangles,
triangles, and mixed family choices. Identical selections were deduplicated;
wide candidates were capped at 600 features and compact mixtures at 429.
All 310 fits, including controls, took **22.544 seconds**. Shared preparation
took 11.036 seconds and includes reference graph extraction; it is not an
optimized per-model extraction cost. The 365/368-feature ridge fits took
about 10 ms each, with test predictions about 1.5 ms. All fits use alpha 10,
training-only StandardScaler, and the existing float64 ridge solver.

Only clocks are coded here. Full offset coding of both graph value and clock
increments is a different construction: coded value endpoints generally
stop closing, so the weighted-moment identity changes. It was not tried.

Reproduce from the repository root:

```bash
../tensorsig/.venv/bin/python examples/uci_har/benchmark.py --coded-occupations
```

See [readout implementation](coded_occupation.py),
[sweep](coded_occupation_sweep.py), [complete results](coded_occupation_results/results.csv),
[run metadata](coded_occupation_results/run.json), and the preceding
[occupation theory](occupation_theory.md). Future library proposals remain
in [tensorsig_suggestions.md](tensorsig_suggestions.md).
