# UCI HAR exploratory results

7,352 training / 2,947 test windows; official subject-disjoint split, fixed classifier settings, exploratory feature comparisons.

Accuracy and macro F1 are percentages. Times are seconds on this machine. Extraction includes train and test, with full calculations shared across readouts; do not sum extraction columns across heads or claim sparse quotient acceleration. The 561-feature extraction time is unmeasured (CSV placeholder 0); hybrid timings measure only the additional features.

## Best row per input/augmentation and head

These are descriptive test-set maxima over representations, not validation-selected models.

| Input / augmentation | Head | Representation | Features | Accuracy | Macro F1 | Extract | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|---:|
| engineered_561 | ridge | uci_features | 561 | 95.72 | 95.85 | 0.000 | 0.021 | 0.002 |
| raw_pascal_reference | ridge | pascal_qr_P3_depth2 | 342 | 84.22 | 84.33 | 0.314 | 0.009 | 0.001 |
| 561_plus_generator_identity | ridge | pascal_qr_P3_depth2 | 903 | 97.12 | 97.16 | 0.314 | 0.035 | 0.002 |
| family_moments | ridge | pooled_plus_pascal_qr_P4_depth2 | 1905 | 91.11 | 91.26 | 3.060 | 0.124 | 0.005 |
| family_moments_plus_raw_pascal | ridge | pooled_plus_pascal_qr_P3_depth1 | 501 | 93.04 | 93.15 | 3.016 | 0.015 | 0.001 |
| family_filters_delays | ridge | pooled_plus_pascal_qr_P1_depth2 | 362 | 87.04 | 87.13 | 3.804 | 0.010 | 0.001 |
| family_filters_delays_plus_raw_pascal | ridge | pooled_plus_pascal_qr_P1_depth1 | 524 | 94.71 | 94.77 | 4.118 | 0.016 | 0.001 |
| family_spectral | ridge | pooled_plus_pascal_qr_P1_depth3 | 719 | 96.27 | 96.27 | 2.398 | 0.023 | 0.003 |
| family_spectral_plus_raw_pascal | ridge | pooled_plus_pascal_qr_P3_depth2 | 1441 | 96.95 | 97.00 | 2.656 | 0.076 | 0.006 |
| family_rotation | ridge | pooled_plus_pascal_qr_P2_depth3 | 1146 | 90.23 | 90.17 | 3.218 | 0.051 | 0.003 |
| family_rotation_plus_raw_pascal | ridge | pooled_plus_pascal_qr_P4_depth1 | 504 | 96.64 | 96.66 | 2.884 | 0.015 | 0.001 |
| family_combined | ridge | pooled_plus_pascal_qr_P1_depth1 | 790 | 97.79 | 97.83 | 5.887 | 0.027 | 0.003 |
| family_combined_plus_raw_pascal | ridge | pooled | 1066 | 98.07 | 98.13 | 2.215 | 0.042 | 0.004 |
| 561_plus_family_combined | ridge | pooled | 1285 | 98.37 | 98.42 | 1.901 | 0.063 | 0.005 |

## Every comparison

| Input / augmentation | Representation | Head | Features | Accuracy | Macro F1 | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|
| engineered_561 | uci_features | ridge | 561 | 95.72 | 95.85 | 0.021 | 0.002 |
| raw_pascal_reference | pascal_qr_P3_depth2 | ridge | 342 | 84.22 | 84.33 | 0.009 | 0.001 |
| 561_plus_generator_identity | pascal_qr_P3_depth2 | ridge | 903 | 97.12 | 97.16 | 0.035 | 0.002 |
| family_moments | pooled | ridge | 105 | 85.88 | 85.93 | 0.003 | 0.000 |
| family_moments_plus_raw_pascal | pooled | ridge | 447 | 92.23 | 92.32 | 0.013 | 0.001 |
| family_moments | pooled_plus_pascal_qr_P1_depth1 | ridge | 123 | 86.73 | 86.74 | 0.003 | 0.000 |
| family_moments_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth1 | ridge | 465 | 92.91 | 93.00 | 0.014 | 0.002 |
| family_moments | pooled_plus_pascal_qr_P1_depth2 | ridge | 231 | 87.78 | 87.70 | 0.006 | 0.001 |
| family_moments_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth2 | ridge | 573 | 91.79 | 91.92 | 0.018 | 0.002 |
| family_moments | pooled_plus_pascal_qr_P1_depth3 | ridge | 879 | 89.38 | 89.38 | 0.034 | 0.003 |
| family_moments_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth3 | ridge | 1221 | 91.69 | 91.86 | 0.056 | 0.004 |
| family_moments | pooled_plus_pascal_qr_P2_depth1 | ridge | 141 | 86.80 | 86.79 | 0.004 | 0.001 |
| family_moments_plus_raw_pascal | pooled_plus_pascal_qr_P2_depth1 | ridge | 483 | 92.94 | 93.05 | 0.014 | 0.001 |
| family_moments | pooled_plus_pascal_qr_P2_depth2 | ridge | 573 | 90.33 | 90.35 | 0.018 | 0.002 |
| family_moments_plus_raw_pascal | pooled_plus_pascal_qr_P2_depth2 | ridge | 915 | 92.03 | 92.18 | 0.035 | 0.003 |
| family_moments | pooled_plus_pascal_qr_P2_depth3 | ridge | 5757 | 90.43 | 90.58 | 1.248 | 0.013 |
| family_moments_plus_raw_pascal | pooled_plus_pascal_qr_P2_depth3 | ridge | 6099 | 91.35 | 91.52 | 1.383 | 0.017 |
| family_moments | pooled_plus_pascal_qr_P3_depth1 | ridge | 159 | 86.94 | 86.93 | 0.004 | 0.001 |
| family_moments_plus_raw_pascal | pooled_plus_pascal_qr_P3_depth1 | ridge | 501 | 93.04 | 93.15 | 0.015 | 0.001 |
| family_moments | pooled_plus_pascal_qr_P3_depth2 | ridge | 1131 | 90.84 | 90.94 | 0.050 | 0.003 |
| family_moments_plus_raw_pascal | pooled_plus_pascal_qr_P3_depth2 | ridge | 1473 | 91.79 | 91.93 | 0.078 | 0.004 |
| family_moments | pascal_qr_P3_depth2_only | ridge | 1026 | 90.43 | 90.45 | 0.043 | 0.003 |
| family_moments_plus_raw_pascal | pascal_qr_P3_depth2_only | ridge | 1368 | 92.09 | 92.23 | 0.065 | 0.006 |
| family_moments | pooled_plus_P3_first_products | ridge | 672 | 88.70 | 88.67 | 0.023 | 0.002 |
| family_moments_plus_raw_pascal | pooled_plus_P3_first_products | ridge | 1014 | 91.96 | 92.13 | 0.041 | 0.003 |
| family_moments | pooled_plus_pascal_qr_P4_depth1 | ridge | 177 | 87.00 | 87.02 | 0.004 | 0.001 |
| family_moments_plus_raw_pascal | pooled_plus_pascal_qr_P4_depth1 | ridge | 519 | 92.98 | 93.08 | 0.016 | 0.001 |
| family_moments | pooled_plus_pascal_qr_P4_depth2 | ridge | 1905 | 91.11 | 91.26 | 0.124 | 0.005 |
| family_moments_plus_raw_pascal | pooled_plus_pascal_qr_P4_depth2 | ridge | 2247 | 91.92 | 92.11 | 0.165 | 0.006 |
| family_filters_delays | pooled | ridge | 146 | 81.64 | 81.40 | 0.004 | 0.000 |
| family_filters_delays_plus_raw_pascal | pooled | ridge | 488 | 93.04 | 93.04 | 0.014 | 0.001 |
| family_filters_delays | pooled_plus_pascal_qr_P1_depth1 | ridge | 182 | 84.59 | 84.49 | 0.005 | 0.001 |
| family_filters_delays_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth1 | ridge | 524 | 94.71 | 94.77 | 0.016 | 0.001 |
| family_filters_delays | pooled_plus_pascal_qr_P1_depth2 | ridge | 362 | 87.04 | 87.13 | 0.010 | 0.001 |
| family_filters_delays_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth2 | ridge | 704 | 94.50 | 94.55 | 0.025 | 0.002 |
| family_filters_delays | pooled_plus_pascal_qr_P1_depth3 | ridge | 1334 | 86.12 | 86.16 | 0.064 | 0.004 |
| family_filters_delays_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth3 | ridge | 1676 | 93.52 | 93.55 | 0.092 | 0.004 |
| family_filters_delays | pooled_plus_pascal_qr_P2_depth1 | ridge | 218 | 85.14 | 85.07 | 0.005 | 0.001 |
| family_filters_delays_plus_raw_pascal | pooled_plus_pascal_qr_P2_depth1 | ridge | 560 | 94.64 | 94.70 | 0.017 | 0.002 |
| family_filters_delays | pooled_plus_pascal_qr_P2_depth2 | ridge | 938 | 86.63 | 86.71 | 0.036 | 0.002 |
| family_filters_delays_plus_raw_pascal | pooled_plus_pascal_qr_P2_depth2 | ridge | 1280 | 94.50 | 94.54 | 0.066 | 0.003 |
| family_filters_delays | pooled_plus_pascal_qr_P3_depth1 | ridge | 254 | 85.37 | 85.31 | 0.006 | 0.001 |
| family_filters_delays_plus_raw_pascal | pooled_plus_pascal_qr_P3_depth1 | ridge | 596 | 94.57 | 94.62 | 0.019 | 0.002 |
| family_filters_delays | pooled_plus_pascal_qr_P3_depth2 | ridge | 1874 | 86.60 | 86.68 | 0.119 | 0.005 |
| family_filters_delays_plus_raw_pascal | pooled_plus_pascal_qr_P3_depth2 | ridge | 2216 | 93.59 | 93.58 | 0.156 | 0.005 |
| family_filters_delays | pascal_qr_P3_depth2_only | ridge | 1728 | 64.85 | 64.36 | 0.105 | 0.004 |
| family_filters_delays_plus_raw_pascal | pascal_qr_P3_depth2_only | ridge | 2070 | 91.48 | 91.54 | 0.139 | 0.005 |
| family_filters_delays | pooled_plus_P3_first_products | ridge | 1118 | 85.68 | 85.70 | 0.048 | 0.003 |
| family_filters_delays_plus_raw_pascal | pooled_plus_P3_first_products | ridge | 1460 | 94.16 | 94.19 | 0.073 | 0.004 |
| family_filters_delays | pooled_plus_pascal_qr_P4_depth1 | ridge | 290 | 85.37 | 85.32 | 0.008 | 0.001 |
| family_filters_delays_plus_raw_pascal | pooled_plus_pascal_qr_P4_depth1 | ridge | 632 | 94.67 | 94.73 | 0.020 | 0.002 |
| family_filters_delays | pooled_plus_pascal_qr_P4_depth2 | ridge | 3170 | 86.19 | 86.29 | 0.332 | 0.008 |
| family_filters_delays_plus_raw_pascal | pooled_plus_pascal_qr_P4_depth2 | ridge | 3512 | 93.04 | 93.00 | 0.407 | 0.010 |
| family_spectral | pooled | ridge | 359 | 95.25 | 95.23 | 0.009 | 0.001 |
| family_spectral_plus_raw_pascal | pooled | ridge | 701 | 96.54 | 96.59 | 0.022 | 0.003 |
| family_spectral | pooled_plus_pascal_qr_P1_depth1 | ridge | 359 | 95.25 | 95.23 | 0.009 | 0.001 |
| family_spectral_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth1 | ridge | 701 | 96.54 | 96.59 | 0.022 | 0.003 |
| family_spectral | pooled_plus_pascal_qr_P1_depth2 | ridge | 419 | 95.55 | 95.55 | 0.011 | 0.002 |
| family_spectral_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth2 | ridge | 761 | 96.50 | 96.55 | 0.025 | 0.003 |
| family_spectral | pooled_plus_pascal_qr_P1_depth3 | ridge | 719 | 96.27 | 96.27 | 0.023 | 0.003 |
| family_spectral_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth3 | ridge | 1061 | 96.84 | 96.89 | 0.042 | 0.004 |
| family_spectral | pooled_plus_pascal_qr_P2_depth1 | ridge | 379 | 95.22 | 95.20 | 0.010 | 0.002 |
| family_spectral_plus_raw_pascal | pooled_plus_pascal_qr_P2_depth1 | ridge | 721 | 96.50 | 96.56 | 0.023 | 0.003 |
| family_spectral | pooled_plus_pascal_qr_P2_depth2 | ridge | 679 | 96.06 | 96.10 | 0.021 | 0.003 |
| family_spectral_plus_raw_pascal | pooled_plus_pascal_qr_P2_depth2 | ridge | 1021 | 96.81 | 96.87 | 0.040 | 0.003 |
| family_spectral | pooled_plus_pascal_qr_P2_depth3 | ridge | 3219 | 95.86 | 95.87 | 0.331 | 0.011 |
| family_spectral_plus_raw_pascal | pooled_plus_pascal_qr_P2_depth3 | ridge | 3561 | 96.61 | 96.66 | 0.419 | 0.012 |
| family_spectral | pooled_plus_pascal_qr_P3_depth1 | ridge | 399 | 95.35 | 95.35 | 0.010 | 0.002 |
| family_spectral_plus_raw_pascal | pooled_plus_pascal_qr_P3_depth1 | ridge | 741 | 96.47 | 96.53 | 0.025 | 0.003 |
| family_spectral | pooled_plus_pascal_qr_P3_depth2 | ridge | 1099 | 96.06 | 96.09 | 0.044 | 0.004 |
| family_spectral_plus_raw_pascal | pooled_plus_pascal_qr_P3_depth2 | ridge | 1441 | 96.95 | 97.00 | 0.076 | 0.006 |
| family_spectral | pascal_qr_P3_depth2_only | ridge | 740 | 87.61 | 87.75 | 0.024 | 0.003 |
| family_spectral_plus_raw_pascal | pascal_qr_P3_depth2_only | ridge | 1082 | 95.22 | 95.19 | 0.043 | 0.004 |
| family_spectral | pooled_plus_P3_first_products | ridge | 739 | 95.76 | 95.80 | 0.024 | 0.003 |
| family_spectral_plus_raw_pascal | pooled_plus_P3_first_products | ridge | 1081 | 96.61 | 96.67 | 0.043 | 0.004 |
| family_spectral | pooled_plus_pascal_qr_P4_depth1 | ridge | 419 | 95.35 | 95.35 | 0.011 | 0.002 |
| family_spectral_plus_raw_pascal | pooled_plus_pascal_qr_P4_depth1 | ridge | 761 | 96.54 | 96.59 | 0.025 | 0.003 |
| family_spectral | pooled_plus_pascal_qr_P4_depth2 | ridge | 1679 | 95.96 | 95.99 | 0.094 | 0.006 |
| family_spectral_plus_raw_pascal | pooled_plus_pascal_qr_P4_depth2 | ridge | 2021 | 96.74 | 96.79 | 0.134 | 0.007 |
| family_rotation | pooled | ridge | 114 | 87.58 | 87.47 | 0.003 | 0.000 |
| family_rotation_plus_raw_pascal | pooled | ridge | 456 | 96.44 | 96.44 | 0.013 | 0.001 |
| family_rotation | pooled_plus_pascal_qr_P1_depth1 | ridge | 126 | 87.58 | 87.47 | 0.003 | 0.000 |
| family_rotation_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth1 | ridge | 468 | 96.47 | 96.48 | 0.014 | 0.001 |
| family_rotation | pooled_plus_pascal_qr_P1_depth2 | ridge | 162 | 88.12 | 88.02 | 0.004 | 0.000 |
| family_rotation_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth2 | ridge | 504 | 96.03 | 96.02 | 0.015 | 0.002 |
| family_rotation | pooled_plus_pascal_qr_P1_depth3 | ridge | 270 | 89.28 | 89.25 | 0.007 | 0.001 |
| family_rotation_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth3 | ridge | 612 | 96.10 | 96.06 | 0.020 | 0.002 |
| family_rotation | pooled_plus_pascal_qr_P2_depth1 | ridge | 138 | 87.51 | 87.39 | 0.004 | 0.000 |
| family_rotation_plus_raw_pascal | pooled_plus_pascal_qr_P2_depth1 | ridge | 480 | 96.44 | 96.45 | 0.014 | 0.001 |
| family_rotation | pooled_plus_pascal_qr_P2_depth2 | ridge | 282 | 89.18 | 89.13 | 0.007 | 0.001 |
| family_rotation_plus_raw_pascal | pooled_plus_pascal_qr_P2_depth2 | ridge | 624 | 96.13 | 96.11 | 0.020 | 0.002 |
| family_rotation | pooled_plus_pascal_qr_P2_depth3 | ridge | 1146 | 90.23 | 90.17 | 0.051 | 0.003 |
| family_rotation_plus_raw_pascal | pooled_plus_pascal_qr_P2_depth3 | ridge | 1488 | 96.03 | 96.00 | 0.076 | 0.004 |
| family_rotation | pooled_plus_pascal_qr_P3_depth1 | ridge | 150 | 87.78 | 87.68 | 0.004 | 0.000 |
| family_rotation_plus_raw_pascal | pooled_plus_pascal_qr_P3_depth1 | ridge | 492 | 96.54 | 96.55 | 0.015 | 0.001 |
| family_rotation | pooled_plus_pascal_qr_P3_depth2 | ridge | 474 | 89.55 | 89.46 | 0.014 | 0.001 |
| family_rotation_plus_raw_pascal | pooled_plus_pascal_qr_P3_depth2 | ridge | 816 | 96.17 | 96.14 | 0.029 | 0.002 |
| family_rotation | pascal_qr_P3_depth2_only | ridge | 360 | 75.64 | 71.10 | 0.010 | 0.001 |
| family_rotation_plus_raw_pascal | pascal_qr_P3_depth2_only | ridge | 702 | 91.92 | 91.92 | 0.024 | 0.002 |
| family_rotation | pooled_plus_P3_first_products | ridge | 330 | 89.14 | 89.10 | 0.009 | 0.001 |
| family_rotation_plus_raw_pascal | pooled_plus_P3_first_products | ridge | 672 | 95.89 | 95.85 | 0.022 | 0.002 |
| family_rotation | pooled_plus_pascal_qr_P3_depth3 | ridge | 3390 | 89.58 | 89.46 | 0.382 | 0.008 |
| family_rotation_plus_raw_pascal | pooled_plus_pascal_qr_P3_depth3 | ridge | 3732 | 95.05 | 94.95 | 0.475 | 0.011 |
| family_rotation | pooled_plus_pascal_qr_P4_depth1 | ridge | 162 | 87.92 | 87.80 | 0.004 | 0.000 |
| family_rotation_plus_raw_pascal | pooled_plus_pascal_qr_P4_depth1 | ridge | 504 | 96.64 | 96.66 | 0.015 | 0.001 |
| family_rotation | pooled_plus_pascal_qr_P4_depth2 | ridge | 738 | 89.92 | 89.88 | 0.026 | 0.002 |
| family_rotation_plus_raw_pascal | pooled_plus_pascal_qr_P4_depth2 | ridge | 1080 | 96.06 | 96.04 | 0.044 | 0.003 |
| family_combined | pooled | ridge | 724 | 97.79 | 97.83 | 0.023 | 0.003 |
| family_combined_plus_raw_pascal | pooled | ridge | 1066 | 98.07 | 98.13 | 0.042 | 0.004 |
| family_combined | pooled_plus_pascal_qr_P1_depth1 | ridge | 790 | 97.79 | 97.83 | 0.027 | 0.003 |
| family_combined_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth1 | ridge | 1132 | 97.93 | 97.99 | 0.047 | 0.004 |
| family_combined | pooled_plus_pascal_qr_P1_depth2 | ridge | 1174 | 96.44 | 96.45 | 0.049 | 0.004 |
| family_combined_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth2 | ridge | 1516 | 97.05 | 97.11 | 0.083 | 0.006 |
| family_combined | pooled_plus_pascal_qr_P1_depth3 | ridge | 3202 | 95.35 | 95.34 | 0.333 | 0.011 |
| family_combined_plus_raw_pascal | pooled_plus_pascal_qr_P1_depth3 | ridge | 3544 | 96.20 | 96.21 | 0.403 | 0.012 |
| family_combined | pooled_plus_pascal_qr_P2_depth1 | ridge | 876 | 97.73 | 97.76 | 0.030 | 0.003 |
| family_combined_plus_raw_pascal | pooled_plus_pascal_qr_P2_depth1 | ridge | 1218 | 97.83 | 97.88 | 0.053 | 0.004 |
| family_combined | pooled_plus_pascal_qr_P2_depth2 | ridge | 2472 | 96.27 | 96.27 | 0.191 | 0.008 |
| family_combined_plus_raw_pascal | pooled_plus_pascal_qr_P2_depth2 | ridge | 2814 | 96.95 | 97.00 | 0.255 | 0.009 |
| family_combined | pooled_plus_pascal_qr_P3_depth1 | ridge | 962 | 97.69 | 97.72 | 0.037 | 0.003 |
| family_combined_plus_raw_pascal | pooled_plus_pascal_qr_P3_depth1 | ridge | 1304 | 97.86 | 97.92 | 0.057 | 0.005 |
| family_combined | pooled_plus_pascal_qr_P3_depth2 | ridge | 4578 | 95.62 | 95.62 | 0.748 | 0.015 |
| family_combined_plus_raw_pascal | pooled_plus_pascal_qr_P3_depth2 | ridge | 4920 | 96.37 | 96.42 | 0.832 | 0.016 |
| family_combined | pooled_plus_pascal_qr_P4_depth1 | ridge | 1048 | 97.79 | 97.83 | 0.041 | 0.004 |
| family_combined_plus_raw_pascal | pooled_plus_pascal_qr_P4_depth1 | ridge | 1390 | 97.83 | 97.89 | 0.065 | 0.006 |
| family_combined | pooled_plus_pascal_qr_P4_depth2 | ridge | 7492 | 94.60 | 94.62 | 2.273 | 0.044 |
| family_combined_plus_raw_pascal | pooled_plus_pascal_qr_P4_depth2 | ridge | 7834 | 95.11 | 95.14 | 2.186 | 0.032 |
| family_combined | pascal_qr_P3_depth2_only | ridge | 3854 | 93.86 | 93.90 | 0.537 | 0.016 |
| family_combined_plus_raw_pascal | pascal_qr_P3_depth2_only | ridge | 4196 | 94.33 | 94.42 | 0.622 | 0.015 |
| family_combined | pooled_plus_P3_first_products | ridge | 2859 | 96.06 | 96.10 | 0.284 | 0.010 |
| family_combined_plus_raw_pascal | pooled_plus_P3_first_products | ridge | 3201 | 96.54 | 96.61 | 0.354 | 0.011 |
| 561_plus_family_combined | pooled | ridge | 1285 | 98.37 | 98.42 | 0.063 | 0.005 |
| 561_plus_family_combined | pooled_plus_raw_pascal | ridge | 1627 | 98.17 | 98.22 | 0.088 | 0.006 |

## Adding features to the 561 features

Corrected and lost predictions compare the hybrid with the same head on the 561 features alone. They are descriptive counts on this test split, not significance tests.

| Hybrid / representation / head | Corrected errors | Introduced errors |
|---|---:|---:|
| 561_plus_generator_identity/pascal_qr_P3_depth2/ridge | 59 | 18 |
| 561_plus_family_combined/pooled/ridge | 89 | 11 |
| 561_plus_family_combined/pooled_plus_raw_pascal/ridge | 87 | 15 |
