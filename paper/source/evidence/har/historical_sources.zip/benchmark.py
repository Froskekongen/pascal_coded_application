"""Small UCI HAR experiment. See README.md; run with --help for subsets."""

from __future__ import annotations

import argparse
import csv
import io
import json
import os
import platform
import shutil
import urllib.request
import zipfile
from pathlib import Path
from time import perf_counter

# Apple Accelerate is not controlled by threadpoolctl. Keep the numerical
# runtimes serial; forests still parallelize across trees with --jobs.
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import numpy as np
import sklearn
import torch
from features import (
    augment,
    direct_covariation,
    extract_features,
    extract_fourier_features,
    self_check,
)
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import RidgeClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from threadpoolctl import threadpool_limits

HERE = Path(__file__).resolve().parent
DATA_URL = "https://archive.ics.uci.edu/static/public/240/human+activity+recognition+using+smartphones.zip"
VARIANTS = {
    "body_time": ("body", "time"),
    "body_basepoint": ("body", "basepoint"),
    "total_basepoint": ("total", "basepoint"),
    "total_integrated": ("total", "integrated"),
    "total_integrated_covariation": ("total", "integrated"),
    "total_integrated_leadlag": ("total", "integrated_leadlag"),
    "total_leadlag": ("total", "leadlag"),
    "total_magnitude": ("total", "magnitude"),
    "total_delay2": ("total", "delay2"),
    "total_delay5": ("total", "delay5"),
}
HEADS = ("ridge", "rbf_svm", "random_forest")
ACTIVITIES = ("walking", "upstairs", "downstairs", "sitting", "standing", "lying")


def download(destination: Path) -> None:
    if destination.exists():
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(".part")
    try:
        with urllib.request.urlopen(DATA_URL, timeout=120) as response, temporary.open("wb") as out:
            shutil.copyfileobj(response, out)
        if not zipfile.is_zipfile(temporary):
            raise ValueError("UCI download is not a ZIP archive")
        temporary.replace(destination)
    finally:
        temporary.unlink(missing_ok=True)


def load_data(source: Path) -> dict:
    """Read the UCI archive directly, including its nested ZIP; no extraction."""
    result = {}
    with zipfile.ZipFile(source) as outer:
        inner_name = next((n for n in outer.namelist() if n.endswith("UCI HAR Dataset.zip")), None)
        inner = zipfile.ZipFile(io.BytesIO(outer.read(inner_name))) if inner_name else outer
        try:
            names = inner.namelist()
            prefix = next(n[:-len("train/y_train.txt")] for n in names if n.endswith("train/y_train.txt"))
            for split, count in (("train", 7352), ("test", 2947)):
                def read(name, dtype=float, split=split):
                    with inner.open(prefix + split + "/" + name) as stream:
                        return np.loadtxt(stream, dtype=dtype)

                signals = np.stack([
                    read(f"Inertial Signals/{sensor}_{axis}_{split}.txt")
                    for sensor in ("body_acc", "body_gyro", "total_acc")
                    for axis in "xyz"
                ], axis=-1)
                engineered = read(f"X_{split}.txt")
                labels = read(f"y_{split}.txt", int) - 1
                subjects = read(f"subject_{split}.txt", int)
                if (signals.shape != (count, 128, 9) or engineered.shape != (count, 561)
                        or labels.shape != (count,) or subjects.shape != (count,)
                        or not np.isfinite(signals).all() or not np.isfinite(engineered).all()
                        or not np.array_equal(np.unique(labels), np.arange(6))):
                    raise ValueError(f"Unexpected UCI HAR data in {split}")
                result[split] = {"signals": signals, "engineered": engineered, "labels": labels, "subjects": subjects}
        finally:
            if inner is not outer:
                inner.close()
    if set(result["train"]["subjects"]) & set(result["test"]["subjects"]):
        raise ValueError("Training and test subjects overlap")
    return result


def sensor_channels(signals: np.ndarray, source: str) -> np.ndarray:
    return signals[..., :6] if source == "body" else signals[..., [6, 7, 8, 3, 4, 5]]


def classifier(name: str, args):
    # ponytail: fixed settings keep the sweep cheap; tune on training subjects if pursued.
    if name == "ridge":
        model = RidgeClassifier(alpha=10.0)
    elif name == "rbf_svm":
        model = SVC(C=10.0, gamma="scale", cache_size=512)
    else:
        return RandomForestClassifier(
            n_estimators=args.trees, max_depth=20, min_samples_leaf=2,
            max_features="sqrt", n_jobs=args.jobs, random_state=2025,
        )
    return make_pipeline(StandardScaler(), model)


def write_results(rows: list[dict], metadata: dict, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    with (output / "results.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (output / "run.json").write_text(json.dumps(metadata, indent=2) + "\n")
    lines = [
        "# UCI HAR exploratory results", "",
        (f"{metadata['train_windows']:,} training / {metadata['test_windows']:,} test windows; "
         "official subject-disjoint split, fixed classifier settings, exploratory feature comparisons."), "",
        ("Accuracy and macro F1 are percentages. Times are seconds on this machine. "
        "Extraction includes train and test, with full calculations shared across readouts; "
        "do not sum extraction columns across heads or claim sparse quotient acceleration. "
        "The 561-feature extraction time is unmeasured (CSV placeholder 0); "
        "hybrid timings measure only the additional features."), "",
        "## Best row per input/augmentation and head", "",
        "These are descriptive test-set maxima over representations, not validation-selected models.", "",
        "| Input / augmentation | Head | Representation | Features | Accuracy | Macro F1 | Extract | Fit | Predict |",
        "|---|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    for variant in dict.fromkeys(row["variant"] for row in rows):
        for head in dict.fromkeys(row["head"] for row in rows):
            candidates = [r for r in rows if r["variant"] == variant and r["head"] == head]
            if not candidates:
                continue
            r = max(candidates, key=lambda row: row["macro_f1"])
            lines.append(f"| {variant} | {head} | {r['representation']} | {r['features']} | "
                         f"{100*r['accuracy']:.2f} | {100*r['macro_f1']:.2f} | "
                         f"{r['extract_s']:.3f} | {r['fit_s']:.3f} | {r['predict_s']:.3f} |")
    lines += ["", "## Every comparison", "", "| Input / augmentation | Representation | Head | Features | Accuracy | Macro F1 | Fit | Predict |",
              "|---|---|---|---:|---:|---:|---:|---:|"]
    for r in rows:
        lines.append(f"| {r['variant']} | {r['representation']} | {r['head']} | {r['features']} | "
                     f"{100*r['accuracy']:.2f} | {100*r['macro_f1']:.2f} | {r['fit_s']:.3f} | {r['predict_s']:.3f} |")
    if metadata.get("paired_vs_561"):
        lines += ["", "## Adding features to the 561 features", "",
                  ("Corrected and lost predictions compare the hybrid with the same head on the 561 features alone. "
                   "They are descriptive counts on this test split, not significance tests."), "",
                  "| Hybrid / representation / head | Corrected errors | Introduced errors |",
                  "|---|---:|---:|"]
        for name, counts in metadata["paired_vs_561"].items():
            lines.append(f"| {name} | {counts['corrected']} | {counts['introduced']} |")
    (output / "RESULTS.md").write_text("\n".join(lines) + "\n")


def pascal_sweep(evaluate, signals, n_train, engineered, args, metadata):
    """Small full-tensor grid and reusable pretransforms, all with ridge."""
    from features import _standardize
    from generators import coded_integration, transform_observations

    begin = perf_counter()
    x = _standardize(torch.as_tensor(sensor_channels(signals, "total"),
                                    dtype=torch.float64), n_train)
    scaling_seconds = perf_counter() - begin
    # ponytail: a fixed size cap keeps this exploratory dense sweep cheap.
    # Add sparse word readouts if larger P/depth becomes worth pursuing.
    metadata["sweep_settings"] = {
        "P": [1, 2, 3, 4, 6], "depths": [1, 2, 3], "extra": "Pascal P1 depth4",
        "max_signature_features": 7000, "ridge_alpha": 10.0,
        "source": "training-globally standardized total_acc xyz + body_gyro xyz",
        "integration": "observations / sequence length, no clock or extra posture block",
        "codes": "Pascal QR: P columns; Fourier-Pascal QR: 1+2P columns, carrier bin4",
        "pretransform_controls": "difference, energy, lag_product, spectral_power: Pascal P1/P3, depths1/2",
        "feature_scaling": "StandardScaler fitted on training rows for every head",
        "fit_dtype": "float64 (extracted tensors stored float32, internal signature arithmetic float64)",
        "depth_reuse": "compute largest retained depth once, slice all smaller depths",
    }
    begin = perf_counter()
    paths, modalities = augment(sensor_channels(signals, "total"), "basepoint", train_size=n_train)
    preprocessing = perf_counter() - begin
    controls, times = extract_features(paths, modalities, batch_size=args.batch_size)
    ordinary = controls["ordinary_full_signature"]
    evaluate("total_basepoint", "ordinary_full_signature", ordinary,
             preprocessing + times["ordinary_full_signature"])
    evaluate("561_plus_total_basepoint", "ordinary_full_signature",
             np.concatenate((engineered, ordinary), axis=1),
             preprocessing + times["ordinary_full_signature"])
    del paths, controls

    def compare(transform, family, p, depths, observations, preprocessing):
        width = observations.shape[-1] * (p if family == "pascal" else 1 + 2 * p)
        depths = [depth for depth in depths if sum(width**k for k in range(1, depth + 1)) <= 7000]
        if not depths:
            return
        values, seconds = coded_integration(observations, p, max(depths), family,
                                            batch_size=args.batch_size)
        for depth in depths:
            size = sum(width**k for k in range(1, depth + 1))
            features = values[:, :size]
            name = f"{family}_qr_P{p}_depth{depth}"
            variant = "generator_" + transform
            evaluate(variant, name, features, seconds + preprocessing)
            evaluate("561_plus_" + variant, name,
                     np.concatenate((engineered, features), axis=1), seconds + preprocessing)

    for family in ("pascal", "fourier_pascal"):
        for p in (3, 1, 2, 4, 6):  # Evaluate the chosen P3/depth2 reference early.
            depths = [1, 2, 3] + ([4] if family == "pascal" and p == 1 else [])
            compare("identity", family, p, depths, x, scaling_seconds)
    for transform in ("difference", "energy", "lag_product", "spectral_power"):
        begin = perf_counter()
        observations = transform_observations(x, transform)
        preprocessing = scaling_seconds + perf_counter() - begin
        for p in (1, 3):
            compare(transform, "pascal", p, [1, 2], observations, preprocessing)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=HERE / "data/uci_har.zip")
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--output", type=Path, default=HERE / "results")
    parser.add_argument("--variants", nargs="*", choices=VARIANTS)
    parser.add_argument("--heads", nargs="+", choices=HEADS, default=["ridge"])
    parser.add_argument("--trees", type=int, default=100)
    parser.add_argument("--jobs", type=int, default=4)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--smoke", action="store_true", help="Small software check using a subset, not benchmark evidence")
    parser.add_argument("--self-check", action="store_true", help="Check feature mathematics without downloading data")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--temporal", action="store_true", help="Small Fourier, delay and Pascal extension; saves temporal_results/")
    mode.add_argument("--observables", action="store_true", help="Integrated energy/delay-product comparison; saves observable_results/")
    mode.add_argument("--pascal-sweep", action="store_true", help="Ridge-only P/depth and generic pretransform sweep; saves pascal_results/")
    mode.add_argument("--families", action="store_true", help="Ridge-only generic families and P/depth sweep; saves family_results/")
    mode.add_argument("--ablations", action="store_true", help="Ridge-only pooled/spectral ablations; saves ablation_results/")
    mode.add_argument("--pool-story", action="store_true", help="Ridge-only small pools and spectral logsignatures; saves pool_results/")
    mode.add_argument("--occupations", action="store_true", help="Ridge-only observable graph logs and log-energy paths; saves occupation_results/")
    mode.add_argument("--coded-occupations", action="store_true", help="Ridge-only Pascal clock-coded graph sweep; saves coded_occupation_results/")
    mode.add_argument("--consolidated", action="store_true", help="Three retained ridge models and ordinary-signature ablations; saves consolidated_results/")
    parser.add_argument("--temporal-codes", nargs="*", choices=("fourier24", "fourier4", "pascal"),
                        default=["fourier24", "fourier4", "pascal"], help="Optional subset of the temporal code experiments")
    args = parser.parse_args()
    if (args.pascal_sweep or args.families or args.ablations or args.pool_story or args.occupations or args.coded_occupations or args.consolidated) and args.heads != ["ridge"]:
        parser.error("Pascal/family/ablation/occupation sweeps use only ridge")
    stable_ridge = args.families or args.ablations or args.pool_story or args.occupations or args.coded_occupations or args.consolidated
    if args.variants is None:
        args.variants = (["total_basepoint"] if args.observables else
                         ["total_basepoint", "total_integrated", "total_delay2", "total_delay5"]
                         if args.temporal else [name for name in VARIANTS if "delay" not in name])
    if min(args.trees, args.jobs, args.batch_size) < 1:
        parser.error("trees, jobs and batch-size must be positive")
    torch.set_num_threads(1)
    if args.self_check:
        self_check()
        from temporal import self_check as temporal_check
        temporal_check()
        from generators import self_check as generators_check
        generators_check()
        from families import self_check as families_check
        families_check()
        from family_sweep import self_check as ridge_check
        ridge_check()
        from pooled_blocks import self_check as pooled_check
        pooled_check()
        from spectral_readouts import self_check as spectral_check
        spectral_check()
        from moment_lifts import self_check as moment_check
        moment_check()
        from occupation_graph import self_check as graph_check
        graph_check()
        from occupation_experiment import self_check as occupation_check
        occupation_check()
        from coded_occupation import self_check as coded_occupation_check
        coded_occupation_check()
        from ordinary_controls import self_check as ordinary_check
        ordinary_check()
        from ordinary_spectral import self_check as ordinary_spectral_check
        ordinary_spectral_check()
        print("Feature checks passed.")
        return
    if args.smoke and args.output == HERE / "results":
        args.output = HERE / "smoke_results"
    elif args.observables and args.output == HERE / "results":
        args.output = HERE / "observable_results"
    elif args.temporal and args.output == HERE / "results":
        args.output = HERE / "temporal_results"
    elif args.pascal_sweep and args.output == HERE / "results":
        args.output = HERE / "pascal_results"
    elif args.families and args.output == HERE / "results":
        args.output = HERE / "family_results"
    elif args.ablations and args.output == HERE / "results":
        args.output = HERE / "ablation_results"
    elif args.pool_story and args.output == HERE / "results":
        args.output = HERE / "pool_results"
    elif args.occupations and args.output == HERE / "results":
        args.output = HERE / "occupation_results"
    elif args.coded_occupations and args.output == HERE / "results":
        args.output = HERE / "coded_occupation_results"
    elif args.consolidated and args.output == HERE / "results":
        args.output = HERE / "consolidated_results"
    if args.download:
        download(args.data)
    start = perf_counter()
    data = load_data(args.data)
    if args.smoke:
        rng = np.random.default_rng(2025)
        for split, count in (("train", 240), ("test", 120)):
            indices = np.sort(rng.choice(len(data[split]["labels"]), count, replace=False))
            data[split] = {key: value[indices] for key, value in data[split].items()}
    train, test = data["train"], data["test"]
    n_train = len(train["labels"])
    signals = np.concatenate((train["signals"], test["signals"]))
    metadata = {
        "dataset_url": DATA_URL, "smoke": args.smoke,
        "train_windows": n_train, "test_windows": len(test["labels"]),
        "train_subjects": np.unique(train["subjects"]).tolist(),
        "test_subjects": np.unique(test["subjects"]).tolist(),
        "activities": ACTIVITIES, "python": platform.python_version(),
        "platform": platform.platform(), "numpy": np.__version__,
        "torch": torch.__version__, "sklearn": sklearn.__version__,
        "settings": {"ridge_alpha": 10.0, "svm_C": 10.0, "svm_gamma": "scale", "rf_trees": args.trees,
                     "rf_max_depth": 20, "rf_min_samples_leaf": 2, "jobs": args.jobs, "seed": 2025,
                     "depth": 2, "code": "constant + linear increment position"},
        "variants": args.variants, "heads": args.heads, "confusion_matrices": {},
        "paired_vs_561": {}, "paired_vs_pascal_p3_depth2": {},
    }
    metadata["settings"]["numerical_threads"] = 1
    metadata["settings"]["accelerate_thread_limit"] = os.environ["VECLIB_MAXIMUM_THREADS"]
    if args.temporal:
        metadata["temporal_settings"] = {
            "delay_samples": [2, 5], "fourier_bins": [[2, 4], [4]],
            "codes": args.temporal_codes,
            "pascal_dimension": 3, "fourier_pascal_carrier_bin": 4,
            "sample_phase": "r / N", "coded_input": "train-scaled samples / N, no clock",
            "quotients": "omitted in the temporal extension; retained in original suite",
        }
    if args.observables:
        metadata["observable_settings"] = {
            "dynamic_signals": "body_acc xyz + body_gyro xyz, training-global axis standardization",
            "energy_envelope": "triad sum of squares, trailing 5-sample mean, first-value padding",
            "delayed_products": "triad dot products with lags 2 and 5, first-sample padding",
            "groups": ["energy_envelopes", "delayed_products", "energy_delayed_products"],
            "codes": ["ordinary constant", "orthonormal Pascal dimension 3", "Fourier-Pascal bin 4, dimension 5"],
            "input": "observable / 128 as increments, no clock, no additional observable scaling",
            "posture": "six training-scaled total_acc + body_gyro means appended to every readout",
            "controls": "pooled observable means and products of each code's first levels",
        }
    rows = []
    reference_predictions = {}

    def evaluate(variant: str, name: str, values: np.ndarray, extraction: float):
        if not np.isfinite(values).all():
            raise ValueError(f"Nonfinite features: {variant}/{name}")
        if args.pascal_sweep or stable_ridge:
            # Deeper, redundant tensor coordinates need double-precision ridge solves.
            values = np.asarray(values, dtype=np.float64)
        if stable_ridge:
            training = values[:n_train]
            magnitude = np.maximum(training.max(0), -training.min(0))
            keep = training.std(0) > 1e-6 * magnitude
            metadata.setdefault("constant_columns_removed", {})[f"{variant}/{name}"] = int((~keep).sum())
            if not keep.all():
                values = values[:, keep]
        for head in args.heads:
            if stable_ridge:
                from family_sweep import ridge_predict
                predicted, fit_seconds, prediction_seconds = ridge_predict(
                    values[:n_train], train["labels"], values[n_train:])
            else:
                model = classifier(head, args)
                begin = perf_counter()
                model.fit(values[:n_train], train["labels"])
                fit_seconds = perf_counter() - begin
                begin = perf_counter()
                predicted = model.predict(values[n_train:])
                prediction_seconds = perf_counter() - begin
            row = {"variant": variant, "representation": name, "head": head, "features": values.shape[1],
                   "accuracy": accuracy_score(test["labels"], predicted),
                   "macro_f1": f1_score(test["labels"], predicted, average="macro", zero_division=0),
                   "extract_s": round(extraction, 6), "fit_s": round(fit_seconds, 6),
                   "predict_s": round(prediction_seconds, 6)}
            rows.append(row)
            metadata["confusion_matrices"][f"{variant}/{name}/{head}"] = confusion_matrix(
                test["labels"], predicted, labels=np.arange(6)).tolist()
            if args.ablations:
                if variant == "pool_all" and name == "raw_pascal_P3_d2":
                    reference_predictions["pool_all_pascal"] = predicted
                if "pool_all_pascal" in reference_predictions:
                    reference_correct = reference_predictions["pool_all_pascal"] == test["labels"]
                    current_correct = predicted == test["labels"]
                    metadata.setdefault("paired_vs_pool_all_pascal", {})[f"{variant}/{name}"] = {
                        "corrected": int((~reference_correct & current_correct).sum()),
                        "introduced": int((reference_correct & ~current_correct).sum()),
                    }
            if args.pool_story:
                if variant == "pool_full234" and name == "raw_log__spectral_tensor":
                    reference_predictions["pool234"] = predicted
                if "pool234" in reference_predictions:
                    reference_correct = reference_predictions["pool234"] == test["labels"]
                    current_correct = predicted == test["labels"]
                    metadata.setdefault("paired_vs_pool234", {})[f"{variant}/{name}"] = {
                        "corrected": int((~reference_correct & current_correct).sum()),
                        "introduced": int((reference_correct & ~current_correct).sum()),
                    }
            if args.occupations:
                if variant == "direct_pool":
                    reference_predictions["pool102"] = predicted
                if "pool102" in reference_predictions:
                    reference_correct = reference_predictions["pool102"] == test["labels"]
                    current_correct = predicted == test["labels"]
                    metadata.setdefault("paired_vs_pool102", {})[f"{variant}/{name}"] = {
                        "corrected": int((~reference_correct & current_correct).sum()),
                        "introduced": int((reference_correct & ~current_correct).sum()),
                        "predictions_changed": int((reference_predictions["pool102"] != predicted).sum()),
                    }
            if variant == "engineered_561":
                reference_predictions[head] = predicted
            elif variant.startswith("561_plus_"):
                reference_correct = reference_predictions[head] == test["labels"]
                hybrid_correct = predicted == test["labels"]
                metadata["paired_vs_561"][f"{variant}/{name}/{head}"] = {
                    "corrected": int((~reference_correct & hybrid_correct).sum()),
                    "introduced": int((reference_correct & ~hybrid_correct).sum()),
                }
                if variant == "561_plus_generator_identity" and name == "pascal_qr_P3_depth2":
                    reference_predictions["pascal_p3_depth2"] = predicted
                if "pascal_p3_depth2" in reference_predictions:
                    reference_correct = reference_predictions["pascal_p3_depth2"] == test["labels"]
                    metadata["paired_vs_pascal_p3_depth2"][f"{variant}/{name}/{head}"] = {
                        "corrected": int((~reference_correct & hybrid_correct).sum()),
                        "introduced": int((reference_correct & ~hybrid_correct).sum()),
                    }
            if args.coded_occupations:
                if variant == "reference429":
                    reference_predictions["graph429"] = predicted
                if "graph429" in reference_predictions:
                    reference_correct = reference_predictions["graph429"] == test["labels"]
                    current_correct = predicted == test["labels"]
                    metadata.setdefault("paired_vs_graph429", {})[f"{variant}/{name}"] = {
                        "corrected": int((~reference_correct & current_correct).sum()),
                        "introduced": int((reference_correct & ~current_correct).sum()),
                        "predictions_changed": int((reference_predictions["graph429"] != predicted).sum()),
                    }
            if args.consolidated:
                for retained in ("compact368", "pool803", "uci903"):
                    if variant == "retained_" + retained:
                        reference_predictions[retained] = predicted
                    if variant.endswith(retained) and retained in reference_predictions:
                        reference_correct = reference_predictions[retained] == test["labels"]
                        current_correct = predicted == test["labels"]
                        metadata.setdefault("paired_vs_retained", {})[f"{variant}/{name}"] = {
                            "reference": retained,
                            "corrected": int((~reference_correct & current_correct).sum()),
                            "introduced": int((reference_correct & ~current_correct).sum()),
                            "predictions_changed": int((reference_predictions[retained] != predicted).sum()),
                        }
            print(f"{variant:20s} {name:30s} {head:14s} d={row['features']:4d} "
                  f"acc={100*row['accuracy']:6.2f} F1={100*row['macro_f1']:6.2f} "
                  f"fit={fit_seconds:.2f}s predict={prediction_seconds:.2f}s", flush=True)
        metadata["elapsed_s"] = round(perf_counter() - start, 3)
        write_results(rows, metadata, args.output)

    with threadpool_limits(limits=1):
        if args.pascal_sweep or stable_ridge:
            metadata["variants"] = ["identity", "difference", "energy", "lag_product", "spectral_power"]
            metadata["settings"] = {"ridge_alpha": 10.0, "numerical_threads": 1,
                                    "accelerate_thread_limit": os.environ["VECLIB_MAXIMUM_THREADS"]}
            if stable_ridge:
                metadata["settings"].update(ridge_solver="numpy general LU, primal/dual closed form",
                                             fit_dtype="float64")
            engineered = np.concatenate((train["engineered"], test["engineered"]))
            evaluate("engineered_561", "uci_features", engineered, 0.0)
            if args.consolidated:
                from consolidated import run
                metadata["variants"] = ["retained", "ordinary_raw", "ordinary_spectral", "ordinary_joint", "component_ablations"]
                run(evaluate, signals, n_train, engineered, args, metadata)
            elif args.coded_occupations:
                from coded_occupation_sweep import run
                metadata["variants"] = ["graph_reference", "uniform_codes", "compact_mixed"]
                run(evaluate, signals, n_train, engineered, args, metadata)
            elif args.occupations:
                from occupation_experiment import run
                metadata["variants"] = ["no_pool", "log_energy_paths", "observable_graphs", "calibrated_readouts"]
                run(evaluate, signals, n_train, engineered, args, metadata)
            elif args.pool_story:
                from pool_story import run
                metadata["variants"] = ["no_pool", "pool234_ablation", "small_pools", "observable_integrals"]
                run(evaluate, signals, n_train, engineered, args, metadata)
            elif args.ablations:
                from ablations import run
                metadata["variants"] = ["pooled_subsets", "pooled_blocks", "spectral_readouts", "compact_triples"]
                run(evaluate, signals, n_train, engineered, args, metadata)
            elif args.families:
                from family_sweep import run
                metadata["variants"] = ["moments", "filters_delays", "spectral", "rotation", "combined"]
                run(evaluate, signals, n_train, engineered, args, metadata)
            else:
                pascal_sweep(evaluate, signals, n_train, engineered, args, metadata)
            metadata["elapsed_s"] = round(perf_counter() - start, 3)
            write_results(rows, metadata, args.output)
            print(f"Saved {len(rows)} ridge comparisons to {args.output}; {metadata['elapsed_s']:.1f}s total.")
            return
        covariation_blocks, covariation_seconds = {}, {}
        for source in ("body", "total"):
            begin = perf_counter()
            raw = sensor_channels(signals, source)
            summary = np.concatenate((raw.mean(axis=1), raw.std(axis=1)), axis=1)
            evaluate(source + "_mean_std", "mean_std", summary, perf_counter() - begin)
            begin = perf_counter()
            direct, covariation_blocks[source] = direct_covariation(raw, n_train)
            covariation_seconds[source] = perf_counter() - begin
            for name, values in direct.items():
                evaluate(source + "_direct_covariation", name, values, covariation_seconds[source])
        engineered = np.concatenate((train["engineered"], test["engineered"]))
        evaluate("engineered_561", "uci_features", engineered, 0.0)
        evaluate("561_plus_total_covariation", "mean_std_covariation",
                 np.concatenate((engineered, direct["mean_std_covariation"]), axis=1),
                 covariation_seconds["total"])
        for variant in args.variants:
            source, mode = VARIANTS[variant]
            begin = perf_counter()
            paths, modalities = augment(sensor_channels(signals, source), mode, train_size=n_train)
            augmentation_seconds = perf_counter() - begin
            representations, timings = extract_features(paths, modalities, batch_size=args.batch_size)
            del paths
            for name, values in representations.items():
                if (args.temporal or args.observables) and "modality" in name:
                    continue
                extraction = augmentation_seconds + timings[name]
                if variant.endswith("_covariation"):
                    values = np.concatenate((values, covariation_blocks[source]), axis=1)
                    extraction += covariation_seconds[source]
                evaluate(variant, name, values, extraction)
                # ponytail: fixed hybrid controls, no search over feature combinations.
                hybrid = ((variant == "total_basepoint" and name in
                           ("ordinary_full_signature", "offset_full_signature")) or
                          (variant == "total_leadlag" and name in
                           ("ordinary_full_logsignature", "offset_full_logsignature")))
                if args.temporal or args.observables:
                    hybrid = True
                if hybrid:
                    evaluate("561_plus_" + variant, name,
                             np.concatenate((engineered, values), axis=1), extraction)
        if args.temporal:
            from temporal import extract_pascal_features
            raw = sensor_channels(signals, "total")
            for code_name, frequencies in (("fourier24", (2, 4)), ("fourier4", (4,))):
                if code_name not in args.temporal_codes:
                    continue
                representations, timings = extract_fourier_features(
                    raw, n_train, args.batch_size, frequencies=frequencies)
                variant = "total_fourier_" + "_".join(map(str, frequencies))
                for name, values in representations.items():
                    evaluate(variant, name, values, timings[name])
                    evaluate("561_plus_" + variant, name,
                             np.concatenate((engineered, values), axis=1), timings[name])
            if "pascal" in args.temporal_codes:
                representations, timings = extract_pascal_features(raw, n_train, args.batch_size)
                for name, values in representations.items():
                    evaluate("total_pascal", name, values, timings[name])
                    evaluate("561_plus_total_pascal", name,
                             np.concatenate((engineered, values), axis=1), timings[name])
        if args.observables:
            from temporal import extract_observable_features
            groups, timings = extract_observable_features(signals, n_train, args.batch_size)
            for group, representations in groups.items():
                variant = "observable_" + group
                for name, values in representations.items():
                    evaluate(variant, name, values, timings[group][name])
                    evaluate("561_plus_" + variant, name,
                             np.concatenate((engineered, values), axis=1), timings[group][name])
    metadata["elapsed_s"] = round(perf_counter() - start, 3)
    write_results(rows, metadata, args.output)
    print(f"Saved {len(rows)} comparisons to {args.output}; {metadata['elapsed_s']:.1f}s total.")


if __name__ == "__main__":
    main()
