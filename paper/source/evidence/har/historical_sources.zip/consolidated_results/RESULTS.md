# UCI HAR exploratory results

7,352 training / 2,947 test windows; official subject-disjoint split, fixed classifier settings, exploratory feature comparisons.

Accuracy and macro F1 are percentages. Times are seconds on this machine. Extraction includes train and test, with full calculations shared across readouts; do not sum extraction columns across heads or claim sparse quotient acceleration. The 561-feature extraction time is unmeasured (CSV placeholder 0); hybrid timings measure only the additional features.

## Best row per input/augmentation and head

These are descriptive test-set maxima over representations, not validation-selected models.

| Input / augmentation | Head | Representation | Features | Accuracy | Macro F1 | Extract | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|---:|
| engineered_561 | ridge | uci_features | 561 | 95.72 | 95.85 | 0.000 | 0.026 | 0.003 |
| retained_compact368 | ridge | pascal_qr | 368 | 98.03 | 98.06 | 8.747 | 0.010 | 0.002 |
| drop_raw_compact368 | ridge | none | 197 | 96.17 | 96.14 | 8.747 | 0.005 | 0.001 |
| retained_pool803 | ridge | pascal_qr | 803 | 98.10 | 98.14 | 8.747 | 0.033 | 0.004 |
| drop_raw_pool803 | ridge | none | 461 | 97.18 | 97.14 | 8.747 | 0.013 | 0.002 |
| retained_uci903 | ridge | pascal_qr | 903 | 97.12 | 97.16 | 8.747 | 0.041 | 0.003 |
| drop_raw_uci903 | ridge | none | 561 | 95.72 | 95.85 | 8.747 | 0.023 | 0.002 |
| ordinary_lift_compact368 | ridge | explicit_polynomial_path_d2 | 368 | 98.03 | 98.06 | 9.428 | 0.011 | 0.002 |
| ordinary_lift_pool803 | ridge | explicit_polynomial_path_d2 | 803 | 98.10 | 98.14 | 9.428 | 0.032 | 0.003 |
| ordinary_lift_uci903 | ridge | explicit_polynomial_path_d2 | 903 | 97.12 | 97.16 | 9.428 | 0.051 | 0.004 |
| ordinary_raw_compact368 | ridge | total_leadlag_d2_tensor | 377 | 97.46 | 97.46 | 9.839 | 0.011 | 0.002 |
| ordinary_raw_pool803 | ridge | total_delay1_d2_tensor | 641 | 97.83 | 97.83 | 9.261 | 0.031 | 0.004 |
| ordinary_raw_uci903 | ridge | total_basepoint_d2_tensor | 615 | 97.05 | 97.07 | 8.919 | 0.027 | 0.002 |
| drop_spectral_compact368 | ridge | none | 268 | 96.78 | 96.81 | 8.747 | 0.011 | 0.001 |
| ordinary_spectral_compact368 | ridge | spectral_clock_d5_projected_pascal_P3 | 368 | 98.03 | 98.06 | 14.559 | 0.011 | 0.002 |
| ordinary_joint_compact368 | ridge | total_delay2_d2_log__spectral_clock_log_d5 | 427 | 96.44 | 96.51 | 15.101 | 0.017 | 0.001 |
| drop_trends_compact368 | ridge | none | 353 | 97.86 | 97.89 | 8.747 | 0.009 | 0.002 |
| ordinary_trends_compact368 | ridge | closed_value_graph_xtt | 368 | 98.03 | 98.06 | 8.747 | 0.014 | 0.002 |
| drop_amplitude40_compact368 | ridge | none | 328 | 97.15 | 97.13 | 8.747 | 0.010 | 0.002 |
| drop_cosine6_compact368 | ridge | none | 362 | 96.34 | 96.42 | 8.747 | 0.011 | 0.001 |
| drop_invariant36_compact368 | ridge | none | 332 | 97.42 | 97.40 | 8.747 | 0.009 | 0.001 |

## Every comparison

| Input / augmentation | Representation | Head | Features | Accuracy | Macro F1 | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|
| engineered_561 | uci_features | ridge | 561 | 95.72 | 95.85 | 0.026 | 0.003 |
| retained_compact368 | pascal_qr | ridge | 368 | 98.03 | 98.06 | 0.010 | 0.002 |
| drop_raw_compact368 | none | ridge | 197 | 96.17 | 96.14 | 0.005 | 0.001 |
| retained_pool803 | pascal_qr | ridge | 803 | 98.10 | 98.14 | 0.033 | 0.004 |
| drop_raw_pool803 | none | ridge | 461 | 97.18 | 97.14 | 0.013 | 0.002 |
| retained_uci903 | pascal_qr | ridge | 903 | 97.12 | 97.16 | 0.041 | 0.003 |
| drop_raw_uci903 | none | ridge | 561 | 95.72 | 95.85 | 0.023 | 0.002 |
| ordinary_lift_compact368 | explicit_polynomial_path_d2 | ridge | 368 | 98.03 | 98.06 | 0.011 | 0.002 |
| ordinary_lift_pool803 | explicit_polynomial_path_d2 | ridge | 803 | 98.10 | 98.14 | 0.032 | 0.003 |
| ordinary_lift_uci903 | explicit_polynomial_path_d2 | ridge | 903 | 97.12 | 97.16 | 0.051 | 0.004 |
| ordinary_raw_compact368 | total_integrated_no_clock_d2_tensor | ridge | 239 | 96.61 | 96.55 | 0.009 | 0.001 |
| ordinary_raw_pool803 | total_integrated_no_clock_d2_tensor | ridge | 503 | 97.42 | 97.41 | 0.022 | 0.002 |
| ordinary_raw_uci903 | total_integrated_no_clock_d2_tensor | ridge | 603 | 96.67 | 96.71 | 0.024 | 0.003 |
| ordinary_raw_compact368 | total_integrated_no_clock_d2_log | ridge | 218 | 95.42 | 95.45 | 0.005 | 0.001 |
| ordinary_raw_pool803 | total_integrated_no_clock_d2_log | ridge | 482 | 97.32 | 97.32 | 0.017 | 0.002 |
| ordinary_raw_uci903 | total_integrated_no_clock_d2_log | ridge | 582 | 95.76 | 95.88 | 0.022 | 0.002 |
| ordinary_raw_compact368 | total_integrated_no_clock_d3_tensor | ridge | 455 | 95.25 | 95.23 | 0.015 | 0.003 |
| ordinary_raw_pool803 | total_integrated_no_clock_d3_tensor | ridge | 719 | 96.13 | 96.13 | 0.027 | 0.003 |
| ordinary_raw_uci903 | total_integrated_no_clock_d3_tensor | ridge | 819 | 95.11 | 95.18 | 0.041 | 0.003 |
| ordinary_raw_compact368 | total_integrated_no_clock_d3_log | ridge | 288 | 95.55 | 95.60 | 0.007 | 0.001 |
| ordinary_raw_pool803 | total_integrated_no_clock_d3_log | ridge | 552 | 97.15 | 97.19 | 0.017 | 0.002 |
| ordinary_raw_uci903 | total_integrated_no_clock_d3_log | ridge | 652 | 95.01 | 95.14 | 0.025 | 0.002 |
| ordinary_raw_compact368 | total_integrated_no_clock_d4_tensor | ridge | 1751 | 95.76 | 95.76 | 0.162 | 0.007 |
| ordinary_raw_pool803 | total_integrated_no_clock_d4_tensor | ridge | 2015 | 96.17 | 96.16 | 0.183 | 0.009 |
| ordinary_raw_uci903 | total_integrated_no_clock_d4_tensor | ridge | 2115 | 95.15 | 95.20 | 0.259 | 0.010 |
| ordinary_raw_compact368 | total_integrated_no_clock_d4_log | ridge | 603 | 95.55 | 95.56 | 0.023 | 0.003 |
| ordinary_raw_pool803 | total_integrated_no_clock_d4_log | ridge | 867 | 96.61 | 96.66 | 0.057 | 0.005 |
| ordinary_raw_uci903 | total_integrated_no_clock_d4_log | ridge | 967 | 95.45 | 95.55 | 0.053 | 0.004 |
| ordinary_raw_compact368 | total_time_d2_tensor | ridge | 251 | 97.15 | 97.16 | 0.008 | 0.002 |
| ordinary_raw_pool803 | total_time_d2_tensor | ridge | 515 | 97.49 | 97.48 | 0.018 | 0.003 |
| ordinary_raw_uci903 | total_time_d2_tensor | ridge | 615 | 96.17 | 96.29 | 0.030 | 0.002 |
| ordinary_raw_compact368 | total_time_d2_log | ridge | 224 | 97.22 | 97.23 | 0.008 | 0.001 |
| ordinary_raw_pool803 | total_time_d2_log | ridge | 488 | 97.59 | 97.58 | 0.018 | 0.002 |
| ordinary_raw_uci903 | total_time_d2_log | ridge | 588 | 96.13 | 96.26 | 0.030 | 0.002 |
| ordinary_raw_compact368 | total_time_d3_tensor | ridge | 593 | 96.88 | 96.87 | 0.020 | 0.003 |
| ordinary_raw_pool803 | total_time_d3_tensor | ridge | 857 | 97.42 | 97.40 | 0.038 | 0.005 |
| ordinary_raw_uci903 | total_time_d3_tensor | ridge | 957 | 95.62 | 95.72 | 0.053 | 0.004 |
| ordinary_raw_compact368 | total_time_d3_log | ridge | 336 | 97.08 | 97.07 | 0.015 | 0.002 |
| ordinary_raw_pool803 | total_time_d3_log | ridge | 600 | 97.49 | 97.46 | 0.019 | 0.002 |
| ordinary_raw_uci903 | total_time_d3_log | ridge | 700 | 95.96 | 96.07 | 0.026 | 0.002 |
| ordinary_raw_compact368 | total_time_d4_log | ridge | 924 | 96.34 | 96.24 | 0.040 | 0.003 |
| ordinary_raw_pool803 | total_time_d4_log | ridge | 1188 | 97.25 | 97.20 | 0.073 | 0.006 |
| ordinary_raw_uci903 | total_time_d4_log | ridge | 1288 | 95.35 | 95.40 | 0.076 | 0.004 |
| ordinary_raw_compact368 | total_basepoint_d2_tensor | ridge | 251 | 96.95 | 96.96 | 0.007 | 0.001 |
| ordinary_raw_pool803 | total_basepoint_d2_tensor | ridge | 515 | 97.62 | 97.61 | 0.021 | 0.002 |
| ordinary_raw_uci903 | total_basepoint_d2_tensor | ridge | 615 | 97.05 | 97.07 | 0.027 | 0.002 |
| ordinary_raw_compact368 | total_basepoint_d2_log | ridge | 224 | 96.44 | 96.53 | 0.008 | 0.001 |
| ordinary_raw_pool803 | total_basepoint_d2_log | ridge | 488 | 97.46 | 97.48 | 0.020 | 0.003 |
| ordinary_raw_uci903 | total_basepoint_d2_log | ridge | 588 | 96.23 | 96.36 | 0.025 | 0.002 |
| ordinary_raw_compact368 | total_basepoint_d3_tensor | ridge | 593 | 97.08 | 97.06 | 0.020 | 0.002 |
| ordinary_raw_pool803 | total_basepoint_d3_tensor | ridge | 857 | 97.46 | 97.43 | 0.039 | 0.003 |
| ordinary_raw_uci903 | total_basepoint_d3_tensor | ridge | 957 | 96.71 | 96.70 | 0.046 | 0.003 |
| ordinary_raw_compact368 | total_basepoint_d3_log | ridge | 336 | 96.34 | 96.39 | 0.009 | 0.001 |
| ordinary_raw_pool803 | total_basepoint_d3_log | ridge | 600 | 97.29 | 97.25 | 0.019 | 0.002 |
| ordinary_raw_uci903 | total_basepoint_d3_log | ridge | 700 | 96.78 | 96.79 | 0.029 | 0.002 |
| ordinary_raw_compact368 | total_basepoint_d4_log | ridge | 924 | 96.78 | 96.76 | 0.053 | 0.005 |
| ordinary_raw_pool803 | total_basepoint_d4_log | ridge | 1188 | 97.32 | 97.31 | 0.103 | 0.008 |
| ordinary_raw_uci903 | total_basepoint_d4_log | ridge | 1288 | 96.71 | 96.71 | 0.094 | 0.004 |
| ordinary_raw_compact368 | total_integrated_d2_tensor | ridge | 251 | 96.67 | 96.64 | 0.009 | 0.001 |
| ordinary_raw_pool803 | total_integrated_d2_tensor | ridge | 515 | 97.42 | 97.41 | 0.018 | 0.002 |
| ordinary_raw_uci903 | total_integrated_d2_tensor | ridge | 615 | 96.64 | 96.68 | 0.026 | 0.002 |
| ordinary_raw_compact368 | total_integrated_d2_log | ridge | 224 | 95.45 | 95.49 | 0.007 | 0.001 |
| ordinary_raw_pool803 | total_integrated_d2_log | ridge | 488 | 97.25 | 97.24 | 0.016 | 0.002 |
| ordinary_raw_uci903 | total_integrated_d2_log | ridge | 588 | 95.79 | 95.92 | 0.022 | 0.002 |
| ordinary_raw_compact368 | total_integrated_d3_tensor | ridge | 593 | 96.34 | 96.39 | 0.019 | 0.003 |
| ordinary_raw_pool803 | total_integrated_d3_tensor | ridge | 857 | 96.61 | 96.67 | 0.040 | 0.003 |
| ordinary_raw_uci903 | total_integrated_d3_tensor | ridge | 957 | 95.83 | 95.93 | 0.060 | 0.003 |
| ordinary_raw_compact368 | total_integrated_d3_log | ridge | 336 | 95.59 | 95.63 | 0.009 | 0.002 |
| ordinary_raw_pool803 | total_integrated_d3_log | ridge | 600 | 96.98 | 97.03 | 0.024 | 0.002 |
| ordinary_raw_uci903 | total_integrated_d3_log | ridge | 700 | 95.08 | 95.20 | 0.031 | 0.002 |
| ordinary_raw_compact368 | total_integrated_d4_log | ridge | 924 | 95.62 | 95.65 | 0.046 | 0.004 |
| ordinary_raw_pool803 | total_integrated_d4_log | ridge | 1188 | 96.47 | 96.52 | 0.078 | 0.005 |
| ordinary_raw_uci903 | total_integrated_d4_log | ridge | 1288 | 95.11 | 95.19 | 0.075 | 0.004 |
| ordinary_raw_compact368 | total_delay1_d2_tensor | ridge | 377 | 97.42 | 97.42 | 0.012 | 0.001 |
| ordinary_raw_pool803 | total_delay1_d2_tensor | ridge | 641 | 97.83 | 97.83 | 0.031 | 0.004 |
| ordinary_raw_uci903 | total_delay1_d2_tensor | ridge | 741 | 96.81 | 96.82 | 0.034 | 0.002 |
| ordinary_raw_compact368 | total_delay1_d2_log | ridge | 287 | 96.50 | 96.61 | 0.008 | 0.001 |
| ordinary_raw_pool803 | total_delay1_d2_log | ridge | 551 | 97.49 | 97.53 | 0.019 | 0.002 |
| ordinary_raw_uci903 | total_delay1_d2_log | ridge | 651 | 96.03 | 96.15 | 0.035 | 0.002 |
| ordinary_raw_compact368 | total_delay1_d3_log | ridge | 1015 | 96.10 | 96.12 | 0.052 | 0.004 |
| ordinary_raw_pool803 | total_delay1_d3_log | ridge | 1279 | 97.01 | 96.97 | 0.097 | 0.007 |
| ordinary_raw_uci903 | total_delay1_d3_log | ridge | 1379 | 96.47 | 96.46 | 0.131 | 0.005 |
| ordinary_raw_compact368 | total_delay2_d2_tensor | ridge | 377 | 97.29 | 97.26 | 0.016 | 0.002 |
| ordinary_raw_pool803 | total_delay2_d2_tensor | ridge | 641 | 97.66 | 97.64 | 0.033 | 0.003 |
| ordinary_raw_uci903 | total_delay2_d2_tensor | ridge | 741 | 96.91 | 96.93 | 0.044 | 0.003 |
| ordinary_raw_compact368 | total_delay2_d2_log | ridge | 287 | 96.30 | 96.38 | 0.009 | 0.002 |
| ordinary_raw_pool803 | total_delay2_d2_log | ridge | 551 | 97.42 | 97.45 | 0.019 | 0.002 |
| ordinary_raw_uci903 | total_delay2_d2_log | ridge | 651 | 95.96 | 96.07 | 0.035 | 0.003 |
| ordinary_raw_compact368 | total_delay2_d3_log | ridge | 1015 | 96.03 | 96.04 | 0.051 | 0.004 |
| ordinary_raw_pool803 | total_delay2_d3_log | ridge | 1279 | 97.12 | 97.06 | 0.070 | 0.005 |
| ordinary_raw_uci903 | total_delay2_d3_log | ridge | 1379 | 96.47 | 96.45 | 0.088 | 0.004 |
| ordinary_raw_compact368 | total_delay5_d2_tensor | ridge | 377 | 96.78 | 96.69 | 0.015 | 0.001 |
| ordinary_raw_pool803 | total_delay5_d2_tensor | ridge | 641 | 97.12 | 97.04 | 0.030 | 0.003 |
| ordinary_raw_uci903 | total_delay5_d2_tensor | ridge | 741 | 96.40 | 96.36 | 0.032 | 0.003 |
| ordinary_raw_compact368 | total_delay5_d2_log | ridge | 287 | 96.13 | 96.17 | 0.007 | 0.001 |
| ordinary_raw_pool803 | total_delay5_d2_log | ridge | 551 | 96.81 | 96.79 | 0.017 | 0.002 |
| ordinary_raw_uci903 | total_delay5_d2_log | ridge | 651 | 95.62 | 95.68 | 0.029 | 0.002 |
| ordinary_raw_compact368 | total_delay5_d3_log | ridge | 1015 | 96.23 | 96.24 | 0.064 | 0.004 |
| ordinary_raw_pool803 | total_delay5_d3_log | ridge | 1279 | 97.01 | 96.99 | 0.096 | 0.005 |
| ordinary_raw_uci903 | total_delay5_d3_log | ridge | 1379 | 96.34 | 96.33 | 0.094 | 0.005 |
| ordinary_raw_compact368 | total_leadlag_d2_tensor | ridge | 377 | 97.46 | 97.46 | 0.011 | 0.002 |
| ordinary_raw_pool803 | total_leadlag_d2_tensor | ridge | 641 | 97.69 | 97.68 | 0.031 | 0.003 |
| ordinary_raw_uci903 | total_leadlag_d2_tensor | ridge | 741 | 96.81 | 96.82 | 0.032 | 0.002 |
| ordinary_raw_compact368 | total_leadlag_d2_log | ridge | 287 | 96.47 | 96.57 | 0.008 | 0.001 |
| ordinary_raw_pool803 | total_leadlag_d2_log | ridge | 551 | 97.42 | 97.45 | 0.019 | 0.002 |
| ordinary_raw_uci903 | total_leadlag_d2_log | ridge | 651 | 95.96 | 96.09 | 0.026 | 0.002 |
| ordinary_raw_compact368 | total_leadlag_d3_log | ridge | 1015 | 96.27 | 96.30 | 0.054 | 0.004 |
| ordinary_raw_pool803 | total_leadlag_d3_log | ridge | 1279 | 97.52 | 97.50 | 0.089 | 0.004 |
| ordinary_raw_uci903 | total_leadlag_d3_log | ridge | 1379 | 96.64 | 96.64 | 0.084 | 0.004 |
| ordinary_raw_compact368 | total_integrated_leadlag_d2_tensor | ridge | 377 | 96.91 | 96.87 | 0.011 | 0.002 |
| ordinary_raw_pool803 | total_integrated_leadlag_d2_tensor | ridge | 641 | 97.56 | 97.54 | 0.022 | 0.003 |
| ordinary_raw_uci903 | total_integrated_leadlag_d2_tensor | ridge | 741 | 96.64 | 96.68 | 0.035 | 0.002 |
| ordinary_raw_compact368 | total_integrated_leadlag_d2_log | ridge | 287 | 97.05 | 97.00 | 0.007 | 0.001 |
| ordinary_raw_pool803 | total_integrated_leadlag_d2_log | ridge | 551 | 97.39 | 97.35 | 0.023 | 0.003 |
| ordinary_raw_uci903 | total_integrated_leadlag_d2_log | ridge | 651 | 96.78 | 96.82 | 0.027 | 0.002 |
| ordinary_raw_compact368 | total_integrated_leadlag_d3_log | ridge | 1015 | 96.13 | 96.13 | 0.048 | 0.004 |
| ordinary_raw_pool803 | total_integrated_leadlag_d3_log | ridge | 1279 | 97.52 | 97.53 | 0.080 | 0.004 |
| ordinary_raw_uci903 | total_integrated_leadlag_d3_log | ridge | 1379 | 96.13 | 96.15 | 0.091 | 0.006 |
| ordinary_raw_compact368 | total_paper_shift1_d2_tensor | ridge | 401 | 97.35 | 97.37 | 0.020 | 0.001 |
| ordinary_raw_pool803 | total_paper_shift1_d2_tensor | ridge | 665 | 97.76 | 97.76 | 0.027 | 0.004 |
| ordinary_raw_uci903 | total_paper_shift1_d2_tensor | ridge | 765 | 96.06 | 96.18 | 0.034 | 0.003 |
| ordinary_raw_compact368 | total_paper_shift1_d2_log | ridge | 299 | 97.22 | 97.23 | 0.011 | 0.001 |
| ordinary_raw_pool803 | total_paper_shift1_d2_log | ridge | 563 | 97.66 | 97.65 | 0.020 | 0.002 |
| ordinary_raw_uci903 | total_paper_shift1_d2_log | ridge | 663 | 95.83 | 95.94 | 0.024 | 0.002 |
| ordinary_raw_compact368 | total_paper_shift1_d3_log | ridge | 1207 | 97.05 | 97.02 | 0.073 | 0.005 |
| ordinary_raw_pool803 | total_paper_shift1_d3_log | ridge | 1471 | 97.49 | 97.45 | 0.105 | 0.007 |
| ordinary_raw_uci903 | total_paper_shift1_d3_log | ridge | 1571 | 95.52 | 95.60 | 0.118 | 0.005 |
| ordinary_raw_compact368 | total_paper_staircase_leadlag_d2_tensor | ridge | 401 | 97.22 | 97.22 | 0.012 | 0.002 |
| ordinary_raw_pool803 | total_paper_staircase_leadlag_d2_tensor | ridge | 665 | 97.59 | 97.58 | 0.031 | 0.003 |
| ordinary_raw_uci903 | total_paper_staircase_leadlag_d2_tensor | ridge | 765 | 95.89 | 96.01 | 0.035 | 0.003 |
| ordinary_raw_compact368 | total_paper_staircase_leadlag_d2_log | ridge | 299 | 97.18 | 97.19 | 0.008 | 0.001 |
| ordinary_raw_pool803 | total_paper_staircase_leadlag_d2_log | ridge | 563 | 97.62 | 97.61 | 0.018 | 0.003 |
| ordinary_raw_uci903 | total_paper_staircase_leadlag_d2_log | ridge | 663 | 96.00 | 96.11 | 0.025 | 0.002 |
| ordinary_raw_compact368 | total_paper_staircase_leadlag_d3_log | ridge | 1207 | 96.98 | 96.96 | 0.083 | 0.005 |
| ordinary_raw_pool803 | total_paper_staircase_leadlag_d3_log | ridge | 1471 | 97.59 | 97.57 | 0.096 | 0.008 |
| ordinary_raw_uci903 | total_paper_staircase_leadlag_d3_log | ridge | 1571 | 95.49 | 95.55 | 0.120 | 0.005 |
| ordinary_raw_compact368 | body_time_d2_tensor | ridge | 251 | 97.22 | 97.23 | 0.006 | 0.001 |
| ordinary_raw_pool803 | body_time_d2_tensor | ridge | 515 | 97.52 | 97.51 | 0.016 | 0.002 |
| ordinary_raw_uci903 | body_time_d2_tensor | ridge | 615 | 96.17 | 96.29 | 0.023 | 0.002 |
| ordinary_raw_compact368 | body_time_d2_log | ridge | 224 | 97.22 | 97.23 | 0.008 | 0.001 |
| ordinary_raw_pool803 | body_time_d2_log | ridge | 488 | 97.59 | 97.58 | 0.016 | 0.002 |
| ordinary_raw_uci903 | body_time_d2_log | ridge | 588 | 96.10 | 96.22 | 0.022 | 0.002 |
| ordinary_raw_compact368 | body_time_d3_tensor | ridge | 593 | 96.95 | 96.95 | 0.028 | 0.002 |
| ordinary_raw_pool803 | body_time_d3_tensor | ridge | 857 | 97.42 | 97.39 | 0.045 | 0.003 |
| ordinary_raw_uci903 | body_time_d3_tensor | ridge | 957 | 95.69 | 95.79 | 0.042 | 0.004 |
| ordinary_raw_compact368 | body_time_d3_log | ridge | 336 | 97.08 | 97.07 | 0.014 | 0.002 |
| ordinary_raw_pool803 | body_time_d3_log | ridge | 600 | 97.52 | 97.50 | 0.021 | 0.002 |
| ordinary_raw_uci903 | body_time_d3_log | ridge | 700 | 96.03 | 96.14 | 0.027 | 0.002 |
| ordinary_raw_compact368 | body_paper_shift1_d2_tensor | ridge | 401 | 97.35 | 97.37 | 0.017 | 0.002 |
| ordinary_raw_pool803 | body_paper_shift1_d2_tensor | ridge | 665 | 97.69 | 97.69 | 0.026 | 0.002 |
| ordinary_raw_uci903 | body_paper_shift1_d2_tensor | ridge | 765 | 95.96 | 96.08 | 0.038 | 0.002 |
| ordinary_raw_compact368 | body_paper_shift1_d2_log | ridge | 299 | 97.25 | 97.26 | 0.009 | 0.001 |
| ordinary_raw_pool803 | body_paper_shift1_d2_log | ridge | 563 | 97.69 | 97.69 | 0.034 | 0.003 |
| ordinary_raw_uci903 | body_paper_shift1_d2_log | ridge | 663 | 95.89 | 96.01 | 0.032 | 0.002 |
| ordinary_raw_compact368 | body_paper_shift1_d3_log | ridge | 1207 | 97.05 | 97.01 | 0.084 | 0.007 |
| ordinary_raw_pool803 | body_paper_shift1_d3_log | ridge | 1471 | 97.52 | 97.48 | 0.119 | 0.006 |
| ordinary_raw_uci903 | body_paper_shift1_d3_log | ridge | 1571 | 95.59 | 95.67 | 0.143 | 0.006 |
| ordinary_raw_compact368 | body_paper_staircase_leadlag_d2_tensor | ridge | 401 | 97.18 | 97.19 | 0.022 | 0.002 |
| ordinary_raw_pool803 | body_paper_staircase_leadlag_d2_tensor | ridge | 665 | 97.62 | 97.62 | 0.040 | 0.004 |
| ordinary_raw_uci903 | body_paper_staircase_leadlag_d2_tensor | ridge | 765 | 95.83 | 95.94 | 0.058 | 0.003 |
| ordinary_raw_compact368 | body_paper_staircase_leadlag_d2_log | ridge | 299 | 97.18 | 97.19 | 0.014 | 0.002 |
| ordinary_raw_pool803 | body_paper_staircase_leadlag_d2_log | ridge | 563 | 97.62 | 97.62 | 0.020 | 0.002 |
| ordinary_raw_uci903 | body_paper_staircase_leadlag_d2_log | ridge | 663 | 96.03 | 96.15 | 0.033 | 0.002 |
| ordinary_raw_compact368 | body_paper_staircase_leadlag_d3_log | ridge | 1207 | 97.08 | 97.06 | 0.075 | 0.005 |
| ordinary_raw_pool803 | body_paper_staircase_leadlag_d3_log | ridge | 1471 | 97.52 | 97.49 | 0.106 | 0.006 |
| ordinary_raw_uci903 | body_paper_staircase_leadlag_d3_log | ridge | 1571 | 95.52 | 95.59 | 0.114 | 0.006 |
| drop_spectral_compact368 | none | ridge | 268 | 96.78 | 96.81 | 0.011 | 0.001 |
| ordinary_spectral_compact368 | spectral_clock_tensor_d2 | ridge | 308 | 97.49 | 97.51 | 0.011 | 0.001 |
| ordinary_spectral_compact368 | spectral_clock_log_d2 | ridge | 288 | 97.49 | 97.51 | 0.013 | 0.001 |
| ordinary_spectral_compact368 | spectral_clock_tensor_d3 | ridge | 428 | 97.83 | 97.87 | 0.013 | 0.001 |
| ordinary_spectral_compact368 | spectral_clock_log_d3 | ridge | 328 | 97.79 | 97.83 | 0.010 | 0.001 |
| ordinary_spectral_compact368 | spectral_clock_tensor_d4 | ridge | 708 | 98.00 | 98.02 | 0.027 | 0.003 |
| ordinary_spectral_compact368 | spectral_clock_log_d4 | ridge | 388 | 97.83 | 97.86 | 0.013 | 0.002 |
| ordinary_joint_compact368 | total_integrated_d3_log__spectral_clock_log_d4 | ridge | 356 | 95.49 | 95.53 | 0.010 | 0.001 |
| ordinary_joint_compact368 | total_delay2_d2_log__spectral_clock_log_d4 | ridge | 307 | 96.40 | 96.47 | 0.010 | 0.001 |
| ordinary_spectral_compact368 | spectral_clock_tensor_d5 | ridge | 1308 | 97.83 | 97.86 | 0.091 | 0.004 |
| ordinary_spectral_compact368 | spectral_clock_log_d5 | ridge | 508 | 97.93 | 97.97 | 0.018 | 0.002 |
| ordinary_joint_compact368 | total_integrated_d3_log__spectral_clock_log_d5 | ridge | 476 | 95.72 | 95.79 | 0.018 | 0.001 |
| ordinary_joint_compact368 | total_delay2_d2_log__spectral_clock_log_d5 | ridge | 427 | 96.44 | 96.51 | 0.017 | 0.001 |
| ordinary_spectral_compact368 | spectral_clock_d5_projected_pascal_P3 | ridge | 368 | 98.03 | 98.06 | 0.011 | 0.002 |
| ordinary_joint_compact368 | total_integrated_d3_log__spectral_clock_d5_projected_pascal_P3 | ridge | 336 | 95.59 | 95.63 | 0.008 | 0.001 |
| ordinary_joint_compact368 | total_delay2_d2_log__spectral_clock_d5_projected_pascal_P3 | ridge | 287 | 96.30 | 96.38 | 0.010 | 0.001 |
| drop_trends_compact368 | none | ridge | 353 | 97.86 | 97.89 | 0.009 | 0.002 |
| ordinary_trends_compact368 | closed_value_graph_xtt | ridge | 368 | 98.03 | 98.06 | 0.014 | 0.002 |
| drop_amplitude40_compact368 | none | ridge | 328 | 97.15 | 97.13 | 0.010 | 0.002 |
| drop_cosine6_compact368 | none | ridge | 362 | 96.34 | 96.42 | 0.011 | 0.001 |
| drop_invariant36_compact368 | none | ridge | 332 | 97.42 | 97.40 | 0.009 | 0.001 |
