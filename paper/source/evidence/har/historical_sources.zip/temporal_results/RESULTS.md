# UCI HAR exploratory results

7,352 training / 2,947 test windows; official subject-disjoint split, fixed settings, no hyperparameter search.

Accuracy and macro F1 are percentages. Times are seconds on this machine. Extraction includes train and test, with full calculations shared across readouts; do not sum extraction columns across heads or claim sparse quotient acceleration. The 561-feature extraction time is unmeasured (CSV placeholder 0); hybrid timings measure only the additional features.

## Best row per input/augmentation and head

These are descriptive test-set maxima over representations, not validation-selected models.

| Input / augmentation | Head | Representation | Features | Accuracy | Macro F1 | Extract | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|---:|
| body_mean_std | ridge | mean_std | 12 | 53.68 | 50.32 | 0.034 | 0.005 | 0.000 |
| body_mean_std | rbf_svm | mean_std | 12 | 77.57 | 77.48 | 0.034 | 0.211 | 0.291 |
| body_mean_std | random_forest | mean_std | 12 | 80.18 | 79.92 | 0.034 | 0.243 | 0.014 |
| body_direct_covariation | ridge | mean_std_covariation | 54 | 74.11 | 73.01 | 0.217 | 0.003 | 0.000 |
| body_direct_covariation | rbf_svm | mean_std_covariation | 54 | 78.79 | 79.11 | 0.217 | 0.303 | 0.362 |
| body_direct_covariation | random_forest | mean_std_covariation | 54 | 85.99 | 86.08 | 0.217 | 0.413 | 0.014 |
| total_mean_std | ridge | mean_std | 12 | 76.42 | 75.62 | 0.013 | 0.002 | 0.000 |
| total_mean_std | rbf_svm | mean_std | 12 | 81.95 | 81.29 | 0.013 | 0.071 | 0.122 |
| total_mean_std | random_forest | mean_std | 12 | 81.10 | 80.55 | 0.013 | 0.187 | 0.012 |
| total_direct_covariation | ridge | mean_std_covariation | 54 | 88.53 | 88.46 | 0.061 | 0.002 | 0.000 |
| total_direct_covariation | rbf_svm | mean_std_covariation | 54 | 89.85 | 89.72 | 0.061 | 0.094 | 0.136 |
| total_direct_covariation | random_forest | mean_std_covariation | 54 | 92.77 | 92.69 | 0.061 | 0.361 | 0.011 |
| engineered_561 | ridge | uci_features | 561 | 95.72 | 95.85 | 0.000 | 0.023 | 0.002 |
| engineered_561 | rbf_svm | uci_features | 561 | 95.49 | 95.40 | 0.000 | 0.593 | 0.743 |
| engineered_561 | random_forest | uci_features | 561 | 92.43 | 92.21 | 0.000 | 1.175 | 0.016 |
| 561_plus_total_covariation | ridge | mean_std_covariation | 615 | 95.86 | 96.01 | 0.061 | 0.027 | 0.002 |
| 561_plus_total_covariation | rbf_svm | mean_std_covariation | 615 | 96.17 | 96.15 | 0.061 | 0.616 | 0.761 |
| 561_plus_total_covariation | random_forest | mean_std_covariation | 615 | 92.47 | 92.32 | 0.061 | 1.207 | 0.014 |
| total_basepoint | ridge | offset_full_signature | 210 | 86.29 | 86.32 | 0.251 | 0.007 | 0.001 |
| total_basepoint | rbf_svm | offset_full_signature | 210 | 88.29 | 88.17 | 0.251 | 0.313 | 0.388 |
| total_basepoint | random_forest | offset_full_signature | 210 | 88.73 | 88.58 | 0.251 | 0.669 | 0.012 |
| 561_plus_total_basepoint | ridge | ordinary_full_signature | 617 | 97.05 | 97.07 | 0.141 | 0.026 | 0.002 |
| 561_plus_total_basepoint | rbf_svm | offset_full_logsignature | 666 | 96.98 | 97.00 | 0.251 | 0.713 | 0.828 |
| 561_plus_total_basepoint | random_forest | offset_full_logsignature | 666 | 93.15 | 93.18 | 0.251 | 1.217 | 0.014 |
| total_integrated | ridge | offset_full_signature | 210 | 78.89 | 78.96 | 0.250 | 0.006 | 0.001 |
| total_integrated | rbf_svm | offset_full_logsignature | 105 | 86.73 | 86.56 | 0.250 | 0.233 | 0.353 |
| total_integrated | random_forest | ordinary_full_logsignature | 28 | 82.90 | 82.49 | 0.137 | 0.320 | 0.016 |
| 561_plus_total_integrated | ridge | offset_full_signature | 771 | 96.84 | 96.89 | 0.250 | 0.033 | 0.002 |
| 561_plus_total_integrated | rbf_svm | offset_full_logsignature | 666 | 96.03 | 95.97 | 0.250 | 0.742 | 0.912 |
| 561_plus_total_integrated | random_forest | ordinary_full_logsignature | 589 | 92.37 | 92.19 | 0.137 | 1.217 | 0.016 |
| total_delay2 | ridge | offset_full_signature | 702 | 88.80 | 88.77 | 0.563 | 0.022 | 0.001 |
| total_delay2 | rbf_svm | offset_full_logsignature | 351 | 91.41 | 91.44 | 0.563 | 0.431 | 0.543 |
| total_delay2 | random_forest | offset_full_signature | 702 | 92.30 | 92.27 | 0.563 | 1.207 | 0.014 |
| 561_plus_total_delay2 | ridge | ordinary_full_signature | 743 | 96.91 | 96.93 | 0.429 | 0.036 | 0.004 |
| 561_plus_total_delay2 | rbf_svm | ordinary_full_signature | 743 | 96.95 | 96.96 | 0.429 | 0.769 | 0.912 |
| 561_plus_total_delay2 | random_forest | ordinary_full_signature | 743 | 93.65 | 93.69 | 0.429 | 1.245 | 0.014 |
| total_delay5 | ridge | offset_full_signature | 702 | 87.11 | 86.97 | 0.543 | 0.020 | 0.001 |
| total_delay5 | rbf_svm | offset_full_logsignature | 351 | 88.63 | 88.49 | 0.543 | 0.442 | 0.568 |
| total_delay5 | random_forest | offset_full_signature | 702 | 92.13 | 91.98 | 0.543 | 1.228 | 0.014 |
| 561_plus_total_delay5 | ridge | ordinary_full_signature | 743 | 96.40 | 96.36 | 0.409 | 0.038 | 0.002 |
| 561_plus_total_delay5 | rbf_svm | ordinary_full_logsignature | 652 | 96.91 | 96.93 | 0.409 | 0.675 | 0.799 |
| 561_plus_total_delay5 | random_forest | ordinary_full_logsignature | 652 | 93.32 | 93.32 | 0.409 | 1.221 | 0.016 |
| total_fourier_2_4 | ridge | fourier_full_signature | 930 | 88.90 | 89.26 | 0.599 | 0.026 | 0.002 |
| total_fourier_2_4 | rbf_svm | fourier_first_level | 30 | 90.91 | 90.93 | 0.599 | 0.129 | 0.188 |
| total_fourier_2_4 | random_forest | fourier_cross_spectrum | 78 | 92.87 | 92.79 | 0.599 | 0.450 | 0.016 |
| 561_plus_total_fourier_2_4 | ridge | fourier_full_logsignature | 1026 | 96.95 | 96.98 | 0.599 | 0.055 | 0.004 |
| 561_plus_total_fourier_2_4 | rbf_svm | fourier_cross_spectrum | 639 | 97.05 | 97.07 | 0.599 | 0.692 | 0.843 |
| 561_plus_total_fourier_2_4 | random_forest | fourier_cross_spectrum | 639 | 94.10 | 94.05 | 0.599 | 1.259 | 0.016 |
| total_fourier_4 | ridge | fourier_full_signature | 342 | 85.34 | 85.81 | 0.308 | 0.010 | 0.001 |
| total_fourier_4 | rbf_svm | fourier_full_signature | 342 | 88.70 | 88.79 | 0.308 | 0.736 | 0.775 |
| total_fourier_4 | random_forest | fourier_full_signature | 342 | 90.02 | 89.96 | 0.308 | 0.932 | 0.014 |
| 561_plus_total_fourier_4 | ridge | fourier_full_signature | 903 | 96.88 | 96.92 | 0.308 | 0.045 | 0.003 |
| 561_plus_total_fourier_4 | rbf_svm | fourier_cross_spectrum | 603 | 96.78 | 96.78 | 0.308 | 0.648 | 0.792 |
| 561_plus_total_fourier_4 | random_forest | fourier_cross_spectrum | 603 | 93.52 | 93.47 | 0.308 | 1.204 | 0.014 |
| total_pascal | ridge | fourier_pascal_full_signature | 930 | 90.30 | 90.46 | 0.602 | 0.026 | 0.002 |
| total_pascal | rbf_svm | fourier_pascal_full_signature | 930 | 89.31 | 89.37 | 0.602 | 1.830 | 5.085 |
| total_pascal | random_forest | fourier_pascal_full_signature | 930 | 90.63 | 90.60 | 0.602 | 1.493 | 0.014 |
| 561_plus_total_pascal | ridge | pascal_qr_full_signature | 903 | 97.12 | 97.16 | 0.516 | 0.048 | 0.003 |
| 561_plus_total_pascal | rbf_svm | pascal_qr_full_signature | 903 | 96.57 | 96.58 | 0.516 | 1.305 | 3.742 |
| 561_plus_total_pascal | random_forest | fourier_pascal_gap | 639 | 92.47 | 92.30 | 0.602 | 1.254 | 0.014 |

## Every comparison

| Input / augmentation | Representation | Head | Features | Accuracy | Macro F1 | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|
| body_mean_std | mean_std | ridge | 12 | 53.68 | 50.32 | 0.005 | 0.000 |
| body_mean_std | mean_std | rbf_svm | 12 | 77.57 | 77.48 | 0.211 | 0.291 |
| body_mean_std | mean_std | random_forest | 12 | 80.18 | 79.92 | 0.243 | 0.014 |
| body_direct_covariation | mean_second_moment | ridge | 27 | 57.41 | 55.32 | 0.002 | 0.000 |
| body_direct_covariation | mean_second_moment | rbf_svm | 27 | 66.03 | 64.15 | 0.263 | 0.309 |
| body_direct_covariation | mean_second_moment | random_forest | 27 | 83.85 | 83.92 | 0.324 | 0.015 |
| body_direct_covariation | mean_second_moment_roughness | ridge | 48 | 60.06 | 58.36 | 0.002 | 0.000 |
| body_direct_covariation | mean_second_moment_roughness | rbf_svm | 48 | 65.32 | 63.09 | 0.293 | 0.359 |
| body_direct_covariation | mean_second_moment_roughness | random_forest | 48 | 85.34 | 85.43 | 0.362 | 0.016 |
| body_direct_covariation | mean_std_covariation | ridge | 54 | 74.11 | 73.01 | 0.003 | 0.000 |
| body_direct_covariation | mean_std_covariation | rbf_svm | 54 | 78.79 | 79.11 | 0.303 | 0.362 |
| body_direct_covariation | mean_std_covariation | random_forest | 54 | 85.99 | 86.08 | 0.413 | 0.014 |
| total_mean_std | mean_std | ridge | 12 | 76.42 | 75.62 | 0.002 | 0.000 |
| total_mean_std | mean_std | rbf_svm | 12 | 81.95 | 81.29 | 0.071 | 0.122 |
| total_mean_std | mean_std | random_forest | 12 | 81.10 | 80.55 | 0.187 | 0.012 |
| total_direct_covariation | mean_second_moment | ridge | 27 | 72.28 | 70.08 | 0.002 | 0.000 |
| total_direct_covariation | mean_second_moment | rbf_svm | 27 | 86.70 | 86.39 | 0.088 | 0.116 |
| total_direct_covariation | mean_second_moment | random_forest | 27 | 84.02 | 83.75 | 0.272 | 0.016 |
| total_direct_covariation | mean_second_moment_roughness | ridge | 48 | 82.93 | 82.87 | 0.002 | 0.000 |
| total_direct_covariation | mean_second_moment_roughness | rbf_svm | 48 | 86.94 | 86.78 | 0.107 | 0.142 |
| total_direct_covariation | mean_second_moment_roughness | random_forest | 48 | 87.07 | 86.79 | 0.327 | 0.013 |
| total_direct_covariation | mean_std_covariation | ridge | 54 | 88.53 | 88.46 | 0.002 | 0.000 |
| total_direct_covariation | mean_std_covariation | rbf_svm | 54 | 89.85 | 89.72 | 0.094 | 0.136 |
| total_direct_covariation | mean_std_covariation | random_forest | 54 | 92.77 | 92.69 | 0.361 | 0.011 |
| engineered_561 | uci_features | ridge | 561 | 95.72 | 95.85 | 0.023 | 0.002 |
| engineered_561 | uci_features | rbf_svm | 561 | 95.49 | 95.40 | 0.593 | 0.743 |
| engineered_561 | uci_features | random_forest | 561 | 92.43 | 92.21 | 1.175 | 0.016 |
| 561_plus_total_covariation | mean_std_covariation | ridge | 615 | 95.86 | 96.01 | 0.027 | 0.002 |
| 561_plus_total_covariation | mean_std_covariation | rbf_svm | 615 | 96.17 | 96.15 | 0.616 | 0.761 |
| 561_plus_total_covariation | mean_std_covariation | random_forest | 615 | 92.47 | 92.32 | 1.207 | 0.014 |
| total_basepoint | ordinary_full_signature | ridge | 56 | 75.57 | 75.49 | 0.003 | 0.000 |
| total_basepoint | ordinary_full_signature | rbf_svm | 56 | 87.44 | 87.31 | 0.121 | 0.172 |
| total_basepoint | ordinary_full_signature | random_forest | 56 | 87.92 | 87.83 | 0.355 | 0.013 |
| 561_plus_total_basepoint | ordinary_full_signature | ridge | 617 | 97.05 | 97.07 | 0.026 | 0.002 |
| 561_plus_total_basepoint | ordinary_full_signature | rbf_svm | 617 | 96.91 | 96.93 | 0.632 | 0.766 |
| 561_plus_total_basepoint | ordinary_full_signature | random_forest | 617 | 92.94 | 92.97 | 1.159 | 0.014 |
| total_basepoint | ordinary_full_logsignature | ridge | 28 | 76.86 | 76.76 | 0.002 | 0.000 |
| total_basepoint | ordinary_full_logsignature | rbf_svm | 28 | 87.11 | 86.99 | 0.091 | 0.138 |
| total_basepoint | ordinary_full_logsignature | random_forest | 28 | 87.51 | 87.33 | 0.274 | 0.016 |
| 561_plus_total_basepoint | ordinary_full_logsignature | ridge | 589 | 96.23 | 96.36 | 0.024 | 0.002 |
| 561_plus_total_basepoint | ordinary_full_logsignature | rbf_svm | 589 | 96.74 | 96.75 | 0.618 | 0.755 |
| 561_plus_total_basepoint | ordinary_full_logsignature | random_forest | 589 | 92.98 | 92.91 | 1.160 | 0.016 |
| total_basepoint | offset_full_signature | ridge | 210 | 86.29 | 86.32 | 0.007 | 0.001 |
| total_basepoint | offset_full_signature | rbf_svm | 210 | 88.29 | 88.17 | 0.313 | 0.388 |
| total_basepoint | offset_full_signature | random_forest | 210 | 88.73 | 88.58 | 0.669 | 0.012 |
| 561_plus_total_basepoint | offset_full_signature | ridge | 771 | 97.01 | 97.04 | 0.033 | 0.002 |
| 561_plus_total_basepoint | offset_full_signature | rbf_svm | 771 | 96.64 | 96.64 | 0.825 | 0.975 |
| 561_plus_total_basepoint | offset_full_signature | random_forest | 771 | 92.57 | 92.56 | 1.296 | 0.016 |
| total_basepoint | offset_full_logsignature | ridge | 105 | 82.97 | 82.91 | 0.004 | 0.000 |
| total_basepoint | offset_full_logsignature | rbf_svm | 105 | 88.12 | 88.03 | 0.168 | 0.291 |
| total_basepoint | offset_full_logsignature | random_forest | 105 | 87.14 | 86.91 | 0.509 | 0.016 |
| 561_plus_total_basepoint | offset_full_logsignature | ridge | 666 | 96.17 | 96.28 | 0.028 | 0.002 |
| 561_plus_total_basepoint | offset_full_logsignature | rbf_svm | 666 | 96.98 | 97.00 | 0.713 | 0.828 |
| 561_plus_total_basepoint | offset_full_logsignature | random_forest | 666 | 93.15 | 93.18 | 1.217 | 0.014 |
| total_integrated | ordinary_full_signature | ridge | 56 | 68.54 | 67.01 | 0.003 | 0.000 |
| total_integrated | ordinary_full_signature | rbf_svm | 56 | 81.34 | 80.91 | 0.190 | 0.230 |
| total_integrated | ordinary_full_signature | random_forest | 56 | 77.71 | 77.11 | 0.386 | 0.016 |
| 561_plus_total_integrated | ordinary_full_signature | ridge | 617 | 96.64 | 96.68 | 0.025 | 0.002 |
| 561_plus_total_integrated | ordinary_full_signature | rbf_svm | 617 | 95.79 | 95.73 | 0.659 | 0.813 |
| 561_plus_total_integrated | ordinary_full_signature | random_forest | 617 | 91.25 | 91.08 | 1.167 | 0.014 |
| total_integrated | ordinary_full_logsignature | ridge | 28 | 66.78 | 65.19 | 0.002 | 0.000 |
| total_integrated | ordinary_full_logsignature | rbf_svm | 28 | 86.22 | 86.04 | 0.149 | 0.188 |
| total_integrated | ordinary_full_logsignature | random_forest | 28 | 82.90 | 82.49 | 0.320 | 0.016 |
| 561_plus_total_integrated | ordinary_full_logsignature | ridge | 589 | 95.79 | 95.92 | 0.023 | 0.002 |
| 561_plus_total_integrated | ordinary_full_logsignature | rbf_svm | 589 | 95.96 | 95.91 | 0.649 | 0.799 |
| 561_plus_total_integrated | ordinary_full_logsignature | random_forest | 589 | 92.37 | 92.19 | 1.217 | 0.016 |
| total_integrated | offset_full_signature | ridge | 210 | 78.89 | 78.96 | 0.006 | 0.001 |
| total_integrated | offset_full_signature | rbf_svm | 210 | 83.98 | 83.68 | 0.378 | 0.434 |
| total_integrated | offset_full_signature | random_forest | 210 | 80.69 | 80.18 | 0.713 | 0.014 |
| 561_plus_total_integrated | offset_full_signature | ridge | 771 | 96.84 | 96.89 | 0.033 | 0.002 |
| 561_plus_total_integrated | offset_full_signature | rbf_svm | 771 | 95.76 | 95.70 | 0.840 | 1.005 |
| 561_plus_total_integrated | offset_full_signature | random_forest | 771 | 90.84 | 90.71 | 1.282 | 0.014 |
| total_integrated | offset_full_logsignature | ridge | 105 | 73.43 | 73.23 | 0.004 | 0.000 |
| total_integrated | offset_full_logsignature | rbf_svm | 105 | 86.73 | 86.56 | 0.233 | 0.353 |
| total_integrated | offset_full_logsignature | random_forest | 105 | 81.98 | 81.52 | 0.565 | 0.016 |
| 561_plus_total_integrated | offset_full_logsignature | ridge | 666 | 96.67 | 96.71 | 0.030 | 0.003 |
| 561_plus_total_integrated | offset_full_logsignature | rbf_svm | 666 | 96.03 | 95.97 | 0.742 | 0.912 |
| 561_plus_total_integrated | offset_full_logsignature | random_forest | 666 | 91.86 | 91.73 | 1.232 | 0.016 |
| total_delay2 | ordinary_full_signature | ridge | 182 | 85.58 | 85.25 | 0.006 | 0.001 |
| total_delay2 | ordinary_full_signature | rbf_svm | 182 | 90.77 | 90.79 | 0.232 | 0.302 |
| total_delay2 | ordinary_full_signature | random_forest | 182 | 91.31 | 91.29 | 0.599 | 0.014 |
| 561_plus_total_delay2 | ordinary_full_signature | ridge | 743 | 96.91 | 96.93 | 0.036 | 0.004 |
| 561_plus_total_delay2 | ordinary_full_signature | rbf_svm | 743 | 96.95 | 96.96 | 0.769 | 0.912 |
| 561_plus_total_delay2 | ordinary_full_signature | random_forest | 743 | 93.65 | 93.69 | 1.245 | 0.014 |
| total_delay2 | ordinary_full_logsignature | ridge | 91 | 85.34 | 85.27 | 0.003 | 0.000 |
| total_delay2 | ordinary_full_logsignature | rbf_svm | 91 | 90.77 | 90.80 | 0.144 | 0.223 |
| total_delay2 | ordinary_full_logsignature | random_forest | 91 | 92.06 | 92.10 | 0.432 | 0.014 |
| 561_plus_total_delay2 | ordinary_full_logsignature | ridge | 652 | 95.96 | 96.07 | 0.026 | 0.002 |
| 561_plus_total_delay2 | ordinary_full_logsignature | rbf_svm | 652 | 96.91 | 96.94 | 0.670 | 0.795 |
| 561_plus_total_delay2 | ordinary_full_logsignature | random_forest | 652 | 93.18 | 93.19 | 1.207 | 0.016 |
| total_delay2 | offset_full_signature | ridge | 702 | 88.80 | 88.77 | 0.022 | 0.001 |
| total_delay2 | offset_full_signature | rbf_svm | 702 | 91.28 | 91.30 | 0.821 | 1.035 |
| total_delay2 | offset_full_signature | random_forest | 702 | 92.30 | 92.27 | 1.207 | 0.014 |
| 561_plus_total_delay2 | offset_full_signature | ridge | 1263 | 96.78 | 96.79 | 0.067 | 0.004 |
| 561_plus_total_delay2 | offset_full_signature | rbf_svm | 1263 | 96.10 | 96.09 | 1.254 | 3.446 |
| 561_plus_total_delay2 | offset_full_signature | random_forest | 1263 | 93.11 | 93.14 | 1.673 | 0.015 |
| total_delay2 | offset_full_logsignature | ridge | 351 | 87.21 | 87.14 | 0.010 | 0.001 |
| total_delay2 | offset_full_logsignature | rbf_svm | 351 | 91.41 | 91.44 | 0.431 | 0.543 |
| total_delay2 | offset_full_logsignature | random_forest | 351 | 91.99 | 91.94 | 0.869 | 0.013 |
| 561_plus_total_delay2 | offset_full_logsignature | ridge | 912 | 95.96 | 96.07 | 0.041 | 0.003 |
| 561_plus_total_delay2 | offset_full_logsignature | rbf_svm | 912 | 96.50 | 96.51 | 1.053 | 2.958 |
| 561_plus_total_delay2 | offset_full_logsignature | random_forest | 912 | 93.65 | 93.68 | 1.424 | 0.014 |
| total_delay5 | ordinary_full_signature | ridge | 182 | 82.93 | 83.07 | 0.005 | 0.001 |
| total_delay5 | ordinary_full_signature | rbf_svm | 182 | 88.09 | 87.94 | 0.239 | 0.312 |
| total_delay5 | ordinary_full_signature | random_forest | 182 | 91.72 | 91.64 | 0.613 | 0.016 |
| 561_plus_total_delay5 | ordinary_full_signature | ridge | 743 | 96.40 | 96.36 | 0.038 | 0.002 |
| 561_plus_total_delay5 | ordinary_full_signature | rbf_svm | 743 | 96.67 | 96.67 | 0.782 | 0.928 |
| 561_plus_total_delay5 | ordinary_full_signature | random_forest | 743 | 92.74 | 92.77 | 1.246 | 0.014 |
| total_delay5 | ordinary_full_logsignature | ridge | 91 | 83.27 | 83.38 | 0.003 | 0.000 |
| total_delay5 | ordinary_full_logsignature | rbf_svm | 91 | 87.99 | 87.83 | 0.143 | 0.228 |
| total_delay5 | ordinary_full_logsignature | random_forest | 91 | 91.04 | 90.86 | 0.450 | 0.016 |
| 561_plus_total_delay5 | ordinary_full_logsignature | ridge | 652 | 95.62 | 95.68 | 0.027 | 0.002 |
| 561_plus_total_delay5 | ordinary_full_logsignature | rbf_svm | 652 | 96.91 | 96.93 | 0.675 | 0.799 |
| 561_plus_total_delay5 | ordinary_full_logsignature | random_forest | 652 | 93.32 | 93.32 | 1.221 | 0.016 |
| total_delay5 | offset_full_signature | ridge | 702 | 87.11 | 86.97 | 0.020 | 0.001 |
| total_delay5 | offset_full_signature | rbf_svm | 702 | 88.36 | 88.21 | 0.875 | 1.099 |
| total_delay5 | offset_full_signature | random_forest | 702 | 92.13 | 91.98 | 1.228 | 0.014 |
| 561_plus_total_delay5 | offset_full_signature | ridge | 1263 | 96.27 | 96.23 | 0.067 | 0.004 |
| 561_plus_total_delay5 | offset_full_signature | rbf_svm | 1263 | 95.18 | 95.11 | 1.285 | 3.546 |
| 561_plus_total_delay5 | offset_full_signature | random_forest | 1263 | 93.21 | 93.17 | 1.685 | 0.018 |
| total_delay5 | offset_full_logsignature | ridge | 351 | 85.61 | 85.49 | 0.009 | 0.001 |
| total_delay5 | offset_full_logsignature | rbf_svm | 351 | 88.63 | 88.49 | 0.442 | 0.568 |
| total_delay5 | offset_full_logsignature | random_forest | 351 | 90.91 | 90.74 | 0.883 | 0.016 |
| 561_plus_total_delay5 | offset_full_logsignature | ridge | 912 | 95.66 | 95.73 | 0.043 | 0.003 |
| 561_plus_total_delay5 | offset_full_logsignature | rbf_svm | 912 | 96.00 | 95.96 | 1.074 | 2.992 |
| 561_plus_total_delay5 | offset_full_logsignature | random_forest | 912 | 92.74 | 92.68 | 1.433 | 0.014 |
| total_fourier_2_4 | fourier_first_level | ridge | 30 | 57.01 | 52.47 | 0.002 | 0.000 |
| total_fourier_2_4 | fourier_first_level | rbf_svm | 30 | 90.91 | 90.93 | 0.129 | 0.188 |
| total_fourier_2_4 | fourier_first_level | random_forest | 30 | 88.77 | 88.61 | 0.333 | 0.013 |
| 561_plus_total_fourier_2_4 | fourier_first_level | ridge | 591 | 95.86 | 95.99 | 0.024 | 0.002 |
| 561_plus_total_fourier_2_4 | fourier_first_level | rbf_svm | 591 | 95.59 | 95.52 | 0.675 | 0.865 |
| 561_plus_total_fourier_2_4 | fourier_first_level | random_forest | 591 | 91.69 | 91.47 | 1.243 | 0.014 |
| total_fourier_2_4 | fourier_cross_spectrum | ridge | 78 | 80.62 | 81.19 | 0.003 | 0.000 |
| total_fourier_2_4 | fourier_cross_spectrum | rbf_svm | 78 | 90.26 | 90.23 | 0.140 | 0.226 |
| total_fourier_2_4 | fourier_cross_spectrum | random_forest | 78 | 92.87 | 92.79 | 0.450 | 0.016 |
| 561_plus_total_fourier_2_4 | fourier_cross_spectrum | ridge | 639 | 96.67 | 96.85 | 0.026 | 0.002 |
| 561_plus_total_fourier_2_4 | fourier_cross_spectrum | rbf_svm | 639 | 97.05 | 97.07 | 0.692 | 0.843 |
| 561_plus_total_fourier_2_4 | fourier_cross_spectrum | random_forest | 639 | 94.10 | 94.05 | 1.259 | 0.016 |
| total_fourier_2_4 | fourier_full_signature | ridge | 930 | 88.90 | 89.26 | 0.026 | 0.002 |
| total_fourier_2_4 | fourier_full_signature | rbf_svm | 930 | 89.79 | 89.90 | 1.965 | 5.415 |
| total_fourier_2_4 | fourier_full_signature | random_forest | 930 | 91.45 | 91.37 | 1.572 | 0.015 |
| 561_plus_total_fourier_2_4 | fourier_full_signature | ridge | 1491 | 96.67 | 96.70 | 0.099 | 0.005 |
| 561_plus_total_fourier_2_4 | fourier_full_signature | rbf_svm | 1491 | 96.13 | 96.12 | 2.024 | 5.199 |
| 561_plus_total_fourier_2_4 | fourier_full_signature | random_forest | 1491 | 91.86 | 91.75 | 1.882 | 0.018 |
| total_fourier_2_4 | fourier_full_logsignature | ridge | 465 | 85.88 | 86.24 | 0.014 | 0.001 |
| total_fourier_2_4 | fourier_full_logsignature | rbf_svm | 465 | 89.28 | 89.24 | 1.017 | 1.091 |
| total_fourier_2_4 | fourier_full_logsignature | random_forest | 465 | 90.30 | 90.10 | 1.131 | 0.014 |
| 561_plus_total_fourier_2_4 | fourier_full_logsignature | ridge | 1026 | 96.95 | 96.98 | 0.055 | 0.004 |
| 561_plus_total_fourier_2_4 | fourier_full_logsignature | rbf_svm | 1026 | 96.10 | 96.07 | 1.532 | 4.261 |
| 561_plus_total_fourier_2_4 | fourier_full_logsignature | random_forest | 1026 | 92.26 | 92.15 | 1.612 | 0.017 |
| total_fourier_4 | fourier_first_level | ridge | 18 | 54.09 | 47.90 | 0.002 | 0.000 |
| total_fourier_4 | fourier_first_level | rbf_svm | 18 | 87.07 | 86.91 | 0.116 | 0.162 |
| total_fourier_4 | fourier_first_level | random_forest | 18 | 84.83 | 84.51 | 0.259 | 0.016 |
| 561_plus_total_fourier_4 | fourier_first_level | ridge | 579 | 96.03 | 96.17 | 0.025 | 0.002 |
| 561_plus_total_fourier_4 | fourier_first_level | rbf_svm | 579 | 95.49 | 95.40 | 0.651 | 0.824 |
| 561_plus_total_fourier_4 | fourier_first_level | random_forest | 579 | 91.96 | 91.76 | 1.215 | 0.016 |
| total_fourier_4 | fourier_cross_spectrum | ridge | 42 | 76.15 | 76.57 | 0.002 | 0.000 |
| total_fourier_4 | fourier_cross_spectrum | rbf_svm | 42 | 86.26 | 86.12 | 0.125 | 0.172 |
| total_fourier_4 | fourier_cross_spectrum | random_forest | 42 | 89.45 | 89.35 | 0.333 | 0.016 |
| 561_plus_total_fourier_4 | fourier_cross_spectrum | ridge | 603 | 96.47 | 96.64 | 0.027 | 0.002 |
| 561_plus_total_fourier_4 | fourier_cross_spectrum | rbf_svm | 603 | 96.78 | 96.78 | 0.648 | 0.792 |
| 561_plus_total_fourier_4 | fourier_cross_spectrum | random_forest | 603 | 93.52 | 93.47 | 1.204 | 0.014 |
| total_fourier_4 | fourier_full_signature | ridge | 342 | 85.34 | 85.81 | 0.010 | 0.001 |
| total_fourier_4 | fourier_full_signature | rbf_svm | 342 | 88.70 | 88.79 | 0.736 | 0.775 |
| total_fourier_4 | fourier_full_signature | random_forest | 342 | 90.02 | 89.96 | 0.932 | 0.014 |
| 561_plus_total_fourier_4 | fourier_full_signature | ridge | 903 | 96.88 | 96.92 | 0.045 | 0.003 |
| 561_plus_total_fourier_4 | fourier_full_signature | rbf_svm | 903 | 96.34 | 96.31 | 1.330 | 3.728 |
| 561_plus_total_fourier_4 | fourier_full_signature | random_forest | 903 | 92.30 | 92.25 | 1.492 | 0.017 |
| total_fourier_4 | fourier_full_logsignature | ridge | 171 | 79.67 | 79.95 | 0.006 | 0.000 |
| total_fourier_4 | fourier_full_logsignature | rbf_svm | 171 | 88.09 | 88.07 | 0.428 | 0.452 |
| total_fourier_4 | fourier_full_logsignature | random_forest | 171 | 89.31 | 89.10 | 0.706 | 0.016 |
| 561_plus_total_fourier_4 | fourier_full_logsignature | ridge | 732 | 96.67 | 96.71 | 0.034 | 0.002 |
| 561_plus_total_fourier_4 | fourier_full_logsignature | rbf_svm | 732 | 96.30 | 96.26 | 0.908 | 1.082 |
| 561_plus_total_fourier_4 | fourier_full_logsignature | random_forest | 732 | 92.53 | 92.44 | 1.360 | 0.014 |
| total_pascal | ordinary_integrated_full_signature | ridge | 42 | 67.93 | 66.29 | 0.003 | 0.000 |
| total_pascal | ordinary_integrated_full_signature | rbf_svm | 42 | 80.08 | 79.61 | 0.178 | 0.222 |
| total_pascal | ordinary_integrated_full_signature | random_forest | 42 | 78.83 | 78.26 | 0.365 | 0.013 |
| 561_plus_total_pascal | ordinary_integrated_full_signature | ridge | 603 | 96.67 | 96.71 | 0.024 | 0.002 |
| 561_plus_total_pascal | ordinary_integrated_full_signature | rbf_svm | 603 | 95.72 | 95.66 | 0.662 | 0.818 |
| 561_plus_total_pascal | ordinary_integrated_full_signature | random_forest | 603 | 92.03 | 91.83 | 1.207 | 0.016 |
| total_pascal | ordinary_integrated_full_logsignature | ridge | 21 | 66.81 | 65.37 | 0.002 | 0.000 |
| total_pascal | ordinary_integrated_full_logsignature | rbf_svm | 21 | 82.93 | 82.69 | 0.140 | 0.183 |
| total_pascal | ordinary_integrated_full_logsignature | random_forest | 21 | 81.85 | 81.42 | 0.264 | 0.016 |
| 561_plus_total_pascal | ordinary_integrated_full_logsignature | ridge | 582 | 95.76 | 95.88 | 0.023 | 0.002 |
| 561_plus_total_pascal | ordinary_integrated_full_logsignature | rbf_svm | 582 | 95.89 | 95.84 | 0.638 | 0.781 |
| 561_plus_total_pascal | ordinary_integrated_full_logsignature | random_forest | 582 | 91.69 | 91.52 | 1.234 | 0.016 |
| total_pascal | pascal_qr_full_signature | ridge | 342 | 84.22 | 84.33 | 0.009 | 0.001 |
| total_pascal | pascal_qr_full_signature | rbf_svm | 342 | 88.39 | 88.37 | 0.710 | 0.765 |
| total_pascal | pascal_qr_full_signature | random_forest | 342 | 84.87 | 84.49 | 0.921 | 0.014 |
| 561_plus_total_pascal | pascal_qr_full_signature | ridge | 903 | 97.12 | 97.16 | 0.048 | 0.003 |
| 561_plus_total_pascal | pascal_qr_full_signature | rbf_svm | 903 | 96.57 | 96.58 | 1.305 | 3.742 |
| 561_plus_total_pascal | pascal_qr_full_signature | random_forest | 903 | 91.48 | 91.32 | 1.467 | 0.017 |
| total_pascal | pascal_qr_full_logsignature | ridge | 171 | 81.98 | 82.19 | 0.006 | 0.000 |
| total_pascal | pascal_qr_full_logsignature | rbf_svm | 171 | 88.43 | 88.42 | 0.401 | 0.442 |
| total_pascal | pascal_qr_full_logsignature | random_forest | 171 | 85.65 | 85.30 | 0.716 | 0.014 |
| 561_plus_total_pascal | pascal_qr_full_logsignature | ridge | 732 | 96.88 | 96.92 | 0.034 | 0.002 |
| 561_plus_total_pascal | pascal_qr_full_logsignature | rbf_svm | 732 | 96.57 | 96.55 | 0.906 | 1.085 |
| 561_plus_total_pascal | pascal_qr_full_logsignature | random_forest | 732 | 92.23 | 92.11 | 1.364 | 0.014 |
| total_pascal | pascal_qr_first_level | ridge | 18 | 55.24 | 50.02 | 0.002 | 0.000 |
| total_pascal | pascal_qr_first_level | rbf_svm | 18 | 85.85 | 85.61 | 0.158 | 0.196 |
| total_pascal | pascal_qr_first_level | random_forest | 18 | 83.27 | 82.79 | 0.269 | 0.014 |
| 561_plus_total_pascal | pascal_qr_first_level | ridge | 579 | 96.00 | 96.13 | 0.023 | 0.002 |
| 561_plus_total_pascal | pascal_qr_first_level | rbf_svm | 579 | 95.76 | 95.68 | 0.647 | 0.821 |
| 561_plus_total_pascal | pascal_qr_first_level | random_forest | 579 | 91.52 | 91.29 | 1.184 | 0.014 |
| total_pascal | pascal_newton_full_signature | ridge | 342 | 80.05 | 80.21 | 0.009 | 0.001 |
| total_pascal | pascal_newton_full_signature | rbf_svm | 342 | 83.88 | 83.64 | 0.591 | 0.669 |
| total_pascal | pascal_newton_full_signature | random_forest | 342 | 81.10 | 80.59 | 0.954 | 0.014 |
| 561_plus_total_pascal | pascal_newton_full_signature | ridge | 903 | 97.01 | 97.07 | 0.042 | 0.004 |
| 561_plus_total_pascal | pascal_newton_full_signature | rbf_svm | 903 | 95.52 | 95.45 | 1.123 | 3.256 |
| 561_plus_total_pascal | pascal_newton_full_signature | random_forest | 903 | 89.96 | 89.78 | 1.453 | 0.014 |
| total_pascal | pascal_newton_full_logsignature | ridge | 171 | 75.98 | 76.11 | 0.006 | 0.000 |
| total_pascal | pascal_newton_full_logsignature | rbf_svm | 171 | 85.07 | 84.91 | 0.326 | 0.400 |
| total_pascal | pascal_newton_full_logsignature | random_forest | 171 | 82.29 | 81.84 | 0.726 | 0.016 |
| 561_plus_total_pascal | pascal_newton_full_logsignature | ridge | 732 | 96.88 | 96.92 | 0.031 | 0.002 |
| 561_plus_total_pascal | pascal_newton_full_logsignature | rbf_svm | 732 | 95.96 | 95.90 | 0.828 | 0.993 |
| 561_plus_total_pascal | pascal_newton_full_logsignature | random_forest | 732 | 91.35 | 91.19 | 1.326 | 0.014 |
| total_pascal | pascal_newton_first_level | ridge | 18 | 54.36 | 48.16 | 0.002 | 0.000 |
| total_pascal | pascal_newton_first_level | rbf_svm | 18 | 75.30 | 74.69 | 0.164 | 0.208 |
| total_pascal | pascal_newton_first_level | random_forest | 18 | 73.06 | 72.42 | 0.245 | 0.013 |
| 561_plus_total_pascal | pascal_newton_first_level | ridge | 579 | 95.79 | 95.92 | 0.028 | 0.002 |
| 561_plus_total_pascal | pascal_newton_first_level | rbf_svm | 579 | 95.62 | 95.55 | 0.628 | 0.779 |
| 561_plus_total_pascal | pascal_newton_first_level | random_forest | 579 | 91.38 | 91.21 | 1.204 | 0.016 |
| total_pascal | pascal_gap_moments | ridge | 78 | 65.35 | 63.29 | 0.004 | 0.000 |
| total_pascal | pascal_gap_moments | rbf_svm | 78 | 80.12 | 79.79 | 0.253 | 0.343 |
| total_pascal | pascal_gap_moments | random_forest | 78 | 79.71 | 79.12 | 0.470 | 0.014 |
| 561_plus_total_pascal | pascal_gap_moments | ridge | 639 | 96.78 | 96.82 | 0.029 | 0.002 |
| 561_plus_total_pascal | pascal_gap_moments | rbf_svm | 639 | 95.76 | 95.70 | 0.729 | 0.891 |
| 561_plus_total_pascal | pascal_gap_moments | random_forest | 639 | 91.18 | 91.00 | 1.231 | 0.016 |
| total_pascal | fourier_pascal_full_signature | ridge | 930 | 90.30 | 90.46 | 0.026 | 0.002 |
| total_pascal | fourier_pascal_full_signature | rbf_svm | 930 | 89.31 | 89.37 | 1.830 | 5.085 |
| total_pascal | fourier_pascal_full_signature | random_forest | 930 | 90.63 | 90.60 | 1.493 | 0.014 |
| 561_plus_total_pascal | fourier_pascal_full_signature | ridge | 1491 | 96.78 | 96.82 | 0.103 | 0.005 |
| 561_plus_total_pascal | fourier_pascal_full_signature | rbf_svm | 1491 | 95.39 | 95.32 | 1.808 | 4.858 |
| 561_plus_total_pascal | fourier_pascal_full_signature | random_forest | 1491 | 92.16 | 92.15 | 1.831 | 0.017 |
| total_pascal | fourier_pascal_full_logsignature | ridge | 465 | 82.59 | 83.02 | 0.014 | 0.001 |
| total_pascal | fourier_pascal_full_logsignature | rbf_svm | 465 | 88.63 | 88.63 | 0.953 | 1.048 |
| total_pascal | fourier_pascal_full_logsignature | random_forest | 465 | 89.89 | 89.74 | 1.083 | 0.012 |
| 561_plus_total_pascal | fourier_pascal_full_logsignature | ridge | 1026 | 97.01 | 97.07 | 0.058 | 0.003 |
| 561_plus_total_pascal | fourier_pascal_full_logsignature | rbf_svm | 1026 | 95.66 | 95.59 | 1.446 | 4.001 |
| 561_plus_total_pascal | fourier_pascal_full_logsignature | random_forest | 1026 | 91.96 | 91.85 | 1.527 | 0.012 |
| total_pascal | fourier_pascal_first_level | ridge | 30 | 53.72 | 47.97 | 0.002 | 0.000 |
| total_pascal | fourier_pascal_first_level | rbf_svm | 30 | 87.78 | 87.65 | 0.129 | 0.187 |
| total_pascal | fourier_pascal_first_level | random_forest | 30 | 87.58 | 87.38 | 0.306 | 0.016 |
| 561_plus_total_pascal | fourier_pascal_first_level | ridge | 591 | 95.96 | 96.10 | 0.030 | 0.002 |
| 561_plus_total_pascal | fourier_pascal_first_level | rbf_svm | 591 | 95.86 | 95.80 | 0.672 | 0.854 |
| 561_plus_total_pascal | fourier_pascal_first_level | random_forest | 591 | 91.52 | 91.36 | 1.221 | 0.014 |
| total_pascal | fourier_pascal_gap | ridge | 78 | 68.41 | 67.22 | 0.003 | 0.000 |
| total_pascal | fourier_pascal_gap | rbf_svm | 78 | 84.59 | 84.44 | 0.215 | 0.298 |
| total_pascal | fourier_pascal_gap | random_forest | 78 | 89.01 | 88.91 | 0.450 | 0.016 |
| 561_plus_total_pascal | fourier_pascal_gap | ridge | 639 | 96.95 | 97.00 | 0.033 | 0.002 |
| 561_plus_total_pascal | fourier_pascal_gap | rbf_svm | 639 | 96.47 | 96.45 | 0.742 | 0.925 |
| 561_plus_total_pascal | fourier_pascal_gap | random_forest | 639 | 92.47 | 92.30 | 1.254 | 0.014 |

## Adding features to the 561 features

Corrected and lost predictions compare the hybrid with the same head on the 561 features alone. They are descriptive counts on this test split, not significance tests.

| Hybrid / representation / head | Corrected errors | Introduced errors |
|---|---:|---:|
| 561_plus_total_covariation/mean_std_covariation/ridge | 23 | 19 |
| 561_plus_total_covariation/mean_std_covariation/rbf_svm | 35 | 15 |
| 561_plus_total_covariation/mean_std_covariation/random_forest | 47 | 46 |
| 561_plus_total_basepoint/ordinary_full_signature/ridge | 59 | 20 |
| 561_plus_total_basepoint/ordinary_full_signature/rbf_svm | 47 | 5 |
| 561_plus_total_basepoint/ordinary_full_signature/random_forest | 74 | 59 |
| 561_plus_total_basepoint/ordinary_full_logsignature/ridge | 25 | 10 |
| 561_plus_total_basepoint/ordinary_full_logsignature/rbf_svm | 40 | 3 |
| 561_plus_total_basepoint/ordinary_full_logsignature/random_forest | 60 | 44 |
| 561_plus_total_basepoint/offset_full_signature/ridge | 61 | 23 |
| 561_plus_total_basepoint/offset_full_signature/rbf_svm | 53 | 19 |
| 561_plus_total_basepoint/offset_full_signature/random_forest | 92 | 88 |
| 561_plus_total_basepoint/offset_full_logsignature/ridge | 28 | 15 |
| 561_plus_total_basepoint/offset_full_logsignature/rbf_svm | 52 | 8 |
| 561_plus_total_basepoint/offset_full_logsignature/random_forest | 86 | 65 |
| 561_plus_total_integrated/ordinary_full_signature/ridge | 44 | 17 |
| 561_plus_total_integrated/ordinary_full_signature/rbf_svm | 20 | 11 |
| 561_plus_total_integrated/ordinary_full_signature/random_forest | 39 | 74 |
| 561_plus_total_integrated/ordinary_full_logsignature/ridge | 11 | 9 |
| 561_plus_total_integrated/ordinary_full_logsignature/rbf_svm | 20 | 6 |
| 561_plus_total_integrated/ordinary_full_logsignature/random_forest | 38 | 40 |
| 561_plus_total_integrated/offset_full_signature/ridge | 50 | 17 |
| 561_plus_total_integrated/offset_full_signature/rbf_svm | 37 | 29 |
| 561_plus_total_integrated/offset_full_signature/random_forest | 52 | 99 |
| 561_plus_total_integrated/offset_full_logsignature/ridge | 47 | 19 |
| 561_plus_total_integrated/offset_full_logsignature/rbf_svm | 32 | 16 |
| 561_plus_total_integrated/offset_full_logsignature/random_forest | 51 | 68 |
| 561_plus_total_delay2/ordinary_full_signature/ridge | 62 | 27 |
| 561_plus_total_delay2/ordinary_full_signature/rbf_svm | 56 | 13 |
| 561_plus_total_delay2/ordinary_full_signature/random_forest | 108 | 72 |
| 561_plus_total_delay2/ordinary_full_logsignature/ridge | 33 | 26 |
| 561_plus_total_delay2/ordinary_full_logsignature/rbf_svm | 51 | 9 |
| 561_plus_total_delay2/ordinary_full_logsignature/random_forest | 77 | 55 |
| 561_plus_total_delay2/offset_full_signature/ridge | 63 | 32 |
| 561_plus_total_delay2/offset_full_signature/rbf_svm | 59 | 41 |
| 561_plus_total_delay2/offset_full_signature/random_forest | 120 | 100 |
| 561_plus_total_delay2/offset_full_logsignature/ridge | 32 | 25 |
| 561_plus_total_delay2/offset_full_logsignature/rbf_svm | 60 | 30 |
| 561_plus_total_delay2/offset_full_logsignature/random_forest | 112 | 76 |
| 561_plus_total_delay5/ordinary_full_signature/ridge | 60 | 40 |
| 561_plus_total_delay5/ordinary_full_signature/rbf_svm | 55 | 20 |
| 561_plus_total_delay5/ordinary_full_signature/random_forest | 93 | 84 |
| 561_plus_total_delay5/ordinary_full_logsignature/ridge | 27 | 30 |
| 561_plus_total_delay5/ordinary_full_logsignature/rbf_svm | 50 | 8 |
| 561_plus_total_delay5/ordinary_full_logsignature/random_forest | 83 | 57 |
| 561_plus_total_delay5/offset_full_signature/ridge | 62 | 46 |
| 561_plus_total_delay5/offset_full_signature/rbf_svm | 55 | 64 |
| 561_plus_total_delay5/offset_full_signature/random_forest | 121 | 98 |
| 561_plus_total_delay5/offset_full_logsignature/ridge | 30 | 32 |
| 561_plus_total_delay5/offset_full_logsignature/rbf_svm | 56 | 41 |
| 561_plus_total_delay5/offset_full_logsignature/random_forest | 99 | 90 |
| 561_plus_total_fourier_2_4/fourier_first_level/ridge | 7 | 3 |
| 561_plus_total_fourier_2_4/fourier_first_level/rbf_svm | 10 | 7 |
| 561_plus_total_fourier_2_4/fourier_first_level/random_forest | 31 | 53 |
| 561_plus_total_fourier_2_4/fourier_cross_spectrum/ridge | 34 | 6 |
| 561_plus_total_fourier_2_4/fourier_cross_spectrum/rbf_svm | 53 | 7 |
| 561_plus_total_fourier_2_4/fourier_cross_spectrum/random_forest | 80 | 31 |
| 561_plus_total_fourier_2_4/fourier_full_signature/ridge | 69 | 41 |
| 561_plus_total_fourier_2_4/fourier_full_signature/rbf_svm | 58 | 39 |
| 561_plus_total_fourier_2_4/fourier_full_signature/random_forest | 63 | 80 |
| 561_plus_total_fourier_2_4/fourier_full_logsignature/ridge | 65 | 29 |
| 561_plus_total_fourier_2_4/fourier_full_logsignature/rbf_svm | 50 | 32 |
| 561_plus_total_fourier_2_4/fourier_full_logsignature/random_forest | 64 | 69 |
| 561_plus_total_fourier_4/fourier_first_level/ridge | 9 | 0 |
| 561_plus_total_fourier_4/fourier_first_level/rbf_svm | 5 | 5 |
| 561_plus_total_fourier_4/fourier_first_level/random_forest | 33 | 47 |
| 561_plus_total_fourier_4/fourier_cross_spectrum/ridge | 29 | 7 |
| 561_plus_total_fourier_4/fourier_cross_spectrum/rbf_svm | 44 | 6 |
| 561_plus_total_fourier_4/fourier_cross_spectrum/random_forest | 68 | 36 |
| 561_plus_total_fourier_4/fourier_full_signature/ridge | 68 | 34 |
| 561_plus_total_fourier_4/fourier_full_signature/rbf_svm | 53 | 28 |
| 561_plus_total_fourier_4/fourier_full_signature/random_forest | 66 | 70 |
| 561_plus_total_fourier_4/fourier_full_logsignature/ridge | 54 | 26 |
| 561_plus_total_fourier_4/fourier_full_logsignature/rbf_svm | 44 | 20 |
| 561_plus_total_fourier_4/fourier_full_logsignature/random_forest | 64 | 61 |
| 561_plus_total_pascal/ordinary_integrated_full_signature/ridge | 43 | 15 |
| 561_plus_total_pascal/ordinary_integrated_full_signature/rbf_svm | 16 | 9 |
| 561_plus_total_pascal/ordinary_integrated_full_signature/random_forest | 44 | 56 |
| 561_plus_total_pascal/ordinary_integrated_full_logsignature/ridge | 9 | 8 |
| 561_plus_total_pascal/ordinary_integrated_full_logsignature/rbf_svm | 17 | 5 |
| 561_plus_total_pascal/ordinary_integrated_full_logsignature/random_forest | 28 | 50 |
| 561_plus_total_pascal/pascal_qr_full_signature/ridge | 59 | 18 |
| 561_plus_total_pascal/pascal_qr_full_signature/rbf_svm | 55 | 23 |
| 561_plus_total_pascal/pascal_qr_full_signature/random_forest | 47 | 75 |
| 561_plus_total_pascal/pascal_qr_full_logsignature/ridge | 57 | 23 |
| 561_plus_total_pascal/pascal_qr_full_logsignature/rbf_svm | 45 | 13 |
| 561_plus_total_pascal/pascal_qr_full_logsignature/random_forest | 51 | 57 |
| 561_plus_total_pascal/pascal_qr_first_level/ridge | 9 | 1 |
| 561_plus_total_pascal/pascal_qr_first_level/rbf_svm | 12 | 4 |
| 561_plus_total_pascal/pascal_qr_first_level/random_forest | 27 | 54 |
| 561_plus_total_pascal/pascal_newton_full_signature/ridge | 55 | 17 |
| 561_plus_total_pascal/pascal_newton_full_signature/rbf_svm | 40 | 39 |
| 561_plus_total_pascal/pascal_newton_full_signature/random_forest | 51 | 124 |
| 561_plus_total_pascal/pascal_newton_full_logsignature/ridge | 51 | 17 |
| 561_plus_total_pascal/pascal_newton_full_logsignature/rbf_svm | 39 | 25 |
| 561_plus_total_pascal/pascal_newton_full_logsignature/random_forest | 48 | 80 |
| 561_plus_total_pascal/pascal_newton_first_level/ridge | 3 | 1 |
| 561_plus_total_pascal/pascal_newton_first_level/rbf_svm | 10 | 6 |
| 561_plus_total_pascal/pascal_newton_first_level/random_forest | 32 | 63 |
| 561_plus_total_pascal/pascal_gap_moments/ridge | 47 | 16 |
| 561_plus_total_pascal/pascal_gap_moments/rbf_svm | 18 | 10 |
| 561_plus_total_pascal/pascal_gap_moments/random_forest | 41 | 78 |
| 561_plus_total_pascal/fourier_pascal_full_signature/ridge | 65 | 34 |
| 561_plus_total_pascal/fourier_pascal_full_signature/rbf_svm | 55 | 58 |
| 561_plus_total_pascal/fourier_pascal_full_signature/random_forest | 84 | 92 |
| 561_plus_total_pascal/fourier_pascal_full_logsignature/ridge | 65 | 27 |
| 561_plus_total_pascal/fourier_pascal_full_logsignature/rbf_svm | 54 | 49 |
| 561_plus_total_pascal/fourier_pascal_full_logsignature/random_forest | 66 | 80 |
| 561_plus_total_pascal/fourier_pascal_first_level/ridge | 9 | 2 |
| 561_plus_total_pascal/fourier_pascal_first_level/rbf_svm | 17 | 6 |
| 561_plus_total_pascal/fourier_pascal_first_level/random_forest | 33 | 60 |
| 561_plus_total_pascal/fourier_pascal_gap/ridge | 55 | 19 |
| 561_plus_total_pascal/fourier_pascal_gap/rbf_svm | 38 | 9 |
| 561_plus_total_pascal/fourier_pascal_gap/random_forest | 47 | 46 |
