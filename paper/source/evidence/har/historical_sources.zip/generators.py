"""Small composable observation -> integration -> temporal-code generators.

Inputs are already scaled using training windows. There is no additional
window centering: DC and posture levels remain. These transforms describe the
scaled samples, not physical acceleration/gyro units or exact UCI columns.
"""

from time import perf_counter

import numpy as np
import torch
from features import extract_coded_features
from tensorsig.offset_coded_signatures.codes import OffsetCode

TRANSFORMS = ("identity", "difference", "energy", "lag_product", "spectral_power")


def transform_observations(x: torch.Tensor, name: str) -> torch.Tensor:
    """Return observation sequences with the channel axes retained.

    Differences are one-sample differences, without multiplication by 50 Hz.
    Lag products use valid lag-two pairs only, with no padding. Energy means
    axiswise squares, not a pooled triad norm. Spectral power is the one-sided
    periodogram in increasing frequency order, including DC and Nyquist when
    present. Its bins are multiplied by their count so that averaging the
    returned observations recovers each original channel's mean square.
    """
    if x.ndim != 3 or x.shape[1] < 3 or not torch.isfinite(x).all():
        raise ValueError("Expected finite (windows, >=3 samples, channels) observations")
    if name == "identity":
        return x
    if name == "difference":
        return x.diff(dim=1)
    if name == "energy":
        return x.square()
    if name == "lag_product":
        return x[:, 2:] * x[:, :-2]
    if name == "spectral_power":
        power = (torch.fft.rfft(x, dim=1).abs() / x.shape[1]).square()
        # Paired negative-frequency bins contribute twice; DC/Nyquist do not.
        power[:, 1:power.shape[1] - (x.shape[1] % 2 == 0)] *= 2
        return power * power.shape[1]
    raise ValueError(f"Expected transform in {TRANSFORMS}")


def temporal_code(length: int, P: int, family: str = "pascal") -> OffsetCode:
    """QR Pascal with P columns, or QR Fourier-Pascal with 1+2P columns.

    Fourier-Pascal spans [1, t^a cos(8*pi*t), t^a sin(8*pi*t)] for
    a=0,...,P-1, with t=r/length. The carrier therefore has four cycles over
    the sequence supplied to this function. On spectral observations it
    weights frequency bins; it is not modulation of the original time series.
    QR changes the ridge geometry from the earlier unnormalized carrier basis.
    """
    if family == "pascal":
        return OffsetCode.pascal(length, P, orthonormal=True, dtype=torch.float64)
    if family != "fourier_pascal":
        raise ValueError("Expected family 'pascal' or 'fourier_pascal'")
    if not isinstance(P, int) or P < 1 or 1 + 2 * P > length:
        raise ValueError("Fourier-Pascal requires positive P and 1+2P <= length")
    t = torch.arange(length, dtype=torch.float64) / length
    phase = 8 * torch.pi * t
    matrix = torch.stack([torch.ones_like(t), *(
        component for degree in range(P)
        for component in (t**degree * phase.cos(), t**degree * phase.sin())
    )], dim=1)
    basis, triangular = torch.linalg.qr(matrix, mode="reduced")
    tolerance = torch.finfo(matrix.dtype).eps * length * torch.linalg.norm(matrix)
    if triangular.diagonal().abs().min() <= tolerance:
        raise ValueError("Fourier carrier is rank deficient on this sequence length")
    signs = torch.where(triangular.diagonal() < 0, -1., 1.)
    return OffsetCode(basis * signs)


def coded_integration(
    observations: torch.Tensor, P: int, depth: int = 2,
    family: str = "pascal", batch_size: int = 256,
) -> tuple[np.ndarray, float]:
    """Integrate observations/length, then take the dense coded signature.

    No clock is appended. With a constant unit code, level one is the pooled
    observation mean. QR Pascal P=1 scales that by 1/sqrt(length); featurewise
    standardization in the classifier removes this fixed scale at each level.
    Timings include code construction and extraction, not the pre-transform.
    """
    start = perf_counter()
    length = observations.shape[1]
    code = temporal_code(length, P, family)
    values, _ = extract_coded_features(
        observations / length, code, batch_size=batch_size, depth=depth,
    )
    return values, perf_counter() - start


def self_check() -> None:
    from tensorsig.classical.signatures import signature

    generator = torch.Generator().manual_seed(31)
    for n in (15, 16):
        x = torch.randn(3, n, 2, generator=generator, dtype=torch.float64)
        torch.testing.assert_close(
            transform_observations(x, "spectral_power").mean(1), x.square().mean(1),
        )
    torch.testing.assert_close(transform_observations(x, "difference"), x[:, 1:] - x[:, :-1])
    torch.testing.assert_close(transform_observations(x, "lag_product"), x[:, 2:] * x[:, :-2])
    for family in ("pascal", "fourier_pascal"):
        code = temporal_code(n, 2, family)
        torch.testing.assert_close(code.matrix.T @ code.matrix,
                                   torch.eye(code.matrix.shape[1], dtype=torch.float64))
        lifted = ((x / n)[..., None] * code.matrix[None, :, None, :]).flatten(2)
        path = torch.cat((torch.zeros_like(lifted[:, :1]), lifted.cumsum(1)), 1)
        expected = signature(path, depth=3).numpy()
        actual, _ = coded_integration(x, 2, depth=3, family=family, batch_size=2)
        np.testing.assert_allclose(actual, expected, atol=1e-7, rtol=1e-6)


if __name__ == "__main__":
    self_check()
    print("Generic feature generator checks passed.")
