"""Compact selected words of Pascal QR clock-coded value graphs.

For each scalar sequence z, the graph starts at value x=0. It jumps to z[k],
then advances clock a by q[k,a]/N while holding x fixed, and finally returns
x to zero. Only the clocks are coded; q is the actual QR Pascal matrix.

The selected tensor-log word x**r t_a equals mean(z**r q_a)/r!. Indeed the
signature coefficient is integral x**r/r! dt_a, and every correction in the
tensor logarithm contains a pure-x prefix, which vanishes because x closes.
We compute these selected words by a fused polynomial lift and a first-level
tensorsig coded signature. This is exactly the graph readout, not the full
graph logsignature. Full graph computation is retained as a small control.
"""

from math import factorial
from time import perf_counter

import numpy as np
import torch
from generators import temporal_code
from tensorsig.algebra.lyndon_words import lyndon_words
from tensorsig.classical.signatures import log_signature
from tensorsig.offset_coded_signatures.plans import LocalRealization


def _inputs(observations, P: int, depth: int, batch_size: int) -> torch.Tensor:
    z = torch.as_tensor(observations, dtype=torch.float64)
    if z.ndim != 3 or min(z.shape) < 1 or z.device.type != "cpu":
        raise ValueError("Expected nonempty CPU (windows, samples, channels) observations")
    if not torch.isfinite(z).all() or batch_size < 1:
        raise ValueError("Expected finite observations and positive batch_size")
    if not isinstance(P, int) or not 1 <= P <= z.shape[1] or depth not in (2, 3, 4):
        raise ValueError("Expected 1 <= P <= samples and depth in (2, 3, 4)")
    return z


@torch.inference_mode()
def coded_occupation_readouts(
    observations: torch.Tensor, P: int, depth: int = 4, batch_size: int = 256,
) -> tuple[dict[str, np.ndarray | float], float]:
    """Return selected graph log words and their factorial-unscaled moments.

    Both arrays have shape (windows, channels, depth-1, P), in increasing
    power r=1,...,depth-1 and QR code order. ``moments[...,r-1,a]`` is
    mean(z**r q_a), and ``log_words`` divides this by r!. ``code_scale`` is
    the constant first QR column, so moments[...,r-1,0]/code_scale is the
    ordinary raw moment. No centering, variance normalization, or nonlinear
    calibration is performed here. All computation and outputs are float64.

    ``batch_size`` counts multichannel windows for this fused computation.
    """
    started = perf_counter()
    z = _inputs(observations, P, depth, batch_size)
    windows, samples, channels = z.shape
    code = temporal_code(samples, P)
    plan = LocalRealization(code, channels=channels * (depth - 1), max_depth=1).signature(
        coordinates="dense"
    )
    parts = []
    for batch in z.split(batch_size):
        lift = torch.stack([batch**r for r in range(1, depth)], dim=-1).flatten(2)
        parts.append(plan.evaluate((lift / samples)[:, None])[:, 0].numpy().copy())
    moments = np.concatenate(parts).reshape(windows, channels, depth - 1, P)
    divisors = np.array([factorial(r) for r in range(1, depth)])[None, None, :, None]
    return {
        "moments": moments,
        "log_words": moments / divisors,
        "code_scale": float(code.matrix[0, 0]),
    }, perf_counter() - started


@torch.inference_mode()
def full_coded_graph_readouts(
    observations: torch.Tensor, P: int, depth: int = 3, batch_size: int = 256,
) -> tuple[np.ndarray, float]:
    """Compute full channelwise graph logsignatures as a small dense control.

    Returns shape (windows, channels, len(lyndon_words(P+1, depth))), with
    alphabet x,t_0,...,t_(P-1). Constant endpoint and clock-only coordinates
    are retained; the benchmark removes constant columns. ``batch_size``
    counts scalar paths, including channels. Dense cost grows exponentially
    with depth; use the selected-word helper for the main sweep.
    """
    started = perf_counter()
    z = _inputs(observations, P, depth, batch_size)
    windows, samples, channels = z.shape
    code = temporal_code(samples, P).matrix
    clock = torch.cat((code.new_zeros((1, P)), (code / samples).cumsum(0)))
    staircase_clock = torch.stack((clock[:-1], clock[1:]), dim=1).flatten(0, 1)
    scalar_paths = z.transpose(1, 2).reshape(-1, samples)
    parts = []
    for values in scalar_paths.split(batch_size):
        path = values.new_zeros((len(values), 2 * samples + 2, P + 1))
        path[:, 1:-1, 0] = values.repeat_interleave(2, dim=1)
        path[:, 1:-1, 1:] = staircase_clock
        path[:, -1, 1:] = clock[-1]
        parts.append(log_signature(path, depth=depth, mode="words").numpy())
    full = np.concatenate(parts).reshape(windows, channels, -1)
    return full, perf_counter() - started


def self_check() -> None:
    """Verify graph equality, channel layout, and the role of sample order."""
    rng = torch.Generator().manual_seed(37)
    random = torch.randn(2, 13, 3, generator=rng, dtype=torch.float64)
    constant = torch.tensor([0.0, 2.0, -3.0], dtype=torch.float64).expand(2, 13, 3)
    for z in (random, constant):
        for P in (1, 2, 3):
            q = temporal_code(z.shape[1], P).matrix
            for depth in (2, 3, 4):
                compact, _ = coded_occupation_readouts(z, P, depth, batch_size=1)
                expected = torch.stack([
                    torch.einsum("bnc,np->bcp", z**r, q) / z.shape[1]
                    for r in range(1, depth)
                ], dim=2).numpy()
                np.testing.assert_allclose(compact["moments"], expected,
                                           rtol=2e-12, atol=2e-13)
                full, _ = full_coded_graph_readouts(z, P, depth, batch_size=2)
                words = lyndon_words(P + 1, depth)
                indices = [words.index((1,) * r + (a + 2,))
                           for r in range(1, depth) for a in range(P)]
                selected = full[..., indices].reshape(*expected.shape)
                np.testing.assert_allclose(compact["log_words"], selected,
                                           rtol=2e-11, atol=2e-13)

    permutation = torch.randperm(random.shape[1], generator=rng)
    original, _ = coded_occupation_readouts(random, 3)
    permuted, _ = coded_occupation_readouts(random[:, permutation], 3)
    np.testing.assert_allclose(original["moments"][..., 0], permuted["moments"][..., 0],
                               atol=2e-13)
    assert not np.allclose(original["moments"][..., 1:], permuted["moments"][..., 1:])
    # P=1 is an occupation readout; nonconstant clocks additionally locate
    # values within the window, so permuting values alone must change them.
    expected_raw = torch.stack([(random**r).mean(1) for r in (1, 2, 3)], dim=-1).numpy()
    np.testing.assert_allclose(original["moments"][..., 0] / original["code_scale"],
                               expected_raw, rtol=2e-12, atol=2e-13)


if __name__ == "__main__":
    torch.set_num_threads(1)
    self_check()
    print("Coded occupation graph checks passed")
