"""Small ridge comparisons of generic observation/signature families."""

from hashlib import sha256
from time import perf_counter

import numpy as np
import torch
from families import build_families
from features import _standardize
from generators import coded_integration
from sklearn.preprocessing import StandardScaler


def ridge_predict(train, labels, test):
    """Standardized alpha-10 ridge; general LU avoids the failing Cholesky route.

    This is sklearn's unweighted multiclass ridge objective, with its usual
    +/-1 targets and an unpenalized intercept. Only the linear solver differs.
    """
    begin = perf_counter()
    scaler = StandardScaler()
    x = scaler.fit_transform(np.asarray(train, dtype=np.float64))
    offset = x.mean(0)
    x -= offset
    classes = np.unique(labels)
    target = 2.0 * (labels[:, None] == classes) - 1.0
    intercept = target.mean(0)
    target -= intercept
    primal = x.shape[1] <= len(x)
    gram = x.T @ x if primal else x @ x.T
    gram.flat[::len(gram) + 1] += 10.0
    solution = np.linalg.solve(gram, x.T @ target if primal else target)
    coefficient = solution if primal else x.T @ solution
    intercept -= offset @ coefficient
    fit_seconds = perf_counter() - begin
    begin = perf_counter()
    prediction = classes[(scaler.transform(test) @ coefficient + intercept).argmax(1)]
    return prediction, fit_seconds, perf_counter() - begin


def self_check():
    from sklearn.linear_model import RidgeClassifier
    from sklearn.pipeline import make_pipeline

    rng = np.random.default_rng(43)
    for width in (7, 70):  # Both primal and dual solves, including dependent columns.
        x = rng.normal(size=(80, width))
        x[:, -1] = x[:, 0] + x[:, 1]
        labels = np.arange(50) % 3
        expected = make_pipeline(StandardScaler(), RidgeClassifier(alpha=10, solver="lsqr", tol=1e-12))
        expected.fit(x[:50], labels)
        actual, _, _ = ridge_predict(x[:50], labels, x[50:])
        np.testing.assert_array_equal(actual, expected.predict(x[50:]))


def run(evaluate, signals, n_train, engineered, args, metadata):
    begin = perf_counter()
    raw = _standardize(torch.as_tensor(signals[..., [6, 7, 8, 3, 4, 5]],
                                      dtype=torch.float64), n_train)
    reference, _ = coded_integration(raw, P=3, depth=2, batch_size=args.batch_size)
    reference_seconds = perf_counter() - begin
    evaluate("raw_pascal_reference", "pascal_qr_P3_depth2", reference, reference_seconds)
    evaluate("561_plus_generator_identity", "pascal_qr_P3_depth2",
             np.concatenate((engineered, reference), axis=1), reference_seconds)
    del raw

    begin = perf_counter()
    families = build_families(signals, n_train)
    pooled_hashes = {name: sha256(family["pooled"]).digest() for name, family in families.items()}
    preparation = perf_counter() - begin
    grid = [(p, depth) for p in (1, 2, 3, 4) for depth in (1, 2, 3)]

    def dimension(family, p, depth):
        return sum(sum((obs.shape[-1] * p)**k for k in range(1, depth + 1))
                   for obs in family["observations"])

    combined_grid = [(p, d) for p, d in grid
                     if sum(dimension(f, p, d) for f in families.values()) <= 7000]
    combined_parts = {key: [] for key in combined_grid}
    combined_times = dict.fromkeys(combined_grid, 0.0)
    product_parts, signature_parts = [], []
    reference_grid_seconds = 0.0
    metadata["family_settings"] = {
        "P": [1, 2, 3, 4], "depths": [1, 2, 3], "max_signature_features": 7000,
        "codes": "QR Pascal on the sequence index; P1 is ordinary up to fixed level scales",
        "integration": "observation / sequence length; independently sign each declared group, concatenate",
        "reference": "342 raw total_acc + gyro Pascal P3 QR depth2 coordinates, no 561 columns",
        "readouts": "pooled; pooled + signature; each also + raw reference; P3d2 signature-only and first-level products",
        "constant_columns": "remove using training std <= 1e-6 * max(abs(training values)), with no absolute floor",
        "combined_grid": combined_grid, "preparation_s": preparation,
        "timings": "shared all-family preparation, maximum retained depth per P/group; not additive across rows",
        "families": {
            name: {key: value for key, value in family.items()
                   if key not in ("observations", "pooled")}
            | {"pooled_features": family["pooled"].shape[1],
               "observation_shapes": [list(obs.shape[1:]) for obs in family["observations"]]}
            for name, family in families.items()
        },
    }

    def compare(name, representation, values, seconds):
        evaluate("family_" + name, representation, values, seconds)
        evaluate("family_" + name + "_plus_raw_pascal", representation,
                 np.concatenate((values, reference), axis=1), seconds + reference_seconds)

    for name, family in families.items():
        pooled = family["pooled"]
        compare(name, "pooled", pooled, preparation)
        for p in (1, 2, 3, 4):
            depths = [d for d in (1, 2, 3) if dimension(family, p, d) <= 7000]
            if not depths:
                continue
            blocks, products = [], []
            seconds = 0.0
            for observations in family["observations"]:
                values, elapsed = coded_integration(observations, P=p, depth=max(depths),
                                                    batch_size=args.batch_size)
                blocks.append(values)
                seconds += elapsed
                if p == 3:
                    first = values[:, :observations.shape[-1] * p]
                    i, j = np.triu_indices(first.shape[1])
                    products.extend((first, first[:, i] * first[:, j]))
            for depth in depths:
                signature = np.concatenate([
                    values[:, :sum((obs.shape[-1] * p)**k for k in range(1, depth + 1))]
                    for obs, values in zip(family["observations"], blocks)
                ], axis=1)
                checksum = sha256(signature).digest()
                label = f"pooled_plus_pascal_qr_P{p}_depth{depth}"
                compare(name, label, np.concatenate((pooled, signature), axis=1),
                        preparation + seconds)
                if (p, depth) in combined_parts:
                    combined_parts[p, depth].append((signature, checksum))
                    combined_times[p, depth] += seconds
                if (p, depth) == (3, 2):
                    compare(name, "pascal_qr_P3_depth2_only", signature, preparation + seconds)
                    compare(name, "pooled_plus_P3_first_products",
                            np.concatenate((pooled, *products), axis=1), preparation + seconds)
                    signature_parts.append(signature)
                    product_parts.extend(products)
                    reference_grid_seconds += seconds
            del blocks, products

    for name, family in families.items():
        if sha256(family["pooled"]).digest() != pooled_hashes[name]:
            raise RuntimeError("Pooled features changed during model fitting")
    pooled = np.concatenate([family["pooled"] for family in families.values()], axis=1)
    compare("combined", "pooled", pooled, preparation)
    for p, depth in combined_grid:
        parts = combined_parts.pop((p, depth))
        if any(sha256(values).digest() != checksum for values, checksum in parts):
            raise RuntimeError("Cached signatures changed during model fitting")
        signature = np.concatenate([values for values, _ in parts], axis=1)
        compare("combined", f"pooled_plus_pascal_qr_P{p}_depth{depth}",
                np.concatenate((pooled, signature), axis=1), preparation + combined_times[p, depth])
    compare("combined", "pascal_qr_P3_depth2_only", np.concatenate(signature_parts, axis=1),
            preparation + reference_grid_seconds)
    compare("combined", "pooled_plus_P3_first_products", np.concatenate((pooled, *product_parts), axis=1),
            preparation + reference_grid_seconds)
    # A fixed hybrid control checks whether the generic replacement also adds to 561.
    evaluate("561_plus_family_combined", "pooled", np.concatenate((engineered, pooled), axis=1), preparation)
    evaluate("561_plus_family_combined", "pooled_plus_raw_pascal",
             np.concatenate((engineered, pooled, reference), axis=1), preparation + reference_seconds)
