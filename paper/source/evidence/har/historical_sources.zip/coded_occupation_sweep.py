"""Compact QR clock-coded graph sweep with the raw/spectral base fixed."""

from itertools import combinations, product
from time import perf_counter

import numpy as np
import torch
from coded_occupation import coded_occupation_readouts
from families import _power, _with_norm, build_families
from features import _coordinates, _standardize
from generators import coded_integration, temporal_code
from moment_lifts import _cosines
from occupation_experiment import log_energy_readouts
from occupation_graph import occupation_readouts
from spectral_readouts import signature_readouts


def word_pairs(P, depth, total_degree=None):
    """Positive location degrees; constant-code moments live in calibration."""
    return tuple((r, a) for r in range(1, depth) for a in range(1, P)
                 if total_degree is None or r + a <= total_degree)


@torch.inference_mode()
def run(evaluate, signals, n_train, engineered, args, metadata):
    tick = perf_counter()
    raw = _standardize(torch.as_tensor(signals[..., [6, 7, 8, 3, 4, 5]], dtype=torch.float64), n_train)
    tensor, _ = coded_integration(raw, 3, 2, batch_size=args.batch_size)
    raw_log = _coordinates(torch.as_tensor(tensor), ("accel",) * 9 + ("gyro",) * 9)["full_logsignature"].numpy()
    families = build_families(signals, n_train)
    spectral, _ = signature_readouts(families["spectral"]["observations"], 3, 2, args.batch_size)
    base = np.concatenate((raw_log, spectral["within_channel_first_areas"]), 1)
    vectors = [obs[:, :, :3] for obs in families["moments"]["observations"]]
    vectors += [obs[:, :, :3] for obs in families["filters_delays"]["observations"][:2]]
    powers = [_power(_with_norm(vector)) for vector in vectors]
    observations = {"amplitude": [p.sqrt() for p in powers],
                    "cosine": [_cosines(*families["rotation"]["observations"][:2])],
                    "invariant": families["rotation"]["observations"]}
    base_seconds = perf_counter() - tick
    cat = lambda values: np.concatenate(list(values), 1)
    empty = np.empty((len(signals), 0))

    tick = perf_counter()
    energy = cat(log_energy_readouts(p, 1, args.batch_size)[0]["endpoint"] for p in powers)
    energy_seconds = perf_counter() - tick
    settings = {
        "base": "Fixed raw171 + spectral100: Pascal P3 QR depth2 logsignatures",
        "P": [1, 2, 3, 4, 6], "depths": [2, 3, 4], "ridge_alpha": 10.,
        "coding": "Only graph clock holds are coded, by q_a(k)/N; value coordinate starts/ends zero",
        "selected_words": "x^r t_a, r=1..depth-1; r! times logword = mean(z^r q_a)",
        "normalization": "Mean/std retained separately; nonconstant clocks applied to standardized scalar observations",
        "computation": "Exact selected graph words via fused polynomial lift and tensorsig level-one coded signature",
        "constant_clock": "P1 contributes calibration; location sweep omits a=0 to avoid duplicate/constant coordinates",
        "max_total_features": 600, "mixed_max_total_features": 429,
        "no_supplied561": True,
        "timings": "Base preparation plus shared P6/depth4 extraction; smaller readouts reuse this extraction",
        "models": {},
    }
    metadata["coded_occupation_settings"] = settings

    coded, calibrated, ordinary, seconds = {}, {}, {}, {}
    for family, groups in observations.items():
        tick = perf_counter()
        codes, stats, old_orders = [], [], []
        for obs in groups:
            # Verify reuse rather than assume different QR calls orient prefixes identically.
            maximum_code = temporal_code(obs.shape[1], 6).matrix
            for P in settings["P"]:
                torch.testing.assert_close(maximum_code[:, :P], temporal_code(obs.shape[1], P).matrix,
                                           rtol=1e-12, atol=1e-12)
            raw, _ = coded_occupation_readouts(obs, 1, 2, args.batch_size)
            mean = raw["moments"][:, :, 0, 0] / raw["code_scale"]
            center = obs - torch.as_tensor(mean)[:, None]
            central, _ = coded_occupation_readouts(center, 6, 4, args.batch_size)
            variance = np.maximum(central["moments"][:, :, 1, 0] / central["code_scale"], 0)
            sd = np.sqrt(variance)
            normalized = central["moments"] / np.maximum(sd, 1e-8)[:, :, None, None] ** np.arange(1, 4)[None, None, :, None]
            normalized = np.where((variance > 1e-12)[:, :, None, None], normalized, 0)
            skew = normalized[:, :, 2, 0] / central["code_scale"]
            codes.append(normalized)
            stats.append(np.stack((mean, sd, skew), -1))
            if family != "cosine":
                z = center / torch.as_tensor(np.maximum(sd, 1e-8))[:, None]
                z = torch.where(torch.as_tensor(variance > 1e-12)[:, None], z, 0.)
                old, _ = occupation_readouts(z, args.batch_size)
                old_orders.append(old["order_d3" if family == "amplitude" else "order_d4"])
        coded[family], calibrated[family] = cat(codes), cat(stats)
        ordinary[family] = cat(old_orders) if old_orders else empty
        seconds[family] = perf_counter() - tick

    # Explicit per-stream degree selections; never learned projections of test rows.
    pools = {
        "pool102": cat((energy, calibrated["amplitude"][:, :, :2].reshape(len(signals), -1),
                        calibrated["cosine"][:, :, :2].reshape(len(signals), -1),
                        calibrated["invariant"].reshape(len(signals), -1))),
        "pool90": cat((energy, *(calibrated[f][:, :, :2].reshape(len(signals), -1) for f in calibrated))),
        "pool66": cat((energy, calibrated["amplitude"][:, :, :2].reshape(len(signals), -1),
                       calibrated["cosine"][:, :, :2].reshape(len(signals), -1))),
        "pool82_no_energy": cat((calibrated["amplitude"][:, :, :2].reshape(len(signals), -1),
                                 calibrated["cosine"][:, :, :2].reshape(len(signals), -1),
                                 calibrated["invariant"].reshape(len(signals), -1))),
    }
    preparation = base_seconds + energy_seconds + sum(seconds.values())
    settings["extraction_s"] = {"base": base_seconds, "log_energy": energy_seconds, **seconds}
    settings["pool_descriptions"] = {
        "pool102": "logenergy20 + amplitude mean/std40 + cosine mean/std6 + invariant mean/std/skew36",
        "pool90": "pool102 without the 12 invariant skews",
        "pool66": "pool102 without all 36 invariant moment readouts",
        "pool82_no_energy": "pool102 without the 20 spectral log-energy endpoints",
    }
    evaluate("reference429", "ordinary_graph", cat((base, pools["pool102"], ordinary["amplitude"], ordinary["invariant"])), preparation)
    evaluate("no_pool", "raw_log__spectral_log", base, base_seconds)
    for name, pool in pools.items():
        evaluate("calibration", name, cat((base, pool)), preparation)

    def select(family, pairs):
        return (coded[family][:, :, [r - 1 for r, a in pairs], [a for r, a in pairs]].reshape(len(signals), -1)
                if pairs else empty)

    seen = set()

    def compare(variant, name, selections, pool="pool102", cap=600):
        key = (pool, tuple((family, tuple(selections.get(family, ()))) for family in coded))
        if key in seen:
            return
        extra = cat((pools[pool], *(select(f, selections.get(f, ())) for f in coded)))
        # Base has 20 known constant spectral columns before the shared mask.
        if 271 + extra.shape[1] > cap:
            return
        seen.add(key)
        settings["models"][variant + "/" + name] = {
            "pool": pool, "words": {f: list(selections.get(f, ())) for f in coded},
        }
        evaluate(variant, name, cat((base, extra)), preparation)

    triangle = ((1, 1), (2, 1), (1, 2))
    compare("coded_reference429", "P2_d2_amplitude__P3_d3_triangle_invariant",
            {"amplitude": ((1, 1),), "invariant": triangle})
    for P, depth in product((2, 3, 4, 6), (2, 3, 4)):
        for shape, cutoff in (("rectangle", None), ("triangle3", 3), ("triangle4", 4)):
            pairs = word_pairs(P, depth, cutoff)
            for count in (1, 2, 3):
                for families_to_code in combinations(coded, count):
                    name = f"P{P}_d{depth}_{shape}__" + "+".join(families_to_code)
                    compare("uniform_codes", name, dict.fromkeys(families_to_code, pairs))

    # Small, interpretable mixed grids target fewer than the reference's 429.
    amplitude_options = {
        "none": (), "P2d2": ((1, 1),), "P3d2": ((1, 1), (1, 2)),
        "P2d3": ((1, 1), (2, 1)), "P2d4": ((1, 1), (2, 1), (3, 1)),
    }
    invariant_options = {
        "none": (), "P2d2": ((1, 1),), "P3d2": ((1, 1), (1, 2)),
        "P2d3": ((1, 1), (2, 1)), "P2d4": ((1, 1), (2, 1), (3, 1)),
        "P3d3tri": triangle, "P3d3": word_pairs(3, 3),
        "P4d2": word_pairs(4, 2),
    }
    for pool, amplitude, invariant, cosine in product(pools, amplitude_options, invariant_options, (False, True)):
        selections = {"amplitude": amplitude_options[amplitude], "invariant": invariant_options[invariant],
                      "cosine": ((1, 1),) if cosine else ()}
        name = f"{pool}__A{amplitude}__I{invariant}__C{int(cosine)}"
        compare("compact_mixed", name, selections, pool, cap=429)
