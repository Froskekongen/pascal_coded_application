# Small pools and spectral Pascal logsignatures

**Yes: both main blocks can use Pascal logsignatures.** Raw 171 + spectral 100 +
142 generic moment readouts reaches **97.90% with 413 total features**. A smaller
102-readout version gives **97.79% with 373 features**. These differ from the
736-feature reference by one and four test errors, respectively. Reducing the
extra block to just 26 energy/cosine values does not retain this accuracy.

All rows below use tensorsig, QR Pascal P3/depth 2 for the two main blocks,
training-only scaling, fixed ridge alpha 10, and the existing official
7,352/2,947 split. None appends supplied 561 columns. The 561 reference alone is
95.72%. These are descriptive ablations on the same test split; the focused
moment comparisons followed the first results, without an independent selection
split or classifier tuning.

## Run and practical choices

```sh
../tensorsig/.venv/bin/python examples/uci_har/benchmark.py --pool-story
```

All **414 ridge fits completed in 18.01 seconds**. The 337–413 feature
models fit in about 8–11 ms and predict all 2,947 test windows in about 1–2 ms.
Their direct pooled extraction takes about 2.7 s over all 10,299 windows. The
alternative calculation through tensorsig integral endpoints takes about 4.8 s,
including every extra lift calculated in this experiment. Both timings include
shared preparation of all families and dense signature extraction before
projection; neither is an optimized standalone deployment measurement. The
largest ridge fit in the run took 0.045 s.

| Construction | Features | Accuracy | Errors |
|---|---:|---:|---:|
| Original pool 234 + raw tensor + spectral tensor | 736 | 97.93% | 61 |
| Original pool 234 + raw log + spectral tensor | 565 | 97.86% | 63 |
| Original pool 234 + raw log + spectral log | 505 | 97.90% | 62 |
| Moment readouts 142 + raw log + spectral log | 413 | 97.90% | 62 |
| Moment readouts 102 + raw log + spectral log | 373 | 97.79% | 65 |
| Moment readouts 66 + raw log + spectral log | 337 | 97.56% | 72 |
| Energy/cosine 26 + raw log + spectral log | 297 | 96.91% | 91 |

The 413-feature model is the closest small replacement: one error fewer than
565, one more than 736. The 373-feature version has roughly half the 736-feature
count, with four additional errors. The 337-feature version is a more aggressive
compromise, with eleven additional errors. Pool 142 and pool 102 are uniform
statistic families, not selected individual UCI columns.

## What remains in the pool?

Both 413 and 373 use raw log 171 and within-channel spectral log 100. Their extra
readouts are:

| Generic readout family | Pool 142 | Pool 102 |
|---|---:|---:|
| Spectral energy or log-energy, respectively |20|20|
| Spectral-amplitude mean/std |40|40|
| Spectral-amplitude skewness/kurtosis |40|0|
| Cross-triad cosine mean/std |6|6|
| Invariant-stream mean/std/skewness |36|36|
| Total |142|102|

The 20 spectral channels are xyz plus norm for body acceleration, estimated
gravity, gyroscope and acceleration/gyroscope differences. These spectral norms
follow training axis scaling and are not strictly rotation invariant.

The three cosine streams compare the body-acceleration, gravity and gyroscope
triads pairwise. The 12 invariant streams are three triad energies, three
simultaneous cross-triad dot products, and three lagged self-dot products at
each of lags 2 and 5. Applying the same mean/std/skewness recipe to each gives 36
readouts. This branch uses one uncentered training RMS per triad and is invariant
to a common orthogonal rotation. Adding the raw signature and axis spectra gives
up invariance of the complete classifier.

Both small pools remove extrema, mean absolute values, RMS summaries, lag-cosine
summaries and the simultaneous use of energy and log-energy. Neither uses
spectral bands, entropy or peak selection. Difference spectra and lagged Gram
streams remain, so this does not show that filtering or delays are unnecessary.

The leave-one-block-out results below hold the raw-log/spectral-log pair fixed:

| Construction | Features | Accuracy | Errors |
|---|---:|---:|---:|
| Full 234 pool | 505 | 97.90% | 62 |
| Remove cross-cosine mean/std (6) | 499 | 96.61% | 100 |
| Remove instantaneous Gram summaries (24) | 481 | 97.62% | 70 |
| Remove lagged Gram summaries (48) | 457 | 97.62% | 70 |
| Remove triad-energy summaries (24) | 481 | 97.90% | 62 |
| Remove spectral energy (20) | 485 | 97.86% | 63 |
| Remove log spectral energy (20) | 485 | 97.73% | 67 |
| Remove spectral amplitude std (20) | 485 | 97.66% | 69 |
| Remove spectral amplitude skew (20) | 485 | 97.66% | 69 |
| Remove spectral amplitude kurtosis (20) | 485 | 97.69% | 68 |

Cross-cosines are the strongest individual addition: removing just their six
summaries costs 38 net correct predictions. Removing either instantaneous or
lagged Gram summaries costs eight. Removing the entire 24-column triad-energy
summary changes no accuracy in this full pool, but dropping it simultaneously
with other blocks can behave differently. The smaller models are therefore
measured combinations, not sums of isolated feature-importance scores.

The same six cross-cosine readouts also matter in the original models: removing
them changes the 565-feature model from 97.86% to 96.78% (32 additional errors),
and the 736-feature model from 97.93% to 96.67% (37 additional errors). Their
complete block ablations are included in the saved results.

## Only spectral Pascal + raw Pascal, without pooling

| Construction | Features | Accuracy | Errors |
|---|---:|---:|---:|
| Raw tensor 342 + within-channel spectral tensor 160 | 502 | 94.16% | 172 |
| Raw log 171 + within-channel spectral tensor 160 | 331 | 93.86% | 181 |
| Raw tensor 342 + within-channel spectral log 100 | 442 | 93.59% | 189 |
| Raw log 171 + within-channel spectral log 100 | 271 | 93.48% | 192 |
| Raw tensor 342 + cross-channel spectral log 370 | 712 | 95.32% | 138 |
| Raw log 171 + cross-channel spectral log 370 | 541 | 94.88% | 151 |
| Raw tensor 342 + full spectral tensor 740 | 1,082 | 95.22% | 141 |
| Raw tensor 342 + full-span compact spectral tensor 550 | 892 | 95.35% | 137 |

The compact log/log pair alone reaches **93.48%**. Even the best broader
signature-only row here reaches **95.35%**. The earlier high scores depended
substantially on the extra readouts. The two main signatures complement each
other—raw tensor alone is 84.22%, compact spectral tensor alone 83.85%—but do not
replace amplitude and geometry summaries at these truncation orders.

The spectral log 100 representation has two nonconstant endpoints and three
areas per scalar spectrum, across 20 spectra. It is a genuine depth-two
logsignature readout, obtained from tensorsig's first level and antisymmetric
second level. The spectral cross-log 370 instead retains cross-channel areas
within each four-channel group. Its larger no-pool score does not make it the
best pooled model: with pool 234, compact log/log gives 97.90%, while the larger
raw-log/cross-spectral-log version gives 97.79% with 775 features.

Logsignatures retain the truncated tensor under nonlinear reconstruction.
For a linear ridge head, switching to log coordinates removes explicit
quadratic endpoint-product readouts. The score comparison is consequently about
linear representation and regularization as well as dimension, not an inherent
loss of information from taking logarithms.

## The signature-like explanation for the extra readouts

The reusable construction is **local observable transform → integration →
signature/logsignature → moment readout**. For scalar samples z, integrate the
fixed polynomial lift `(z,z²,...,zʳ)`. Its first level contains moments through
degree r; first signature and logsignature levels coincide. This is different
from embedding an already computed window feature as a constant path. The
observables are specified per time sample or frequency bin.

It also connects directly to an ordinary graph signature. With a staircase
value/clock path anchored at value zero, the word containing r value letters
then one clock letter equals `mean(zʳ)/r!`. Polynomial lifting therefore moves
selected higher-depth graph-signature readouts into level one, keeping the
feature generator small.

This gives a concrete role for each remaining family:

1. **Energy restores scale.** Normalizing spectral powers to mass one discards
   absolute power. Energy is the integral of squared signal or spectral amplitude.
   Log-energy is an optional nonlinear calibration of that endpoint.
2. **Amplitude moments describe concentration.** Low-degree frequency-location
   moments do not completely describe whether power is concentrated in a few
   bins. For nonzero spectra with bin energies e, E=sum(e), p=e/E and amplitudes a=sqrt(e),
   `mean(aʳ) = E^(r/2) * sum(p^(r/2)) / K`, where K is the bin count. Energy and
   the three concentration sums at q=1/2,3/2,2 determine amplitude moments through
   degree four. These are fixed power-observable integrals without band boundaries.
3. **Gram/cosine moments describe relative geometry.** Dot products and normalized
   dot products are invariant local observation streams. Their integrated moments
   measure energy, alignment and its variability. They involve same-time or
   selected-lag products, unlike a raw signature's general ordered cross-time
   products. Their addition has a clear complementary role.

Mean/std/skewness and kurtosis use deterministic centering, square roots and
normalization. They are **nonlinear moment readouts**, not all linear coordinates
of the original raw logsignature. Computing centered observables before
integration is a numerically stable implementation of the same moment family.
The successful 142/102 profiles were also computed via tensorsig P1 QR endpoints
in [moment_lifts.py](moment_lifts.py), reproducing their direct pooled scores and
confusion matrices.

Merely giving ridge an information-equivalent raw moment generator performs
worse than giving it appropriate normalized readouts. Every row below appends
the same raw-log171 + spectral-log100 pair:

| Construction | Features | Accuracy | Errors |
|---|---:|---:|---:|
| Energy/cosine raw moments (12) | 283 | 95.66% | 128 |
| Energy/cosine mean/std (12) | 283 | 96.37% | 107 |
| Amplitude raw moments + cosine raw moments (86) | 357 | 96.13% | 114 |
| Log energy + cosine mean/std + concentration moments (86) | 357 | 97.29% | 80 |
| Energy + cosine mean/std + amplitude mean/std (66) | 337 | 97.56% | 72 |
| Log energy + cosine mean/std + amplitude mean/std + invariant mean/std/skew (102) | 373 | 97.79% | 65 |
| Energy + cosine mean/std + amplitude mean/std/skew/kurt + invariant mean/std/skew (142) | 413 | 97.90% | 62 |

Thus the justified story includes the readout, not just the signature. The
normalized summaries are computationally cheap and generic. P3 is justified
by quadratic time/frequency-location coverage; polynomial observable degrees
three/four provide the chosen shape moments. None of these coverage arguments
proves an optimal HAR parameter choice, and the particular lags remain simple
fixed exploratory choices. Higher coded signatures of energy/cosine streams
were also tried; they did not replace the moment summaries successfully here.

## Code and checks

[pool_story.py](pool_story.py) defines the ablations;
[moment_lifts.py](moment_lifts.py) implements the integral alternatives.
[Full scores](pool_results/results.csv), [all comparisons](pool_results/RESULTS.md)
and [run metadata](pool_results/run.json) are retained separately from previous
experiments. The mathematical explanation continues in
[feature_families.md](feature_families.md#a-generic-explanation-for-the-remaining-small-readouts),
and implementation ideas remain in [tensorsig_suggestions.md](tensorsig_suggestions.md).

Self-checks cover moment identities, compatibility with the old pooled features,
rotation invariance, finite zero-input behavior and spectral concentration
identities; Ruff passes. Independent sklearn LSQR ridge fits of the 413-, 373-
and 337-feature integral models match every prediction of the closed-form ridge
implementation and reproduce the recorded direct/integral confusion matrices.
