# UCI HAR exploratory results

7,352 training / 2,947 test windows; official subject-disjoint split, fixed settings, no hyperparameter search.

Accuracy and macro F1 are percentages. Times are seconds on this machine. Extraction includes train and test, with full calculations shared by quotient readouts; do not sum extraction columns across heads or claim sparse quotient acceleration. The 561-feature extraction time is unmeasured (CSV placeholder 0); hybrid timings measure only the additional features.

## Best row per input/augmentation and head

These are descriptive test-set maxima over representations, not validation-selected models.

| Input / augmentation | Head | Representation | Features | Accuracy | Macro F1 | Extract | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|---:|
| body_mean_std | ridge | mean_std | 12 | 53.68 | 50.32 | 0.036 | 0.005 | 0.000 |
| body_mean_std | rbf_svm | mean_std | 12 | 77.57 | 77.48 | 0.036 | 0.220 | 0.298 |
| body_mean_std | random_forest | mean_std | 12 | 80.18 | 79.92 | 0.036 | 0.237 | 0.012 |
| body_direct_covariation | ridge | mean_std_covariation | 54 | 74.11 | 73.01 | 0.200 | 0.003 | 0.000 |
| body_direct_covariation | rbf_svm | mean_std_covariation | 54 | 78.79 | 79.11 | 0.200 | 0.360 | 0.394 |
| body_direct_covariation | random_forest | mean_std_covariation | 54 | 85.99 | 86.08 | 0.200 | 0.416 | 0.013 |
| total_mean_std | ridge | mean_std | 12 | 76.42 | 75.62 | 0.013 | 0.002 | 0.000 |
| total_mean_std | rbf_svm | mean_std | 12 | 81.95 | 81.29 | 0.013 | 0.074 | 0.128 |
| total_mean_std | random_forest | mean_std | 12 | 81.10 | 80.55 | 0.013 | 0.190 | 0.013 |
| total_direct_covariation | ridge | mean_std_covariation | 54 | 88.53 | 88.46 | 0.047 | 0.002 | 0.000 |
| total_direct_covariation | rbf_svm | mean_std_covariation | 54 | 89.85 | 89.72 | 0.047 | 0.099 | 0.144 |
| total_direct_covariation | random_forest | mean_std_covariation | 54 | 92.77 | 92.69 | 0.047 | 0.384 | 0.013 |
| engineered_561 | ridge | uci_features | 561 | 95.72 | 95.85 | 0.000 | 0.024 | 0.002 |
| engineered_561 | rbf_svm | uci_features | 561 | 95.49 | 95.40 | 0.000 | 0.655 | 0.805 |
| engineered_561 | random_forest | uci_features | 561 | 92.43 | 92.21 | 0.000 | 1.179 | 0.012 |
| body_time | ridge | offset_full_signature | 210 | 61.35 | 59.69 | 0.325 | 0.007 | 0.001 |
| body_time | rbf_svm | offset_full_signature | 210 | 63.15 | 60.93 | 0.325 | 0.823 | 0.931 |
| body_time | random_forest | offset_full_signature | 210 | 79.81 | 80.00 | 0.325 | 0.838 | 0.013 |
| body_basepoint | ridge | offset_full_signature | 210 | 61.42 | 59.73 | 0.327 | 0.007 | 0.001 |
| body_basepoint | rbf_svm | offset_modality_signature | 174 | 65.05 | 63.24 | 0.327 | 0.740 | 0.791 |
| body_basepoint | random_forest | offset_modality_signature | 174 | 82.35 | 82.41 | 0.327 | 0.791 | 0.012 |
| total_basepoint | ridge | offset_full_signature | 210 | 86.29 | 86.32 | 0.333 | 0.006 | 0.001 |
| total_basepoint | rbf_svm | offset_full_signature | 210 | 88.29 | 88.17 | 0.333 | 0.354 | 0.421 |
| total_basepoint | random_forest | offset_full_signature | 210 | 88.73 | 88.58 | 0.333 | 0.711 | 0.014 |
| 561_plus_total_basepoint | ridge | ordinary_full_signature | 617 | 97.05 | 97.07 | 0.068 | 0.033 | 0.002 |
| 561_plus_total_basepoint | rbf_svm | ordinary_full_signature | 617 | 96.91 | 96.93 | 0.068 | 0.732 | 0.847 |
| 561_plus_total_basepoint | random_forest | ordinary_full_signature | 617 | 92.94 | 92.97 | 0.068 | 1.192 | 0.013 |
| total_integrated | ridge | offset_full_signature | 210 | 78.89 | 78.96 | 0.352 | 0.006 | 0.001 |
| total_integrated | rbf_svm | offset_full_logsignature | 105 | 86.73 | 86.56 | 0.352 | 0.274 | 0.381 |
| total_integrated | random_forest | ordinary_full_logsignature | 28 | 82.90 | 82.49 | 0.088 | 0.342 | 0.013 |
| total_integrated_covariation | ridge | offset_full_signature | 252 | 89.14 | 89.17 | 0.383 | 0.007 | 0.001 |
| total_integrated_covariation | rbf_svm | offset_full_logsignature | 147 | 89.24 | 89.15 | 0.383 | 0.266 | 0.315 |
| total_integrated_covariation | random_forest | ordinary_modality_logsignature | 61 | 88.77 | 88.58 | 0.121 | 0.372 | 0.012 |
| total_integrated_leadlag | ridge | offset_full_logsignature | 351 | 87.00 | 87.15 | 1.351 | 0.013 | 0.001 |
| total_integrated_leadlag | rbf_svm | offset_full_logsignature | 351 | 88.39 | 88.20 | 1.351 | 0.597 | 0.675 |
| total_integrated_leadlag | random_forest | ordinary_full_logsignature | 91 | 84.66 | 84.26 | 0.392 | 0.504 | 0.013 |
| total_leadlag | ridge | offset_full_signature | 702 | 87.82 | 87.70 | 1.211 | 0.021 | 0.001 |
| total_leadlag | rbf_svm | offset_full_logsignature | 351 | 90.09 | 90.04 | 1.211 | 0.418 | 0.556 |
| total_leadlag | random_forest | offset_full_signature | 702 | 89.41 | 89.25 | 1.211 | 1.232 | 0.014 |
| 561_plus_total_leadlag | ridge | ordinary_full_logsignature | 652 | 95.96 | 96.09 | 0.365 | 0.026 | 0.002 |
| 561_plus_total_leadlag | rbf_svm | ordinary_full_logsignature | 652 | 96.88 | 96.89 | 0.365 | 0.668 | 0.801 |
| 561_plus_total_leadlag | random_forest | ordinary_full_logsignature | 652 | 93.62 | 93.67 | 0.365 | 1.189 | 0.013 |
| total_magnitude | ridge | offset_full_signature | 342 | 88.23 | 88.31 | 0.530 | 0.010 | 0.001 |
| total_magnitude | rbf_svm | offset_full_logsignature | 171 | 90.02 | 90.01 | 0.530 | 0.245 | 0.332 |
| total_magnitude | random_forest | offset_full_signature | 342 | 88.84 | 88.74 | 0.530 | 0.897 | 0.016 |
| 561_plus_total_covariation | ridge | mean_std_covariation | 615 | 95.86 | 96.01 | 0.048 | 0.029 | 0.002 |
| 561_plus_total_covariation | rbf_svm | mean_std_covariation | 615 | 96.17 | 96.15 | 0.048 | 0.649 | 0.805 |
| 561_plus_total_covariation | random_forest | mean_std_covariation | 615 | 92.47 | 92.32 | 0.048 | 1.191 | 0.014 |

## Every comparison

| Input / augmentation | Representation | Head | Features | Accuracy | Macro F1 | Fit | Predict |
|---|---|---|---:|---:|---:|---:|---:|
| body_mean_std | mean_std | ridge | 12 | 53.68 | 50.32 | 0.005 | 0.000 |
| body_mean_std | mean_std | rbf_svm | 12 | 77.57 | 77.48 | 0.220 | 0.298 |
| body_mean_std | mean_std | random_forest | 12 | 80.18 | 79.92 | 0.237 | 0.012 |
| body_direct_covariation | mean_second_moment | ridge | 27 | 57.41 | 55.32 | 0.002 | 0.000 |
| body_direct_covariation | mean_second_moment | rbf_svm | 27 | 66.03 | 64.15 | 0.273 | 0.330 |
| body_direct_covariation | mean_second_moment | random_forest | 27 | 83.85 | 83.92 | 0.327 | 0.013 |
| body_direct_covariation | mean_second_moment_roughness | ridge | 48 | 60.06 | 58.36 | 0.003 | 0.000 |
| body_direct_covariation | mean_second_moment_roughness | rbf_svm | 48 | 65.32 | 63.09 | 0.352 | 0.388 |
| body_direct_covariation | mean_second_moment_roughness | random_forest | 48 | 85.34 | 85.43 | 0.390 | 0.013 |
| body_direct_covariation | mean_std_covariation | ridge | 54 | 74.11 | 73.01 | 0.003 | 0.000 |
| body_direct_covariation | mean_std_covariation | rbf_svm | 54 | 78.79 | 79.11 | 0.360 | 0.394 |
| body_direct_covariation | mean_std_covariation | random_forest | 54 | 85.99 | 86.08 | 0.416 | 0.013 |
| total_mean_std | mean_std | ridge | 12 | 76.42 | 75.62 | 0.002 | 0.000 |
| total_mean_std | mean_std | rbf_svm | 12 | 81.95 | 81.29 | 0.074 | 0.128 |
| total_mean_std | mean_std | random_forest | 12 | 81.10 | 80.55 | 0.190 | 0.013 |
| total_direct_covariation | mean_second_moment | ridge | 27 | 72.28 | 70.08 | 0.002 | 0.000 |
| total_direct_covariation | mean_second_moment | rbf_svm | 27 | 86.70 | 86.39 | 0.094 | 0.122 |
| total_direct_covariation | mean_second_moment | random_forest | 27 | 84.02 | 83.75 | 0.279 | 0.012 |
| total_direct_covariation | mean_second_moment_roughness | ridge | 48 | 82.93 | 82.87 | 0.002 | 0.000 |
| total_direct_covariation | mean_second_moment_roughness | rbf_svm | 48 | 86.94 | 86.78 | 0.115 | 0.147 |
| total_direct_covariation | mean_second_moment_roughness | random_forest | 48 | 87.07 | 86.79 | 0.324 | 0.013 |
| total_direct_covariation | mean_std_covariation | ridge | 54 | 88.53 | 88.46 | 0.002 | 0.000 |
| total_direct_covariation | mean_std_covariation | rbf_svm | 54 | 89.85 | 89.72 | 0.099 | 0.144 |
| total_direct_covariation | mean_std_covariation | random_forest | 54 | 92.77 | 92.69 | 0.384 | 0.013 |
| engineered_561 | uci_features | ridge | 561 | 95.72 | 95.85 | 0.024 | 0.002 |
| engineered_561 | uci_features | rbf_svm | 561 | 95.49 | 95.40 | 0.655 | 0.805 |
| engineered_561 | uci_features | random_forest | 561 | 92.43 | 92.21 | 1.179 | 0.012 |
| body_time | ordinary_full_signature | ridge | 56 | 55.99 | 51.81 | 0.003 | 0.000 |
| body_time | ordinary_full_signature | rbf_svm | 56 | 60.30 | 58.04 | 0.370 | 0.470 |
| body_time | ordinary_full_signature | random_forest | 56 | 78.69 | 78.97 | 0.435 | 0.013 |
| body_time | ordinary_full_logsignature | ridge | 28 | 53.78 | 48.94 | 0.002 | 0.000 |
| body_time | ordinary_full_logsignature | rbf_svm | 28 | 60.30 | 58.17 | 0.303 | 0.389 |
| body_time | ordinary_full_logsignature | random_forest | 28 | 79.30 | 79.57 | 0.319 | 0.013 |
| body_time | ordinary_modality_logsignature | ridge | 19 | 47.81 | 42.51 | 0.002 | 0.000 |
| body_time | ordinary_modality_logsignature | rbf_svm | 19 | 55.99 | 53.54 | 0.301 | 0.388 |
| body_time | ordinary_modality_logsignature | random_forest | 19 | 69.09 | 69.41 | 0.291 | 0.013 |
| body_time | ordinary_modality_signature | ridge | 47 | 49.92 | 47.60 | 0.002 | 0.000 |
| body_time | ordinary_modality_signature | rbf_svm | 47 | 54.94 | 52.27 | 0.408 | 0.495 |
| body_time | ordinary_modality_signature | random_forest | 47 | 68.92 | 69.25 | 0.397 | 0.012 |
| body_time | offset_full_signature | ridge | 210 | 61.35 | 59.69 | 0.007 | 0.001 |
| body_time | offset_full_signature | rbf_svm | 210 | 63.15 | 60.93 | 0.823 | 0.931 |
| body_time | offset_full_signature | random_forest | 210 | 79.81 | 80.00 | 0.838 | 0.013 |
| body_time | offset_full_logsignature | ridge | 105 | 56.77 | 54.68 | 0.004 | 0.000 |
| body_time | offset_full_logsignature | rbf_svm | 105 | 60.94 | 58.71 | 0.554 | 0.803 |
| body_time | offset_full_logsignature | random_forest | 105 | 79.44 | 79.67 | 0.595 | 0.013 |
| body_time | offset_modality_logsignature | ridge | 69 | 52.80 | 50.20 | 0.003 | 0.000 |
| body_time | offset_modality_logsignature | rbf_svm | 69 | 59.01 | 56.59 | 0.416 | 0.582 |
| body_time | offset_modality_logsignature | random_forest | 69 | 72.89 | 73.06 | 0.506 | 0.013 |
| body_time | offset_modality_signature | ridge | 174 | 56.80 | 54.99 | 0.005 | 0.000 |
| body_time | offset_modality_signature | rbf_svm | 174 | 61.93 | 59.36 | 0.773 | 0.850 |
| body_time | offset_modality_signature | random_forest | 174 | 76.08 | 76.17 | 0.779 | 0.013 |
| body_basepoint | ordinary_full_signature | ridge | 56 | 54.16 | 54.04 | 0.003 | 0.000 |
| body_basepoint | ordinary_full_signature | rbf_svm | 56 | 63.59 | 61.43 | 0.379 | 0.442 |
| body_basepoint | ordinary_full_signature | random_forest | 56 | 80.22 | 80.44 | 0.428 | 0.013 |
| body_basepoint | ordinary_full_logsignature | ridge | 28 | 53.21 | 53.12 | 0.002 | 0.000 |
| body_basepoint | ordinary_full_logsignature | rbf_svm | 28 | 61.59 | 58.78 | 0.281 | 0.379 |
| body_basepoint | ordinary_full_logsignature | random_forest | 28 | 79.47 | 79.72 | 0.315 | 0.013 |
| body_basepoint | ordinary_modality_logsignature | ridge | 19 | 48.76 | 48.29 | 0.002 | 0.000 |
| body_basepoint | ordinary_modality_logsignature | rbf_svm | 19 | 57.89 | 54.96 | 0.283 | 0.367 |
| body_basepoint | ordinary_modality_logsignature | random_forest | 19 | 69.83 | 70.09 | 0.290 | 0.013 |
| body_basepoint | ordinary_modality_signature | ridge | 47 | 50.76 | 50.52 | 0.002 | 0.000 |
| body_basepoint | ordinary_modality_signature | rbf_svm | 47 | 60.64 | 58.18 | 0.379 | 0.458 |
| body_basepoint | ordinary_modality_signature | random_forest | 47 | 74.92 | 75.11 | 0.410 | 0.011 |
| body_basepoint | offset_full_signature | ridge | 210 | 61.42 | 59.73 | 0.007 | 0.001 |
| body_basepoint | offset_full_signature | rbf_svm | 210 | 65.02 | 63.19 | 0.856 | 0.892 |
| body_basepoint | offset_full_signature | random_forest | 210 | 81.54 | 81.77 | 0.798 | 0.013 |
| body_basepoint | offset_full_logsignature | ridge | 105 | 59.08 | 57.67 | 0.004 | 0.000 |
| body_basepoint | offset_full_logsignature | rbf_svm | 105 | 62.74 | 60.06 | 0.537 | 0.743 |
| body_basepoint | offset_full_logsignature | random_forest | 105 | 80.39 | 80.66 | 0.590 | 0.013 |
| body_basepoint | offset_modality_logsignature | ridge | 69 | 54.22 | 52.70 | 0.003 | 0.000 |
| body_basepoint | offset_modality_logsignature | rbf_svm | 69 | 61.86 | 59.21 | 0.418 | 0.547 |
| body_basepoint | offset_modality_logsignature | random_forest | 69 | 76.08 | 76.07 | 0.490 | 0.013 |
| body_basepoint | offset_modality_signature | ridge | 174 | 56.77 | 54.95 | 0.005 | 0.000 |
| body_basepoint | offset_modality_signature | rbf_svm | 174 | 65.05 | 63.24 | 0.740 | 0.791 |
| body_basepoint | offset_modality_signature | random_forest | 174 | 82.35 | 82.41 | 0.791 | 0.012 |
| total_basepoint | ordinary_full_signature | ridge | 56 | 75.57 | 75.49 | 0.003 | 0.000 |
| total_basepoint | ordinary_full_signature | rbf_svm | 56 | 87.44 | 87.31 | 0.127 | 0.182 |
| total_basepoint | ordinary_full_signature | random_forest | 56 | 87.92 | 87.83 | 0.364 | 0.013 |
| 561_plus_total_basepoint | ordinary_full_signature | ridge | 617 | 97.05 | 97.07 | 0.033 | 0.002 |
| 561_plus_total_basepoint | ordinary_full_signature | rbf_svm | 617 | 96.91 | 96.93 | 0.732 | 0.847 |
| 561_plus_total_basepoint | ordinary_full_signature | random_forest | 617 | 92.94 | 92.97 | 1.192 | 0.013 |
| total_basepoint | ordinary_full_logsignature | ridge | 28 | 76.86 | 76.76 | 0.002 | 0.000 |
| total_basepoint | ordinary_full_logsignature | rbf_svm | 28 | 87.11 | 86.99 | 0.095 | 0.153 |
| total_basepoint | ordinary_full_logsignature | random_forest | 28 | 87.51 | 87.33 | 0.274 | 0.013 |
| total_basepoint | ordinary_modality_logsignature | ridge | 19 | 77.30 | 77.12 | 0.002 | 0.000 |
| total_basepoint | ordinary_modality_logsignature | rbf_svm | 19 | 83.85 | 83.60 | 0.101 | 0.146 |
| total_basepoint | ordinary_modality_logsignature | random_forest | 19 | 82.25 | 81.99 | 0.241 | 0.012 |
| total_basepoint | ordinary_modality_signature | ridge | 47 | 75.67 | 75.71 | 0.003 | 0.000 |
| total_basepoint | ordinary_modality_signature | rbf_svm | 47 | 84.32 | 84.07 | 0.143 | 0.200 |
| total_basepoint | ordinary_modality_signature | random_forest | 47 | 84.05 | 83.86 | 0.337 | 0.013 |
| total_basepoint | offset_full_signature | ridge | 210 | 86.29 | 86.32 | 0.006 | 0.001 |
| total_basepoint | offset_full_signature | rbf_svm | 210 | 88.29 | 88.17 | 0.354 | 0.421 |
| total_basepoint | offset_full_signature | random_forest | 210 | 88.73 | 88.58 | 0.711 | 0.014 |
| 561_plus_total_basepoint | offset_full_signature | ridge | 771 | 97.01 | 97.04 | 0.035 | 0.002 |
| 561_plus_total_basepoint | offset_full_signature | rbf_svm | 771 | 96.64 | 96.64 | 0.916 | 1.058 |
| 561_plus_total_basepoint | offset_full_signature | random_forest | 771 | 92.57 | 92.56 | 1.370 | 0.014 |
| total_basepoint | offset_full_logsignature | ridge | 105 | 82.97 | 82.91 | 0.004 | 0.000 |
| total_basepoint | offset_full_logsignature | rbf_svm | 105 | 88.12 | 88.03 | 0.180 | 0.315 |
| total_basepoint | offset_full_logsignature | random_forest | 105 | 87.14 | 86.91 | 0.534 | 0.013 |
| total_basepoint | offset_modality_logsignature | ridge | 69 | 79.27 | 79.21 | 0.004 | 0.000 |
| total_basepoint | offset_modality_logsignature | rbf_svm | 69 | 86.94 | 86.78 | 0.161 | 0.248 |
| total_basepoint | offset_modality_logsignature | random_forest | 69 | 83.24 | 82.98 | 0.435 | 0.013 |
| total_basepoint | offset_modality_signature | ridge | 174 | 83.34 | 83.30 | 0.006 | 0.001 |
| total_basepoint | offset_modality_signature | rbf_svm | 174 | 87.48 | 87.30 | 0.318 | 0.393 |
| total_basepoint | offset_modality_signature | random_forest | 174 | 86.73 | 86.55 | 0.684 | 0.012 |
| total_integrated | ordinary_full_signature | ridge | 56 | 68.54 | 67.01 | 0.003 | 0.000 |
| total_integrated | ordinary_full_signature | rbf_svm | 56 | 81.34 | 80.91 | 0.208 | 0.244 |
| total_integrated | ordinary_full_signature | random_forest | 56 | 77.71 | 77.11 | 0.403 | 0.012 |
| total_integrated | ordinary_full_logsignature | ridge | 28 | 66.78 | 65.19 | 0.002 | 0.000 |
| total_integrated | ordinary_full_logsignature | rbf_svm | 28 | 86.22 | 86.04 | 0.178 | 0.194 |
| total_integrated | ordinary_full_logsignature | random_forest | 28 | 82.90 | 82.49 | 0.342 | 0.013 |
| total_integrated | ordinary_modality_logsignature | ridge | 19 | 63.15 | 60.43 | 0.002 | 0.000 |
| total_integrated | ordinary_modality_logsignature | rbf_svm | 19 | 85.61 | 85.39 | 0.171 | 0.193 |
| total_integrated | ordinary_modality_logsignature | random_forest | 19 | 80.62 | 80.16 | 0.295 | 0.012 |
| total_integrated | ordinary_modality_signature | ridge | 47 | 64.37 | 61.65 | 0.003 | 0.000 |
| total_integrated | ordinary_modality_signature | rbf_svm | 47 | 75.84 | 75.08 | 0.218 | 0.288 |
| total_integrated | ordinary_modality_signature | random_forest | 47 | 76.52 | 75.86 | 0.353 | 0.013 |
| total_integrated | offset_full_signature | ridge | 210 | 78.89 | 78.96 | 0.006 | 0.001 |
| total_integrated | offset_full_signature | rbf_svm | 210 | 83.98 | 83.68 | 0.410 | 0.475 |
| total_integrated | offset_full_signature | random_forest | 210 | 80.69 | 80.18 | 0.772 | 0.027 |
| total_integrated | offset_full_logsignature | ridge | 105 | 73.43 | 73.23 | 0.006 | 0.001 |
| total_integrated | offset_full_logsignature | rbf_svm | 105 | 86.73 | 86.56 | 0.274 | 0.381 |
| total_integrated | offset_full_logsignature | random_forest | 105 | 81.98 | 81.52 | 0.583 | 0.013 |
| total_integrated | offset_modality_logsignature | ridge | 69 | 65.29 | 63.43 | 0.003 | 0.000 |
| total_integrated | offset_modality_logsignature | rbf_svm | 69 | 85.75 | 85.58 | 0.198 | 0.267 |
| total_integrated | offset_modality_logsignature | random_forest | 69 | 81.20 | 80.71 | 0.466 | 0.013 |
| total_integrated | offset_modality_signature | ridge | 174 | 69.32 | 67.54 | 0.005 | 0.000 |
| total_integrated | offset_modality_signature | rbf_svm | 174 | 78.76 | 78.33 | 0.379 | 0.422 |
| total_integrated | offset_modality_signature | random_forest | 174 | 79.78 | 79.24 | 0.661 | 0.014 |
| total_integrated_covariation | ordinary_full_signature | ridge | 98 | 87.14 | 87.03 | 0.004 | 0.000 |
| total_integrated_covariation | ordinary_full_signature | rbf_svm | 98 | 88.16 | 88.02 | 0.175 | 0.263 |
| total_integrated_covariation | ordinary_full_signature | random_forest | 98 | 86.63 | 86.38 | 0.470 | 0.013 |
| total_integrated_covariation | ordinary_full_logsignature | ridge | 70 | 83.47 | 83.44 | 0.003 | 0.000 |
| total_integrated_covariation | ordinary_full_logsignature | rbf_svm | 70 | 89.21 | 89.13 | 0.175 | 0.238 |
| total_integrated_covariation | ordinary_full_logsignature | random_forest | 70 | 88.36 | 88.14 | 0.453 | 0.012 |
| total_integrated_covariation | ordinary_modality_logsignature | ridge | 61 | 82.90 | 82.87 | 0.003 | 0.000 |
| total_integrated_covariation | ordinary_modality_logsignature | rbf_svm | 61 | 88.56 | 88.46 | 0.156 | 0.198 |
| total_integrated_covariation | ordinary_modality_logsignature | random_forest | 61 | 88.77 | 88.58 | 0.372 | 0.012 |
| total_integrated_covariation | ordinary_modality_signature | ridge | 89 | 86.77 | 86.70 | 0.003 | 0.000 |
| total_integrated_covariation | ordinary_modality_signature | rbf_svm | 89 | 87.99 | 87.85 | 0.159 | 0.220 |
| total_integrated_covariation | ordinary_modality_signature | random_forest | 89 | 86.53 | 86.27 | 0.455 | 0.013 |
| total_integrated_covariation | offset_full_signature | ridge | 252 | 89.14 | 89.17 | 0.007 | 0.001 |
| total_integrated_covariation | offset_full_signature | rbf_svm | 252 | 88.33 | 88.12 | 0.336 | 0.398 |
| total_integrated_covariation | offset_full_signature | random_forest | 252 | 85.85 | 85.55 | 0.736 | 0.014 |
| total_integrated_covariation | offset_full_logsignature | ridge | 147 | 87.99 | 87.98 | 0.005 | 0.000 |
| total_integrated_covariation | offset_full_logsignature | rbf_svm | 147 | 89.24 | 89.15 | 0.266 | 0.315 |
| total_integrated_covariation | offset_full_logsignature | random_forest | 147 | 87.89 | 87.59 | 0.613 | 0.013 |
| total_integrated_covariation | offset_modality_logsignature | ridge | 111 | 84.83 | 84.83 | 0.004 | 0.000 |
| total_integrated_covariation | offset_modality_logsignature | rbf_svm | 111 | 88.63 | 88.53 | 0.202 | 0.317 |
| total_integrated_covariation | offset_modality_logsignature | random_forest | 111 | 87.38 | 87.12 | 0.503 | 0.013 |
| total_integrated_covariation | offset_modality_signature | ridge | 216 | 87.75 | 87.73 | 0.006 | 0.001 |
| total_integrated_covariation | offset_modality_signature | rbf_svm | 216 | 87.89 | 87.65 | 0.282 | 0.327 |
| total_integrated_covariation | offset_modality_signature | random_forest | 216 | 85.31 | 84.99 | 0.671 | 0.012 |
| total_integrated_leadlag | ordinary_full_signature | ridge | 182 | 72.65 | 72.21 | 0.006 | 0.001 |
| total_integrated_leadlag | ordinary_full_signature | rbf_svm | 182 | 83.14 | 82.69 | 0.400 | 0.401 |
| total_integrated_leadlag | ordinary_full_signature | random_forest | 182 | 80.12 | 79.57 | 0.689 | 0.013 |
| total_integrated_leadlag | ordinary_full_logsignature | ridge | 91 | 73.16 | 72.46 | 0.003 | 0.000 |
| total_integrated_leadlag | ordinary_full_logsignature | rbf_svm | 91 | 87.92 | 87.74 | 0.212 | 0.295 |
| total_integrated_leadlag | ordinary_full_logsignature | random_forest | 91 | 84.66 | 84.26 | 0.504 | 0.013 |
| total_integrated_leadlag | ordinary_modality_logsignature | ridge | 55 | 67.09 | 64.63 | 0.003 | 0.000 |
| total_integrated_leadlag | ordinary_modality_logsignature | rbf_svm | 55 | 88.09 | 87.92 | 0.164 | 0.216 |
| total_integrated_leadlag | ordinary_modality_logsignature | random_forest | 55 | 81.40 | 80.93 | 0.396 | 0.014 |
| total_integrated_leadlag | ordinary_modality_signature | ridge | 146 | 67.63 | 66.23 | 0.005 | 0.000 |
| total_integrated_leadlag | ordinary_modality_signature | rbf_svm | 146 | 80.35 | 79.80 | 0.337 | 0.381 |
| total_integrated_leadlag | ordinary_modality_signature | random_forest | 146 | 77.67 | 77.02 | 0.637 | 0.012 |
| total_integrated_leadlag | offset_full_signature | ridge | 702 | 84.39 | 84.68 | 0.023 | 0.001 |
| total_integrated_leadlag | offset_full_signature | rbf_svm | 702 | 84.53 | 84.19 | 1.133 | 1.253 |
| total_integrated_leadlag | offset_full_signature | random_forest | 702 | 82.46 | 81.95 | 1.387 | 0.015 |
| total_integrated_leadlag | offset_full_logsignature | ridge | 351 | 87.00 | 87.15 | 0.013 | 0.001 |
| total_integrated_leadlag | offset_full_logsignature | rbf_svm | 351 | 88.39 | 88.20 | 0.597 | 0.675 |
| total_integrated_leadlag | offset_full_logsignature | random_forest | 351 | 83.03 | 82.56 | 0.934 | 0.013 |
| total_integrated_leadlag | offset_modality_logsignature | ridge | 207 | 78.11 | 77.70 | 0.006 | 0.001 |
| total_integrated_leadlag | offset_modality_logsignature | rbf_svm | 207 | 87.68 | 87.56 | 0.329 | 0.420 |
| total_integrated_leadlag | offset_modality_logsignature | random_forest | 207 | 81.13 | 80.61 | 0.708 | 0.012 |
| total_integrated_leadlag | offset_modality_signature | ridge | 558 | 75.98 | 75.89 | 0.017 | 0.001 |
| total_integrated_leadlag | offset_modality_signature | rbf_svm | 558 | 82.46 | 82.05 | 0.945 | 1.066 |
| total_integrated_leadlag | offset_modality_signature | random_forest | 558 | 81.74 | 81.25 | 1.135 | 0.014 |
| total_leadlag | ordinary_full_signature | ridge | 182 | 85.00 | 84.58 | 0.006 | 0.001 |
| total_leadlag | ordinary_full_signature | rbf_svm | 182 | 89.48 | 89.41 | 0.226 | 0.301 |
| total_leadlag | ordinary_full_signature | random_forest | 182 | 88.60 | 88.49 | 0.581 | 0.012 |
| total_leadlag | ordinary_full_logsignature | ridge | 91 | 84.87 | 84.55 | 0.003 | 0.000 |
| total_leadlag | ordinary_full_logsignature | rbf_svm | 91 | 89.79 | 89.75 | 0.139 | 0.223 |
| total_leadlag | ordinary_full_logsignature | random_forest | 91 | 87.51 | 87.33 | 0.446 | 0.013 |
| 561_plus_total_leadlag | ordinary_full_logsignature | ridge | 652 | 95.96 | 96.09 | 0.026 | 0.002 |
| 561_plus_total_leadlag | ordinary_full_logsignature | rbf_svm | 652 | 96.88 | 96.89 | 0.668 | 0.801 |
| 561_plus_total_leadlag | ordinary_full_logsignature | random_forest | 652 | 93.62 | 93.67 | 1.189 | 0.013 |
| total_leadlag | ordinary_modality_logsignature | ridge | 55 | 80.08 | 79.76 | 0.003 | 0.000 |
| total_leadlag | ordinary_modality_logsignature | rbf_svm | 55 | 86.97 | 86.83 | 0.112 | 0.171 |
| total_leadlag | ordinary_modality_logsignature | random_forest | 55 | 84.83 | 84.64 | 0.339 | 0.012 |
| total_leadlag | ordinary_modality_signature | ridge | 146 | 80.18 | 79.86 | 0.004 | 0.000 |
| total_leadlag | ordinary_modality_signature | rbf_svm | 146 | 86.53 | 86.32 | 0.231 | 0.297 |
| total_leadlag | ordinary_modality_signature | random_forest | 146 | 85.78 | 85.64 | 0.547 | 0.013 |
| total_leadlag | offset_full_signature | ridge | 702 | 87.82 | 87.70 | 0.021 | 0.001 |
| total_leadlag | offset_full_signature | rbf_svm | 702 | 89.68 | 89.61 | 0.840 | 1.076 |
| total_leadlag | offset_full_signature | random_forest | 702 | 89.41 | 89.25 | 1.232 | 0.014 |
| total_leadlag | offset_full_logsignature | ridge | 351 | 85.78 | 85.56 | 0.010 | 0.001 |
| total_leadlag | offset_full_logsignature | rbf_svm | 351 | 90.09 | 90.04 | 0.418 | 0.556 |
| total_leadlag | offset_full_logsignature | random_forest | 351 | 88.70 | 88.53 | 0.869 | 0.013 |
| 561_plus_total_leadlag | offset_full_logsignature | ridge | 912 | 95.86 | 95.97 | 0.040 | 0.003 |
| 561_plus_total_leadlag | offset_full_logsignature | rbf_svm | 912 | 96.03 | 95.99 | 1.070 | 2.957 |
| 561_plus_total_leadlag | offset_full_logsignature | random_forest | 912 | 92.09 | 92.08 | 1.427 | 0.013 |
| total_leadlag | offset_modality_logsignature | ridge | 207 | 84.90 | 84.81 | 0.006 | 0.001 |
| total_leadlag | offset_modality_logsignature | rbf_svm | 207 | 88.43 | 88.32 | 0.266 | 0.371 |
| total_leadlag | offset_modality_logsignature | random_forest | 207 | 86.97 | 86.78 | 0.674 | 0.012 |
| total_leadlag | offset_modality_signature | ridge | 558 | 86.87 | 86.77 | 0.016 | 0.001 |
| total_leadlag | offset_modality_signature | rbf_svm | 558 | 88.26 | 88.10 | 0.773 | 0.957 |
| total_leadlag | offset_modality_signature | random_forest | 558 | 88.16 | 88.03 | 1.116 | 0.016 |
| total_magnitude | ordinary_full_signature | ridge | 90 | 83.68 | 83.65 | 0.004 | 0.000 |
| total_magnitude | ordinary_full_signature | rbf_svm | 90 | 89.31 | 89.28 | 0.157 | 0.242 |
| total_magnitude | ordinary_full_signature | random_forest | 90 | 88.29 | 88.31 | 0.442 | 0.016 |
| total_magnitude | ordinary_full_logsignature | ridge | 45 | 82.90 | 82.94 | 0.002 | 0.000 |
| total_magnitude | ordinary_full_logsignature | rbf_svm | 45 | 89.45 | 89.45 | 0.106 | 0.164 |
| total_magnitude | ordinary_full_logsignature | random_forest | 45 | 88.16 | 88.19 | 0.327 | 0.016 |
| total_magnitude | ordinary_modality_logsignature | ridge | 29 | 80.52 | 80.34 | 0.002 | 0.000 |
| total_magnitude | ordinary_modality_logsignature | rbf_svm | 29 | 84.70 | 84.48 | 0.097 | 0.157 |
| total_magnitude | ordinary_modality_logsignature | random_forest | 29 | 84.59 | 84.55 | 0.281 | 0.013 |
| total_magnitude | ordinary_modality_signature | ridge | 74 | 80.49 | 80.41 | 0.003 | 0.000 |
| total_magnitude | ordinary_modality_signature | rbf_svm | 74 | 84.87 | 84.61 | 0.160 | 0.241 |
| total_magnitude | ordinary_modality_signature | random_forest | 74 | 85.21 | 85.14 | 0.409 | 0.014 |
| total_magnitude | offset_full_signature | ridge | 342 | 88.23 | 88.31 | 0.010 | 0.001 |
| total_magnitude | offset_full_signature | rbf_svm | 342 | 89.82 | 89.80 | 0.491 | 0.589 |
| total_magnitude | offset_full_signature | random_forest | 342 | 88.84 | 88.74 | 0.897 | 0.016 |
| total_magnitude | offset_full_logsignature | ridge | 171 | 85.54 | 85.60 | 0.005 | 0.000 |
| total_magnitude | offset_full_logsignature | rbf_svm | 171 | 90.02 | 90.01 | 0.245 | 0.332 |
| total_magnitude | offset_full_logsignature | random_forest | 171 | 87.78 | 87.81 | 0.674 | 0.016 |
| total_magnitude | offset_modality_logsignature | ridge | 107 | 83.75 | 83.74 | 0.004 | 0.000 |
| total_magnitude | offset_modality_logsignature | rbf_svm | 107 | 86.77 | 86.61 | 0.193 | 0.326 |
| total_magnitude | offset_modality_logsignature | random_forest | 107 | 85.00 | 85.01 | 0.521 | 0.016 |
| total_magnitude | offset_modality_signature | ridge | 278 | 86.73 | 86.91 | 0.008 | 0.001 |
| total_magnitude | offset_modality_signature | rbf_svm | 278 | 87.38 | 87.18 | 0.492 | 0.546 |
| total_magnitude | offset_modality_signature | random_forest | 278 | 87.31 | 87.20 | 0.820 | 0.016 |
| 561_plus_total_covariation | mean_std_covariation | ridge | 615 | 95.86 | 96.01 | 0.029 | 0.002 |
| 561_plus_total_covariation | mean_std_covariation | rbf_svm | 615 | 96.17 | 96.15 | 0.649 | 0.805 |
| 561_plus_total_covariation | mean_std_covariation | random_forest | 615 | 92.47 | 92.32 | 1.191 | 0.014 |

## Adding features to the 561 features

Corrected and lost predictions compare the hybrid with the same head on the 561 features alone. They are descriptive counts on this test split, not significance tests.

| Hybrid / representation / head | Corrected errors | Introduced errors |
|---|---:|---:|
| 561_plus_total_basepoint/ordinary_full_signature/ridge | 59 | 20 |
| 561_plus_total_basepoint/ordinary_full_signature/rbf_svm | 47 | 5 |
| 561_plus_total_basepoint/ordinary_full_signature/random_forest | 74 | 59 |
| 561_plus_total_basepoint/offset_full_signature/ridge | 61 | 23 |
| 561_plus_total_basepoint/offset_full_signature/rbf_svm | 53 | 19 |
| 561_plus_total_basepoint/offset_full_signature/random_forest | 92 | 88 |
| 561_plus_total_leadlag/ordinary_full_logsignature/ridge | 27 | 20 |
| 561_plus_total_leadlag/ordinary_full_logsignature/rbf_svm | 52 | 11 |
| 561_plus_total_leadlag/ordinary_full_logsignature/random_forest | 97 | 62 |
| 561_plus_total_leadlag/offset_full_logsignature/ridge | 29 | 25 |
| 561_plus_total_leadlag/offset_full_logsignature/rbf_svm | 57 | 41 |
| 561_plus_total_leadlag/offset_full_logsignature/random_forest | 96 | 106 |
| 561_plus_total_covariation/mean_std_covariation/ridge | 23 | 19 |
| 561_plus_total_covariation/mean_std_covariation/rbf_svm | 35 | 15 |
| 561_plus_total_covariation/mean_std_covariation/random_forest | 47 | 46 |
